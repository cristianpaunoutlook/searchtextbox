﻿using Application.Interfaces.Export;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Export
{
    public class ExportAsExcel<T> : ExportBase<T>, IExportAsExcel<T>
    {
        const int FONT_SIZE = 12;
        public byte[] Export(string title, IList<T> listToExport)
        {
            if (listToExport == null || listToExport.Count == 0)
                return null;

            byte[] fileContents;

            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add(title);

                BuildHeader(listToExport, worksheet);
                BuildContent(listToExport, worksheet);

                fileContents = package.GetAsByteArray();
            }

            return fileContents;
        }

        private void BuildHeader(IList<T> listForReport, ExcelWorksheet worksheet)
        {
            var firstRow = listForReport.First();
            var properties = firstRow.GetType().GetProperties();
            for (var i = 0; i < properties.Count(); i++)
            {
                worksheet.Cells[1, i + 1].Value = GetColumnName(properties[i]);
                worksheet.Cells[1, i + 1].Style.Font.Size = FONT_SIZE;
                worksheet.Cells[1, i + 1].Style.Font.Name = "ING Me";
                worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                worksheet.Cells[1, i + 1].Style.Font.Color.SetColor(System.Drawing.Color.White);
                worksheet.Cells[1, i + 1].Style.Border.Top.Style = ExcelBorderStyle.Hair;
                worksheet.Cells[1, i + 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                worksheet.Cells[1, i + 1].Style.Fill.BackgroundColor.SetColor(1, 255, 98, 0);
            }
            worksheet.Cells.AutoFitColumns();
        }

        private void BuildContent(IList<T> listForReport, ExcelWorksheet worksheet)
        {
            for (var i = 0; i < listForReport.Count(); i++)
            {
                BuildRow(listForReport[i], worksheet, i+2);
            }
            worksheet.Cells.AutoFitColumns();
        }
        
        private void BuildRow(T rowData, ExcelWorksheet worksheet, int currentRow)
        {
            var properties = rowData.GetType().GetProperties();
            for (int i = 0; i < properties.Count(); i++)
            {
                worksheet.Cells[currentRow, i + 1].Value = FormatColumn(rowData, properties[i]);
                worksheet.Cells[currentRow, i + 1].Style.Font.Name = "ING Me";
                worksheet.Cells[currentRow, i + 1].Style.Font.Size = FONT_SIZE;
                worksheet.Cells[currentRow, i + 1].Style.Border.Top.Style = ExcelBorderStyle.Hair;

                if (currentRow % 2 == 1)
                {
                    worksheet.Cells[currentRow, i + 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    worksheet.Cells[currentRow, i + 1].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
                }
            }
        }
    }
}