using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ProductDetailsDTO
    {
        public int Id { get; set; }

        public string ProductType { get; set; }

        public string ShortName { get; set; }

        public string Name { get; set; }

        public int ExpenseAccountId { get; set; }

        public string ExpenseAccountName { get; set; }

        public long ExpenseAccountNo { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime UpdatedDate { get; set; }

        public string ApprovedRejectedBy { get; set; }

        public DateTime? ApproveRejectDate { get; set; }

        public short StatusId { get; set; }

        public short DisplayOrder { get; set; }

        public string Status { get; set; }

    }
}