﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class StatusExportFilterDTO
    {
        public int MonthId { get; set; }
        public string MonthName { get; set; }
    }
}
