﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ExpenseAccountListDTO
    {
        public string Name { get; set; }
        public long Number { get; set; }
    }
}
