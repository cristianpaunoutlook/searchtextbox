﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ImportOfficesFileDTO
    {
        public int NoOfficesUpdated { get; set; }
        public List<string> Messages { get; set; } = new List<string>();
    }
}
