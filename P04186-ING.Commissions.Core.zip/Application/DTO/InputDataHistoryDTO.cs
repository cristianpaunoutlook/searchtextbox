﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.DTO
{
    public class InputDataHistoryDTO
    {
        public string TableName { get; set; }
        public string ShortDescription { get; set; }
        public DateTime? Date { get; set; }
        public string TableStatus { get; set; }
        public int? NoOfRecords { get; set; }

    }
}
