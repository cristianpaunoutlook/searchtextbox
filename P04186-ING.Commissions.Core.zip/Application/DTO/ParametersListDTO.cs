﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.DTO
{
    public class ParametersListDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public string OldValue { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string ApprovedRejectedBy { get; set; }
        public DateTime? ApprovedRejectedDate { get; set; }
        public string RejectReason { get; set; }
        public short StatusId { get; set; }
        public string StatusName { get; set; }
        public byte DisplayOrder { get; set; }
        public int TableId { get; set; }
        public string TableName { get; set; }
    }
}
