﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.DTO
{
    public class ParametersPageListsDTO
    {
        public IEnumerable<ObjectStatus> StatusList { get; set; }
        public IEnumerable<TableDTO> TablesList { get; set; }
    }
}
