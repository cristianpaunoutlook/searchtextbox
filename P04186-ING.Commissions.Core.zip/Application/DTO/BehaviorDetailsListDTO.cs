﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class BehaviorDetailsListDTO
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        public long ExpenseAccountNo { get; set; }
        public string ExpenseAccountShortName { get; set; }
        public int CommissionTableId { get; set; }
        public string CommissionTable { get; set; }
        public string CommissionType { get; set; }
        public string CustomerCodeRange { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string ApproveRejectBy { get; set; }
        public DateTime? ApproveRejectDate { get; set; }
        public string RejectReason { get; set; }
        public short StatusId { get; set; }
        public string Status { get; set; }
        public byte DisplayOrder { get; set; }

    }
}
