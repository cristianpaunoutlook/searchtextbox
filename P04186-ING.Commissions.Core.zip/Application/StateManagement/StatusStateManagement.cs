﻿using System;
using System.Net;
using Application.Commons.Enums;
using Application.Errors;
using Stateless;

namespace Application.StateManagement
{
    public class StatusStateManagement
    {
        private State _statusState;
        private readonly StateMachine<State, StateTrigger> _machine;
        private readonly string entityType;

        public StatusStateManagement(string statusState, string entityType)
        {
            if (!Enum.TryParse(statusState, true, out _statusState))
            {
                throw new RestException(HttpStatusCode.BadRequest, $"{statusState} is not a valid state!");
            }
            _machine = new StateMachine<State, StateTrigger>(() => _statusState, s => _statusState = s);
            InitStates();
            this.entityType = entityType;
        }

        private void InitStates()
        {
            _machine.Configure(State.Added).Permit(StateTrigger.Approve, State.Approved);
            _machine.Configure(State.Added).Permit(StateTrigger.Reject, State.RejectAdd);
            _machine.Configure(State.Updated).Permit(StateTrigger.Approve, State.Approved);
            _machine.Configure(State.Updated).Permit(StateTrigger.Reject, State.Rejected);
            _machine.Configure(State.PendingDelete).Permit(StateTrigger.Approve, State.Deleted);
            _machine.Configure(State.PendingDelete).Permit(StateTrigger.Reject, State.Approved);

            _machine.OnUnhandledTrigger((state, trigger) =>
            {
                throw new RestException(HttpStatusCode.BadRequest, $"We can't {trigger} {entityType} in state {_statusState}");
            });
        }

        public State State { get => _machine.State; }

        public void SetNextState(StateTrigger trigger)
        {
            _machine.Fire(trigger);
        }
    }
}

