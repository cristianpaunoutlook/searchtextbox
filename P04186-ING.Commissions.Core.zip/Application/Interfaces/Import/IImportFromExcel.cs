﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Interfaces.Import
{
    public interface IImportFromExcel<T> where T : new()
    {
        List<T> GetListFromFile(string filePath);
    }
}
