﻿using Application.DTO;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboTableColumns
{
    public class ColumnsListForBEHDetails
    {
        public class Query : IRequest<List<TableColumnDTO>>
        {
        }

        public class Handler : IRequestHandler<Query, List<TableColumnDTO>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<List<TableColumnDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                return await context.TableColumns
                            .Where(t => t.Table.BehDetails == true)
                            .ProjectTo<TableColumnDTO>(mapper.ConfigurationProvider)
                            .ToListAsync();
            }
        }
    }
}
