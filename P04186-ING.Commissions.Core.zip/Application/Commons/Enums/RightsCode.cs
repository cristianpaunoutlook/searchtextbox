﻿namespace Application.Commons.Enums
{
    public enum RightsCode
    {
        NORIGHT,
        READ,
        EDIT,
        APPROVE
    }
}
