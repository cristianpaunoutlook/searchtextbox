﻿namespace Application.Commons.Enums
{
    public enum UserObject
    {
        UserGroup = 1,
        UserGroupRights = 2,
        Session = 3
    }
}
