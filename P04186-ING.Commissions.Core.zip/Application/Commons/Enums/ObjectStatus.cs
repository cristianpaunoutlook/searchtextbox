﻿namespace Application.Commons.Enums
{
    public static class ObjectStatus
    {
        public static string Updated { get { return "Updated"; } }
        public static string Approved { get { return "Approved"; } }
        public static string Rejected { get { return "Rejected"; } }
        public static string Deleted { get { return "Deleted"; } }
        public static string Added { get { return "Added"; } }
        public static string PendingDelete { get { return "PendingDelete"; } }
        public static string RejectAdd { get { return "RejectAdd"; } }

    }
}