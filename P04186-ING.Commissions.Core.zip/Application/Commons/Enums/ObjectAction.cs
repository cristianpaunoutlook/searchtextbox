﻿namespace Application.Commons.Enums
{
    public enum ObjectAction
    {
        Add = 1,
        Edit = 2,
        Approve = 3,
        Reject = 4,
        Delete = 5,
        Generate = 6,
        Upload = 7
    }
}
