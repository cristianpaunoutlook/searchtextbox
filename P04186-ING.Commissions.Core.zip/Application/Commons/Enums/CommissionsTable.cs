﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Commons.Enums
{
    public enum CommissionsTable
    {
        Behaviors = 1,
        SL2 = 2,
        SME = 3,
        TLS = 6,
        OLTSFR = 7,
        BehaviorsCommissions = 8,	
	    SL2Commissions = 11,
	    TLSCommissions = 12,
	    ConsolidatedCommissions = 9,
	    SMECommissions = 10
    }
}
