﻿namespace Application.Commons.Enums
{
    public enum ObjectStatusId
    {
        Updated = 1,
        Approved = 2,
        Rejected = 3,
        Deleted = 4,
        Added = 5,
        PendingDelete = 6,
        RejectAdd = 7
    }
}
