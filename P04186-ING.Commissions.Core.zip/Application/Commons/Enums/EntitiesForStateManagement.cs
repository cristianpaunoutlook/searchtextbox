﻿namespace Application.Commons.Enums
{
    public static class EntitiesForStateManagement
    {
        public static string ProductDetail { get { return "a product detail"; } }
        public static string BehaviorsCommission { get { return "a behaviors commission"; } }
        public static string Parameter { get { return "a parameter"; } }
        public static string Office { get { return "an office"; } }
    }
}
