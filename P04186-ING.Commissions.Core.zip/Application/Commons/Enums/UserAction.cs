﻿namespace Application.Commons.Enums
{
    public enum UserAction
    {
        Add = 1,
        ModifyEdit = 2,
        Delete = 3,
        Reject = 4,
        Approve = 5,
        Login = 6,
        ForcedLogout = 9,
        FailedLogin = 10
    }
}
