﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Commons.Enums
{
    public enum ProcessAction
    {
        All = 1,
        Generate = 2,
        History = 3,
        Download = 4
    }
}
