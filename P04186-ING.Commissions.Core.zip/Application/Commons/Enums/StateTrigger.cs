﻿namespace Application.Commons.Enums
{
    public enum StateTrigger
    {
        Approve,
        Reject,
        Modify,
        Delete
    }
}
