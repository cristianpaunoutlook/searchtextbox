﻿namespace Application.Commons.Enums
{
    public enum GroupRight
    {
        ViewExport = 1,
        AddEditDelete = 2,
        ApproveReject = 3
    }
}
