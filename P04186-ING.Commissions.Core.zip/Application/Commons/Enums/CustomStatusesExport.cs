﻿namespace Application.Commons.Enums
{
    public static class CustomStatusesExport
    {
        public static string Ok { get { return "Successfully"; } }
        public static string Executing { get { return "In progress"; } }
        public static string NULL { get { return ""; } }
        public static string Failed { get { return "Failed"; } }

    }
}