﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Commons.Enums
{
    public enum SortOrder
    {
        OrderBy,
        OrderByDescending
    }
}
