﻿namespace Application.Commons.Enums
{
    public enum State
    {
        Added,
        PendingDelete,
        Rejected,
        Updated,
        Approved,
        RejectAdd,
        Deleted
    }
}
