﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Commons.Cache
{
    [ExcludeFromCodeCoverage]
    public static class CacheKeys
    {
        public static string AdGroupsForApp { get { return "AdGroupsForApp"; } } 
    }
}
