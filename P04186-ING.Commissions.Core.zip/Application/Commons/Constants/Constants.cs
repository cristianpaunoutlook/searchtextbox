﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Commons.Constants
{
    [ExcludeFromCodeCoverage]
    public static class Constants
    {
        public const int CORPORATE_KEY_LENGTH = 6;
        public const int SESSION_KEY_LENGTH = 50;

        public const string NON_TRANSACTIONAL_FEES = "Non Transactional Fees";
        public const string OFFICE_SALES_COMMISSIONS = "Office sales Commissions";

        public const string SECURITY_PAGE = "SEC";

        public const int OFFICES_POINTS_LIMIT = 5801;
        public const int MIN_CSAT_PREV_Q = 1;
        public const int MAX_CSAT_PREV_Q = 5;

        public static readonly string[] INVALID_STRINGS = new string[]
        {
            "insert",
            "update",
            "delete",
            "drop",
            "truncate",
            "select",
            "exec",
            "cmd",
            "=",
            "+",
            "-",
            "@",
        };

        public static readonly string[] INVALID_JOB_STATUS = new string[]
        {
            "Requested job/jobs already Executing!",
            "ConsolidatedCommissions can be called only if table status for all commissions is Successfully!",
            "Can not start requested job while ConsolidatedCommissions job is running!"
        };

        public static readonly string TOAPPROVE = "toapprove";
        public static readonly string TOFILLREQ = "tofillmandatory";
    }
}
