﻿using System.Diagnostics.CodeAnalysis;
namespace Application.Export.ProductDetailsReport
{
    [ExcludeFromCodeCoverage]
    public class ProductDetailsFilter 
    {
        public string ProductType { get; set; }
        public string ShortName { get; set; }
        public int StatusId { get; set; }
        public string Context { get; set; }
    }
}
