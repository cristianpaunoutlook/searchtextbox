﻿using System;
using System.ComponentModel;

namespace Application.Export.ProductDetailsReport
{
    public class ProductDetailsReportData
    {
        [Description("Product Type")]
        public string ProductType { get; set; }
        
        [Description("Product Short Name")]
        public string ShortName { get; set; }
        
        [Description("Product Description")]
        public string Name { get; set; }
        
        [Description("Expense Account No")]
        public long ExpenseAccountNo { get; set; }

        [Description("Expense Account Short Name")]
        public string ExpenseAccountName { get; set; }
        
        [Description("Updated By")]
        public string UpdatedBy { get; set; }
        
        [Description("Update Date")]
        public DateTime UpdatedDate { get; set; }

        [Description("Approved / Rejected By")]
        public string ApprovedRejectedBy { get; set; }

        [Description("Approve / Reject Date")]
        public DateTime? ApproveRejectDate { get; set; }

        [Description("Status")]
        public string Status { get; set; }
    }
}
