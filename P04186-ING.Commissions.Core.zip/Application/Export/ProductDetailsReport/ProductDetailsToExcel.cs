﻿using Application.DboProductDetails;
using Application.DTO;
using Application.Errors;
using Application.Export.ProductDetailsReport;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.ExpenseAccountReport
{
    [ExcludeFromCodeCoverage]
    public class ProductDetailsToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public ProductDetailsFilter ProductParams { get; set; }

        }
        public class Handler : ProductDetailsListBase, IRequestHandler<Query, byte[]>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;
            private readonly IExportAsExcel<ProductDetailsReportData> export;

            public Handler(CommissionsContext context, IMapper mapper, IExportAsExcel<ProductDetailsReportData> export)
            {
                this.context = context;
                this.mapper = mapper;
                this.export = export;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {

                var productDetailsList = ProductDetailsList(context, request.ProductParams, mapper);
                var productDetailsToExport = await productDetailsList.ToListAsync();
                var result = mapper.Map<List<ProductDetailsDTO>, List<ProductDetailsReportData>>(productDetailsToExport);

                if (result == null || result.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched product details does not exist in the database!");
                }

                return export.Export(request.Title, result);
            }
        }
    }
}
