﻿using System;
using System.ComponentModel;

namespace Application.Export.OfficesReport
{
    public class OfficesReportData
    {
        [Description("Is SME Club")]
        public bool IsSMEClub { get; set; }

        [Description("Agent Code")]
        public long AgentCode { get; set; }

        [Description("Branch Code")]
        public int BranchCode { get; set; }

        [Description("Branch Name")]
        public string BranchName { get; set; }

        [Description("Branch Type")]
        public string BranchType { get; set; }

        [Description("Owner No")]
        public long OwnerNo { get; set; }

        [Description("Company Name")]
        public string CompanyName { get; set; }

        [Description("Opened Date")]
        public DateTime OpenedDate { get; set; }

        [Description("Updated By")]
        public string ModifiedBy { get; set; }

        [Description("Updated Date")]
        public DateTime ModifiedDate { get; set; }

        [Description("Approved/Rejected By")]
        public string ApprovedRejectedBy { get; set; }

        [Description("Approved/Rejected Date")]
        public DateTime? ApprovedRejectedDate { get; set; }

        [Description("CSAT previous Q")]
        public decimal? CsatPrevQ { get; set; }

        [Description("Target Digital Sales (min)")]
        public int? MinDigitalSale { get; set; }

        [Description("%Digital Sales Level 1")]
        public int? MinLevel1 { get; set; }

        [Description("%Digital Sales Level 2")]
        public int? MaxLevel1 { get; set; }

        [Description("No of Digital Sales")]
        public int? NoDigitalSales { get; set; }

        [Description("%Digital Sales")]
        public decimal? DigitalSales { get; set; }

        [Description("Status")]
        public string StatusName { get; set; }
    }
}
