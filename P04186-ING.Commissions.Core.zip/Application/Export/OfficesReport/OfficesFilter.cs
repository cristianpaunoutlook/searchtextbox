﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Export.OfficesReport
{
    public class OfficesFilter
    {
        public long? AgentCode { get; set; }
        public int? BranchCode { get; set; }
        public string BranchName { get; set; }
        public bool? IsSMEClub { get; set; }
        public short StatusId { get; set; }
        public string Context { get; set; }
    }
}
