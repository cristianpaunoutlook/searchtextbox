﻿using Application.DboOffices;
using Application.DTO;
using Application.Errors;
using Application.Helpers;
using Application.Interfaces.Export;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.OfficesReport
{
    [ExcludeFromCodeCoverage]
    public class OfficesToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public OfficesFilter Filter { get; set; }
        }

        public class Handler : OfficesListBase, IRequestHandler<Query, byte[]>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;
            private readonly IExportAsExcel<OfficesReportData> export;
            public Handler(CommissionsContext context, IMapper mapper, IExportAsExcel<OfficesReportData> export)
            {
                this.context = context;
                this.mapper = mapper;
                this.export = export;
            }

            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var offices = OfficesList(context, mapper, request.Filter);
                var officesToExport = await offices.ToListAsync();
                var result = mapper.Map<List<OfficesListDTO>, List<OfficesReportData>>(officesToExport);

                if (result == null || result.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched offices does not exist in the database!");
                }

                return export.Export(request.Title, result);
            }
        }
    }
}
