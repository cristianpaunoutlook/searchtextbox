﻿namespace Application.Export.BehaviorDetailsReport
{
    public class BehaviorDetailsFilter
    {
        public string BehaviorType { get; set; }
        public string Description { get; set; }
        public int StatusId { get; set; }
        public int CommissionsTableId { get; set; }
        public string Context { get; set; }
    }
}
