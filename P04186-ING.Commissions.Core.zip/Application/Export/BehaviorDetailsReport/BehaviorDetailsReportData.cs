﻿using System;
using System.ComponentModel;

namespace Application.Export.BehaviorDetailsReport
{
    public class BehaviorDetailsReportData
    {
        [Description("Type")]
        public string Type { get; set; }
        
        [Description("Description")]
        public string Description { get; set; }
        
        [Description("Expense Account No")]
        public long ExpenseAccountNo { get; set; }
       
        [Description("Expense Account Short Name")]
        public string ExpenseAccountShortName { get; set; }
        
        [Description("Commission Table Id")]
        public int CommissionTableId { get; set; }
        
        [Description("Commission Table")]
        public string CommissionTable { get; set; }

        [Description("Commission Type")]
        public string CommissionType { get; set; }

        [Description("Customer Code Range")]
        public string CustomerCodeRange { get; set; }

        [Description("Updated By")]
        public string UpdatedBy { get; set; }

        [Description("Updated Date")]
        public DateTime UpdatedDate { get; set; }

        [Description("Approve / Reject By")]
        public string ApproveRejectBy { get; set; }

        [Description("Approve Reject Date")]
        public DateTime ApproveRejectDate { get; set; }

        [Description("RejectReason")]
        public string RejectReason { get; set; }

        [Description("Status")]
        public string Status { get; set; }
    }
}
