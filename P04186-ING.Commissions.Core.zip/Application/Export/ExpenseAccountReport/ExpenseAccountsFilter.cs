﻿namespace Application.Export.ExpenseAccountReport
{
    public class ExpenseAccountsFilter
    {
        public string AccountNo { get; set; }
        public string AccountName { get; set; }
    }
}
