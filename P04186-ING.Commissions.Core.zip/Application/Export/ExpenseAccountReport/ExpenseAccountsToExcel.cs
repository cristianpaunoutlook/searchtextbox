﻿using Application.DboExpenseAccount;
using Application.DTO;
using Application.Errors;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.ExpenseAccountReport
{
    [ExcludeFromCodeCoverage]
    public class ExpenseAccountsToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public ExpenseAccountsFilter Filter { get; set; }
        }
        public class Handler : ExpenseAccountListBase, IRequestHandler<Query, byte[]>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;
            private readonly IExportAsExcel<ExpenseAccountsReportData> export;

            public Handler(CommissionsContext context, IMapper mapper, IExportAsExcel<ExpenseAccountsReportData> export)
            {
                this.context = context;
                this.mapper = mapper;
                this.export = export;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var expenseAccountsList = ExpenseAccountList(context, mapper, request.Filter);
                var expenseAccountsToExport = await expenseAccountsList.ToListAsync();
                var result = mapper.Map<List<ExpenseAccountListDTO>, List<ExpenseAccountsReportData>>(expenseAccountsToExport);

                if (result == null || result.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched expense accounts does not exist in the database!");
                }

                return export.Export(request.Title, result);
            }
        }
    }
}
