﻿using System.ComponentModel;

namespace Application.Export.ExpenseAccountReport
{
    public class ExpenseAccountsReportData
    {
        [Description("Account No")]
        public long Number { get; set; }

        [Description("Account Name")]
        public string Name { get; set; }

    }
}
