﻿using Application.DboParameters;
using Application.DTO;
using Application.Errors;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.ParametersReport
{
    [ExcludeFromCodeCoverage]
    public class ParametersToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public ParametersFilter Filter { get; set; }
        }

        public class Handler : ParametersListBase, IRequestHandler<Query, byte[]>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;
            private readonly IExportAsExcel<ParametersReportData> export;

            public Handler(CommissionsContext context, IMapper mapper, IExportAsExcel<ParametersReportData> export)
            {
                this.context = context;
                this.mapper = mapper;
                this.export = export;
            }

            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                IQueryable<ParametersListDTO> paramters = ParametersList(context, mapper, request.Filter);
                List<ParametersListDTO> parametrsToExport = await paramters.ToListAsync();
                List<ParametersReportData> result = mapper.Map<List<ParametersListDTO>, List<ParametersReportData>>(parametrsToExport);
                if (result == null || result.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched parameters does not exist in the database!");
                }

                return export.Export(request.Title, result);
            }
        }
    }
}
