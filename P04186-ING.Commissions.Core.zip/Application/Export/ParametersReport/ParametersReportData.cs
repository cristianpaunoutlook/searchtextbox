﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Export.ParametersReport
{
    [ExcludeFromCodeCoverage]
    public class ParametersReportData
    {
        [Description("Parameter Name")]
        public string Name { get; set; }
        [Description("Parameter Value_New")]
        public string Value { get; set; }
        [Description("Parameter Value_Old")]
        public string OldValue { get; set; }
        [Description("Commission Table")]
        public string TableName { get; set; }
        [Description("Updated By")]
        public string UpdatedBy { get; set; }
        [Description("Updated Date")]
        public DateTime UpdatedDate { get; set; }
        [Description("Approved / Rejected By")]
        public string ApprovedRejectedBy { get; set; }
        [Description("Approved / Rejected Date")]
        public DateTime? ApprovedRejectedDate { get; set; }
        [Description("Status")]
        public string StatusName { get; set; }
    }
}
