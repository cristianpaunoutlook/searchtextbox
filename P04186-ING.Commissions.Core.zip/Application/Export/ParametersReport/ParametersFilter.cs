﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Export.ParametersReport
{
    [ExcludeFromCodeCoverage]
    public class ParametersFilter
    {
        public string Name { get; set; }
        public short StatusId { get; set; }
        public int TableId { get; set; }
        public string Context { get; set; }
    }
}
