﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Export.CommissionsDownload.Interfaces
{
    public interface ICommissionsReportFactory
    {
        ICommissionsReport GetInstance(string reportName);
    }
}
