﻿using Application.Export.CommissionsDownload.Filter;
using System.Threading.Tasks;

namespace Application.Export.CommissionsDownload.Interfaces
{
    public interface ICommissionsReport
    {
        Task<byte[]> Generate(CommissionsFilter filter);
    }
}
