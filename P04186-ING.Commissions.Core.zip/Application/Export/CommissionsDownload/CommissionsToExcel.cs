﻿using Application.Export.CommissionsDownload.Filter;
using Application.Export.CommissionsDownload.Interfaces;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.CommissionsDownload
{
    public class CommissionsToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public CommissionsFilter Filter { get; set; }
        }

        public class Handler : IRequestHandler<Query, byte[]>
        {
            private readonly ICommissionsReportFactory factory;

            public Handler(ICommissionsReportFactory factory)
            {
                this.factory = factory;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                return await factory.GetInstance(request.Filter.Name).Generate(request.Filter);
            }
        }
    }
}
