﻿using Application.Interfaces.Export;
using AutoMapper;
using Domain;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Export.CommissionsDownload.SME
{
    public class SMECommissionsReport : CommissionsReportBase<SMECommissions, DWHSMECommissions, SMECommissionsReportData>
    {
        public SMECommissionsReport(CommissionsContext context, IMapper mapper, IExportAsExcel<SMECommissionsReportData> export) 
            : base(context, mapper, export)
        {
        }
    }
}
