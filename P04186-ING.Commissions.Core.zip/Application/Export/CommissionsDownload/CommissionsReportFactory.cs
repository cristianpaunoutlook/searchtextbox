﻿using Application.Errors;
using Application.Export.CommissionsDownload.Interfaces;
using System;
using System.Net;
using System.Reflection;

namespace Application.Export.CommissionsDownload
{
    public class CommissionsReportFactory : ICommissionsReportFactory
    {
        private const string nameExtension = "Report";
        private readonly IServiceProvider _serviceProvider;

        public CommissionsReportFactory(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public ICommissionsReport GetInstance(string reportName)
        {
            reportName = reportName + nameExtension;
            foreach (var t in typeof(CommissionsReportFactory).Assembly.GetTypes())
            {
                if (typeof(ICommissionsReport).IsAssignableFrom(t) && !t.IsInterface && t.Name.ToLower() == reportName.ToLower())
                {
                    return (ICommissionsReport) _serviceProvider.GetService(t);
                }
            }
            throw new RestException(HttpStatusCode.BadRequest, "Invalid report name!");
        }
    }
}
