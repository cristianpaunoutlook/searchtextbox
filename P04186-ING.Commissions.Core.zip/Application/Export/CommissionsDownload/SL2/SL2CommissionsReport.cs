﻿using Application.Interfaces.Export;
using AutoMapper;
using Domain;
using Persistence;

namespace Application.Export.CommissionsDownload.SL2
{
    public class SL2CommissionsReport : CommissionsReportBase<SL2Commissions, DWHSL2Commissions, SL2CommissionsReportData>
    {
        public SL2CommissionsReport(CommissionsContext context, IMapper mapper, IExportAsExcel<SL2CommissionsReportData> export) 
            : base(context, mapper, export)
        {
        }
    }
}
