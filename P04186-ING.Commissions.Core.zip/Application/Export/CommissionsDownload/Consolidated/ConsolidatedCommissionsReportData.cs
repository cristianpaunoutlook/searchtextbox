﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Export.CommissionsDownload.Consolidated
{
    public class ConsolidatedCommissionsReportData
    {
        public int BranchCode { get; set; }

        public int AgentCode { get; set; }

        public DateTime OpenedDate { get; set; }

        public decimal SL2Commission { get; set; }

        public decimal TLSCommission { get; set; }

        public decimal SMERevolvingCommission { get; set; }

        public decimal SMETermLoansCommission { get; set; }

        public decimal SMEServiceCommission { get; set; }

        public decimal SMEPOSIncomingCommission { get; set; }

        public decimal SMECommission { get; set; }

        public decimal SMEFXCommission { get; set; }

        public decimal MCSEDailyBankingCommission { get; set; }

        public decimal MCSELendingCommission { get; set; }

        public decimal BehaviorsCommission { get; set; }

        public decimal DailyBankingBehaviorCommissions { get; set; }

        public decimal LendingComplexBehaviorCommissions { get; set; }

        public decimal PrepareYourFutureBehaviorCommissions { get; set; }

        public decimal DailyBankingBehaviorDigitalCommissions { get; set; }

        public decimal LendingComplexBehaviorDigitalCommissions { get; set; }

        public decimal PrepareYourFutureBehaviorDigitalCommissions { get; set; }

        public decimal PrimaryCommission { get; set; }

        public decimal TotalCommission { get; set; }
    }
}
