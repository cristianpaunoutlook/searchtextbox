﻿using Application.Interfaces.Export;
using AutoMapper;
using Domain;
using Persistence;

namespace Application.Export.CommissionsDownload.Consolidated
{
    class ConsolidatedCommissionsReport : CommissionsReportBase<ConsolidatedCommissions, DWHConsolidatedCommissions, ConsolidatedCommissionsReportData>
    {
        public ConsolidatedCommissionsReport(CommissionsContext context, IMapper mapper, IExportAsExcel<ConsolidatedCommissionsReportData> export) 
            : base(context, mapper, export)
        {
        }
    }
}
