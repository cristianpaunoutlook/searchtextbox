﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Export.CommissionsDownload.Filter
{
    public class CommissionsFilter
    {
        public string Name { get; set; }
        public int MonthId { get; set; }
        public int TableId { get; set; }
    }
}
