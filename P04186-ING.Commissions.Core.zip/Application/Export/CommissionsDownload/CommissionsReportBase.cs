﻿using Application.Errors;
using Application.Export.CommissionsDownload.Filter;
using Application.Export.CommissionsDownload.Interfaces;
using Application.Interfaces.Export;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Domain;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Application.Export.CommissionsDownload
{
    public class CommissionsReportBase <DBOEntity, DWHEntity, TReportData> : ICommissionsReport
        where DBOEntity : class 
        where DWHEntity : DWHCommissionsBase
        where TReportData : class
    {
        private readonly CommissionsContext context;
        private readonly IMapper mapper;
        private readonly IExportAsExcel<TReportData> export;

        public CommissionsReportBase(CommissionsContext context, IMapper mapper, IExportAsExcel<TReportData> export)
        {
            this.context = context;
            this.mapper = mapper;
            this.export = export;
        }

        public async Task<byte[]> Generate(CommissionsFilter filter)
        {
            var lastExport = await context
                                        .StatusExports
                                        .Where(e => e.IdTable == filter.TableId)
                                        .OrderByDescending(e => e.MonthId)
                                        .FirstOrDefaultAsync();

            List<TReportData> commissionsReport;
            if (lastExport != null && lastExport.MonthId == filter.MonthId && lastExport.NoOfRecords > 0)
            {
                commissionsReport = await context
                                            .Set<DBOEntity>()
                                            .ProjectTo<TReportData>(mapper.ConfigurationProvider)
                                            .ToListAsync();
            }
            else
            {
                commissionsReport = await context
                                            .Set<DWHEntity>()
                                            .Where(e => e.MonthId == filter.MonthId)
                                            .ProjectTo<TReportData>(mapper.ConfigurationProvider)
                                            .ToListAsync();
            }
                


            if (commissionsReport == null || commissionsReport.Count == 0)
            {
                throw new RestException(HttpStatusCode.BadRequest, "The searched commissions does not exists in the database!");
            }

            return export.Export(filter.Name, commissionsReport);
        }
    }
}
