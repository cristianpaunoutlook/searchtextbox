﻿using Application.Export.CommissionsDownload.Filter;
using Application.Export.CommissionsDownload.Interfaces;
using Application.Interfaces.Export;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Persistence;
using AutoMapper.QueryableExtensions;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Errors;
using System.Net;
using Domain;

namespace Application.Export.CommissionsDownload.TLS
{
    public class TLSCommissionsReport : CommissionsReportBase<TLSCommissions, DWHTLSCommissions, TLSCommissionsReportData>
    {
        public TLSCommissionsReport(CommissionsContext context, IMapper mapper, IExportAsExcel<TLSCommissionsReportData> export) 
            : base(context, mapper, export)
        {
        }
    }
}
