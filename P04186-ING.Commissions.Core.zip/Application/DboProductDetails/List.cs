﻿
using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Application.Export.ProductDetailsReport;
using Application.Helpers;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboProductDetails
{
    public class List
    {
        public class Query : IRequest<PagedList<ProductDetailsDTO>>
        {
            public ProductDetailsParams ProductDetailsParams { get; set; }
        }

        public class Handler : ProductDetailsListBase ,IRequestHandler<Query, PagedList<ProductDetailsDTO>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;


            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<PagedList<ProductDetailsDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get products list");

                var filter = mapper.Map<ProductDetailsFilter>(request.ProductDetailsParams);

                var productDetails = ProductDetailsList(context, filter, mapper);

                var paginatedResult = await PagedList<ProductDetailsDTO>.CreateAsync(productDetails, request.ProductDetailsParams.PageNumber,
                    request.ProductDetailsParams.PageSize);

                if (paginatedResult.Items.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "There are no records corresponding to your search!");
                }

                return paginatedResult;
            }
        }
    }
}