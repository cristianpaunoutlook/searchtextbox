﻿using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Application.Errors;

namespace Application.DboProductDetails
{
    public class Compare
    {
        public class Query : IRequest<List<ProductDetailsHistory>>
        {
            public int ProductDetailsId { get; set; }
        }

        public class Handler : IRequestHandler<Query, List<ProductDetailsHistory>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<List<ProductDetailsHistory>> Handle(Query request, CancellationToken cancellationToken)
            {
                var prodDetailsHist = await context.ProductDetailsHistory
                                        .Where(h => h.ProductDetailsId == request.ProductDetailsId)
                                        .OrderByDescending(h => h.Id)
                                        .Take(2)
                                        .ToListAsync();

                if (prodDetailsHist.Count != 2)
                    throw new RestException(HttpStatusCode.BadRequest, $"Requested product has no history!");
                
                return prodDetailsHist;
            }
        }
    }
}
