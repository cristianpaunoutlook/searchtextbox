﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.ProductDetailsNotification;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboProductDetails
{
    public class Delete
    {
        public class Command : IRequest
        {
            public int Id { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : ProductDetailsNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper,
                 IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot delete product because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot delete product because there is a running job in progress");
                }

                var currentProduct = await context.ProductDetails.FindAsync(request.Id);
                if (currentProduct == null)
                    throw new RestException(HttpStatusCode.BadRequest, $"The product is not in the database");
                if (currentProduct.Status.StatusName != Commons.Enums.ObjectStatus.Approved &&
                    currentProduct.Status.StatusName != Commons.Enums.ObjectStatus.Rejected)
                    throw new RestException(HttpStatusCode.BadRequest, $"The product {currentProduct.Name} should be in Approved or Rejected state to be deleted!");

                var statusPendingDelete = await context.ObjectStatus.FirstOrDefaultAsync(o => o.StatusName == Commons.Enums.ObjectStatus.PendingDelete);
                var actionDeleted = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Delete.ToString());
                currentProduct.Status = statusPendingDelete;
                currentProduct.StatusId = statusPendingDelete.Id;
                currentProduct.ChangeDate = DateTime.Now;
                currentProduct.UserId = request.UserKey;
                var productHistory = mapper.Map<ProductDetailsHistory>(currentProduct);
                productHistory.Action = actionDeleted;
                productHistory.ActionId = actionDeleted.Id;
                context.ProductDetailsHistory.Add(productHistory);

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendProductDetailsEmailAsync(currentProduct, currentProduct.Status.StatusName, nameof(NotificationType.SendToApprove));
                    return Unit.Value;
                }
                throw new Exception("The product was not deleted!");
            }
        }
    }
}
