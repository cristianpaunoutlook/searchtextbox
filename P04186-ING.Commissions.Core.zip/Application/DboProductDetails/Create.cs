﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.ProductDetailsNotification;
using AutoMapper;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboProductDetails
{
    public class Create
    {
        public class Command : IRequest
        {
            public string ProductType { get; set; }
            public string ProductDescription { get; set; }
            public string ProductName { get; set; }
            public string LastModifiedBy { get; set; }
            public DateTime ChangeDate { get; set; }
            public short StatusId { get; set; }
            public int ExpenseAccountId { get; set; }
        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(pd => pd.ProductType).NotNull();
                RuleFor(pd => pd.ExpenseAccountId).NotNull();
                RuleFor(pd => pd.ProductName).NotNull().MinimumLength(2).MaximumLength(50);
                RuleFor(pd => pd.ProductDescription).NotNull().MinimumLength(5).MaximumLength(100);
            }
        }

        public class Handler : ProductDetailsNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, IMapper mapper, ILogger<Handler> logger,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot create product because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot create product because there is a running job in progress");
                }

                var selectedProductDetails = await context.Products.GroupJoin(
                                                      context.ProductDetails,
                                                      product => product.ProductType,
                                                      detail => detail.ProductType,
                                                      (x, y) => new { Product = x, ProductDetails = y })
                                                .SelectMany(
                                                      x => x.ProductDetails.DefaultIfEmpty(),
                                                      (x, y) => new { Product = x.Product, ProductDetails = y })
                                                .Where(x => x.Product.ProductType == request.ProductType && (x.ProductDetails.ProductType == null || 
                                                      (x.ProductDetails.StatusId == (short)Application.Commons.Enums.ObjectStatusId.Deleted || 
                                                        x.ProductDetails.StatusId == (short)Application.Commons.Enums.ObjectStatusId.RejectAdd))).FirstOrDefaultAsync();

                if (selectedProductDetails == null) 
                {
                    logger.LogWarning("Product with type {ProductType} can not be added! It already exists in product details or is not a product!", request.ProductType);
                    throw new RestException(HttpStatusCode.BadRequest, $"Product with type {request.ProductType} can not be added!");
                }

                var productStatus = await context.ObjectStatus.Where(os => os.StatusName == Application.Commons.Enums.ObjectStatus.Added).FirstOrDefaultAsync();
                var expenseAccount = await context.ExpenseAccounts.Where(es => es.Id == request.ExpenseAccountId).FirstOrDefaultAsync();
                var actionAdded = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Add.ToString());
                ProductDetails productForNotif;
                if (selectedProductDetails.ProductDetails == null)
                {
                    logger.LogInformation("Create product details with product type {ProductType}", request.ProductType);

                    
                    ProductDetails product = mapper.Map<Command, ProductDetails>(request);
                    product.StatusId = productStatus.Id;
                    product.ExpenseAccountId = expenseAccount.Id;
                    product.UserId = request.LastModifiedBy;
                    var productHistory = mapper.Map<ProductDetailsHistory>(product);
                    productHistory.Action = actionAdded;
                    productHistory.ActionId = actionAdded.Id;
                    productForNotif = product;
                    context.Add(product);
                    context.Add(productHistory);
                }
                else
                {
                    logger.LogInformation("Update product details with product type {ProductType}", selectedProductDetails.ProductDetails.ProductType);
                    var updatedProduct = selectedProductDetails.ProductDetails;
                    updatedProduct.StatusId = productStatus.Id;
                    updatedProduct.ExpenseAccountId = expenseAccount.Id;
                    updatedProduct.ChangeDate = request.ChangeDate;
                    updatedProduct.UserId = request.LastModifiedBy;
                    updatedProduct.ApproveRejectDate = null;
                    updatedProduct.ApproveRejectId = null;
                    updatedProduct.Name = request.ProductDescription;
                    updatedProduct.ShortName = request.ProductName;
                    var productHistory = mapper.Map<ProductDetailsHistory>(updatedProduct);
                    productHistory.Action = actionAdded;
                    productHistory.ActionId = actionAdded.Id;
                    productForNotif = updatedProduct;
                    context.Add(productHistory);
                }

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendProductDetailsEmailAsync(productForNotif, productStatus.StatusName, nameof(NotificationType.SendToApprove));
                    return Unit.Value;
                }
                throw new Exception("Product was not created!");
            }
        }
    }
}