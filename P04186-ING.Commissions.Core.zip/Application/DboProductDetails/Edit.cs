﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.ProductDetailsNotification;
using AutoMapper;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboProductDetails
{
    public class Edit
    {
        public class Command : IRequest
        {
            public int Id { get; set; }
            public string ProductType { get; set; }
            public string ProductDescription { get; set; }
            public string ProductName { get; set; }
            public string LastModifiedBy { get; set; }
            public DateTime ChangeDate { get; set; }
            public short StatusId { get; set; }
            public int ExpenseAccountId { get; set; }
        }
        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(pd => pd.ProductType).NotNull();
                RuleFor(pd => pd.ExpenseAccountId).NotNull();
                RuleFor(pd => pd.ProductName).NotNull().MinimumLength(2).MaximumLength(50);
                RuleFor(pd => pd.ProductDescription).NotNull().MinimumLength(5).MaximumLength(100);
            }
        }

        public class Handler : ProductDetailsNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot edit product because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot edit product because there is a running job in progress");
                }

                var currentProduct = await context.ProductDetails.FindAsync(request.Id);
                if (currentProduct == null)
                    throw new RestException(HttpStatusCode.BadRequest, $"The product {request.ProductType} is not in the database");
                if (currentProduct.Status.StatusName != Commons.Enums.ObjectStatus.Approved &&
                    currentProduct.Status.StatusName != Commons.Enums.ObjectStatus.Rejected)
                    throw new RestException(HttpStatusCode.BadRequest, $"The product {request.ProductType} should be in Approved or Rejected state to be modified!");

                var statusUpdated = await context.ObjectStatus.FirstOrDefaultAsync(o => o.StatusName == Commons.Enums.ObjectStatus.Updated);
                var actionUpdated = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Edit.ToString());
                var expenseAccount = await context.ExpenseAccounts.FirstOrDefaultAsync(ea => ea.Id == request.ExpenseAccountId);
                logger.LogInformation("Update product details with product type {ProductType}", currentProduct.ProductType);
                currentProduct.StatusId = statusUpdated.Id;
                currentProduct.ExpenseAccountId = expenseAccount.Id;
                currentProduct.UserId = request.LastModifiedBy;
                currentProduct.ChangeDate = request.ChangeDate;
                currentProduct.ApproveRejectDate = null;
                currentProduct.ApproveRejectId = null;
                currentProduct.Name = request.ProductDescription;
                currentProduct.ShortName = request.ProductName;
                var productHistory = mapper.Map<ProductDetailsHistory>(currentProduct);
                productHistory.Action = actionUpdated;
                productHistory.ActionId = actionUpdated.Id;

                context.Add(productHistory);

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendProductDetailsEmailAsync(currentProduct, currentProduct.Status.StatusName, nameof(NotificationType.SendToApprove));
                    return Unit.Value;
                }
                throw new Exception("Product was not updated!");
            }
        }
    }
}

