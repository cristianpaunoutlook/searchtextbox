﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.ProductDetailsNotification;
using Application.StateManagement;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboProductDetails
{
    public class Reject
    {
        public class Command : IRequest
        {
            public int ProductDetailsId { get; set; }
            public string ProductType { get; set; }
            public string RejectReason { get; set; }
            public string UserKey { get; set; }
        }
        public class Handler : ProductDetailsNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, IMapper mapper, ILogger<Handler> logger,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot reject product because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot reject product because there is a running job in progress");
                }

                logger.LogInformation($"Reject product detail {request.ProductDetailsId}");
                var productDetail = await context.ProductDetails.FindAsync(request.ProductDetailsId);
                if (productDetail == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "This product is not in the database!");
                }

                if (request.UserKey == productDetail.UserId)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"You have changed the product {productDetail.Name} so you can not approve the changes!");
                }
                var oldStatus = productDetail.Status.StatusName;
                var statusManger = new StatusStateManagement(productDetail.Status.StatusName, EntitiesForStateManagement.ProductDetail);
                statusManger.SetNextState(StateTrigger.Reject);
                var objStatus = await context.ObjectStatus.FirstOrDefaultAsync(os => os.StatusName == statusManger.State.ToString());
                var actionReject = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Reject.ToString());
                productDetail.Status = objStatus;
                productDetail.StatusId = objStatus.Id;
                productDetail.ApproveRejectId = request.UserKey;
                productDetail.ApproveRejectDate = DateTime.Now;
                productDetail.RejectReason = request.RejectReason;
                var accountHistory = mapper.Map<ProductDetailsHistory>(productDetail);
                accountHistory.Action = actionReject;
                accountHistory.ActionId = actionReject.Id;                
                context.Add(accountHistory);

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendProductDetailsEmailAsync(productDetail, oldStatus, nameof(NotificationType.Rejected));
                    return Unit.Value;
                }
                throw new Exception("The product was not rejected!");
            }
        }
    }
}
