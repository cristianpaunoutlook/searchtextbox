﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.DTO;
using Application.Export.ProductDetailsReport;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Persistence;
using System.Linq;

namespace Application.DboProductDetails
{
    public class ProductDetailsListBase
    {
        public IQueryable<ProductDetailsDTO> ProductDetailsList(CommissionsContext context, ProductDetailsFilter ProductParams, IMapper mapper)
        {
            if(!string.IsNullOrEmpty(ProductParams.Context) && ProductParams.Context.ToLower() == Constants.TOAPPROVE)
            {
                return context
                            .ProductDetails
                            .Where(prd => prd.Status.StatusName != ObjectStatus.Deleted &&
                                            prd.Status.StatusName != ObjectStatus.RejectAdd &&
                                            prd.Status.StatusName != ObjectStatus.Approved)
                            .OrderBy(prd => prd.Status.DisplayOrder)
                            .ThenBy(prd => prd.Name)
                            .ProjectTo<ProductDetailsDTO>(mapper.ConfigurationProvider);
            }
            

            var productDetails = (from prd in context.ProductDetails.Where(prd => prd.Status.StatusName != ObjectStatus.Deleted && prd.Status.StatusName != ObjectStatus.RejectAdd)

                                  select new ProductDetailsDTO
                                  {
                                      ProductType = prd.ProductType,
                                      ShortName = prd.ShortName,
                                      Name = prd.Name,
                                      ExpenseAccountId = prd.ExpenseAccountId,
                                      ExpenseAccountNo = prd.ExpenseAccount.Number,
                                      ExpenseAccountName = prd.ExpenseAccount.Name,
                                      UpdatedBy = prd.UserId,
                                      UpdatedDate = prd.ChangeDate,
                                      ApprovedRejectedBy = prd.ApproveRejectId,
                                      ApproveRejectDate = prd.ApproveRejectDate,
                                      StatusId = prd.StatusId,
                                      DisplayOrder = prd.Status.DisplayOrder,
                                      Status = prd.Status.StatusName,
                                      Id = prd.Id,
                                  });

            if (!string.IsNullOrEmpty(ProductParams.ProductType))
            {
                productDetails = productDetails.Where(p => p.ProductType.Contains(ProductParams.ProductType));
            }

            if (!string.IsNullOrEmpty(ProductParams.ShortName))
            {
                productDetails = productDetails.Where(p => p.ShortName.Contains(ProductParams.ShortName));
            }

            if (ProductParams.StatusId != -1)
            {
                productDetails = productDetails.Where(p => p.StatusId == ProductParams.StatusId);
            }

            productDetails = productDetails.OrderBy(prd => prd.DisplayOrder).ThenBy(prd => prd.Name);

            return productDetails;
        }
    }
}
