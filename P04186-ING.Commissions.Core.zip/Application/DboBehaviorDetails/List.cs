﻿using Application.DTO;
using Application.Errors;
using Application.Export.BehaviorDetailsReport;
using Application.Helpers;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Domain;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboBehaviorDetails
{
    public class List
    {
        public class Query : IRequest<PagedList<BehaviorDetailsListDTO>>
        {
            public BehaviorParams BehaviorParams { get; set; }
        }

        public class Handler : BehaviorDetailsListBase, IRequestHandler<Query, PagedList<BehaviorDetailsListDTO>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<PagedList<BehaviorDetailsListDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get offices list");
                var filter = mapper.Map<BehaviorDetailsFilter>(request.BehaviorParams);

                var behaviorDetails = BehaviorDetailsList(context, mapper, filter);

                return await behaviorDetails.GetPaginatedListAndCheckIfEmpty<BehaviorDetailsListDTO>(request.BehaviorParams.PageNumber, request.BehaviorParams.PageSize);                
            }
        }
    }
}
    