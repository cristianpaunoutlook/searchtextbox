﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.BehaviorDetailsNotification;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboBehaviorDetails
{
    public class Delete
    {
        public class Command : IRequest
        {
            public int Id { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : BehaviorDetailsNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper,
                 IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot delete behavior because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot delete behavior because there is a running job in progress");
                }

                var currentBehavior = await context.BehaviorDetails.FindAsync(request.Id);
                if (currentBehavior == null)
                    throw new RestException(HttpStatusCode.BadRequest, $"The behavior is not in the database");
                if (currentBehavior.Status.StatusName != Commons.Enums.ObjectStatus.Approved &&
                    currentBehavior.Status.StatusName != Commons.Enums.ObjectStatus.Rejected)
                    throw new RestException(HttpStatusCode.BadRequest, $"The behavior {currentBehavior.Type} should be in Approved or Rejected state to be deleted!");

                var statusPendingDelete = await context.ObjectStatus.FirstOrDefaultAsync(o => o.StatusName == Commons.Enums.ObjectStatus.PendingDelete);
                var actionDeleted = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Delete.ToString());
                currentBehavior.Status = statusPendingDelete;
                currentBehavior.StatusId = statusPendingDelete.Id;
                currentBehavior.UpdatedDate = DateTime.Now;
                currentBehavior.UpdatedBy = request.UserKey;
                var behaviorHistory = mapper.Map<BehaviorDetailsHistory>(currentBehavior);
                behaviorHistory.Action = actionDeleted;
                behaviorHistory.ActionId = actionDeleted.Id;
                context.BehaviorDetailsHistory.Add(behaviorHistory);

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendBehaviorDetailsEmailAsync(currentBehavior, currentBehavior.Status.StatusName, nameof(NotificationType.SendToApprove));
                    return Unit.Value;
                }
                throw new Exception("The behavior was not deleted!");
            }
        }
    }
}
