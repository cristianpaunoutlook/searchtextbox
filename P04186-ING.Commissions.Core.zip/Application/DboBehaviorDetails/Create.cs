﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.BehaviorDetailsNotification;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboBehaviorDetails
{
    public class Create
    {
        public class Command : IRequest
        {
            public string Type { get; set; }
            public string Description { get; set; }
            public int ExpenseAccountId { get; set; }
            public int CommissionBehaviorTablesId { get; set; }
            public int CommissionBehaviorColumnsId { get; set; }
            public string CustomerCodeRange { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : BehaviorDetailsNotificationBase,IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot create behavior because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot create behavior because there is a running job in progress");
                }

                logger.LogInformation("Create behavior with details: type{Type}, description{Description}, expense account id {ExpenseAccountId}" +
                    "behavior tables id {CommissionBehaviorTablesId}, behavior columns id {CommissionBehaviorColumnsId}, customer code range {CustomerCodeRange} by user {UserKey}", 
                    request.Type, request.Description, request.ExpenseAccountId, request.CommissionBehaviorTablesId, request.CommissionBehaviorColumnsId, request.CustomerCodeRange, request.UserKey);
                
                BehaviorDetails behaviorDetails = await context.BehaviorDetails.FirstOrDefaultAsync(bd => bd.Type == request.Type || bd.Description == request.Description);
                
                if (behaviorDetails != null && (behaviorDetails.Status.StatusName != Commons.Enums.ObjectStatus.Deleted && behaviorDetails.Status.StatusName != Commons.Enums.ObjectStatus.RejectAdd))
                {
                    logger.LogWarning("Cannot create duplicates in table BehaviorDetails!");
                    throw new RestException(HttpStatusCode.BadRequest, $"There is already a behavior with this info " +
                        $"{behaviorDetails.Type} {behaviorDetails.Description} {behaviorDetails.Status.StatusName} in the database!");
                }
                
                Domain.ObjectStatus statusAdded = await context.ObjectStatus.FirstOrDefaultAsync(o => o.StatusName == Commons.Enums.ObjectStatus.Added);
                Domain.ObjectAction actionAdded = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Add.ToString());
                ExpenseAccount expenseAccount = await context.ExpenseAccounts.FirstOrDefaultAsync(ea => ea.Id == request.ExpenseAccountId);
                BehaviorDetails behaviorDetailsForNotif = new BehaviorDetails();

                if (behaviorDetails != null && 
                    (behaviorDetails.Status.StatusName == Commons.Enums.ObjectStatus.Deleted || behaviorDetails.Status.StatusName == Commons.Enums.ObjectStatus.RejectAdd))
                {
                    behaviorDetails.Type = request.Type;
                    behaviorDetails.Description = request.Description;
                    behaviorDetails.ExpenseAccountId = expenseAccount.Id;
                    behaviorDetails.ExpenseAccount = expenseAccount;
                    behaviorDetails.CommissionBehaviorTablesId = request.CommissionBehaviorTablesId;
                    behaviorDetails.CommissionBehaviorColumnsId = request.CommissionBehaviorColumnsId;
                    behaviorDetails.CustomerCodeRange = request.CustomerCodeRange;
                    behaviorDetails.Status = statusAdded;
                    behaviorDetails.StatusId = statusAdded.Id;
                    behaviorDetails.UpdatedBy = request.UserKey;
                    behaviorDetails.UpdatedDate = DateTime.Now;
                    behaviorDetailsForNotif = behaviorDetails;
                    BehaviorDetailsHistory updatedbehaviorDetailsHist = mapper.Map<BehaviorDetailsHistory>(behaviorDetails);
                    updatedbehaviorDetailsHist.ActionId = actionAdded.Id;
                    context.BehaviorDetailsHistory.Add(updatedbehaviorDetailsHist);
                }
                else
                {
                    BehaviorDetails newBehaviorDetails = mapper.Map<BehaviorDetails>(request);
                    newBehaviorDetails.Status = statusAdded;
                    newBehaviorDetails.StatusId = statusAdded.Id;
                    newBehaviorDetails.UpdatedBy = request.UserKey;
                    newBehaviorDetails.UpdatedDate = DateTime.Now;
                    behaviorDetailsForNotif = newBehaviorDetails;
                    BehaviorDetailsHistory behaviorDetailsHistory = mapper.Map<BehaviorDetailsHistory>(newBehaviorDetails);
                    behaviorDetailsHistory.Action = actionAdded;
                    behaviorDetailsHistory.ActionId = actionAdded.Id;
                    context.BehaviorDetails.Add(newBehaviorDetails);
                    context.BehaviorDetailsHistory.Add(behaviorDetailsHistory);
                }

                bool success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendBehaviorDetailsEmailAsync(behaviorDetailsForNotif, behaviorDetailsForNotif.Status.StatusName, nameof(NotificationType.SendToApprove));
                    return Unit.Value;
                }
                throw new Exception("Behavior details was not created!");
            }
        }
    }
}
