﻿using Application.Export.BehaviorDetailsReport;
using AutoMapper;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Application.DTO;
using Application.Commons.Enums;
using AutoMapper.QueryableExtensions;
using Application.Helpers;
using Application.Commons.Constants;

namespace Application.DboBehaviorDetails
{
    public class BehaviorDetailsListBase
    {
        public IQueryable<BehaviorDetailsListDTO> BehaviorDetailsList(CommissionsContext context, IMapper mapper,
               BehaviorDetailsFilter filter)
        {
            if(filter.Context == Constants.TOAPPROVE)
                return context.BehaviorDetails
                                             .Where(beh => beh.Status.StatusName != ObjectStatus.Deleted &&
                                                     beh.Status.StatusName != ObjectStatus.RejectAdd &&
                                                     beh.Status.StatusName != ObjectStatus.Approved)
                                             .ProjectTo<BehaviorDetailsListDTO>(mapper.ConfigurationProvider);

            var behaviorDetails = context.BehaviorDetails
                                             .Where(beh => beh.Status.StatusName != ObjectStatus.Deleted &&
                                                     beh.Status.StatusName != ObjectStatus.RejectAdd)
                                             .ProjectTo<BehaviorDetailsListDTO>(mapper.ConfigurationProvider);

            behaviorDetails = behaviorDetails.FilterIfValueProvided(!string.IsNullOrEmpty(filter.BehaviorType), o => o.Type.Contains(filter.BehaviorType))
                        .FilterIfValueProvided(!string.IsNullOrEmpty(filter.Description), o => o.Description.Contains(filter.Description))
                        .FilterIfValueProvided(filter.StatusId != -1, o => o.StatusId == filter.StatusId)
                        .FilterIfValueProvided(filter.CommissionsTableId != -1, o => o.CommissionTableId == filter.CommissionsTableId)
                        .OrderBy(o => o.DisplayOrder).ThenBy(o => o.Type);

            return behaviorDetails;

        }
    }
}
