﻿using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Application.Errors;

namespace Application.DboBehaviorDetails
{
    public class Compare
    {
        public class Query : IRequest<List<BehaviorDetailsHistory>>
        {
            public int BehaviorDetailsId { get; set; }
        }

        public class Handler : IRequestHandler<Query, List<BehaviorDetailsHistory>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<List<BehaviorDetailsHistory>> Handle(Query request, CancellationToken cancellationToken)
            {
                var behDetailsHist = await context.BehaviorDetailsHistory
                                        .Where(h => h.BehaviorDetailsId == request.BehaviorDetailsId)
                                        .OrderByDescending(h => h.Id)
                                        .Take(2)
                                        .ToListAsync();

                if (behDetailsHist.Count != 2)
                    throw new RestException(HttpStatusCode.BadRequest, $"Requested behavior has no history!");
                
                return behDetailsHist;
            }
        }
    }
}
