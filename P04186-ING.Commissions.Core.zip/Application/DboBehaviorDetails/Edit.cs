﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.BehaviorDetailsNotification;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboBehaviorDetails
{
    public class Edit
    {
        public class Command : IRequest
        {
            public int Id { get; set; }
            public string Type { get; set; }
            public string Description { get; set; }
            public int ExpenseAccountId { get; set; }
            public int CommissionBehaviorTablesId { get; set; }
            public int CommissionBehaviorColumnsId { get; set; }
            public string CustomerCodeRange { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : BehaviorDetailsNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper, IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot edit behavior because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot edit behavior because there is a running job in progress");
                }

                logger.LogInformation("Edit behavior with details: type {Type}, description {Description}, expense account id {ExpenseAccountId}" +
                    "behavior tables id {CommissionBehaviorTablesId}, behavior columns id {CommissionBehaviorColumnsId}, customer code range {CustomerCodeRange} by user {UserKey}",
                    request.Type, request.Description, request.ExpenseAccountId, request.CommissionBehaviorTablesId, request.CommissionBehaviorColumnsId, request.CustomerCodeRange, request.UserKey);
                BehaviorDetails behaviorDetailsToUpdate = await context.BehaviorDetails.FindAsync(request.Id);
                if (behaviorDetailsToUpdate == null)
                {
                    logger.LogWarning("Cannot edit behavior details that isn't in the database!");
                    throw new RestException(HttpStatusCode.BadRequest, $"The behavior details with type {request.Type} is not in the database!");
                }
                if (behaviorDetailsToUpdate.Status.StatusName != Commons.Enums.ObjectStatus.Approved &&
                    behaviorDetailsToUpdate.Status.StatusName != Commons.Enums.ObjectStatus.Rejected)        
                {
                    logger.LogWarning("Cannot edit behavior details that isn't in status {Status}!", Commons.Enums.ObjectStatus.Approved);
                    throw new RestException(HttpStatusCode.BadRequest, $"Behavior details with type {request.Type} should be in Approved or Rejected state to be modified!");
                }

                    BehaviorDetails checkTypeAndDescription = await context.BehaviorDetails
                                                .FirstOrDefaultAsync(bd =>
                                                        bd.Type == request.Type &&
                                                        bd.Description == request.Description &&
                                                        bd.ExpenseAccountId == request.ExpenseAccountId &&
                                                        bd.CommissionBehaviorTablesId == request.CommissionBehaviorTablesId &&
                                                        bd.CommissionBehaviorColumnsId == request.CommissionBehaviorColumnsId &&
                                                        bd.CustomerCodeRange == request.CustomerCodeRange
                                                    );

                if (checkTypeAndDescription != null)
                {
                    logger.LogWarning("There is already a behavior details with type {Type} and description {Description} in status {Status}!", 
                        checkTypeAndDescription.Type, checkTypeAndDescription.Description ,checkTypeAndDescription.Status.StatusName);
                    throw new RestException(HttpStatusCode.BadRequest, $"There is already a behavior details with this info " +
                        $"{checkTypeAndDescription.Type} {checkTypeAndDescription.Description} status {checkTypeAndDescription.Status.StatusName} in the database!");
                }

                Domain.ObjectStatus statusUpdated = await context.ObjectStatus.FirstOrDefaultAsync(o => o.StatusName == Commons.Enums.ObjectStatus.Updated);
                Domain.ObjectAction actionUpdated = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Edit.ToString());
                ExpenseAccount expenseAccount = await context.ExpenseAccounts.FirstOrDefaultAsync(ea => ea.Id == request.ExpenseAccountId);

                behaviorDetailsToUpdate.Status = statusUpdated;
                behaviorDetailsToUpdate.Type = request.Type;
                behaviorDetailsToUpdate.Description = request.Description;
                behaviorDetailsToUpdate.ExpenseAccountId = expenseAccount.Id;
                behaviorDetailsToUpdate.ExpenseAccount = expenseAccount;
                behaviorDetailsToUpdate.CommissionBehaviorTablesId = request.CommissionBehaviorTablesId;
                behaviorDetailsToUpdate.CommissionBehaviorColumnsId = request.CommissionBehaviorColumnsId;
                behaviorDetailsToUpdate.CustomerCodeRange = request.CustomerCodeRange;
                behaviorDetailsToUpdate.UpdatedBy = request.UserKey;
                behaviorDetailsToUpdate.UpdatedDate = DateTime.Now;
                BehaviorDetailsHistory updatedbehaviorDetailsHist = mapper.Map<BehaviorDetailsHistory>(behaviorDetailsToUpdate);
                updatedbehaviorDetailsHist.ActionId = actionUpdated.Id;
                context.BehaviorDetailsHistory.Add(updatedbehaviorDetailsHist);

                bool success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendBehaviorDetailsEmailAsync(behaviorDetailsToUpdate, behaviorDetailsToUpdate.Status.StatusName, nameof(NotificationType.SendToApprove));
                    return Unit.Value;
                }
                throw new Exception("Behavior details was not created!");
            }
        }
    }
}
