﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Application.Export.CommissionsDownload.Filter;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application
{
    public class ConsolidatedJobs
    {
        public class RunJob : IRequest<JobResultDTO>
        {
            public CommissionsFilter Filter { get; set; }
            public string RunBy { get; set; }
        }
        public class Handler : IRequestHandler<RunJob, JobResultDTO>
        {
            private readonly CommissionsContext context;

            public Handler(CommissionsContext context)
            {
                this.context = context;
            }

            public async Task<JobResultDTO> Handle(RunJob request, CancellationToken cancellationToken)
            {
                var prevMonth = DateTime.Now.AddMonths(-1);
                var monthId = prevMonth.Year * 100 + prevMonth.Month;

                if (monthId != request.Filter.MonthId)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"The job {request.Filter.Name} can not run for month {request.Filter.MonthId}! Please select {monthId}!");
                }

                var jobIsRunning = await context.JobIsRunning(request.Filter.Name);
                if (jobIsRunning > 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, Constants.INVALID_JOB_STATUS[jobIsRunning-1]);
                }

                var checkErrors = await context.GetErrorNumberForConsolidation(request.Filter.MonthId);

                if (checkErrors > 0)
                {
                    return new JobResultDTO() { Status = "NOK", Message = checkErrors.ToString() };
                }

                await context.StartJob($"Commissions_{request.Filter.Name.Replace("Commissions", "")}");
                SaveToHistory(request);

                return new JobResultDTO() { Status = "OK", Message = $"Job for {request.Filter.Name} was started with success!" };
            }

            private void SaveToHistory(RunJob request)
            {
                if(request.Filter.TableId == 0)
                {
                    var processHistorySL2 = new ProcessHistory() { RunBy = request.RunBy, TableId = (int)CommissionsTable.SL2Commissions, RunDate = DateTime.Now };
                    context.ProcessHistory.Add(processHistorySL2);
                    var processHistoryTLS = new ProcessHistory() { RunBy = request.RunBy, TableId = (int)CommissionsTable.TLSCommissions, RunDate = DateTime.Now };
                    context.ProcessHistory.Add(processHistoryTLS);
                    var processHistorySME = new ProcessHistory() { RunBy = request.RunBy, TableId = (int)CommissionsTable.SMECommissions, RunDate = DateTime.Now };
                    context.ProcessHistory.Add(processHistorySME);
                    var processHistoryBEH = new ProcessHistory() { RunBy = request.RunBy, TableId = (int)CommissionsTable.BehaviorsCommissions, RunDate = DateTime.Now };
                    context.ProcessHistory.Add(processHistoryBEH);
                    var processHistoryCON = new ProcessHistory() { RunBy = request.RunBy, TableId = (int)CommissionsTable.ConsolidatedCommissions, RunDate = DateTime.Now };
                    context.ProcessHistory.Add(processHistoryCON);
                }
                else
                {
                    var processHistory = new ProcessHistory() { RunBy = request.RunBy, TableId = request.Filter.TableId, RunDate = DateTime.Now };
                    context.ProcessHistory.Add(processHistory);
                }
                context.SaveChanges();
            }
        }
    }
}
