﻿using Application.Commons.Enums;
using Application.DTO;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboStatusExport
{
    [ExcludeFromCodeCoverage]
    public class FilterList
    {
        public class Query : IRequest<List<StatusExportFilterDTO>>
        {
        }

        public class Handler : IRequestHandler<Query, List<StatusExportFilterDTO>>
        {
            private readonly CommissionsContext context;

            public Handler(CommissionsContext context)
            {
                this.context = context;
            }

            public async Task<List<StatusExportFilterDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                var lastyear = Convert.ToInt32(DateTime.Now.Year) - 1;
                var lastmonth = DateTime.Now.AddMonths(-1).ToString("MM");
                var previousMonthId = Convert.ToInt32(lastyear + lastmonth);
                var currentMonthId = Convert.ToInt32(DateTime.Now.Year.ToString() + lastmonth);

                var monthList = await context.StatusExports.Select(se => se.MonthId).Where(se => se > previousMonthId).Distinct().OrderByDescending(x => x).Take(12).Select(se => new StatusExportFilterDTO
                {
                    MonthId = se,
                    MonthName = ((Month)int.Parse(se.ToString().Substring(4, 2))).ToString() + " " + se.ToString().Substring(0, 4),
                }).ToListAsync();

               
                if (monthList[0].MonthId.ToString()[4..] != lastmonth)
                        monthList.Insert(0,new StatusExportFilterDTO
                        {
                            MonthId = currentMonthId,
                            MonthName = ((Month)int.Parse(currentMonthId.ToString().Substring(4, 2))).ToString() + " " + currentMonthId.ToString().Substring(0, 4),
                        });

                return monthList;
             
            }
        }
    }
}
