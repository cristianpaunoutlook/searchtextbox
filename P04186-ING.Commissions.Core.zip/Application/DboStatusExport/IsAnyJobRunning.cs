﻿using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboStatusExport
{
    public class IsAnyJobRunning
    {
        public class Query : IRequest<bool> { }

        public class Handler : IRequestHandler<Query, bool>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<bool> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation("Check if any job is running");

                return await context.IsAnyJobRunning();
            }

        }
    }
}
