﻿using Application.Commons.Enums;
using Application.DTO;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboStatusExport
{
    public class List
    {
        public class Query : IRequest<List<ProcessedCommission>>
        {
            public int MonthId { get; set; }
        }

        public class Handler : IRequestHandler<Query, List<ProcessedCommission>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<List<ProcessedCommission>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation("Get processesed commissions by monthid {MonthId}", request.MonthId);

                var processedCommissions = await context.ProcessedCommissionsList(request.MonthId);
                foreach (var pc in processedCommissions)
                {
                    pc.ProcessStatus = pc.ProcessStatus == StatusExportStatuses.Ok.ToString() ? CustomStatusesExport.Ok :
                                        pc.ProcessStatus == StatusExportStatuses.Executing.ToString() ? CustomStatusesExport.Executing :
                                        pc.ProcessStatus == StatusExportStatuses.Failed.ToString() ?
                                        CustomStatusesExport.Failed : null;
                }
                return processedCommissions;
            }

        }
    }
}
