﻿using Application.DTO;
using Application.Export.ExpenseAccountReport;
using Application.Helpers;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboExpenseAccount
{
    public class List
    {
        public class Query : IRequest<PagedList<ExpenseAccountListDTO>> { public ExpenseAccountParams ExpenseAccountParams { get; set; } }

        public class Handler : ExpenseAccountListBase, IRequestHandler<Query, PagedList<ExpenseAccountListDTO>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<PagedList<ExpenseAccountListDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get expense accounts list");

                var filter = mapper.Map<ExpenseAccountsFilter>(request.ExpenseAccountParams);

                var expenseAccounts = ExpenseAccountList(context, mapper, filter);

                return await expenseAccounts.GetPaginatedListAndCheckIfEmpty(request.ExpenseAccountParams.PageNumber, 
                    request.ExpenseAccountParams.PageSize);

            }
        }
    }
}
