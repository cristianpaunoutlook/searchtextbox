﻿using Application.DTO;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboExpenseAccount
{
    public class ListForProducts
    {
        public class Query : IRequest<IEnumerable<ExpenseAccountsDropDownDTO>> { }
        public class Handler : IRequestHandler<Query, IEnumerable<ExpenseAccountsDropDownDTO>>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, IMapper mapper)
            {
                this.context = context;
                this.mapper = mapper;
            }

            public async Task<IEnumerable<ExpenseAccountsDropDownDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                var expenseAccounts = await context.ExpenseAccounts.Where(exp => exp.IsVisible == true).ToListAsync();
                return mapper.Map<IEnumerable<ExpenseAccountsDropDownDTO>>(expenseAccounts);

            }
        }
    }
}
