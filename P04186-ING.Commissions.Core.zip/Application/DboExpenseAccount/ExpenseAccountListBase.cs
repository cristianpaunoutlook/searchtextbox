﻿using Application.DTO;
using Application.Export.ExpenseAccountReport;
using Application.Helpers;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Persistence;
using System.Linq;

namespace Application.DboExpenseAccount
{
    public class ExpenseAccountListBase
    {
        public IQueryable<ExpenseAccountListDTO> ExpenseAccountList(CommissionsContext context, IMapper mapper,
            ExpenseAccountsFilter filter)
        {
            var expenseAccounts = context.ExpenseAccounts.Where(exp => exp.IsVisible == true).
                                                    ProjectTo<ExpenseAccountListDTO>(mapper.ConfigurationProvider);

            expenseAccounts = expenseAccounts.FilterIfValueProvided(!string.IsNullOrEmpty(filter.AccountName), o => o.Name.Contains(filter.AccountName.Trim()))
                            .FilterIfValueProvided(filter.AccountNo != null, o => o.Number.ToString().Contains(filter.AccountNo))
                            .OrderBy(o => o.Name);

            return expenseAccounts;
        }
    }
}
