﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Security;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Application.Authorization
{
    [ExcludeFromCodeCoverage]
    public class GroupKeyAuthorizationHandler : AuthorizationHandler<GroupKeyRequirement>
    {
        private readonly ILogger<GroupKeyAuthorizationHandler> _logger;
        private readonly IMediator _mediator;

        public GroupKeyAuthorizationHandler(ILogger<GroupKeyAuthorizationHandler> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, GroupKeyRequirement requirement)
        {
            _logger.LogInformation("Evaluating authorization requirement for group key {GroupKey}", requirement.GroupKey);
            var groups = _mediator.Send(new UserGroups.Query() { User = context.User.Identity }).Result;
            if (groups == null)
                UserWithoutRights(requirement, HttpStatusCode.Unauthorized);
            var groupRightsList = groups.Select(r => r.Value);
            var found = false;
            foreach (var groupRight in groupRightsList)
            {
                if (CheckGroupRight(requirement.GroupKey, groupRight))
                {
                    _logger.LogInformation("Group key {GroupKey} satisfied", requirement.GroupKey);
                    found = true;
                    context.Succeed(requirement);
                    break;
                }
            }

            if (!found)
            {
                UserWithoutRights(requirement, HttpStatusCode.Forbidden);
            }

            return Task.CompletedTask;
        }

        private bool CheckGroupRight(string requestedGroupRight, string groupRight)
        {
            var requestedPage = requestedGroupRight.Substring(0, requestedGroupRight.IndexOf("_"));
            var requestedRight = requestedGroupRight.Substring(requestedGroupRight.IndexOf("_") + 1);

            var page = groupRight.Substring(0, groupRight.IndexOf("_"));
            var right = groupRight.Substring(groupRight.IndexOf("_") + 1);

            return requestedPage == page && ((int.Parse(requestedRight) <= int.Parse(right) && int.Parse(right) != (int)GroupRight.ApproveReject)
                    || (int.Parse(requestedRight) != (int)GroupRight.AddEditDelete && int.Parse(right) == (int)GroupRight.ApproveReject));
        }

        private Task UserWithoutRights(GroupKeyRequirement requirement, HttpStatusCode statusCode)
        {
            _logger.LogInformation("User does not have the group key {GroupKey} satisfied", requirement.GroupKey);
            throw new RestException(statusCode, $"User does not have the group key {requirement.GroupKey} satisfied");
        }
    }
}
