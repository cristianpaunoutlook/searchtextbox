﻿using Microsoft.AspNetCore.Authorization;
using System.Diagnostics.CodeAnalysis;

namespace Application.Authorization
{
    [ExcludeFromCodeCoverage]
    public class GroupKeyRequirement : IAuthorizationRequirement
    {
        public string GroupKey { get; private set; }

        public GroupKeyRequirement(string groupKey) => GroupKey = groupKey;
    }
}
