﻿using Microsoft.AspNetCore.Authorization;
using System.Diagnostics.CodeAnalysis;

namespace Application.Authorization
{
    [ExcludeFromCodeCoverage]
    public class GroupKeyAuthorizeAttribute : AuthorizeAttribute
    {
        const string POLICY_PREFIX = "GroupKey";

        public GroupKeyAuthorizeAttribute(string groupKey) => GroupKey = groupKey;

        public string GroupKey
        {
            get => Policy.Substring(POLICY_PREFIX.Length);
            set => Policy = $"{POLICY_PREFIX}{value.ToString()}";

        }
    }
}
