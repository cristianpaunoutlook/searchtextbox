﻿using Application.DTO;
using Application.Export.BehaviorDetailsReport;
using Application.Export.CommissionsDownload.Consolidated;
using Application.Export.CommissionsDownload.SL2;
using Application.Export.CommissionsDownload.SME;
using Application.Export.CommissionsDownload.TLS;
using Application.Export.ExpenseAccountReport;
using Application.Export.OfficesReport;
using Application.Export.ParametersReport;
using Application.Export.ProductDetailsReport;
using Application.Helpers;
using AutoMapper;
using Domain;
using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.MapProfile
{
    [ExcludeFromCodeCoverage]
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<DboProductDetails.Create.Command, ProductDetails>()
            .ForMember(pd => pd.UserId, o => o.MapFrom(s => s.LastModifiedBy))
            .ForMember(pd => pd.Name, o => o.MapFrom(s => s.ProductDescription))
            .ForMember(pd => pd.ShortName, o => o.MapFrom(s => s.ProductName))
            .ForMember(pd => pd.ChangeDate, o => o.MapFrom(s => DateTime.Now))
            .ForMember(pd => pd.Id, o => o.Ignore()); ;
            CreateMap<ProductDetails, ProductDetailsHistory>()
                .ForMember(pdh => pdh.ProductType, o => o.MapFrom(s => s.ProductType))
                .ForMember(pdh => pdh.ProductDetailsId, o => o.MapFrom(s => s.Id))
                .ForMember(pdh => pdh.UpdateBy, o => o.MapFrom(s => s.UserId))
                .ForMember(pdh => pdh.UpdatedDate, o => o.MapFrom(s => s.ChangeDate))
                .ForMember(pdh => pdh.Id, o => o.Ignore());
            CreateMap<ProductDetails, ProductDetailsDTO>()
                .ForMember(pdh => pdh.ExpenseAccountNo, o => o.MapFrom(s => s.ExpenseAccount.Number))
                .ForMember(pdh => pdh.ExpenseAccountName, o => o.MapFrom(s => s.ExpenseAccount.Name))
                .ForMember(pdh => pdh.UpdatedBy, o => o.MapFrom(s => s.UserId))
                .ForMember(pdh => pdh.UpdatedDate, o => o.MapFrom(s => s.ChangeDate))
                .ForMember(pdh => pdh.ApprovedRejectedBy, o => o.MapFrom(s => s.ApproveRejectId))
                .ForMember(pdh => pdh.DisplayOrder, o => o.MapFrom(s => (short)s.Status.DisplayOrder))
                .ForMember(pdh => pdh.Status, o => o.MapFrom(s => s.Status.StatusName));
            CreateMap<ExpenseAccount, ExpenseAccountsDropDownDTO>();
            CreateMap<ExpenseAccountListDTO, ExpenseAccountsReportData>();
            CreateMap<BehaviorDetails, BehaviorDetailsListDTO>()
                .ForMember(beh => beh.ExpenseAccountNo, o => o.MapFrom(s => s.ExpenseAccount.Number))
                .ForMember(beh => beh.ExpenseAccountShortName, o => o.MapFrom(s => s.ExpenseAccount.Name))
                .ForMember(beh => beh.CommissionTable, o => o.MapFrom(s => s.CommissionBehaviorTables.TableName))
                .ForMember(beh => beh.CommissionTableId, o => o.MapFrom(s => s.CommissionBehaviorTables.Id))
                .ForMember(beh => beh.CommissionType, o => o.MapFrom(s => s.CommissionBehaviorColumns.ColumnName))
                .ForMember(beh => beh.Status, o => o.MapFrom(s => s.Status.StatusName))
                .ForMember(beh => beh.StatusId, o => o.MapFrom(s => s.Status.Id))
                .ForMember(beh => beh.DisplayOrder, o => o.MapFrom(s => s.Status.DisplayOrder));
            CreateMap<DboBehaviorDetails.Create.Command, BehaviorDetails>()
                .ForMember(bd => bd.UpdatedBy, o => o.MapFrom(s => s.UserKey))
                .ForMember(bd => bd.Id, o => o.Ignore());
            CreateMap<BehaviorDetails, BehaviorDetailsHistory>()
                .ForMember(bdh => bdh.BehaviorDetails, o => o.MapFrom(s => s))
                .ForMember(bdh => bdh.BehaviorDetailsId, o => o.MapFrom(s => s.Id))
                .ForMember(bdh => bdh.Id, o => o.Ignore());
            CreateMap<ProductDetailsParams, ProductDetailsFilter>();
            CreateMap<ProductDetailsDTO, ProductDetailsReportData>();
            CreateMap<Office, OfficesListDTO>()
                .ForMember(d => d.StatusName, o => o.MapFrom(s => s.Status.StatusName))
                .ForMember(d => d.DisplayOrder, o => o.MapFrom(s => s.Status.DisplayOrder));
            CreateMap<Office, OfficeHistory>()
                .ForMember(o => o.Office, o => o.MapFrom(s => s))
                .ForMember(o => o.OfficeId, o => o.MapFrom(s => s.Id))
                .ForMember(d => d.Id, o => o.Ignore());
            CreateMap<OfficesListDTO, OfficesReportData>();
            CreateMap<OfficesParams, OfficesFilter>();
            CreateMap<CommissionsParameter, ParametersListDTO>()
                .ForMember(d => d.StatusName, o => o.MapFrom(s => s.Status.StatusName))
                .ForMember(d => d.TableName, o => o.MapFrom(s => s.Table.TableName))
                .ForMember(d => d.DisplayOrder, o => o.MapFrom(s => s.Status.DisplayOrder));
            CreateMap<ParametersListDTO, ParametersReportData>();
            CreateMap<ParametersParams, ParametersFilter>();
            CreateMap<ExpenseAccountParams, ExpenseAccountsFilter>();
            CreateMap<ExpenseAccount, ExpenseAccountListDTO>();
            CreateMap<Table, TableDTO>()
                .ForMember(d => d.Name, o => o.MapFrom(s => s.TableName));
            CreateMap<TableColumn, TableColumnDTO>()
                .ForMember(d => d.Name, o => o.MapFrom(s => s.ColumnName));
            CreateMap<CommissionsParameter, CommissionsParameterHistory>()
                .ForMember(d => d.CommissionsParametersId, o => o.MapFrom(s => s.Id))
                .ForMember(d => d.Id, o => o.Ignore());        
            CreateMap<BehaviorParams, BehaviorDetailsFilter>();
            CreateMap<BehaviorDetailsListDTO, BehaviorDetailsReportData>();
            CreateMap<TLSCommissions, TLSCommissionsReportData>();
            CreateMap<DWHTLSCommissions, TLSCommissionsReportData>();
            CreateMap<SL2Commissions, SL2CommissionsReportData>();
            CreateMap<DWHSL2Commissions, SL2CommissionsReportData>();
            CreateMap<SMECommissions, SMECommissionsReportData>();
            CreateMap<DWHSMECommissions, SMECommissionsReportData>();
            CreateMap<ConsolidatedCommissions, ConsolidatedCommissionsReportData>();
            CreateMap<DWHConsolidatedCommissions, ConsolidatedCommissionsReportData>();
        }
    }
}
