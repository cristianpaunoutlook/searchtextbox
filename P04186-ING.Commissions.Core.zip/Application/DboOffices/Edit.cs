﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.OfficiesNotification;
using AutoMapper;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboOffices
{
    public class Edit
    {
        public class Command : IRequest
        {
            public int Id { get; set; }
            public bool IsSMEClub { get; set; }
            public int? MinDigitalSale { get; set; }
            public int? MinLevel1 { get; set; }
            public int? MaxLevel1 { get; set; }
            public string ModifiedBy { get; set; }
            public decimal? CsatPrevQ { get; set; }
        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(o => o.CsatPrevQ)
                    .GreaterThanOrEqualTo(1)
                    .LessThanOrEqualTo(5)
                    .ScalePrecision(2, 3)
                    .When(o => o.CsatPrevQ != null);
            }
        }

        public class Handler : OfficesNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot edit office because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot edit office because there is a running job in progress");
                }

                if (request.MinLevel1 > request.MaxLevel1)
                {
                    logger.LogWarning("Max Level 1 {MaxLevel1} must be greater than Min Level 1 {MinLevel1}!", request.MaxLevel1, request.MinLevel1);
                    throw new RestException(HttpStatusCode.BadRequest, $"Max Level 1: { request.MaxLevel1 } must be greater than Min Level 1: { request.MinLevel1}!");
                }

                var currentOffice = await context.Offices.FindAsync(request.Id);
                if (currentOffice == null)
                    throw new RestException(HttpStatusCode.BadRequest, $"The office is not in the database");
                if (currentOffice.Status.StatusName != Commons.Enums.ObjectStatus.Approved &&
                    currentOffice.Status.StatusName != Commons.Enums.ObjectStatus.Rejected)
                    throw new RestException(HttpStatusCode.BadRequest, $"The office with code {currentOffice.BranchCode} and name {currentOffice.BranchName} should be in Approved or Rejected state to be modified!");

                if (currentOffice.IsSMEClub == request.IsSMEClub && currentOffice.MinLevel1 == request.MinLevel1 &&
                    currentOffice.MaxLevel1 == request.MaxLevel1 && currentOffice.MinDigitalSale == request.MinDigitalSale)
                {
                    logger.LogWarning("There is already an Office with the same code {BranchCode}, name {BranchName} and values {MinDigitalSale}, {MaxLevel1}, {MinLevel1} in database!",
                        currentOffice.BranchCode, currentOffice.BranchName, request.MinDigitalSale, request.MaxLevel1, request.MinLevel1);
                    throw new RestException(HttpStatusCode.BadRequest, $"here is already an Office with the same code, name and values in database!");
                }

                if (currentOffice.BranchCode < Constants.OFFICES_POINTS_LIMIT &&
                    (request.CsatPrevQ == null || request.MinDigitalSale == null || request.MinLevel1 == null || request.MaxLevel1 == null))
                {
                    logger.LogWarning($"All fields are mandatory for offices ({currentOffice.BranchCode} < 5801)");
                    throw new RestException(HttpStatusCode.BadRequest, $"All fields are mandatory for offices ({currentOffice.BranchCode} < 5801)");
                }

                var statusUpdated = await context.ObjectStatus.FirstOrDefaultAsync(o => o.StatusName == Commons.Enums.ObjectStatus.Updated);
                var actionUpdated = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Edit.ToString());

                currentOffice.Status = statusUpdated;
                currentOffice.StatusId = statusUpdated.Id;
                currentOffice.IsSMEClub = request.IsSMEClub;
                currentOffice.MinDigitalSale = request.MinDigitalSale;
                currentOffice.MinLevel1 = request.MinLevel1;
                currentOffice.MaxLevel1 = request.MaxLevel1;
                currentOffice.CsatPrevQ = request.CsatPrevQ;
                currentOffice.ModifiedBy = request.ModifiedBy;
                currentOffice.ModifiedDate = DateTime.Now;

                var officeHistory = mapper.Map<OfficeHistory>(currentOffice);
                officeHistory.Action = actionUpdated;
                officeHistory.ActionId = actionUpdated.Id;
                context.Add(officeHistory);

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendOfficeEmailAsync(currentOffice, currentOffice.Status.StatusName, nameof(NotificationType.SendToApprove));
                    return Unit.Value;
                }
                throw new Exception("Office was not updated!");
            }
        }
    }
}
