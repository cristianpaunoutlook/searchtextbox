﻿using Application.Errors;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboOffices
{
    public class Compare
    {
        public class Query : IRequest<List<OfficeHistory>>
        {
            public int OfficeId { get; set; }
        }

        public class Handler : IRequestHandler<Query, List<OfficeHistory>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<List<OfficeHistory>> Handle(Query request, CancellationToken cancellationToken)
            {
                var officeHist = await context.OfficesHistory
                                        .Where(h => h.OfficeId == request.OfficeId)
                                        .OrderByDescending(h => h.Id)
                                        .Take(2)
                                        .ToListAsync();

                if (officeHist.Count != 2)
                    throw new RestException(HttpStatusCode.BadRequest, $"Requested office has no history!");

                return officeHist;
            }
        }
    }
}
