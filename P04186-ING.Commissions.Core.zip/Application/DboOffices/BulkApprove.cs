﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.Errors;
using Application.Helpers;
using Application.Interfaces;
using Application.Notifications.OfficiesNotification;
using Application.StateManagement;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboOffices
{
    public class BulkApprove
    {
        public class Command : IRequest
        {
            public string UserId { get; set; }
            public OfficesParams Filter { get; set; }
        }
        public class Handler : OfficesNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, IMapper mapper, ILogger<Handler> logger,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot bulk approve offices because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot bulk approve offices because there is a running job in progress");
                }

                logger.LogInformation($"Bulk approve offices!");

                if (request.Filter.Context == Constants.TOFILLREQ)
                    throw new RestException(HttpStatusCode.BadRequest, "Can't reject offices without mandatory fields!");

                List<Office> offices = new List<Office>();
                if (request.Filter.Context == Constants.TOAPPROVE)
                    offices = await context.Offices.Where(o => o.StatusId == (short)ObjectStatusId.Updated
                                                || o.StatusId == (short)ObjectStatusId.RejectAdd
                                                || o.StatusId == (short)ObjectStatusId.PendingDelete).ToListAsync();

                if (string.IsNullOrEmpty(request.Filter.Context))
                    offices = await context.Offices.FilterIfValueProvided(request.Filter.AgentCode != null, o => o.AgentCode == request.Filter.AgentCode)
                        .FilterIfValueProvided(request.Filter.BranchCode != null, o => o.BranchCode == request.Filter.BranchCode)
                        .FilterIfValueProvided(!string.IsNullOrEmpty(request.Filter.BranchName), o => o.BranchName.Contains(request.Filter.BranchName))
                        .FilterIfValueProvided(request.Filter.StatusId != -1, o => o.StatusId == request.Filter.StatusId)
                        .FilterIfValueProvided(request.Filter.StatusId == -1, o => o.StatusId == (short)ObjectStatusId.Updated || o.StatusId == (short)ObjectStatusId.Added || o.StatusId == (short)ObjectStatusId.PendingDelete)
                        .FilterIfValueProvided(request.Filter.IsSMEClub != null, o => o.IsSMEClub == request.Filter.IsSMEClub)
                        .FilterIfValueProvided(request.UserId != null, o => o.ModifiedBy != request.UserId).ToListAsync();

                if (offices == null || offices.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "There are no offices in the database corespondig to your search criterias!");
                }

                foreach (var office in offices)
                {
                    var oldStatus = office.Status.StatusName;
                    var statusManger = new StatusStateManagement(office.Status.StatusName, EntitiesForStateManagement.Office);
                    statusManger.SetNextState(StateTrigger.Approve);
                    var objStatus = await context.ObjectStatus.FirstOrDefaultAsync(os => os.StatusName == statusManger.State.ToString());
                    var actionApproved = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Approve.ToString());
                    office.Status = objStatus;
                    office.StatusId = objStatus.Id;
                    office.ApprovedRejectedBy = request.UserId;
                    office.ApprovedRejectedDate = DateTime.Now;
                    var officeHistory = mapper.Map<OfficeHistory>(office);
                    officeHistory.Action = actionApproved;
                    officeHistory.ActionId = actionApproved.Id;
                    context.Add(officeHistory);
                }

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendOfficeEmailForBulkAsync(request.UserId, nameof(NotificationType.BulkApproved));
                    return Unit.Value;
                }
                throw new Exception("The offices was not rejected!");
            }
        }
    }
}
