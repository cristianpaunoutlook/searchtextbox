﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.OfficiesNotification;
using Application.StateManagement;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboOffices
{
    public class Approve
    {
        public class Command : IRequest
        {
            public int Id { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : OfficesNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, IMapper mapper, ILogger<Handler> logger,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot approve office because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot approve office because there is a running job in progress");
                }

                logger.LogInformation($"Approve office {request.Id}");
                var office = await context.Offices.FindAsync(request.Id);
                if (office == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "This office is not in the database!");
                }

                if (request.UserKey == office.ModifiedBy)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"You have changed the office {office.BranchCode} so you can not approve the changes!");
                }
                var oldStatus = office.Status.StatusName;
                var statusManger = new StatusStateManagement(office.Status.StatusName, EntitiesForStateManagement.Office);
                statusManger.SetNextState(StateTrigger.Approve);
                var objStatus = await context.ObjectStatus.FirstOrDefaultAsync(os => os.StatusName == statusManger.State.ToString());
                var actionApproved = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Approve.ToString());
                office.Status = objStatus;
                office.StatusId = objStatus.Id;
                office.ApprovedRejectedBy = request.UserKey;
                office.ApprovedRejectedDate = DateTime.Now;
                var officeHistory = mapper.Map<OfficeHistory>(office);
                officeHistory.Action = actionApproved;
                officeHistory.ActionId = actionApproved.Id;
                context.Add(officeHistory);

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendOfficeEmailAsync(office, oldStatus, nameof(NotificationType.Approved));
                    return Unit.Value;
                }
                throw new Exception("The office was not approved!");
            }
        }
    }
}
