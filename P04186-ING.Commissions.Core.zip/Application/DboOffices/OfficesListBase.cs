﻿using Application.Commons.Constants;
using Application.DTO;
using Application.Export.OfficesReport;
using Application.Helpers;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Persistence;
using System.Linq;

namespace Application.DboOffices
{
    public class OfficesListBase
    {
        public IQueryable<OfficesListDTO> OfficesList(CommissionsContext context, IMapper mapper,
            OfficesFilter filter)
        {
            if(filter.Context == Constants.TOAPPROVE)
                return context.Offices
                                .Where(o => o.Status.StatusName != Commons.Enums.ObjectStatus.Deleted &&
                                                o.Status.StatusName != Commons.Enums.ObjectStatus.RejectAdd &&
                                                o.Status.StatusName != Commons.Enums.ObjectStatus.Approved)
                                .OrderBy(o => o.Status.DisplayOrder).ThenBy(o => o.BranchName)
                                .ProjectTo<OfficesListDTO>(mapper.ConfigurationProvider);

            if(filter.Context == Constants.TOFILLREQ)
                return context.Offices
                                .Where(o => o.BranchCode <= 5800 && (o.MinDigitalSale == null ||
                                                                        o.MinLevel1 == null ||
                                                                        o.MaxLevel1 == null ||
                                                                        o.CsatPrevQ == null ||
                                                                        o.NoDigitalSales == null ||
                                                                        o.DigitalSales == null))
                                .OrderBy(o => o.Status.DisplayOrder).ThenBy(o => o.BranchName)
                                .ProjectTo<OfficesListDTO>(mapper.ConfigurationProvider);

            var offices = context.Offices
                                            .Where(prd => prd.Status.StatusName != Commons.Enums.ObjectStatus.Deleted &&
                                                            prd.Status.StatusName != Commons.Enums.ObjectStatus.RejectAdd)
                                            .ProjectTo<OfficesListDTO>(mapper.ConfigurationProvider);

            offices = offices.FilterIfValueProvided(filter.AgentCode != null, o => o.AgentCode == filter.AgentCode)
                        .FilterIfValueProvided(filter.BranchCode != null, o => o.BranchCode == filter.BranchCode)
                        .FilterIfValueProvided(!string.IsNullOrEmpty(filter.BranchName), o => o.BranchName.Contains(filter.BranchName))
                        .FilterIfValueProvided(filter.StatusId != -1, o => o.StatusId == filter.StatusId)
                        .FilterIfValueProvided(filter.IsSMEClub != null, o => o.IsSMEClub == filter.IsSMEClub)
                        .OrderBy(o => o.DisplayOrder).ThenBy(o => o.BranchName);
            return offices;
        }
    }
}
