﻿using Application.DTO;
using Application.Export.OfficesReport;
using Application.Helpers;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboOffices
{
    public class List
    {
        public class Query : IRequest<PagedList<OfficesListDTO>>
        {
            public OfficesParams OfficesParams { get; set; }
        }

        public class Handler : OfficesListBase, IRequestHandler<Query, PagedList<OfficesListDTO>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<PagedList<OfficesListDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get offices list");
                var filter = mapper.Map<OfficesFilter>(request.OfficesParams);

                var offices = OfficesList(context, mapper, filter);

                return await offices.GetPaginatedListAndCheckIfEmpty(request.OfficesParams.PageNumber, request.OfficesParams.PageSize);
            }
        }
    }
}
