﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Application.Interfaces;
using Application.Interfaces.Import;
using Application.Notifications.OfficiesNotification;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboOffices
{
    public class ImportFile
    {
        public class Command : IRequest<ImportOfficesFileDTO>
        {
            public IFormFile FileToImport { get; set; }
            public string UserKey { get; set; }
            public DateTime UpdateDate { get; set; }
        }

        public class ImportOffice
        {
            [Description("Branch Code")]
            public int BranchCode { get; set; }
            public bool IsSMEClub { get; set; }
            [Description("CSAT previous Q")]
            public decimal? CSATPreviousQ { get; set; }
            [Description("%Digital Sales Level 1")]
            public int? DigitalSalesLevel1 { get; set; }
            [Description("%Digital Sales Level 2")]
            public int? DigitalSalesLevel2 { get; set; }
            [Description("Target Digital Sales (min)")]
            public int? TargetDigitalSales { get; set; }
        }

        public class Handler : FileImportNotificationBase, IRequestHandler<Command, ImportOfficesFileDTO>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IImportFromExcel<ImportOffice> importFile;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IImportFromExcel<ImportOffice> importFile, IMapper mapper,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.logger = logger;
                this.importFile = importFile;
                this.mapper = mapper;
            }

            public async Task<ImportOfficesFileDTO> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot upload offices because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot upload offices because there is a running job in progress");
                }

                var result = new ImportOfficesFileDTO();
                var savedFileFullPath = await SaveFile(request);

                var listToImport = GetListFromFile(savedFileFullPath);
                ValidateFileContent(listToImport, result);

                var officesList = await context
                                            .Offices
                                            .Where(o =>
                                                o.Status.StatusName == Commons.Enums.ObjectStatus.Approved ||
                                                o.Status.StatusName == Commons.Enums.ObjectStatus.Rejected
                                            )
                                            .ToListAsync();
                var officesToUpdate = from o in officesList
                                      join lo in listToImport on o.BranchCode equals lo.BranchCode
                                      where
                                         o.CsatPrevQ != lo.CSATPreviousQ ||
                                         o.IsSMEClub != lo.IsSMEClub ||
                                         o.MinDigitalSale != lo.TargetDigitalSales ||
                                         o.MinLevel1 != lo.DigitalSalesLevel1 ||
                                         o.MaxLevel1 != lo.DigitalSalesLevel2
                                      select lo;

                result.NoOfficesUpdated = officesToUpdate.Count();
                if (result.NoOfficesUpdated == 0)
                    result.Messages.Add("There are no offices to update!");

                if (result.Messages.Count() > 0)
                    return result;

                officesList.
                    Where(o => officesToUpdate.Select(oa => oa.BranchCode).Contains(o.BranchCode))
                    .ToList()
                    .ForEach(o =>
                    {
                        var toUpdate = listToImport.Where(li => li.BranchCode == o.BranchCode).FirstOrDefault();
                        o.CsatPrevQ = toUpdate.CSATPreviousQ;
                        o.IsSMEClub = toUpdate.IsSMEClub;
                        o.MinLevel1 = toUpdate.DigitalSalesLevel1;
                        o.MaxLevel1 = toUpdate.DigitalSalesLevel2;
                        o.MinDigitalSale = toUpdate.TargetDigitalSales;
                        o.ModifiedBy = request.UserKey;
                        o.ModifiedDate = request.UpdateDate;
                        o.StatusId = (short)ObjectStatusId.Updated;
                        var officeHist = mapper.Map<OfficeHistory>(o);
                        officeHist.ActionId = (int)Commons.Enums.ObjectAction.Edit;
                        context.OfficesHistory.Add(officeHist);
                    });

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendFileImportEmailAsync(result.NoOfficesUpdated);
                    return result;
                }
                throw new Exception("Office was not updated!");

            }

            private List<ImportOffice> GetListFromFile(string savedFileFullPath)
            {
                List<ImportOffice> listToImport;
                try
                {
                    listToImport = importFile.GetListFromFile(savedFileFullPath);
                }
                catch (Exception ex)
                {
                    if (ex.Message.StartsWith("BAD INPUT: "))
                        throw new RestException(HttpStatusCode.BadRequest, ex.Message.Substring(10));
                    throw;
                }

                return listToImport;
            }

            private void ValidateFileContent(List<ImportOffice> listToImport, ImportOfficesFileDTO result)
            {
                var duplicateBranchCode = from o in listToImport
                                          group o by o.BranchCode into g
                                          where g.Count() > 1
                                          select g.Key;

                if (duplicateBranchCode.Count() > 0)
                {
                    var officesList = string.Join(", ", duplicateBranchCode.Distinct());
                    result.Messages.Add($"Multiple rows for Branch Code {officesList} in file!");
                }

                var mandatoryOfficeData = listToImport.Where(o =>
                    o.BranchCode < Constants.OFFICES_POINTS_LIMIT &&
                    (o.CSATPreviousQ == null ||
                    o.DigitalSalesLevel1 == null ||
                    o.DigitalSalesLevel2 == null ||
                    o.TargetDigitalSales == null)).Select(o => o.BranchCode);

                if (mandatoryOfficeData.Count() > 0)
                {
                    var officesList = string.Join(", ", mandatoryOfficeData.Distinct());
                    result.Messages.Add($"Missing data from file for Branch: {officesList}!");
                }

                var invalidData = listToImport.Where(o =>
                        (o.CSATPreviousQ != null && (o.CSATPreviousQ < Constants.MIN_CSAT_PREV_Q || o.CSATPreviousQ > Constants.MAX_CSAT_PREV_Q) && o.BranchCode < Constants.OFFICES_POINTS_LIMIT) ||
                        (o.CSATPreviousQ != null && o.CSATPreviousQ != 0 && (o.CSATPreviousQ < Constants.MIN_CSAT_PREV_Q || o.CSATPreviousQ > Constants.MAX_CSAT_PREV_Q) && o.BranchCode >= Constants.OFFICES_POINTS_LIMIT) ||
                        (o.TargetDigitalSales != null && o.TargetDigitalSales <= 0) ||
                        (o.DigitalSalesLevel1 != null && o.DigitalSalesLevel1 <= 0) ||
                        (o.DigitalSalesLevel2 != null && o.DigitalSalesLevel2 <= 0) ||
                        (o.DigitalSalesLevel1 != null && o.DigitalSalesLevel2 != null && o.DigitalSalesLevel1 >= o.DigitalSalesLevel2)
                        ).Select(o => o.BranchCode);
                if (invalidData.Count() > 0)
                {
                    var officesList = string.Join(", ", invalidData.Distinct());
                    result.Messages.Add($"Invalid Data Type in file for Branch: {officesList}!");
                }
            }

            private async Task<string> SaveFile(Command request)
            {
                logger.LogInformation($"Start uploading file {request.FileToImport.FileName} to the server!");
                var file = request.FileToImport;
                if (file.Length <= 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"File is empty!");
                }

                if (Path.GetExtension(file.FileName) != ".xlsx")
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"The file must have .xlsx extension!");
                }

                var folderName = configuration.GetSection("ImportFilePath").Value;
                string savedFileFullPath = "";
                if (folderName == null || !Directory.Exists(folderName))
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Path to save file is invalid, please contact administrator!");
                }

                try
                {
                    var savedFileName = Path.GetFileNameWithoutExtension(file.FileName) + DateTime.Now.ToString("yyyyMMddHHmmss") + Path.GetExtension(file.FileName);
                    savedFileFullPath = Path.Combine(folderName, savedFileName);
                    using (var stream = new FileStream(savedFileFullPath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    var backupPath = $"{folderName}\\Backup";
                    if (!Directory.Exists(backupPath))
                    {
                        throw new RestException(HttpStatusCode.BadRequest, $"Path to create archive file is invalid, please contact administrator!");
                    }
                    var archiveName = Path.GetFileNameWithoutExtension(file.FileName) + DateTime.Now.ToString("yyyyMMddHHmmss") + ".zip";
                    var backupFullPath = Path.Combine(backupPath, archiveName);
                    using (var zipToCreate = new FileStream(backupFullPath, FileMode.Create))
                    {
                        using (var archive = new ZipArchive(zipToCreate, ZipArchiveMode.Update))
                        {
                            logger.LogInformation($"Add file {savedFileName} to archive!");
                            archive.CreateEntryFromFile(savedFileFullPath, savedFileName);
                        }
                    }
                }
                catch (Exception)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"File import error please contact administrator!");
                }

                return savedFileFullPath;
            }
        }
    }
}
