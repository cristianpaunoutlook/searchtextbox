﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.OfficiesNotification;
using Application.StateManagement;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboOffices
{
    public class Reject
    {
        public class Command : IRequest
        {
            public int Id { get; set; }
            public string RejectReason { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : OfficesNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, IMapper mapper, ILogger<Handler> logger,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot reject office because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot reject office because there is a running job in progress");
                }

                logger.LogInformation($"Reject office {request.Id}");
                var office = await context.Offices.FindAsync(request.Id);
                if (office == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "This office is not in the database!");
                }

                if (request.UserKey == office.ModifiedBy)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"You have changed the office {office.BranchCode} so you can not approve the changes!");
                }
                var oldStatus = office.Status.StatusName;
                var statusManger = new StatusStateManagement(office.Status.StatusName, EntitiesForStateManagement.Office);
                statusManger.SetNextState(StateTrigger.Reject);
                var objStatus = await context.ObjectStatus.FirstOrDefaultAsync(os => os.StatusName == statusManger.State.ToString());
                var actionReject = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Reject.ToString());
                office.Status = objStatus;
                office.StatusId = objStatus.Id;
                office.ApprovedRejectedBy = request.UserKey;
                office.ApprovedRejectedDate = DateTime.Now;
                office.RejectReason = request.RejectReason;
                var officeHistory = mapper.Map<OfficeHistory>(office);
                officeHistory.Action = actionReject;
                officeHistory.ActionId = actionReject.Id;
                context.Add(officeHistory);

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendOfficeEmailAsync(office, oldStatus, nameof(NotificationType.Rejected));
                    return Unit.Value;
                }
                throw new Exception("The office was not rejected!");
            }
        }
    }
}
