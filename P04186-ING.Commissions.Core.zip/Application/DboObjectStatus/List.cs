﻿using Domain;
using Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using Application.Commons.Enums;

namespace Application.DboObjectStatus
{
    public class List
    {
        public class Query : IRequest<List<Domain.ObjectStatus>> { }

        public class Handler : IRequestHandler<Query, List<Domain.ObjectStatus>>
        {
            private readonly CommissionsContext _context;

            public Handler(CommissionsContext context)
            {
                _context = context;
            }
            public async Task<List<Domain.ObjectStatus>> Handle(Query request, CancellationToken cancellationToken) =>
                await _context.ObjectStatus.ToListAsync();
        }
    }
}
