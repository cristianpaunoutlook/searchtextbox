﻿using Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

namespace Application.DboObjectStatus
{
    public class StatusListRestricted
    {
        public class Query : IRequest<List<Domain.ObjectStatus>>
        {
            public bool ImportedEntities { get; set; }
        }

        public class Handler : IRequestHandler<Query, List<Domain.ObjectStatus>>
        {
            private readonly CommissionsContext _context;

            public Handler(CommissionsContext context)
            {
                _context = context;
            }

            public async Task<List<Domain.ObjectStatus>> Handle(Query request, CancellationToken cancellationToken)
            {

                var listExceptDeletedRejectAdd =  _context.ObjectStatus.Where(s => s.StatusName != Commons.Enums.ObjectStatus.Deleted
                  && s.StatusName != Commons.Enums.ObjectStatus.RejectAdd);

                if (request.ImportedEntities == true)
                    listExceptDeletedRejectAdd = listExceptDeletedRejectAdd.Where(s => s.StatusName != Commons.Enums.ObjectStatus.Added
                    && s.StatusName != Commons.Enums.ObjectStatus.PendingDelete);

                return await listExceptDeletedRejectAdd.ToListAsync();         
            }
        }
    }
}