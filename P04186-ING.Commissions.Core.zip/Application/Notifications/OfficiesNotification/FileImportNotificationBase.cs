﻿using Application.Interfaces;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace Application.Notifications.OfficiesNotification
{
    [ExcludeFromCodeCoverage]
    public class FileImportNotificationBase : NotificationBase
    {
        protected readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        public FileImportNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("Notifications:OfficesEmail").Value.Split(";");
        }

        private FileImportNotificationParams CreateNotificationParam(int noOfLinesUpdated)
        {
            var notificationParams = new FileImportNotificationParams(configuration)
            {
                NoOfLinesUpdated = noOfLinesUpdated
            };

            return notificationParams;
        }

        public async Task SendFileImportEmailAsync(int noOfLinesUpdated)
        {
            var notificationParams = CreateNotificationParam(noOfLinesUpdated);

            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\OfficiesNotification\\EmailTemplates\\UploadOfficesFile.html";

            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                "Offices - Successfully uploaded file",
                CreateEmailBody(notificationParams, pathToFile));
        }
    }
}
