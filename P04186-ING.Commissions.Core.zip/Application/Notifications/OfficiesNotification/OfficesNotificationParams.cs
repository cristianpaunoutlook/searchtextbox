﻿using Microsoft.Extensions.Configuration;

namespace Application.Notifications.OfficiesNotification
{
    public class OfficesNotificationParams
    {
        private readonly IConfiguration configuration;

        public OfficesNotificationParams(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public int? BranchCode { get; set; }
        public string BranchName { get; set; }
        public string KeyUser { get; set; }
        public string Action { get; set; }
        public string NotificationType { get; set; }
        public string RejectReason { get; set; }
        public string Url { get; set; }
    }
}
