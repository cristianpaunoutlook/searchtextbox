﻿using Application.Commons.Enums;
using Application.Interfaces;
using Domain;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Application.Notifications.OfficiesNotification
{
    public class OfficesNotificationBase : NotificationBase
    {
        private readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        private readonly Dictionary<string, string> actions = new Dictionary<string, string>()
            {
                { nameof(NotificationAction.Add), NotificationAction.Add },
                { nameof(NotificationAction.Edit), NotificationAction.Edit },
                { nameof(NotificationAction.Delete), NotificationAction.Delete },
                { Commons.Enums.ObjectStatus.Added, NotificationAction.Add },
                { Commons.Enums.ObjectStatus.Updated, NotificationAction.Edit},
                { Commons.Enums.ObjectStatus.PendingDelete, NotificationAction.Delete },
                { Commons.Enums.ObjectStatus.RejectAdd, NotificationAction.ApproveRejectAdd}
            };

        public OfficesNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }
        private string CreateEmailSubject(string branchName, string notificationType)
        {
            string emailSubject = $"Office {branchName} ";

            if (notificationType == nameof(NotificationType.SendToApprove))
            {
                emailSubject += $"- Approval Request";
            }
            else if (notificationType == nameof(NotificationType.Approved))
            {
                emailSubject += $"has been approved";
            }
            else if (notificationType == nameof(NotificationType.Rejected))
            {
                emailSubject += $"has been rejected";
            }
            else if (notificationType == nameof(NotificationType.BulkApproved))
            {
                emailSubject = $"Offices has been approved";
            }
            else
            {
                emailSubject = $"Offices has been rejected";
            }
            return emailSubject;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("Notifications:OfficesEmail").Value.Split(";");
        }

        public async Task SendOfficeEmailAsync(Office office, string statusName, string notificationType)
        {
            var notificationParams = CreateNotificationParam(office, actions[statusName], notificationType);

            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\OfficiesNotification\\EmailTemplates\\Offices{notificationParams.NotificationType}.html";

            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                CreateEmailSubject(notificationParams.BranchName, notificationParams.NotificationType),
                CreateEmailBody(notificationParams, pathToFile));
        }

        public async Task SendOfficeEmailForBulkAsync(string userId, string notificationType, string rejectReason = null )
        {
            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\OfficiesNotification\\EmailTemplates\\Offices{notificationType}.html";
            var notificationParams = CreateBulkNotificationParam(userId, rejectReason, notificationType);
            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                CreateEmailSubject(null, notificationType),
                CreateEmailBody(notificationParams, pathToFile));
        }

        private OfficesNotificationParams CreateNotificationParam(Office office, string action, string notificationType)
        {
            var notificationParams = new OfficesNotificationParams(configuration)
            {
                BranchCode = office.BranchCode,
                BranchName = office.BranchName,
                KeyUser = notificationType == nameof(NotificationType.Approved) || notificationType == nameof(NotificationType.Rejected) ? office.ApprovedRejectedBy : office.ModifiedBy,
                Action = action,
                RejectReason = office.RejectReason,
                NotificationType = notificationType,
                Url = $"{configuration.GetSection("Notifications:ApplicationPath").Value}offices-maintenance/{office.BranchCode}",
            };

            return notificationParams;
        }

        private OfficesNotificationParams CreateBulkNotificationParam(string userId, string rejectReason, string notificationType)
        {
            var notificationParams = new OfficesNotificationParams(configuration)
            {
                KeyUser = userId ,
                RejectReason = rejectReason,
                NotificationType = notificationType,
                Url = $"{configuration.GetSection("Notifications:ApplicationPath").Value}offices-maintenance/"
            };

            return notificationParams;
        }
    }
}
