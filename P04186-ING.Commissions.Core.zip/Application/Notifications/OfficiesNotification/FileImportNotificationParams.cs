﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Notifications.OfficiesNotification
{
    public class FileImportNotificationParams
    {
        private readonly IConfiguration configuration;

        public FileImportNotificationParams(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public string Url { get { return $"{configuration.GetSection("Notifications:ApplicationPath").Value}offices-maintenance/__fileupload__"; } }

        public int NoOfLinesUpdated { get; set; }
    }
}
