﻿using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;

namespace Application.Notifications
{
    [ExcludeFromCodeCoverage]
    public class NotificationBase
    {
        protected string CreateEmailBody<T>(T notificationParams, string pathToFile) where T : class
        {
            string body = ReadTextFromMailTemplate(pathToFile);

            PropertyInfo[] properties = notificationParams.GetType().GetProperties();
            foreach (PropertyInfo pi in properties)
            {
                var propertyValue = pi.GetValue(notificationParams, null);
                body = body.Replace($"[{pi.Name}]", propertyValue == null ? string.Empty : propertyValue.ToString());
            }

            return body;
        }

        protected string ReadTextFromMailTemplate(string pathToFile)
        {
            string body = string.Empty;

            using (StreamReader SourceReader = File.OpenText(pathToFile))
            {
                body = SourceReader.ReadToEnd();
            }

            return body;
        }
    }
}
