﻿using Application.Commons.Enums;
using Application.Interfaces;
using Domain;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Application.Notifications.ProductDetailsNotification
{
    [ExcludeFromCodeCoverage]
    public class ProductDetailsNotificationBase : NotificationBase
    {
        private readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        private readonly Dictionary<string, string> actions = new Dictionary<string, string>()
        {
            { nameof(NotificationAction.Add), NotificationAction.Add },
            { nameof(NotificationAction.Edit), NotificationAction.Edit },
            { nameof(NotificationAction.Delete), NotificationAction.Delete },
            { Commons.Enums.ObjectStatus.Added, NotificationAction.Add },
            { Commons.Enums.ObjectStatus.Updated, NotificationAction.Edit},
            { Commons.Enums.ObjectStatus.PendingDelete, NotificationAction.Delete },
            { Commons.Enums.ObjectStatus.RejectAdd, NotificationAction.ApproveRejectAdd},
            { Commons.Enums.ObjectStatus.Approved, NotificationAction.ApproveRejectDelete}

        };

        public ProductDetailsNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }

        private string CreateEmailSubject(string productType, string notificationType)
        {
            string emailSubject = $"Product {productType} - ";

            if (notificationType == nameof(NotificationType.SendToApprove))
            {
                emailSubject += $"Approval Request";
            }
            else if (notificationType == nameof(NotificationType.Approved))
            {
                emailSubject += $"has been approved";
            }
            else
            {
                emailSubject += $"has been rejected";
            }

            return emailSubject;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("Notifications:ProductDetailsEmail").Value.Split(";");
        }

        public async Task SendProductDetailsEmailAsync(ProductDetails product, string statusName, string notificationType)
        {
            var notificationParams = CreateNotificationParam(product, actions[statusName], notificationType);

            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\ProductDetailsNotification\\EmailTemplates\\ProductDetails{notificationParams.NotificationType}.html";

            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                CreateEmailSubject(notificationParams.ProductType, notificationParams.NotificationType),
                CreateEmailBody(notificationParams, pathToFile));
        }

        private ProductDetailsNotificationParams CreateNotificationParam(ProductDetails product, string action, string notificationType)
        {
            var notificationParams = new ProductDetailsNotificationParams(configuration)
            {
                ProductType = product.ProductType,
                KeyUser = notificationType == nameof(NotificationType.Approved) || notificationType == nameof(NotificationType.Rejected) ? product.ApproveRejectId : product.UserId,
                Action = action,
                NotificationType = notificationType,
                RejectReason = product.RejectReason

            };

            return notificationParams;
        }
    }
}
