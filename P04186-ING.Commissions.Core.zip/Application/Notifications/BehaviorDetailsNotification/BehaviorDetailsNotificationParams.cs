﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Notifications.BehaviorDetailsNotification
{
    [ExcludeFromCodeCoverage]
    public class BehaviorDetailsNotificationParams
    {
        private readonly IConfiguration configuration;

        public BehaviorDetailsNotificationParams(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public string BehaviorType { get; set; }
        public string Description { get; set; }
        public string KeyUser { get; set; }
        public string Action { get; set; }
        public string NotificationType { get; set; }
        public string RejectReason { get; set; }
        public string Url { get { return $"{configuration.GetSection("Notifications:ApplicationPath").Value}behaviors-maintenance/{BehaviorType}"; } }
    }
}
