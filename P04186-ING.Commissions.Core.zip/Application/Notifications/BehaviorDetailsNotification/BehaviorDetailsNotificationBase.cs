﻿using Application.Commons.Enums;
using Application.Interfaces;
using Domain;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Application.Notifications.BehaviorDetailsNotification
{
    [ExcludeFromCodeCoverage]
    public class BehaviorDetailsNotificationBase : NotificationBase
    {
        private readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        private readonly Dictionary<string, string> actions = new Dictionary<string, string>()
            {
                { nameof(NotificationAction.Add), NotificationAction.Add },
                { nameof(NotificationAction.Edit), NotificationAction.Edit },
                { nameof(NotificationAction.Delete), NotificationAction.Delete },
                { Commons.Enums.ObjectStatus.Added, NotificationAction.Add },
                { Commons.Enums.ObjectStatus.Updated, NotificationAction.Edit},
                { Commons.Enums.ObjectStatus.PendingDelete, NotificationAction.Delete },
                { Commons.Enums.ObjectStatus.RejectAdd, NotificationAction.ApproveRejectAdd}
            };


        public BehaviorDetailsNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }

        private string CreateEmailSubject(string behaviorName, string notificationType)
        {
            string emailSubject = $"Behavior name {behaviorName} ";

            if (notificationType == nameof(NotificationType.SendToApprove))
            {
                emailSubject += $"- Approval Request";
            }
            else if (notificationType == nameof(NotificationType.Approved))
            {
                emailSubject += $"has been approved";
            }
            else
            {
                emailSubject += $"has been rejected";
            }

            return emailSubject;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("Notifications:BehaviorDetailsEmail").Value.Split(";");
        }

        public async Task SendBehaviorDetailsEmailAsync(BehaviorDetails behavior, string statusName, string notificationType)
        {
            var notificationParams = CreateNotificationParam(behavior, actions[statusName], notificationType);

            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\BehaviorDetailsNotification\\EmailTemplates\\BehaviorDetails{notificationParams.NotificationType}.html";

            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                CreateEmailSubject(notificationParams.BehaviorType, notificationParams.NotificationType),
                CreateEmailBody(notificationParams, pathToFile));
        }

        private BehaviorDetailsNotificationParams CreateNotificationParam(BehaviorDetails behavior, string action, string notificationType)
        {
            var notificationParams = new BehaviorDetailsNotificationParams(configuration)
            {
                BehaviorType = behavior.Type,
                Description = behavior.Description,
                KeyUser = notificationType == nameof(NotificationType.Approved) || notificationType == nameof(NotificationType.Rejected) ? behavior.ApproveRejectBy : behavior.UpdatedBy,
                Action = action,
                RejectReason = behavior.RejectReason,
                NotificationType = notificationType
            };

            return notificationParams;
        }
    }
}
