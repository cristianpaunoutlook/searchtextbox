﻿using Application.Commons.Enums;
using Application.Interfaces;
using Domain;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Application.Notifications.ParameterNotification
{
    public class ParameterNotificationBase : NotificationBase
    {
        private readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        private readonly Dictionary<string, string> actions = new Dictionary<string, string>()
            {
                { nameof(NotificationAction.Add), NotificationAction.Add },
                { nameof(NotificationAction.Edit), NotificationAction.Edit },
                { nameof(NotificationAction.Delete), NotificationAction.Delete },
                { Commons.Enums.ObjectStatus.Added, NotificationAction.Add },
                { Commons.Enums.ObjectStatus.Updated, NotificationAction.Edit},
                { Commons.Enums.ObjectStatus.PendingDelete, NotificationAction.Delete },
                { Commons.Enums.ObjectStatus.RejectAdd, NotificationAction.ApproveRejectAdd}
            };


        public ParameterNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }

        private string CreateEmailSubject(string name, string notificationType)
        {
            string emailSubject = $"Parameter {name} ";

            if (notificationType == nameof(NotificationType.SendToApprove))
            {
                emailSubject += $"- Approval Request";
            }
            else if (notificationType == nameof(NotificationType.Approved))
            {
                emailSubject += $"has been approved";
            }
            else
            {
                emailSubject += $"has been rejected";
            }

            return emailSubject;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("Notifications:ParameterEmail").Value.Split(";");
        }

        public async Task SendParameterEmailAsync(CommissionsParameter parameter, string statusName, string notificationType)
        {
            var notificationParams = CreateNotificationParam(parameter, actions[statusName], notificationType);

            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\ParameterNotification\\EmailTemplates\\Parameter{notificationParams.NotificationType}.html";

            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                CreateEmailSubject(notificationParams.Name, notificationParams.NotificationType),
                CreateEmailBody(notificationParams, pathToFile));
        }

        private ParameterNotificationValues CreateNotificationParam(CommissionsParameter parameter, string action, string notificationType)
        {
            var notificationParams = new ParameterNotificationValues(configuration)
            {
                Name = parameter.Name,
                KeyUser = notificationType == nameof(NotificationType.Approved) || notificationType == nameof(NotificationType.Rejected) ? parameter.ApprovedRejectedBy : parameter.UpdatedBy,
                Action = action,
                RejectReason = parameter.RejectReason,
                NotificationType = notificationType
            };

            return notificationParams;
        }
    }
}

