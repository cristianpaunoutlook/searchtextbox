﻿namespace Application.Helpers
{
    public class ProductDetailsParams : PaginationParams
    {
        public string ProductType { get; set; }
        public string ShortName { get; set; }
        public short? StatusId { get; set; }
        public string Context { get; set; }
    }
}
