﻿namespace Application.Helpers
{
    public class ExpenseAccountParams : PaginationParams
    {
        public string AccountNo { get; set; }
        public string AccountName { get; set; }
    }
}
