﻿namespace Application.Helpers
{
    public class BehaviorParams : PaginationParams
    {
        public string BehaviorType { get; set; }
        public string Description { get; set; }
        public int StatusId { get; set; }
        public int CommissionsTableId { get; set; }
        public string Context { get; set; }
    }
}
