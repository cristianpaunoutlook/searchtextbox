﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Helpers
{
    public class ParametersParams : PaginationParams
    {
        public string Name { get; set; }
        public short StatusId { get; set; }
        public int TableId { get; set; }
        public string Context { get; set; }
    }
}
