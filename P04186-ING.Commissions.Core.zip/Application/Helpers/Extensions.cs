﻿using Application.Commons.Enums;
using Application.Errors;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Threading.Tasks;

namespace Application.Helpers
{
    public static class Extensions
    {
        public static IQueryable<T> OrderByPropertyName<T>(this IQueryable<T> listToSort, string sortField, string sortOrder)
        {
            var param = Expression.Parameter(typeof(T), "p");
            var prop = Expression.Property(param, sortField);
            var exp = Expression.Lambda(prop, param);
            string method = sortOrder.ToLower() == "asc" ? nameof(SortOrder.OrderBy) : nameof(SortOrder.OrderByDescending);
            Type[] types = new Type[] { listToSort.ElementType, exp.Body.Type };
            var rs = Expression.Call(typeof(Queryable), method, types, listToSort.Expression, exp);
            return listToSort.Provider.CreateQuery<T>(rs);
        }

        public static IQueryable<T> FilterIfValueProvided<T>(this IQueryable<T> listToFilter, bool valueProvided, Expression<Func<T, bool>> predicate)
        {
            return valueProvided ? listToFilter.Where(predicate) : listToFilter;
        }

        public static async Task<PagedList<T>> GetPaginatedListAndCheckIfEmpty<T>(this IQueryable<T> listToPaginate, int pageNumber, int pageSize)
        {
            var paginatedResult = await PagedList<T>.CreateAsync(listToPaginate, pageNumber, pageSize);

            if (paginatedResult.Items.Count == 0)
            {
                throw new RestException(HttpStatusCode.BadRequest, "There are no records corresponding to your search!");
            }

            return paginatedResult;
        }

        public static DateTime LastDayOfMonth(this DateTime value)
        {
            var firstDayOfNextMonthMonth = new DateTime(value.Year, value.Month, 1);
            return firstDayOfNextMonthMonth.AddMonths(1).AddDays(-1);
        }

        public static string ReplaceAllIgnoreCase(this string seed, string[] chars, string replacementCharacter)
        {
            if (seed == null)
                return seed;
            return chars.Aggregate(seed, (str, cItem) => str.Replace(cItem, replacementCharacter, StringComparison.CurrentCultureIgnoreCase));
        }
    }
}
