﻿using Application.DTO;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboTables
{
    public class ListForParams
    {
        public class Query : IRequest<IReadOnlyList<TableDTO>>
        {
        }

        public class Handler : IRequestHandler<Query, IReadOnlyList<TableDTO>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<IReadOnlyList<TableDTO>> Handle(Query request, CancellationToken cancellationToken) =>
                await context.Tables
                    .Where(t => t.CommParams == true)
                    .ProjectTo<TableDTO>(mapper.ConfigurationProvider)
                    .ToListAsync();
        }
    }
}
