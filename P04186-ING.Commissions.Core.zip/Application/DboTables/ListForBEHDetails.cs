﻿using Application.DTO;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboTables
{
    public class ListForBEHDetails
    {
        public class Query : IRequest<List<TableDTO>>
        {
        }

        public class Handler : IRequestHandler<Query, List<TableDTO>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<List<TableDTO>> Handle(Query request, CancellationToken cancellationToken) =>
                await context.Tables
                    .Where(t => t.BehDetails == true)
                    .ProjectTo<TableDTO>(mapper.ConfigurationProvider)
                    .ToListAsync();
        }
    }
}
