﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.ParameterNotification;
using Application.StateManagement;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboParameters
{
    public class Reject
    {
        public class Command : IRequest
        {
            public int Id { get; set; }
            public string RejectReason { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : ParameterNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(CommissionsContext context, IMapper mapper, ILogger<Handler> logger,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot reject parameter because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot reject parameter because there is a running job in progress");
                }

                logger.LogInformation($"Reject parameter {request.Id}");
                var parameter = await context.CommissionsParameters.FindAsync(request.Id);
                if (parameter == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "This parameter is not in the database!");
                }

                if (request.UserKey == parameter.UpdatedBy)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"You have changed the parameter {parameter.Name} so you can not approve the changes!");
                }
                var oldStatus = parameter.Status.StatusName;
                var statusManger = new StatusStateManagement(parameter.Status.StatusName, EntitiesForStateManagement.ProductDetail);
                statusManger.SetNextState(StateTrigger.Reject);
                var objStatus = await context.ObjectStatus.FirstOrDefaultAsync(os => os.StatusName == statusManger.State.ToString());
                var actionReject = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Reject.ToString());
                parameter.Status = objStatus;
                parameter.StatusId = objStatus.Id;
                parameter.ApprovedRejectedBy = request.UserKey;
                parameter.ApprovedRejectedDate = DateTime.Now;
                parameter.RejectReason = request.RejectReason;
                parameter.Value = parameter.OldValue ?? parameter.Value;
                var parameterHistory = mapper.Map<CommissionsParameterHistory>(parameter);
                parameterHistory.Action = actionReject;
                parameterHistory.ActionId = actionReject.Id;
                context.Add(parameterHistory);

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendParameterEmailAsync(parameter, oldStatus, nameof(NotificationType.Rejected));
                    return Unit.Value;
                }
                throw new Exception("The parameter was not rejected!");
            }
        }
    }
}
