﻿using Application.DTO;
using Application.Export.ParametersReport;
using Application.Helpers;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboParameters
{
    public class List
    {
        public class Query : IRequest<PagedList<ParametersListDTO>>
        {
            public ParametersParams ParametersParams { get; set; }
        }

        public class Handler : ParametersListBase, IRequestHandler<Query, PagedList<ParametersListDTO>>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<PagedList<ParametersListDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get parameters list");

                var filter = mapper.Map<ParametersFilter>(request.ParametersParams);
                var parameters = ParametersList(context, mapper, filter);

                return await parameters.GetPaginatedListAndCheckIfEmpty(request.ParametersParams.PageNumber, request.ParametersParams.PageSize);                
            }
        }
    }
}
