﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.ParameterNotification;
using AutoMapper;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboParameters
{
    public class Edit
    {
        public class Command : IRequest
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string Value { get; set; }
            public int TableId { get; set; }
            public string UserKey { get; set; }
        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(p => p.Name).NotEmpty().NotNull();
                RuleFor(p => p.Value).NotNull().NotEmpty();
            }
        }

        public class Handler : ParameterNotificationBase, IRequestHandler<Command>
        {
            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;

            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                if (await context.IsAnyJobRunning())
                {
                    logger.LogWarning("Cannot edit parameter because there is a running job in progress");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot edit parameter because there is a running job in progress");
                }

                logger.LogInformation($"Edit parameter {request.Name}");
                var parameter = await context.CommissionsParameters.FindAsync(request.Id);
                if (parameter == null)
                    throw new RestException(HttpStatusCode.BadRequest, $"The parameter {request.Name} is not in the database");
                if (parameter.Status.StatusName != Commons.Enums.ObjectStatus.Approved &&
                    parameter.Status.StatusName != Commons.Enums.ObjectStatus.Rejected)
                    throw new RestException(HttpStatusCode.BadRequest, $"The parameter {request.Name} should be in Approved or Rejected state to be modified!");

                var statusUpdated = await context.ObjectStatus.FirstOrDefaultAsync(o => o.StatusName == Commons.Enums.ObjectStatus.Updated);
                var actionUpdated = await context.ObjectActions.FirstOrDefaultAsync(o => o.ActionName == Commons.Enums.ObjectAction.Edit.ToString());
                parameter.Status = statusUpdated;
                parameter.StatusId = statusUpdated.Id;
                parameter.OldValue = parameter.Value;
                parameter.Value = request.Value;
                parameter.TableId = request.TableId;
                parameter.UpdatedBy = request.UserKey;
                parameter.UpdatedDate = DateTime.Now;
                var parameterHistory = mapper.Map<CommissionsParameterHistory>(parameter);
                parameterHistory.Action = actionUpdated;
                parameterHistory.ActionId = actionUpdated.Id;
                context.CommissionsParametersHistory.Add(parameterHistory);

                var success = await context.SaveChangesAsync() > 0;
                if (success)
                {
                    await SendParameterEmailAsync(parameter, parameter.Status.StatusName, nameof(NotificationType.SendToApprove));
                    return Unit.Value;
                }
                throw new Exception("Parameter was not updated!");
            }
        }
    }
}
