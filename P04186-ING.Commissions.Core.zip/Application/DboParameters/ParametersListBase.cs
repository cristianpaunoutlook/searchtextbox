﻿using Application.Commons.Constants;
using Application.DTO;
using Application.Export.ParametersReport;
using Application.Helpers;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.DboParameters
{
    public class ParametersListBase
    {
        public IQueryable<ParametersListDTO> ParametersList(CommissionsContext context, IMapper mapper,
            ParametersFilter filter)
        {
            if(filter.Context == Constants.TOAPPROVE)
                return context.CommissionsParameters
                                            .Where(prd => prd.Status.StatusName != Commons.Enums.ObjectStatus.Deleted &&
                                                            prd.Status.StatusName != Commons.Enums.ObjectStatus.RejectAdd &&
                                                            prd.Status.StatusName != Commons.Enums.ObjectStatus.Approved)
                                            .OrderBy(o => o.Status.DisplayOrder).ThenBy(o => o.Name)
                                            .ProjectTo<ParametersListDTO>(mapper.ConfigurationProvider);

            var parameters = context.CommissionsParameters
                                            .Where(prd => prd.Status.StatusName != Commons.Enums.ObjectStatus.Deleted &&
                                                            prd.Status.StatusName != Commons.Enums.ObjectStatus.RejectAdd)
                                            .ProjectTo<ParametersListDTO>(mapper.ConfigurationProvider);

            parameters = parameters
                            .FilterIfValueProvided(!string.IsNullOrEmpty(filter.Name), param => param.Name.Contains(filter.Name))
                            .FilterIfValueProvided(filter.StatusId != -1, o => o.StatusId == filter.StatusId)
                            .FilterIfValueProvided(filter.TableId != -1, o => o.TableId == filter.TableId)
                            .OrderBy(o => o.DisplayOrder).ThenBy(o => o.Name);
            
            return parameters;
        }
    }
}
