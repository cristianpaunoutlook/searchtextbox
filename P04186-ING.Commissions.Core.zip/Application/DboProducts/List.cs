﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboProducts
{
    public class List 
    {
        public class Query : IRequest<List<Domain.Product>> 
        {
            public string ActionName { get; set; }
        }
        public class Handler : IRequestHandler<Query, List<Domain.Product>>
        {
            private readonly CommissionsContext context;

            public Handler(CommissionsContext context)
            {
                this.context = context;
            }
            
            public async Task<List<Domain.Product>> Handle(Query request, CancellationToken cancellationToken)
            {
                if (request.ActionName.ToLower() == Commons.Enums.ObjectAction.Edit.ToString().ToLower())
                    return await context.Products.ToListAsync();
                else
                {
                    var products = await context.Products.GroupJoin(
                                                      context.ProductDetails,
                                                      product => product.ProductType,
                                                      detail => detail.ProductType,
                                                      (x, y) => new { Product = x, ProductDetails = y })
                                                .SelectMany(
                                                      x => x.ProductDetails.DefaultIfEmpty(),
                                                      (x, y) => new { Product = x.Product, ProductDetails = y })
                                                .Where(x => (x.ProductDetails.ProductType == null ||
                                                      (x.ProductDetails.StatusId == (short)Application.Commons.Enums.ObjectStatusId.Deleted ||
                                                        x.ProductDetails.StatusId == (short)Application.Commons.Enums.ObjectStatusId.RejectAdd))).ToListAsync();
                    var result = products.Select(p => p.Product).ToList();
                    return result;
                }
            }
        }
    }
}
