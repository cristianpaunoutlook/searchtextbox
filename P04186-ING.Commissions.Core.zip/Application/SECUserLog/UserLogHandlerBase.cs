﻿using Application.Errors;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Application.SECUserLog
{
    public class UserLogHandlerBase
    {
        protected async Task<Unit> AddUserLog(CommissionsContext context, string session, int actionId, int userObjectId, string userId, string ip, string workstation)
        {
            var secSession = await context.SecSessions.Where(s => s.Session == session).FirstOrDefaultAsync();
            if (secSession == null)
            {
                throw new RestException(HttpStatusCode.BadRequest, "The session is not registred!");
            }

            var sessionExpired = new SecUserLog()
            {
                ActionId = (int)actionId,
                ObjectId = (int)userObjectId,
                RecordStamp = DateTime.Now,
                UserId = userId,
                ErrorNumberId = 0,
                SessionId = secSession.SessionId,
                RecordId = secSession.SessionId.ToString(),
                Details = $"Session={secSession.Session};UserId={userId};IP={ip};Workstation={workstation}"
            };

            context.UserLogs.Add(sessionExpired);
            var success = await context.SaveChangesAsync() > 0;

            return success ? Unit.Value : throw new Exception("UserLog record was not created!");
        }
    }
}
