﻿
using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Application.Helpers;
using Application;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace Application.InputDataHistory
{
    public class List
    {
        public class Query : IRequest<List<InputDataHistoryDTO>>
        {
           
            public int MonthId { get; set; }
        }

        public class Handler : IRequestHandler<Query, List<InputDataHistoryDTO>>
        {

            private readonly CommissionsContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;


            public Handler(CommissionsContext context, ILogger<Handler> logger, IMapper mapper)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<List<InputDataHistoryDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get input data history list");


                var inputDataHistory = from t in context.DWHTables
                                       join sts in context.StatusExports
                                       on new { t.Id, request.MonthId } equals new { Id=sts.IdTable, sts.MonthId } into statusTable
                                       from sts in statusTable.DefaultIfEmpty()
                                       where t.Id <= (int)CommissionsTable.OLTSFR orderby sts.RefDate

                                       select new InputDataHistoryDTO
                                       {
                                           TableName = t.TableName,
                                           ShortDescription = t.TableDescription,
                                           Date = sts.RefDate,
                                           TableStatus = sts.ProcessStatus == StatusExportStatuses.Ok.ToString() ? CustomStatusesExport.Ok  :
                                           sts.ProcessStatus == StatusExportStatuses.Executing.ToString()? CustomStatusesExport.Executing:
                                           sts.ProcessStatus == StatusExportStatuses.Failed.ToString()?
                                           CustomStatusesExport.Failed : null,
                                           NoOfRecords = sts.NoOfRecords
                                       };

                return await inputDataHistory.ToListAsync();

            }

        }
    }
}