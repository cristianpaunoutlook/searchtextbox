using Domain;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Persistence.SQLHelpers;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Persistence
{
    public class CommissionsContext : DbContext
    {
        public CommissionsContext(DbContextOptions options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region entity configuration
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
            #endregion
            modelBuilder
                .HasDbFunction(typeof(CommissionsContext).GetMethod(nameof(CheckIfCanCalculate), new[] { typeof(int) }))
                .HasName("fnCheckIfCanCalculate");
            modelBuilder
                .HasDbFunction(typeof(CommissionsContext).GetMethod(nameof(CheckIfJobRunning), new[] { typeof(string) }))
                .HasName("fnCheckIfRunningJob");
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseLazyLoadingProxies();
        }

        #region DbSets for data tables
        public DbSet<ObjectStatus> ObjectStatus { get; set; }
        public DbSet<SecSession> SecSessions { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<Page> Pages { get; set; }
        public DbSet<GroupPageRight> GroupsPagesRights { get; set; }
        public DbSet<Right> Rights { get; set; }
        public DbSet<SecUserObject> UserObjects { get; set; }
        public DbSet<SecUserAction> UserActions { get; set; }
        public DbSet<SecUserLog> UserLogs { get; set; }
        public DbSet<ExpenseAccount> ExpenseAccounts { get; set; }
        public DbSet<ProductDetails> ProductDetails { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ObjectAction> ObjectActions { get; set; }
        public DbSet<ProductDetailsHistory> ProductDetailsHistory { get; set; }
        public DbSet<BehaviorDetails> BehaviorDetails { get; set; }
        public DbSet<BehaviorDetailsHistory> BehaviorDetailsHistory { get; set; }
        public DbSet<Office> Offices { get; set; }
        public DbSet<OfficeHistory> OfficesHistory { get; set; }
        public DbSet<CommissionsParameter> CommissionsParameters { get; set; }
        public DbSet<CommissionsParameterHistory> CommissionsParametersHistory { get; set; }
        public DbSet<Table> Tables { get; set; }
        public DbSet<TableColumn> TableColumns { get; set; }
        public DbSet<StatusExport> StatusExports { get; set; }
        public DbSet<Tables> DWHTables { get; set; }
        public DbSet<DWHConsolidatedCommissions> DWHConsolidatedCommissions { get; set; }
        public DbSet<DWHSL2Commissions> DWHSL2Commissions { get; set; }
        public DbSet<DWHSMECommissions> DWHSMECommissions { get; set; }
        public DbSet<DWHTLSCommissions> DWHTLSCommissions { get; set; }
        public DbSet<ConsolidatedCommissions> ConsolidatedCommissions { get; set; }
        public DbSet<SL2Commissions> SL2Commissions { get; set; }
        public DbSet<SMECommissions> SMECommissions { get; set; }
        public DbSet<TLSCommissions> TLSCommissions { get; set; }
        public DbSet<ProcessHistory> ProcessHistory { get; set; }
        public DbSet<ProcessedCommission> ProcessedCommissions { get; set; }

        #endregion

        #region call stored procedures

        [ExcludeFromCodeCoverage]
        public async Task StartJob(string jobName)
        {
            var parameters = new SqlParameter[] {
                SQLHelper.CreateStringSQLParameter("@JobName", jobName)
                };

            await Database.ExecuteSqlRawAsync($"exec spStartJob @JobName", parameters);
        }

        public int CheckIfCanCalculate(int monthId)
            => throw new NotSupportedException();

        public int CheckIfJobRunning(string tableName)
            => throw new NotSupportedException();

        public async Task<int> GetErrorNumberForConsolidation(int monthId)
        {
            return await Groups.Take(1).Select(x => CheckIfCanCalculate(monthId)).FirstOrDefaultAsync();
        }
        public async Task<int> JobIsRunning(string tableName)
        {
            return await Groups.Take(1).Select(x => CheckIfJobRunning(tableName)).FirstOrDefaultAsync();
        }
        #endregion

        [ExcludeFromCodeCoverage]
        public async Task<List<ProcessedCommission>> ProcessedCommissionsList(int monthId)
        {
            var parameters = new SqlParameter[] {
                SQLHelper.CreateIntSQLParameter("@MonthId",monthId)
            };

            return await ProcessedCommissions.FromSqlRaw("EXECUTE spGetProcessedCommissionsByMonthId @MonthId", parameters).ToListAsync();
        }

        public async Task<bool> IsAnyJobRunning()
        {
            var prevMonth = DateTime.Now.AddMonths(-1);
            var monthId = prevMonth.Year * 100 + prevMonth.Month;

            var statusList = from s in StatusExports
                             join t in DWHTables on s.IdTable equals t.Id
                             where s.MonthId == monthId && t.TableName.ToLower().Contains("commissions") && s.ProcessStatus == "Executing"
                             select s;

            return await statusList.AnyAsync();

        }
    }
}
