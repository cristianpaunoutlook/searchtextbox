﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ObjectActionMap : IEntityTypeConfiguration<ObjectAction>
    {
        public void Configure(EntityTypeBuilder<ObjectAction> builder)
        {
            builder.ToTable("ObjectAction");
        }

    }
}
