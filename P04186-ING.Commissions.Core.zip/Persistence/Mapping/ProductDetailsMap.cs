﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ProductDetailsMap : IEntityTypeConfiguration<ProductDetails>
    {
        public void Configure(EntityTypeBuilder<ProductDetails> builder)
        {
            builder.ToTable("ProductDetails");
            builder.HasKey(pd => pd.Id);
            builder.HasOne(pd => pd.Status).WithMany().HasForeignKey(pd => pd.StatusId);
            builder.HasOne(pd => pd.ExpenseAccount).WithMany().HasForeignKey(pd => pd.ExpenseAccountId);
            builder.Property(pd => pd.StatusId).HasColumnType("SMALLINT");
        }
    }
}
