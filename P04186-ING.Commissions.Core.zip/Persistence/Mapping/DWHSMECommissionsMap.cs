﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Persistence.Mapping
{
    public class DWHSMECommissionsMap : IEntityTypeConfiguration<DWHSMECommissions>
    {
        public void Configure(EntityTypeBuilder<DWHSMECommissions> builder)
        {
            builder.ToTable("SMECommissions", "dwh");
            builder.HasKey(sme => new { sme.MonthId, sme.CustomerNo });
        }
    }
}
