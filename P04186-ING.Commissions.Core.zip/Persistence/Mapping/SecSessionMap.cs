﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    public class SecSessionMap : IEntityTypeConfiguration<SecSession>
    {
        [ExcludeFromCodeCoverage]
        public void Configure(EntityTypeBuilder<SecSession> builder)
        {
            builder
                .ToTable("Session", "sec")
                .HasKey(s => s.SessionId);
            builder
                .Property(s => s.SessionId)
                .ValueGeneratedOnAdd()
                .IsRequired();
            builder
                .Property(s => s.CountFailedLogin)
                .HasColumnType("SMALLINT");
        }
    }
}
