﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class BehaviorDetailsMap : IEntityTypeConfiguration<BehaviorDetails>
    {
        public void Configure(EntityTypeBuilder<BehaviorDetails> builder)
        {
            builder.ToTable("BehaviorDetails");
            builder.HasKey(bd => bd.Id);
            builder.HasOne(bd => bd.Status).WithMany().HasForeignKey(bd => bd.StatusId);
            builder.HasOne(bd => bd.ExpenseAccount).WithMany().HasForeignKey(bd => bd.ExpenseAccountId);
            builder.HasOne(bd => bd.CommissionBehaviorTables).WithMany().HasForeignKey(bd => bd.CommissionBehaviorTablesId);
            builder.HasOne(bd => bd.CommissionBehaviorColumns).WithMany().HasForeignKey(bd => bd.CommissionBehaviorColumnsId);
            builder.Property(bd => bd.StatusId).HasColumnType("SMALLINT");
        }
    }
}
