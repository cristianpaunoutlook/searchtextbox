﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class BehaviorDetailsHistoryMap : IEntityTypeConfiguration<BehaviorDetailsHistory>
    {
        public void Configure(EntityTypeBuilder<BehaviorDetailsHistory> builder)
        {
            builder.ToTable("BehaviorDetailsHistory");
            builder.HasKey(bdh => bdh.Id);
            builder.HasOne(bdh => bdh.BehaviorDetails).WithMany().HasForeignKey(bdh => bdh.BehaviorDetailsId);
            builder.HasOne(bdh => bdh.ExpenseAccount).WithMany().HasForeignKey(bdh => bdh.ExpenseAccountId);
            builder.HasOne(bdh => bdh.CommissionBehaviorTables).WithMany().HasForeignKey(bdh => bdh.CommissionBehaviorTablesId);
            builder.HasOne(bdh => bdh.CommissionBehaviorColumns).WithMany().HasForeignKey(bdh => bdh.CommissionBehaviorColumnsId);
            builder.HasOne(bdh => bdh.Status).WithMany().HasForeignKey(bdh => bdh.StatusId);
            builder.HasOne(bdh => bdh.Action).WithMany().HasForeignKey(bdh => bdh.ActionId);
            builder.Property(bdh => bdh.StatusId).HasColumnType("SMALLINT");
            builder.Property(bdh => bdh.ActionId).HasColumnType("SMALLINT");
        }
    }
}