﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class StatusExportMap : IEntityTypeConfiguration<StatusExport>
    {
        public void Configure(EntityTypeBuilder<StatusExport> builder)
        {
            builder.ToTable("StatusExport", "dwh");
            builder.HasKey(se => new { se.IdTable, se.RefDate});
            builder.Property(se => se.ProcessStatus).HasColumnName("StatusExport");
        }
    }
}
