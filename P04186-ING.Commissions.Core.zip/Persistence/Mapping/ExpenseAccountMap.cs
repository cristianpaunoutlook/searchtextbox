﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ExpenseAccountMap : IEntityTypeConfiguration<ExpenseAccount>
    {
        public void Configure(EntityTypeBuilder<ExpenseAccount> builder)
        {
            builder.ToTable("ExpenseAccounts");
            builder.HasKey(ea => ea.Id);
        }
    }
}
