﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    class CommissionsParameterHistoryMap : IEntityTypeConfiguration<CommissionsParameterHistory>
    {
        public void Configure(EntityTypeBuilder<CommissionsParameterHistory> builder)
        {
            builder.ToTable("CommissionsParametersHistory");
            builder.Property(p => p.StatusId).HasColumnType("SMALLINT");
            builder.Property(p => p.ActionId).HasColumnType("SMALLINT");
            builder.HasKey(p => p.Id);
            builder.HasOne(p => p.Status).WithMany().HasForeignKey(p => p.StatusId);
            builder.HasOne(p => p.Action).WithMany().HasForeignKey(p => p.ActionId);
            builder.HasOne(p => p.CommissionsParameter).WithMany().HasForeignKey(p => p.CommissionsParametersId);
            builder.HasOne(p => p.Table).WithMany().HasForeignKey(p => p.TableId);
        }
    }
}
