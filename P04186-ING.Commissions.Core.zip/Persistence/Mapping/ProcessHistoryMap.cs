﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ProcessHistoryMap : IEntityTypeConfiguration<ProcessHistory>
    {
        public void Configure(EntityTypeBuilder<ProcessHistory> builder)
        {
            builder.ToTable("ProcessHistory");
            builder.HasOne(pd => pd.Table).WithMany().HasForeignKey(pd => pd.TableId);
        }
    }
}
