﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class SecUserLogMap : IEntityTypeConfiguration<SecUserLog>
    {
        public void Configure(EntityTypeBuilder<SecUserLog> builder)
        {
            builder.ToTable("UserLog", "sec");
            builder.HasKey(us => us.LogId);
            builder.Property(us => us.LogId).HasColumnType("BIGINT");
            builder.Property(us => us.ActionId).HasColumnType("SMALLINT");
            builder.Property(us => us.ObjectId).HasColumnType("SMALLINT");
            builder.HasOne(ul => ul.UserAction).WithMany().HasForeignKey(ul => ul.ActionId);
            builder.HasOne(ul => ul.UserObject).WithMany().HasForeignKey(ul => ul.ObjectId);
        }
    }
}
