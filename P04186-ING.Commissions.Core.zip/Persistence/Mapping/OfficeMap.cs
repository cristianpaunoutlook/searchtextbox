﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class OfficeMap : IEntityTypeConfiguration<Office>
    {
        public void Configure(EntityTypeBuilder<Office> builder)
        {
            builder.ToTable("Offices");
            builder.Property(o => o.StatusId).HasColumnType("SMALLINT");
            builder.HasOne(o => o.Status).WithMany().HasForeignKey(o => o.StatusId);
        }
    }
}
