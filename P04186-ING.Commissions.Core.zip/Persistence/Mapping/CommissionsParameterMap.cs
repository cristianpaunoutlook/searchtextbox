﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class CommissionsParameterMap : IEntityTypeConfiguration<CommissionsParameter>
    {
        public void Configure(EntityTypeBuilder<CommissionsParameter> builder)
        {
            builder.ToTable("CommissionsParameters");
            builder.Property(p => p.StatusId).HasColumnType("SMALLINT");
            builder.HasKey(p => p.Id);
            builder.HasOne(p => p.Status).WithMany().HasForeignKey(p => p.StatusId);
            builder.HasOne(p => p.Table).WithMany().HasForeignKey(p => p.TableId);
        }
    }
}
