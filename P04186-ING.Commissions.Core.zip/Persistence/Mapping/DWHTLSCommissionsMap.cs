﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Persistence.Mapping
{
    public class DWHTLSCommissionsMap : IEntityTypeConfiguration<DWHTLSCommissions>
    {
        public void Configure(EntityTypeBuilder<DWHTLSCommissions> builder)
        {
            builder.ToTable("TLSCommissions", "dwh");
            builder.HasKey(tls => new { tls.MonthId, tls.AccountNo });
        }
    }
}
