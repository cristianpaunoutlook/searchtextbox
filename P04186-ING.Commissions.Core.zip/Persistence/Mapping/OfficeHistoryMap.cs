﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class OfficeHistoryMap : IEntityTypeConfiguration<OfficeHistory>
    {
        public void Configure(EntityTypeBuilder<OfficeHistory> builder)
        {
            builder.ToTable("OfficesHistory");
            builder.Property(oh => oh.StatusId).HasColumnType("SMALLINT");
            builder.Property(oh => oh.ActionId).HasColumnType("SMALLINT");
            builder.HasKey(oh => oh.Id);
            builder.HasOne(oh => oh.Status).WithMany().HasForeignKey(oh => oh.StatusId);
            builder.HasOne(oh => oh.Action).WithMany().HasForeignKey(oh => oh.ActionId);
        }
    }
}
