﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class SecUserActionMap : IEntityTypeConfiguration<SecUserAction>
    {
        public void Configure(EntityTypeBuilder<SecUserAction> builder)
        {
            builder.ToTable("UserAction", "sec");
            builder.HasKey(us => us.ActionId);
            builder.Property(us => us.ActionId).HasColumnType("SMALLINT");
        }
    }
}
