﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class DWHSL2CommissionsMap : IEntityTypeConfiguration<DWHSL2Commissions>
    {
        public void Configure(EntityTypeBuilder<DWHSL2Commissions> builder)
        {
            builder.ToTable("SL2Commissions", "dwh");
        }
    }
}
