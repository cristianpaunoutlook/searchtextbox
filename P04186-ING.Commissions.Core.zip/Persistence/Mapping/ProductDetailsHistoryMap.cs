﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ProductDetailsHistoryMap : IEntityTypeConfiguration<ProductDetailsHistory>
    {
        public void Configure(EntityTypeBuilder<ProductDetailsHistory> builder)
        {
            builder.ToTable("ProductDetailsHistory");
            builder.HasKey(pdh => pdh.Id);
            builder.HasOne(pdh => pdh.Status).WithMany().HasForeignKey(pdh => pdh.StatusId);
            builder.HasOne(pdh => pdh.Action).WithMany().HasForeignKey(pdh => pdh.ActionId);
            builder.HasOne(pdh => pdh.ProductDetails).WithMany().HasForeignKey(pdh => pdh.ProductDetailsId);
            builder.HasOne(pdh => pdh.ExpenseAccount).WithMany().HasForeignKey(pdh => pdh.ExpenseAccountId);
            builder.Property(pdh => pdh.StatusId).HasColumnType("SMALLINT");
            builder.Property(pdh => pdh.ActionId).HasColumnType("SMALLINT");
        }
    }
}
