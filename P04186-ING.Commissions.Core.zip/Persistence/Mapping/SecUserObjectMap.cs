﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class SecUserObjectMap : IEntityTypeConfiguration<SecUserObject>
    {
        public void Configure(EntityTypeBuilder<SecUserObject> builder)
        {
            builder.ToTable("UserObject", "sec");
            builder.HasKey(us => us.ObjectId);
            builder.Property(us => us.ObjectId).HasColumnType("SMALLINT");
        }
    }
}
