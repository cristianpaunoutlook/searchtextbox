﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class TableColumnMap : IEntityTypeConfiguration<TableColumn>
    {
        public void Configure(EntityTypeBuilder<TableColumn> builder)
        {
            builder.ToTable("TableColumns");
            builder.HasKey(c => c.Id);
            builder.HasOne(c => c.Table).WithMany().HasForeignKey(c => c.TableId);
        }
    }
}
