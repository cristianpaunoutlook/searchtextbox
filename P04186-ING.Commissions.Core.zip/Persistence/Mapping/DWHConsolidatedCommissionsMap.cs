﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class DWHConsolidatedCommissionsMap : IEntityTypeConfiguration<DWHConsolidatedCommissions>
    {
        public void Configure(EntityTypeBuilder<DWHConsolidatedCommissions> builder)
        {
            builder.ToTable("ConsolidatedCommissions", "dwh");
            builder.HasKey(c => new { c.MonthId, c.BranchCode });
        }
    }
}
