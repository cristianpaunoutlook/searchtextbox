﻿using System;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Data.SqlClient;

namespace Persistence.SQLHelpers
{
    [ExcludeFromCodeCoverage]
    public static class SQLHelper
    {
        public static SqlParameter CreateStringSQLParameter(string paramName, string paramValue)
        {
            return new SqlParameter()
            {
                ParameterName = paramName,
                Value = paramValue == null ? (object)DBNull.Value : paramValue
            };
        }

        public static SqlParameter CreateIntSQLParameter(string paramName, int paramValue)
        {
            return new SqlParameter()
            {
                ParameterName = paramName,
                Value = paramValue
            };
        }

        public static SqlParameter CreateBitSQLParameter(string paramName, bool paramValue)
        {
            return new SqlParameter()
            {
                ParameterName = paramName,
                Value = paramValue
            };
        }

        public static SqlParameter CreateDateSQLParameter(string paramName, DateTime? paramValue)
        {
            return new SqlParameter()
            {
                ParameterName = paramName,
                Value = paramValue == null ? (object)DBNull.Value : paramValue
            };
        }
        public static SqlParameter CreateOutputSQLParameter(string paramName, SqlDbType type)
        {
            return new SqlParameter()
            {
                ParameterName = paramName,
                SqlDbType = type,
                Direction = ParameterDirection.Output
            };
        }

        public static SqlParameter CreateUserDefinedTableSQLParameter<TFirst, TSecond>(TFirst tableStructure, TSecond[] valuesForTable,
            string paramName, string tableTypeName)
        {
            var dt = new DataTable();

            var properties = tableStructure.GetType().GetProperties();
            foreach (var pi in properties)
            {
                dt.Columns.Add(pi.Name, pi.PropertyType);
            }

            if (typeof(TSecond).IsValueType)
            {
                foreach (var item in valuesForTable)
                {
                    dt.Rows.Add(item);
                }
            }
            else
            {
                throw new Exception("To be implemented for reference type when needed!");
            }

            return new SqlParameter()
            {
                ParameterName = paramName,
                SqlDbType = SqlDbType.Structured,
                TypeName = tableTypeName,
                Value = dt
            };
        }
    }
}
