﻿using API.Helpers;
using API.Middleware;
using Elastic.Apm.NetCoreAll;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Serilog;

namespace API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            DIConfig.Setup(services, Configuration);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IConfiguration configuration)
        {
            app.UseAllElasticApm(configuration);
            app.UseSerilogRequestLogging();
            app.UseDefaultFiles();
            app.UseStaticFiles();
            app.UseMiddleware<ErrorHandlingMiddleware>();
            app.UseHttpsRedirection();
            app.UseRouting();
            var exposedHeaders = new string[] { Constants.SESSION_ID, Constants.SESSION_INFO };
            app.UseCors(c => c.WithOrigins(configuration.GetSection("FrontEndApp").Value)
                                .AllowAnyHeader()
                                .AllowAnyMethod()
                                .AllowCredentials()
                                .WithExposedHeaders(exposedHeaders));

            app.UseAuthentication();
            app.UseAuthorization();

            var environmentStage = configuration.GetSection("EnvironmentStage").Value;
            if (!string.IsNullOrEmpty(environmentStage) && environmentStage == "ST")
            {
                app.UseSwagger();
                app.UseSwaggerUI(
                     sw =>
                     {
                         sw.SwaggerEndpoint("/swagger/v1/swagger.json", "Commissions API");
                     });
            }
            app.UseMiddleware<Middleware.SessionInfo>();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapFallbackToController("Index", "Fallback");
            });
        }
    }
}
