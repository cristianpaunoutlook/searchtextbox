﻿namespace API.Helpers
{
    public static class Constants
    {
        public const string SESSION_INFO = "sessionInfo";
        public const string SESSION_ID = "SessionId";
    }
}
