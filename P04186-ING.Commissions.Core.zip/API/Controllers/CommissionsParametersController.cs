﻿using Application.DTO;
using Application.Helpers;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Params = Application.DboParameters ;
using Application.DboObjectStatus;
using Application.DboTables;
using Application.Authorization;
using Application.DboParameters;

namespace API.Controllers
{
    public class CommissionsParametersController : CommissionsControllerBase
    {
        public CommissionsParametersController(IMediator mediator, ILogger<CommissionsParametersController> logger) : base(mediator, logger)
        {
        }

        [HttpGet]
        [GroupKeyAuthorize("PRM_1")]
        public async Task<ActionResult<PagedList<ParametersListDTO>>> Get([FromQuery] ParametersParams parametersParams)
            => await _mediator.Send(new Params.List.Query() { ParametersParams = parametersParams });

        [HttpGet("listsForParamsPage")]
        public async Task<ActionResult<ParametersPageListsDTO>> GetListToInitPages()
        {
            return new ParametersPageListsDTO()
            {
                StatusList = await _mediator.Send(new StatusListRestricted.Query()),
                TablesList = await _mediator.Send(new ListForParams.Query())
            };
        }

        [HttpPut]
        [Route("update")]
        [GroupKeyAuthorize("PRM_2")]
        public async Task<ActionResult<Unit>> Update([FromBody] Edit.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("approve")]
        [GroupKeyAuthorize("PRM_3")]
        public async Task<ActionResult<Unit>> Approve(Approve.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("reject")]
        [GroupKeyAuthorize("PRM_3")]
        public async Task<ActionResult<Unit>> Reject(Reject.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }
    }
}
