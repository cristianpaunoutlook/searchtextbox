﻿using Application.Authorization;
using Application.DboProductDetails;
using Application.DTO;
using Application.Helpers;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class ProductDetailsController : CommissionsControllerBase
    {
        public ProductDetailsController(IMediator mediator, ILogger<ProductDetailsController> logger) : base(mediator, logger) { }

        [HttpGet]
        [GroupKeyAuthorize("PRD_1")]
        public async Task<ActionResult<PagedList<ProductDetailsDTO>>> Get([FromQuery] ProductDetailsParams productDetailsParams)
          => await _mediator.Send(new List.Query() { ProductDetailsParams = productDetailsParams });

        [HttpDelete("{id}")]
        [GroupKeyAuthorize("PRD_2")]
        public async Task<ActionResult<Unit>> Delete(int Id) => await _mediator.Send(new Delete.Command() { Id = Id, UserKey = GetUserName() });
          
	    [HttpPost]
        [Route("create")]
        [GroupKeyAuthorize("PRD_2")]
        public async Task<ActionResult<Unit>> Create([FromBody] Create.Command command)
        {
            command.LastModifiedBy = GetUserName();
            command.ChangeDate = DateTime.Now;
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("update")]
        [GroupKeyAuthorize("PRD_2")]
        public async Task<ActionResult<Unit>> Update([FromBody] Edit.Command command)
        {
            command.LastModifiedBy = GetUserName();
            command.ChangeDate = DateTime.Now;
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("approve")]
        [GroupKeyAuthorize("PRD_3")]
        public async Task<ActionResult<Unit>> Approve(Approve.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("reject")]
        [GroupKeyAuthorize("PRD_3")]
        public async Task<ActionResult<Unit>> Reject(Reject.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpGet]
        [Route("compare/{id}")]
        public async Task<ActionResult<IEnumerable<ProductDetailsHistory>>> Compare(int id)
    => await _mediator.Send(new Compare.Query() { ProductDetailsId = id });

    }
}
