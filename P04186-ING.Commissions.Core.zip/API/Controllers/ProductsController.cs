﻿using Application.DboProducts;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class ProductsController : CommissionsControllerBase
    {
        public ProductsController(IMediator mediator, ILogger<ProductsController> logger) : base(mediator, logger) { }

        [HttpGet]
        [Route("{actionName}")]
        public async Task<ActionResult<IEnumerable<Product>>> Get(string actionName) => await _mediator.Send(new List.Query() { ActionName = actionName});
    }
}
