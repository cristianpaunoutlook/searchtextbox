﻿using Application.DboObjectStatus;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class ObjectStatusController : CommissionsControllerBase
    {
        public ObjectStatusController(IMediator mediator, ILogger<ObjectStatusController> logger) : base(mediator, logger) { }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ObjectStatus>>> Get() => await _mediator.Send(new List.Query());

        [HttpGet]
        [Route("statuslistrestricted")]
        public async Task<ActionResult<IEnumerable<ObjectStatus>>> StatusListRestricted(bool importedEntities)
            => Ok(await _mediator.Send(new StatusListRestricted.Query() { ImportedEntities = importedEntities }));

    }
}