﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : CommissionsControllerBase
    {
        IConfiguration _configuration { get; }
        public HomeController(IMediator mediator, ILogger<ControllerBase> logger, IConfiguration configuration) : base(mediator, logger)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public ActionResult Get()
        {
            var environmentStage = _configuration.GetSection("EnvironmentStage").Value;
            return Ok(environmentStage);
        }
    }
}