﻿using Application.SECUserLog;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class UserLogsController : CommissionsControllerBase
    {

        public UserLogsController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger){}

        [HttpPost]
        [Route("sessionexpired")]
        public async Task<ActionResult<Unit>> SessionExpired()
        {
            var command = new SessionExpired.Command()
            {
                IP = HttpContext.Connection.RemoteIpAddress.ToString(),
                Workstation = HttpContext.Connection.RemoteIpAddress.ToString(),
                UserId = GetUserName(),
                SessionId = GetSession()
            };
            return await _mediator.Send(command);
        }
    }
}
