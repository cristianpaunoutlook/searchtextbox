﻿using Application.Commons.Constants;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CommissionsControllerBase : ControllerBase
    {
        protected readonly IMediator _mediator;
        protected readonly ILogger<ControllerBase> _logger;

        public CommissionsControllerBase(IMediator mediator, ILogger<ControllerBase> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        protected string GetUserName()
        {
            var userName = HttpContext.User.Identity.Name;
            return userName.Substring(userName.Length - Constants.CORPORATE_KEY_LENGTH).ToUpper();
        }

        protected string GetSession()
        {
            return HttpContext.Request.Headers["SessionId"];
        }
    }
}
