﻿using Application.Export.ExpenseAccountReport;
using Application.Authorization;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Application.Export.ProductDetailsReport;
using Application.Export.OfficesReport;
using Application.Export.BehaviorDetailsReport;
using Application.Export.ParametersReport;
using Application.Export.CommissionsDownload.Filter;
using Application.Export.CommissionsDownload;

namespace API.Controllers
{
    public class ExportController : CommissionsControllerBase
    {
        public ExportController(IMediator mediator, ILogger<ExportController> logger) : base(mediator, logger) { }

        [HttpGet]
        [Route("expenseAccountsReport")]
        [GroupKeyAuthorize("EAC_1")]
        public async Task<ActionResult> GetExcelAsync([FromQuery] ExpenseAccountsFilter filter)
        {
            var file = await _mediator.Send(new ExpenseAccountsToExcel.Query() { Title = "Expense Accounts Report", Filter = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("productDetailsReport")]
        [GroupKeyAuthorize("PRD_1")]
        public async Task<ActionResult> GetExcelAsync([FromQuery] ProductDetailsFilter filter)
        {
            var file = await _mediator.Send(new ProductDetailsToExcel.Query() { Title = "Product Details Report", ProductParams = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("officesReport")]
        [GroupKeyAuthorize("OFC_1")]
        public async Task<ActionResult> GetExcelAsync([FromQuery] OfficesFilter filter)
        {
            var file = await _mediator.Send(new OfficesToExcel.Query() { Title = "ING Offices Report", Filter = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("behaviorDetailsReport")]
        [GroupKeyAuthorize("BEH_1")]
        public async Task<ActionResult> GetExcelAsync([FromQuery] BehaviorDetailsFilter filter)
        {
            var file = await _mediator.Send(new BehaviorDetailsToExcel.Query() { Title = "Behavior Details Report", BehaviorParams = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("parametersReport")]
        [GroupKeyAuthorize("OFC_1")]
        public async Task<ActionResult> GetExcelAsync([FromQuery] ParametersFilter filter)
        {
            var file = await _mediator.Send(new ParametersToExcel.Query() { Title = "Parameters Report", Filter = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("commissionsReport")]
        public async Task<ActionResult> GetExcelAsync([FromQuery] CommissionsFilter filter)
        {
            var file = await _mediator.Send(new CommissionsToExcel.Query() { Filter = filter });
            return Ok(file);
        }
    }
}
