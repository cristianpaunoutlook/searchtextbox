﻿using Application.DTO;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class StatusExportController : CommissionsControllerBase
    {
        public StatusExportController(IMediator mediator, ILogger<StatusExportController> logger) : base(mediator, logger) { }

        [HttpGet("listsForParamsPage")]
        [Route("{monthId}")]
        public async Task<ActionResult<List<ProcessedCommission>>> Get(int monthId) => await _mediator.Send(new Application.DboStatusExport.List.Query() { MonthId = monthId });

        [HttpGet()]
        [Route("monthListForFilter")]
        public async Task<ActionResult<IEnumerable<StatusExportFilterDTO>>> Get() => await _mediator.Send(new Application.DboStatusExport.FilterList.Query() { });

        [HttpGet()]
        [Route("isAnyJobRunning")]
        public async Task<ActionResult<bool>> IsAnyJobRunning() => await _mediator.Send(new Application.DboStatusExport.IsAnyJobRunning.Query() { });
    }
}
