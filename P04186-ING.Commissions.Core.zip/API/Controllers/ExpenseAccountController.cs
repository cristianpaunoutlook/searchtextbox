﻿using Application.Authorization;
using Application.DboExpenseAccount;
using Application.DTO;
using Application.Helpers;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class ExpenseAccountController : CommissionsControllerBase
    {
        public ExpenseAccountController(IMediator mediator, ILogger<ExpenseAccountController> logger) : base(mediator, logger) { }

        [HttpGet]
        [GroupKeyAuthorize("EAC_1")]
        public async Task<ActionResult<PagedList<ExpenseAccountListDTO>>> Get([FromQuery] ExpenseAccountParams expenseAccountParams)
            => await _mediator.Send(new List.Query() { ExpenseAccountParams = expenseAccountParams });

        [HttpGet]
        [Route("listforproducts")]
        public async Task<ActionResult<IEnumerable<ExpenseAccountsDropDownDTO>>> ListForProducts()
            => Ok(await _mediator.Send(new ListForProducts.Query()));
    }
}
