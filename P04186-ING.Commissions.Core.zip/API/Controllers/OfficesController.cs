﻿using Application.DTO;
using Application.Helpers;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Application.DboOffices;
using Application.Authorization;
using Domain;

namespace API.Controllers
{
    public class OfficesController : CommissionsControllerBase
    {
        public OfficesController(IMediator mediator, ILogger<OfficesController> logger) : base(mediator, logger)
        {
        }

        [HttpGet]
        [GroupKeyAuthorize("OFC_1")]
        public async Task<ActionResult<PagedList<OfficesListDTO>>> Get([FromQuery] OfficesParams officesParams)
            => await _mediator.Send(new List.Query() { OfficesParams = officesParams });

        [HttpPut]
        [Route("update")]
        [GroupKeyAuthorize("OFC_2")]
        public async Task<ActionResult<Unit>> Update([FromBody] Edit.Command command)
        {
            command.ModifiedBy = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("approve")]
        [GroupKeyAuthorize("OFC_3")]
        public async Task<ActionResult<Unit>> Approve(Approve.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("reject")]
        [GroupKeyAuthorize("OFC_3")]
        public async Task<ActionResult<Unit>> Reject(Reject.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpGet]
        [Route("compare/{id}")]
        public async Task<ActionResult<IEnumerable<OfficeHistory>>> Compare(int id)
            => await _mediator.Send(new Compare.Query() { OfficeId = id });

        [HttpPut]
        [Route("bulkreject")]
        [GroupKeyAuthorize("OFC_3")]
        public async Task<ActionResult<Unit>> BulkReject(BulkReject.Command command)
        {
            command.UserId = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("bulkapprove")]
        [GroupKeyAuthorize("OFC_3")]
        public async Task<ActionResult<Unit>> BulkApprove(BulkApprove.Command command)
        {
            command.UserId = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPost]
        [GroupKeyAuthorize("OFC_2")]
        public async Task<ActionResult<ImportOfficesFileDTO>> ImportFile()
        {
            _logger.LogInformation($"Upload file: {Request.Form.Files[0].FileName}");
            return await _mediator.Send(new ImportFile.Command() { 
                FileToImport = Request.Form.Files[0], 
                UserKey = GetUserName(),
                UpdateDate = DateTime.Now
            });
        }
    }
}
