﻿using Application.Authorization;
using Application.DboBehaviorDetails;
using Application.DboExpenseAccount;
using Application.DboTableColumns;
using Application.DboTables;
using Application.DTO;
using Application.Helpers;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class BehaviorDetailsController : CommissionsControllerBase
    {
        public BehaviorDetailsController(IMediator mediator, ILogger<BehaviorDetailsController> logger) : base(mediator, logger) { }

        [HttpGet]
        [GroupKeyAuthorize("BEH_1")]
        public async Task<ActionResult<PagedList<BehaviorDetailsListDTO>>> Get([FromQuery] BehaviorParams behaviorParams)
            => await _mediator.Send(new Application.DboBehaviorDetails.List.Query() { BehaviorParams = behaviorParams });

        [HttpGet("listsForBehaviorDetailsPage")]
        public async Task<ActionResult<BehaviorDetailsPageListsDTO>> GetListToInitPages()
        {
            return new BehaviorDetailsPageListsDTO()
            {
                ExpenseAccountList = await _mediator.Send(new ListForProducts.Query()),
                TablesList = await _mediator.Send(new ListForBEHDetails.Query()),
                TableColumnsList = await _mediator.Send(new ColumnsListForBEHDetails.Query())
            };
        }

        [HttpPost]
        [Route("create")]
        [GroupKeyAuthorize("BEH_2")]
        public async Task<ActionResult<Unit>> Create([FromBody] Create.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("update")]
        [GroupKeyAuthorize("BEH_2")]
        public async Task<ActionResult<Unit>> Update([FromBody] Edit.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }
        
        [HttpDelete("{id}")]
        [GroupKeyAuthorize("BEH_2")]
        public async Task<ActionResult<Unit>> Delete(int Id) => await _mediator.Send(new Delete.Command() { Id = Id, UserKey = GetUserName() });

        [HttpPut]
        [Route("approve")]
        [GroupKeyAuthorize("BEH_3")]
        public async Task<ActionResult<Unit>> Approve(Approve.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("reject")]
        [GroupKeyAuthorize("BEH_3")]
        public async Task<ActionResult<Unit>> Reject(Reject.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpGet]
        [Route("compare/{id}")]
        public async Task<ActionResult<IEnumerable<BehaviorDetailsHistory>>> Compare(int id)
           => await _mediator.Send(new Compare.Query() { BehaviorDetailsId = id });

    }
}