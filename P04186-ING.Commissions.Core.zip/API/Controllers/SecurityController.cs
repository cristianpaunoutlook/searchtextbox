using Application.Security;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class SecurityController : CommissionsControllerBase
    {
        public SecurityController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger) { }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<KeyValue>>> Get() => await _mediator.Send(new UserGroups.Query() { User = User.Identity });

    }
}