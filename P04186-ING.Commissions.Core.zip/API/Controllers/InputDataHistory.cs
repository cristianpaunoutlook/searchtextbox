﻿using Application.DboTables;
using Application.DTO;
using Application.InputDataHistory;
using Application.InputDataHistory;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class InputDataHistoryController : CommissionsControllerBase
    {
        public InputDataHistoryController(IMediator mediator, ILogger<TablesController> logger) : base(mediator, logger) { }

        [HttpGet]
        [Route("{monthId}")]
        public async Task<ActionResult<List<InputDataHistoryDTO>>> Get(int monthId)  =>
            await _mediator.Send(new List.Query() { MonthId = monthId });


        [HttpGet()]
        [Route("monthListForFilter")]
        public async Task<ActionResult<IEnumerable<StatusExportFilterDTO>>> Get() => await _mediator.Send(new Application.DboStatusExport.FilterList.Query() { });

    }
}
