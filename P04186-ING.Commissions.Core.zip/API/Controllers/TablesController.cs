﻿using Application.DboTables;
using Application.DTO;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class TablesController : CommissionsControllerBase
    {
        public TablesController(IMediator mediator, ILogger<TablesController> logger) : base(mediator, logger) { }

        [HttpGet]
        [Route("behdetails")]
        public async Task<ActionResult<IEnumerable<TableDTO>>> BehDetails() => await _mediator.Send(new ListForBEHDetails.Query());
    }
}
