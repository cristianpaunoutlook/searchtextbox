﻿using Application;
using Application.DTO;
using Application.Export.CommissionsDownload.Filter;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobsController : CommissionsControllerBase
    {
        public JobsController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger)
        {
        }

        [HttpGet]
        [Route("{RunJob}")]
        public async Task<ActionResult<JobResultDTO>> Get([FromQuery] CommissionsFilter filter) =>
            await _mediator.Send(new ConsolidatedJobs.RunJob() { Filter = filter, RunBy = GetUserName() });
    }
}
