﻿using Application.Commons.Enums;
using Application.DboStatusExport;
using Application.InputDataHistory;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using List = Application.DboStatusExport.List;

namespace ApplicationTests.StatusExportTests
{
    public class StatusExportBaseTests : TestBase
    {
        public void InitStatusExportTable(CommissionsContext context)
        {
            var currentMonthId = Convert.ToInt32(DateTime.Now.Year.ToString() + DateTime.Now.ToString("MM"));
            var previousMonthId = Convert.ToInt32(DateTime.Now.Year.ToString() + DateTime.Now.AddMonths(-1).ToString("MM"));
            var previousNotImportedMonthId = Convert.ToInt32(DateTime.Now.Year.ToString() + DateTime.Now.AddMonths(-2).ToString("MM"));
            //imported Failed
            InitStatusExportForImportTable(context, previousNotImportedMonthId, StatusExportStatuses.Failed.ToString());
            //imported OK and not calculated
            InitStatusExportForImportTable(context, currentMonthId, StatusExportStatuses.Ok.ToString());
            //imported OK and calculated
            InitStatusExportForImportTable(context, previousMonthId, StatusExportStatuses.Ok.ToString());

            InitTables(context);

            var statusExportBehCom = GetStatusExports((int)CommissionsTable.BehaviorsCommissions, StatusExportStatuses.Ok.ToString(), previousMonthId);
            var statusExportSl2Com = GetStatusExports((int)CommissionsTable.SL2Commissions, StatusExportStatuses.Ok.ToString(), previousMonthId);
            var statusExportTlsCom = GetStatusExports((int)CommissionsTable.TLSCommissions, StatusExportStatuses.Ok.ToString(), previousMonthId);
            var statusExportSmeCom = GetStatusExports((int)CommissionsTable.SMECommissions, StatusExportStatuses.Ok.ToString(), previousMonthId);
            var statusExportConsolidated = GetStatusExports((int)CommissionsTable.ConsolidatedCommissions, StatusExportStatuses.Ok.ToString(), previousMonthId);

            context.Add(statusExportBehCom);
            context.Add(statusExportSl2Com);
            context.Add(statusExportTlsCom);
            context.Add(statusExportSmeCom);
            context.Add(statusExportConsolidated);

      
            context.SaveChanges();
        }

        protected void ArrangeOnStatusExportList(CommissionsContext context,ILogger<List.Handler> logger, int monthId, out List.Query query, out Application.DboStatusExport.List.Handler handler)
        {
            InitStatusExportTable(context);

            query = new List.Query() { MonthId = monthId};
            handler = new List.Handler(context, logger);
        }

        protected void ArrangeOnInputDataHistoryList(CommissionsContext context, int monthId, out Application.InputDataHistory.List.Query query, out Application.InputDataHistory.List.Handler handler)
        {
            InitStatusExportTable(context);

            query = new Application.InputDataHistory.List.Query() { MonthId = monthId };
            handler = new Application.InputDataHistory.List.Handler(context, Mock.Of<ILogger<Application.InputDataHistory.List.Handler>>(), GetMapper());
        }

        public void InitStatusExportForImportTable(CommissionsContext context, int monthId, string processedStatus)
        {
            var statusExportBeh = GetStatusExports((int)CommissionsTable.Behaviors, processedStatus, monthId);
            var statusExportSl2 = GetStatusExports((int)CommissionsTable.SL2, processedStatus, monthId);
            var statusExportSme = GetStatusExports((int)CommissionsTable.SME, processedStatus, monthId);
            var statusExportTls = GetStatusExports((int)CommissionsTable.TLS, processedStatus, monthId);
            var statusExportOltsfr = GetStatusExports((int)CommissionsTable.OLTSFR, processedStatus, monthId);
            context.Add(statusExportBeh);
            context.Add(statusExportSl2);
            context.Add(statusExportSme);
            context.Add(statusExportTls);
            context.Add(statusExportOltsfr);
        }

        public void InitTables(CommissionsContext context)
        {
            var behaviorsTable = GetTables((int)CommissionsTable.Behaviors, CommissionsTable.Behaviors.ToString());
            var SL2Table = GetTables((int)CommissionsTable.SL2, CommissionsTable.SL2.ToString());
            var SMETable = GetTables((int)CommissionsTable.SME, CommissionsTable.SME.ToString());
            var TLSTable = GetTables((int)CommissionsTable.TLS, CommissionsTable.TLS.ToString());
            var OLTSFRTable = GetTables((int)CommissionsTable.OLTSFR, CommissionsTable.OLTSFR.ToString());

            context.Add(behaviorsTable);
            context.Add(SL2Table);
            context.Add(SMETable);
            context.Add(TLSTable);
            context.Add(OLTSFRTable);

            context.SaveChanges();

        }
    }
}