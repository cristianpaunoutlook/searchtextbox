﻿using Application.Commons.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ApplicationTests.StatusExportTests
{
    [TestClass]
    public class ListTests : StatusExportBaseTests
    {
        [TestMethod]
        public void ShouldReturnAllDataFromGrid()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var previousMonthId = Convert.ToInt32(DateTime.Now.Year.ToString() + DateTime.Now.AddMonths(-1).ToString("MM"));

                ArrangeOnInputDataHistoryList(context, previousMonthId, out var query, out var handler);
                //act
                var inputDataHistList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;
                //Assert
                Assert.IsTrue(inputDataHistList.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnListContainingTableNameSL2()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var previousMonthId = Convert.ToInt32(DateTime.Now.Year.ToString() + DateTime.Now.AddMonths(-1).ToString("MM"));

                ArrangeOnInputDataHistoryList(context, previousMonthId, out var query, out var handler);
                //act
                var inputDataHistList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;
                //Assert
                Assert.IsTrue(inputDataHistList[0].TableName == "Behaviors");
            }
        }

        [TestMethod]
        public void ShouldReturnListContainingTableDescriptionSL2()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var previousMonthId = Convert.ToInt32(DateTime.Now.Year.ToString() + DateTime.Now.AddMonths(-1).ToString("MM"));

                ArrangeOnInputDataHistoryList(context, previousMonthId, out var query, out var handler);
                //act
                var inputDataHistList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;
                //Assert
                Assert.IsTrue(inputDataHistList[1].ShortDescription == "SL2test");
            }

        }

    }
}
