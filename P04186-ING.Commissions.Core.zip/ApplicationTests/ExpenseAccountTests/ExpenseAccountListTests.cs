﻿using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading;

namespace ApplicationTests.ExpenseAccountTests
{
    [TestClass]
    public class ExpenseAccountListTests : ExpenseAccountBaseTests
    {
        [TestMethod]
        public void ShouldReturnAllExpenseAccountsFromDb()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parameters = GetParameters(1, 15);

                ArrangeOnExpAccountList(context, parameters, out var query, out var handler);

                //act
                var expAccounts = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(expAccounts.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnAllExpenseAccountsFromDbForFirstPage()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parameters = GetParameters(1, 3);

                ArrangeOnExpAccountList(context, parameters, out var query, out var handler);

                //act
                var expAccounts = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(expAccounts.Items.Count == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnEmptyListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parameters = GetParameters(5, 10);

                ArrangeOnExpAccountList(context, parameters, out var query, out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "There are no records corresponding to your search!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageNumberIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parameters = GetParameters(-3, 10);

                ArrangeOnExpAccountList(context, parameters, out var query, out var handler);

                //act
                var expAccounts = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(expAccounts.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var parameters = GetParameters(1, 100);

                ArrangeOnExpAccountList(context, parameters, out var query, out var handler);

                //act
                var expAccounts = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(expAccounts.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldReturnListOrderedByName()
        {
            using (var context = GetDbContext())
            {
                //arange
                var parameters = GetParameters(1, 5);

                ArrangeOnExpAccountList(context, parameters, out var query, out var handler);

                //act
                var expAccounts = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(expAccounts.Items[0].Name == "Name_1");
            }
        }

        [TestMethod]
        public void ShouldReturnAllExpenseAccountsFromDbFilteredByAccountNo()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parameters = GetParameters(1, 15, accountNo: "12346");

                ArrangeOnExpAccountList(context, parameters, out var query, out var handler);

                //act
                var expAccounts = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(expAccounts.Items.Count == 1);
            }
        }

        [TestMethod]
        public void ShouldReturnAllExpenseAccountsFromDbFilteredByAccountName()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parameters = GetParameters(1, 15, accountName: "Name_1");

                ArrangeOnExpAccountList(context, parameters, out var query, out var handler);

                //act
                var expAccounts = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(expAccounts.Items.Count == 1);
            }
        }

        [TestMethod]
        public void ShouldReturnAllExpenseAccountsFromDbFilteredByAccountNameNo()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parameters = GetParameters(1, 15, accountNo: "12347", accountName: "Name_2");

                ArrangeOnExpAccountList(context, parameters, out var query, out var handler);

                //act
                var expAccounts = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(expAccounts.Items.Count == 1);
            }
        }

        [TestMethod]
        public void ShouldThrowErrorWhenFilteringOnValueNotExisting()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parameters = GetParameters(1, 15, accountNo: "99999");

                ArrangeOnExpAccountList(context, parameters, out var query, out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "There are no records corresponding to your search!");
            }
        }
    }
}
