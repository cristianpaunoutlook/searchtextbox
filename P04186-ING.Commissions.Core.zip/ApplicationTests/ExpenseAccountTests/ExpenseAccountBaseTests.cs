﻿using Application.DboExpenseAccount;
using Application.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;

namespace ApplicationTests.ExpenseAccountTests
{
    public class ExpenseAccountBaseTests : TestBase
    {
        public void InitExpAccTable(CommissionsContext context)
        {
            var expAccount1 = GetExpenseAccount(1, true);
            context.ExpenseAccounts.Add(expAccount1);

            var expAccount2 = GetExpenseAccount(2, true);
            context.ExpenseAccounts.Add(expAccount2);

            var expAccount3 = GetExpenseAccount(3, true);
            context.ExpenseAccounts.Add(expAccount3);

            var expAccount4 = GetExpenseAccount(4, true);
            context.ExpenseAccounts.Add(expAccount4);

            var expAccount5 = GetExpenseAccount(5, true);
            context.ExpenseAccounts.Add(expAccount5);

            var expAccount6 = GetExpenseAccount(6, false);
            context.ExpenseAccounts.Add(expAccount6);

            context.SaveChanges();
        }

        protected void ArrangeOnExpAccountList(CommissionsContext context, ExpenseAccountParams expenseAccountParams, out List.Query query, out List.Handler handler)
        {
            InitExpAccTable(context);

            query = new List.Query() { ExpenseAccountParams = expenseAccountParams };
            handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>(), GetMapper());
        }

        protected IConfiguration GetConfigurationObject()
        {
            var configuration = new Mock<IConfiguration>();
            configuration.Setup(c => c.GetSection("Notifications:ApplicationPath").Value).Returns("https://commissions");
            return configuration.Object;
        }
    }
}
