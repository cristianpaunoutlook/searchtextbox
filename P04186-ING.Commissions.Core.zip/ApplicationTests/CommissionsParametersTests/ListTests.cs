﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ApplicationTests.CommissionsParametersTests
{
    [TestClass]
    public class ListTests : CommissionsParametersBaseTests
    {
        [TestMethod]
        public void ShouldReturnAllParamsFromDb()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parametersParams = GetParametersParams();
                
                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnAllParamsToApprove()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parametersParams = GetParametersParams(context: Constants.TOAPPROVE);

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.Items.Count == 4);
            }
        }

        [TestMethod]
        public void ShouldReturnAllParametersFromDbForFirstPage()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parametersParams = GetParametersParams(1, 3);

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.Items.Count == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnEmptyListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parametersParams = GetParametersParams(5, 10);

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "There are no records corresponding to your search!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageNumberIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parametersParams = GetParametersParams(-3, 10);

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var parametersParams = GetParametersParams(1, 100);

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldReturnListSortedByStatusFirst()
        {
            using (var context = GetDbContext())
            {
                //arange
                var parametersParams = GetParametersParams(1, 5);

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.Items[0].StatusName == ObjectStatus.Added);
            }
        }

        [TestMethod]
        public void ShouldReturnListSortedByStatusFirstThenByName()
        {
            using (var context = GetDbContext())
            {
                //arange
                var parametersParams = GetParametersParams(1, 5);

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.Items[0].StatusName == ObjectStatus.Added && paramList.Items[3].Name == "Name_1");
            }
        }

        [TestMethod]
        public void FilterByStatusShouldReturnParamsByStatus()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parametersParams = GetParametersParams(1, 15, statusId: (int)ObjectStatusId.Added);

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.Items.Count == 1);
                Assert.IsTrue(paramList.Items.Count(o => o.StatusId == (int)ObjectStatusId.Added) == 1);
            }
        }

        [TestMethod]
        public void FilterByNameShouldReturnParamsByName()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parametersParams = GetParametersParams(1, 15, name: "Name_1");

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.Items.Count == 1);
                Assert.IsTrue(paramList.Items.Count(o => o.Name == "Name_1") == 1);
            }
        }

        [TestMethod]
        public void FilterByTableShouldReturnParamsByDescription()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parametersParams = GetParametersParams(1, 15, tableId: 1);

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.Items.Count == 2);
                Assert.IsTrue(paramList.Items.Count(o => o.TableId == 1) == 2);
            }
        }

        [TestMethod]
        public void FilterByPartialNameShouldReturnParamsContainingDescription()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parametersParams = GetParametersParams(1, 15, name: "Name");

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramList.Items.Count == 5);
                Assert.IsTrue(paramList.Items.Count(o => o.Name.Contains("Name")) == 5);
            }
        }

        [TestMethod]
        public void FilterByMultipleCriteriaReturnParamsWithAllCriteria()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var parametersParams = GetParametersParams(1, 15, name: "Name_1", tableId: 1);

                ArrangeOnParamsList(context, parametersParams, out var query, out var handler);

                //act
                var paramsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(paramsList.Items.Count == 1);
                Assert.IsTrue(paramsList.Items.Count(o => o.Name == "Name_1" && o.TableId == 1) == 1);
            }
        }
    }
}
