﻿using Application.Commons.Enums;
using Application.DboParameters;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;

namespace ApplicationTests.CommissionsParametersTests
{
    [TestClass]
    public class ApproveRejectTests : CommissionsParametersBaseTests
    {
        #region approve
        [TestMethod]
        public void ApproveAddedParameterShouldChangeToApprovedState()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var command = new Approve.Command()
                {
                    Id = 2,
                    UserKey = "AABBCC"
                };

                var currentAddedNumber = context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Approved
                                                        && ah.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Added) == currentAddedNumber - 1);
                Assert.IsTrue(context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Approved
                                                        && ah.Action.ActionName == ObjectAction.Approve.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void ApproveModifiedParameterShouldChangeToApprovedState()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var command = new Approve.Command()
                {
                    Id = 3,
                    UserKey = "AABBCC"
                };

                var currentAddedNumber = context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Updated);
                var currentHistCount = context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Updated
                                                && ah.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Updated) == currentAddedNumber - 1);
                Assert.IsTrue(context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Approved
                                                && ah.Action.ActionName == ObjectAction.Approve.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void ApproveWithSameUserThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var command = new Approve.Command()
                {
                    Id = 2,
                    UserKey = "User_2"
                };

                var currentAddedNumber = context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Approved
                                            && ah.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't approve with same user!");
            }
        }

        [TestMethod]
        public void ApproveOnStatusApprovedThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var command = new Approve.Command()
                {
                    Id = 1,
                    UserKey = "AAABBB"
                };

                var currentAddedNumber = context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Approved
                                            && ah.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't approve an approved account!");
            }
        }

        [TestMethod]
        public void ApproveOnInvalidParamThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var command = new Approve.Command()
                {
                    Id = 0,
                    UserKey = "AAABBB"
                };

                var currentAddedNumber = context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Approved
                                                && ah.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Invalid account!");
            }
        }

        [TestMethod]
        public void ApproveShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);

                var command = new Approve.Command()
                {
                    Id = 2,
                    UserKey = "AABBCC"
                };

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot approve parameter because there is a running job in progress");
            }
        }
        #endregion

        #region reject
        [TestMethod]
        public void RejectAddedParamShouldChangeToRejectAddState()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 2,
                    UserKey = "AABBCC",
                    RejectReason = "reject reason"
                };

                var currentAddedNumber = context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.RejectAdd
                                                    && ah.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Added) == currentAddedNumber - 1);
                Assert.IsTrue(context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.RejectAdd
                                                && ah.Action.ActionName == ObjectAction.Reject.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void RejectModifiedParamShouldChangeToRejectState()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 3,
                    UserKey = "AABBCC"
                };

                var currentAddedNumber = context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Updated);
                var currentHistCount = context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Rejected
                                                && ah.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Updated) == currentAddedNumber - 1);
                Assert.IsTrue(context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Rejected
                                                && ah.Action.ActionName == ObjectAction.Reject.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void RejectWithSameUserThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 2,
                    UserKey = "User_2"
                };

                var currentAddedNumber = context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Approved
                                                && ah.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't reject with same user!");
            }
        }

        [TestMethod]
        public void RejectOnStatusApprovedThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 1,
                    UserKey = "AAABBB"
                };

                var currentAddedNumber = context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Approved
                                                && ah.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't reject an approved account!");
            }
        }

        [TestMethod]
        public void RejectOnInvalidParamThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 0,
                    UserKey = "AAABBB"
                };

                var currentAddedNumber = context.CommissionsParameters.Count(a => a.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.CommissionsParametersHistory.Count(ah => ah.Status.StatusName == ObjectStatus.Approved
                                                && ah.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Invalid account!");
            }
        }

        [TestMethod]
        public void RejectShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);
                var command = new Reject.Command()
                {
                    Id = 2,
                    UserKey = "AABBCC",
                    RejectReason = "reject reason"
                };

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot reject parameter because there is a running job in progress");
            }
        }
        #endregion
    }
}
