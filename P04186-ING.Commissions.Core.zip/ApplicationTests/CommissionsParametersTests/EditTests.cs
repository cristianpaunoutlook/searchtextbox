﻿using Application.DboParameters;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;

namespace ApplicationTests.CommissionsParametersTests
{
    [TestClass]
    public class EditTests : CommissionsParametersBaseTests
    {
        [TestMethod]
        public void SaveParameterShouldBePersistedInDb()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var currentNumber = context.CommissionsParameters.Count();
                // Arrange
                var command = new Edit.Command()
                {
                    Id = 1,
                    Name = "Name_1",
                    TableId = 2,
                    Value = "11",
                    UserKey = "AABBCC"
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.CommissionsParameters.Count() == currentNumber);
                Assert.IsTrue(context.CommissionsParametersHistory.Count() == currentNumber + 1);
                Assert.IsTrue(context.CommissionsParameters.Count(p => p.Value == "11"
                    && p.Status.StatusName == Application.Commons.Enums.ObjectStatus.Updated.ToString()) == 1);
                Assert.IsTrue(context.CommissionsParametersHistory.Count(p => p.Value == "11") == 1);
            }
        }

        [TestMethod]
        public void EditInvalidParameterIdShouldThrowException()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var currentNumber = context.ExpenseAccounts.Count();
                // Arrange
                var command = new Edit.Command()
                {
                    Id = 111111,
                    Name = "Name_1",
                    TableId = 2,
                    Value = "11",
                    UserKey = "AABBCC"
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Asert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Parameter does not exist!");

            }
        }

        [TestMethod]
        public void EditParameterNotApprovedShouldThrowException()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                var currentNumber = context.ExpenseAccounts.Count();
                // Arrange
                var command = new Edit.Command()
                {
                    Id = 2,
                    Name = "Name_1",
                    TableId = 2,
                    Value = "11",
                    UserKey = "AABBCC"
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Asert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Parameter does not exist!");

            }
        }

        [TestMethod]
        public void EditShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitParametersAndParametersHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);

                // Arrange
                var command = new Edit.Command()
                {
                    Id = 1,
                    Name = "Name_1",
                    TableId = 2,
                    Value = "11",
                    UserKey = "AABBCC"
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot edit parameter because there is a running job in progress");
            }
        }
    }
}
