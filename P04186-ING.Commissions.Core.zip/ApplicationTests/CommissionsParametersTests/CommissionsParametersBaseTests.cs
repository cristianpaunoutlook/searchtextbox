﻿using Application.Commons.Enums;
using Application.Helpers;
using Persistence;
using Application.DboParameters;
using Moq;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System;

namespace ApplicationTests.CommissionsParametersTests
{
    public class CommissionsParametersBaseTests : TestBase
    {
        public void InitParametersAndParametersHistoryTables(CommissionsContext context)
        {
            var statusApproved = GetStatusObject((int)ObjectStatusId.Approved, ObjectStatus.Approved, 4);
            var statusAdded = GetStatusObject((int)ObjectStatusId.Added, ObjectStatus.Added, 1);
            var statusUpdated = GetStatusObject((int)ObjectStatusId.Updated, ObjectStatus.Updated, 2);
            var statusPendingDelete = GetStatusObject((int)ObjectStatusId.PendingDelete, ObjectStatus.PendingDelete, 3);
            var statusRejected = GetStatusObject((int)ObjectStatusId.Rejected, ObjectStatus.Rejected, 5);
            var statusDeleted = GetStatusObject((int)ObjectStatusId.Deleted, ObjectStatus.Deleted, 6);
            var statusRejectAdd = GetStatusObject((int)ObjectStatusId.RejectAdd, ObjectStatus.RejectAdd, 7);

            var objectActionAdd = GetObjectAction(1, "Add");
            var objectActionEdit = GetObjectAction(2, "Edit");
            var objectActionApprove = GetObjectAction(3, "Approve");
            var objectActionReject = GetObjectAction(4, "Reject");
            var objectActionDelete = GetObjectAction(5, "Delete");

            var table1 = GetTableObject(1);
            var table2 = GetTableObject(2);

            var paramActive = GetCommParameter(1, statusApproved, table1);
            context.CommissionsParametersHistory.Add(GetParameterHistory(1, paramActive, statusApproved, objectActionAdd, table1));

            var paramAdded = GetCommParameter(2, statusAdded, table1);
            context.CommissionsParametersHistory.Add(GetParameterHistory(2, paramAdded, statusAdded, objectActionAdd, table1));

            var paramUpdated = GetCommParameter(3, statusUpdated, table2);
            context.CommissionsParametersHistory.Add(GetParameterHistory(3, paramUpdated, statusUpdated, objectActionEdit, table2));

            var paramDelete = GetCommParameter(4, statusPendingDelete, table2);
            context.CommissionsParametersHistory.Add(GetParameterHistory(4, paramDelete, statusPendingDelete, objectActionEdit, table2));

            var paramRejected = GetCommParameter(5, statusRejected, table2);
            context.CommissionsParametersHistory.Add(GetParameterHistory(5, paramRejected, statusRejected, objectActionReject, table2));

            var paramDeleted = GetCommParameter(6, statusDeleted, table2);
            context.CommissionsParametersHistory.Add(GetParameterHistory(6, paramDeleted, statusDeleted, objectActionDelete, table2));

            context.ObjectActions.Add(objectActionApprove);
            context.ObjectStatus.Add(statusRejectAdd);
            context.SaveChanges();

        }

        public void InitStatusExportWithExecutingLineForPreviousMonth(CommissionsContext context)
        {
            var prevMonth = DateTime.Now.AddMonths(-1);
            var monthId = prevMonth.Year * 100 + prevMonth.Month;

            var statusExport = GetStatusExports((int)CommissionsTable.SMECommissions, "Executing", monthId);
            context.StatusExports.Add(statusExport);

            var tableSME = GetTables((int)CommissionsTable.SMECommissions, "SMECommissions");
            context.DWHTables.Add(tableSME);

            context.SaveChanges();
        }

        protected void ArrangeOnParamsList(CommissionsContext context, ParametersParams parametersParams, out List.Query query, out List.Handler handler)
        {
            InitParametersAndParametersHistoryTables(context);

            query = new List.Query() { ParametersParams = parametersParams };
            handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>(), GetMapper());
        }

        protected ParametersParams GetParametersParams(int pageNumber = 1, int pageSize = 15,
            string name = "", int tableId = -1, short statusId = -1, string context = "")
        {
            return new ParametersParams()
            {
                PageSize = pageSize,
                PageNumber = pageNumber,
                Name = name,
                StatusId = statusId,
                TableId = tableId,
                Context = context
            };
        }

        protected IConfiguration GetConfigurationObject()
        {
            var configuration = new Mock<IConfiguration>();
            configuration.Setup(c => c.GetSection("Notifications:ApplicationPath").Value).Returns("https://commissions");
            configuration.Setup(c => c.GetSection("Notifications:ParameterEmail").Value).Returns("testemailsmtp@ing.com");
            return configuration.Object;
        }
    }
}
