﻿using Application.SECSession;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ApplicationTests.SecSessionTests
{
    [TestClass]
    public class CreateSecSessionTests : TestBase
    {
        [TestMethod]
        public void AfterCreateWithDefaultValuesShouldHaveOneSecSessionInDb()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                var command = new Create.Command()
                {
                    IP = "1.0.0.0",
                    Session = "sessionKey",
                    UserId = "KK70XR",
                    Workstation = "workstation1"
                };
                var handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.SecSessions.Where(s => s.Session == "sessionKey" &&
                                                            s.CountFailedLogin == 0 &&
                                                            s.SessionDate.ToShortTimeString() == DateTime.Now.ToShortTimeString()).Count() == 1);

            }
        }

        [TestMethod]
        public void AfterCreateShouldHaveOneSecSessionInDb()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                var sessionDate = DateTime.Now.AddDays(1);
                var command = new Create.Command()
                {
                    IP = "1.0.0.0",
                    Session = "sessionKey",
                    UserId = "KK70XR",
                    Workstation = "workstation1",
                    CountFailedLogin = 2,
                    SessionDate = sessionDate
                };
                var handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.SecSessions.Where(s => s.Session == "sessionKey" &&
                                                            s.CountFailedLogin == 2 &&
                                                            s.SessionDate == sessionDate).Count() == 1);

            }
        }
    }
}