﻿using Application.Helpers;
using Application.Interfaces;
using Application.MapProfile;
using AutoMapper;
using Domain;
using Microsoft.EntityFrameworkCore;
using Moq;
using Persistence;
using System;

namespace ApplicationTests
{
    public class TestBase
    {
        private static bool useSqlite;

        public IMapper GetMapper()
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(typeof(MappingProfile)));
            IMapper mapper = config.CreateMapper();
            return mapper;
        }

        public static CommissionsContext GetDbContext(bool isSqlLite = false)
        {
            useSqlite = isSqlLite;
            DbContextOptionsBuilder<CommissionsContext> builder = new DbContextOptionsBuilder<CommissionsContext>();
            if (useSqlite)
            {
                // Use Sqlite DB.
                builder.UseSqlite("DataSource=:memory:", x => { });
            }
            else
            {
                // Use In-Memory DB.
                builder.UseInMemoryDatabase(Guid.NewGuid().ToString());
            }

            CommissionsContext dbContext = new CommissionsContext(builder.Options);
            if (useSqlite)
            {
                dbContext.Database.OpenConnection();
            }

            dbContext.Database.EnsureCreated();

            return dbContext;
        }

        public void UseSqlite()
        {
            useSqlite = true;
        }

        protected IEmailSender GetEmailSenderObject()
        {
            var mockEmailSender = new Mock<IEmailSender>();
            mockEmailSender.Setup(x => x.SendEmailAsync(It.IsAny<string[]>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<byte[]>()));
            return mockEmailSender.Object;
        }

        #region GetEntitiesObjects
        protected Domain.ObjectStatus GetStatusObject(short id, string status, byte displayOrder)
        {
            return new Domain.ObjectStatus
            {
                Id = id,
                StatusName = status,
                DisplayOrder = displayOrder
            };
        }

        protected Table GetTableObject(int id, bool behDeatils = true, bool commParams = true)
        {
            return new Table()
            {
                Id = id,
                TableName = $"Name{id}",
                BehDetails = behDeatils,
                CommParams = commParams
            };
        }

        protected TableColumn GetTableColumnObject(int id, Table table, string name)
        {
            return new TableColumn()
            {
                Id = id,
                Table= table,
                ColumnName = name
            };
        }

        protected ObjectAction GetObjectAction(short actionId, string actionName)
        {
            return new ObjectAction
            {
                Id = actionId,
                ActionName = actionName,
                Description = $"{actionName} - Description"
            };
        }

        protected ExpenseAccount GetExpenseAccount(int id, bool isVisible)
        {
            return new ExpenseAccount
            {
                Id = id,
                Name = $"Name_{id}",
                Number = 12345 + id,
                IsVisible = isVisible
            };
        }

        protected BehaviorDetails GetBehaviorDetails(int id, ExpenseAccount expAccount, Table table,
            TableColumn columns, ObjectStatus status)
        {
            return new BehaviorDetails
            {
                Id = id,
                Type = $"Type_{id}",
                Description = $"Description_{id}",
                ExpenseAccount = expAccount,
                CommissionBehaviorTables = table,
                CommissionBehaviorColumns = columns,
                CustomerCodeRange = $"CustomerCodeRange_{id}",
                UpdatedBy = "SYSTEM",
                UpdatedDate = DateTime.Now,
                ApproveRejectBy = "ABCDEF",
                ApproveRejectDate = DateTime.Now,
                RejectReason = "Reject",
                Status = status
            };
        }

        protected BehaviorDetailsHistory GetBehaviorDetailsHistory(int id, BehaviorDetails behaviorDetails, ExpenseAccount expAccount, Table table,
            TableColumn columns, ObjectStatus status, ObjectAction action)
        {
            return new BehaviorDetailsHistory
            {
                Id = id,
                BehaviorDetails = behaviorDetails,
                Type = $"Type_{id}",
                Description = $"Description_{id}",
                ExpenseAccount = expAccount,
                CommissionBehaviorTables = table,
                CommissionBehaviorColumns = columns,
                CustomerCodeRange = $"CustomerCodeRange_{id}",
                UpdatedBy = "SYSTEM",
                UpdatedDate = DateTime.Now,
                ApproveRejectBy = "ABCDEF",
                ApproveRejectDate = DateTime.Now,
                RejectReason = "Reject",
                Status = status,
                Action = action
            };
        }

        protected Group GetGroupObject(int id, string name, string adName, ObjectStatus objectStatus, ObjectStatus nextObjectStatus, string lastModifiedBy, DateTime lastModifiedDate)
        {
            return new Group()
            {
                Id = id,
                Name = name,
                ADName = adName,
                Status = objectStatus,
                NextStatus = nextObjectStatus,
                LastModifiedBy = lastModifiedBy,
                LastModifiedDate = lastModifiedDate
            };
        }

        protected ProductDetails GetProductDetails(int id, string productType, ExpenseAccount expenseAccount, ObjectStatus status, string userId, int ID = 0)
        {
            return new ProductDetails()
            {
                Id = id,
                ProductType = productType,
                ShortName = $"ShortName_{id}",
                Name = $"Name_{id}",
                UserId = userId,
                ApproveRejectId = $"Approver_{id}",
                ChangeDate = DateTime.Now,
                ApproveRejectDate = DateTime.Now,
                Status = status,
                StatusId = status.Id,
                ExpenseAccount = expenseAccount,
              
            };
        }
        protected Office GetOffice(int id, ObjectStatus status)
        {
            return new Office
            {
                Id = id,
                AgentCode = 11111 + id,
                BranchCode = 5501,
                BranchName = $"BranchName_{id}",
                ModifiedDate = DateTime.Now,
                ModifiedBy = $"User_{id}",
                ApprovedRejectedDate = DateTime.Now,
                ApprovedRejectedBy = $"Approver_{id}",
                BranchType = "STD",
                IsSMEClub = (id % 2) == 0,
                CompanyName = $"Company_{id}",
                OpenedDate = DateTime.Now,
                MaxLevel1 = id * 50,
                MinDigitalSale = id * 30,
                MinLevel1 = id * 40,
                OwnerNo = 33333 + id,
                RejectReason = $"RejectReason_{id}",
                Status = status
            };
        }

        protected OfficeHistory GetOfficeHistory(int id, Office office, ObjectStatus status, ObjectAction action)
        {
            return new OfficeHistory
            {
                Id = id,
                Office = office,
                OfficeId = office.Id,
                AgentCode = 11111 + office.Id,
                BranchCode = 22222 + office.Id,
                BranchName = $"BranchName_{office.Id}",
                ModifiedDate = DateTime.Now,
                ModifiedBy = $"User_{office.Id}",
                ApprovedRejectedDate = DateTime.Now,
                ApprovedRejectedBy = $"Approver_{office.Id}",
                BranchType = "STD",
                IsSMEClub = (office.Id % 2) == 0,
                CompanyName = $"Company_{office.Id}",
                OpenedDate = DateTime.Now,
                MaxLevel1 = office.Id * 50,
                MinDigitalSale = office.Id * 30,
                MinLevel1 = office.Id * 40,
                OwnerNo = 33333 + office.Id,
                RejectReason = $"RejectReason_{office.Id}",
                Status = status,
                Action = action
            };
        }

        protected CommissionsParameter GetCommParameter(int id, ObjectStatus status, Table table)
        {
            return new CommissionsParameter
            {
                Id = id,
                Name = $"Name_{id}",
                Value = $"Value_{id}",
                UpdatedDate = DateTime.Now,
                UpdatedBy = $"User_{id}",
                ApprovedRejectedDate = DateTime.Now,
                ApprovedRejectedBy = $"Approver_{id}",
                RejectReason = $"RejectReason_{id}",
                Status = status,
                Table = table
            };
        }

        protected CommissionsParameterHistory GetParameterHistory(int id, CommissionsParameter parameter, ObjectStatus status, ObjectAction action, Table table)
        {
            return new CommissionsParameterHistory
            {
                Id = id,
                CommissionsParameter = parameter,
                Name = $"Name_{parameter.Id}",
                Value = $"Value_{parameter.Id}",
                UpdatedDate = DateTime.Now,
                UpdatedBy = $"User_{parameter.Id}",
                ApprovedRejectedDate = DateTime.Now,
                ApprovedRejectedBy = $"Approver_{parameter.Id}",
                RejectReason = $"RejectReason_{parameter.Id}",
                Status = status,
                Action = action,
                Table = table
            };
        }

        protected ExpenseAccountParams GetParameters(int pageNumber, int pageSize, string accountNo = "", string accountName = "")
        {
            return new ExpenseAccountParams
            {
                PageNumber = pageNumber,
                PageSize = pageSize,
                AccountName = accountName,
                AccountNo = accountNo
            };
        }

        protected Product GetProduct(string productType)
        {
            return new Product()
            {
                ProductType = productType
            };
        }

        protected ProductDetailsHistory GetProductDetailsHistory(int id, ProductDetails productId, ExpenseAccount expenseAccount, ObjectStatus status, ObjectAction action)
        {
            return new ProductDetailsHistory
            {
                Id = id,
                ProductDetails = productId,
                ProductType = productId.ProductType,
                Name = $"Name_{productId.ProductType}",
                ShortName = $"ShortName_{productId.ProductType}",
                ExpenseAccount = expenseAccount,
                UpdatedDate = DateTime.Now,
                UpdateBy = $"User_{id}",
                ApprovedDate = DateTime.Now,
                ApprovedBy = $"Approver_{productId.ApproveRejectId}",
                Status = status,
                Action = action,
            };
        }

        protected StatusExport GetStatusExports(int id,string status ,int monthId)
        {
            return new StatusExport()
            {
                IdTable = id,
                ProcessStatus = status,
                RefDate = DateTime.Now,
                NoOfRecords = id * 100,
                MonthId = monthId
            };
        }
        protected Tables GetTables(int id, string tableName)
        {
            return new Tables()
            {
                Id = id,
                TableName = tableName,
                TableDescription = tableName + "test"
            };
        }
        #endregion
    }
}
