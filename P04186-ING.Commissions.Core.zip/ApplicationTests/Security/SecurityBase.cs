﻿using System;
using System.Collections.Generic;
using Application.Commons.Enums;
using Application.Interfaces;
using Domain;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Moq;
using Persistence;

namespace ApplicationTests.Security
{
    public class SecurityBase : TestBase
    {
        protected List<string> GetAdGroups()
        {
            return new List<string> { "AD\\\\GSAPC5D_WBIF-ADMIN",
                                        "AD\\\\GSAPC5D_WBIF-AUDIT",
                                        "AD\\\\GSAPC5D_WBIF-BROWSER",
                                        "AD\\\\GSAPC5D_WBIF-CADM",
                                        "AD\\\\GSAPC5A_POPRINT-Client",
                                        "AD\\\\GSAPC5D_INGCollection"
                                    };
        }

        protected void PrepareData(CommissionsContext context)
        {
            context.Pages.Add(new Page() { Id = 1, Code = "SEC", Name = "Security" });
            context.Pages.Add(new Page() { Id = 2, Code = "PG1", Name = "Page 1" });
            context.Pages.Add(new Page() { Id = 3, Code = "PG2", Name = "Page 2" });
            context.Pages.Add(new Page() { Id = 4, Code = "PG3", Name = "Page 3" });

            context.Rights.Add(new Right() { Id = 1, Code = "NORIGHT", Description = "User has no rights", Value = 0 });
            context.Rights.Add(new Right() { Id = 2, Code = "READ", Description = "Right to read or export", Value = 1 });
            context.Rights.Add(new Right() { Id = 3, Code = "EDIT", Description = "Right to add, modify or delete an entity", Value = 2 });
            context.Rights.Add(new Right() { Id = 4, Code = "APPROVE", Description = "Right to approve or reject a change on an entity", Value = 3 });

            context.ObjectStatus.Add(new Domain.ObjectStatus() { Id = (int)ObjectStatusId.Approved, StatusName = "Approved" });
            context.ObjectStatus.Add(new Domain.ObjectStatus() { Id = (int)ObjectStatusId.Added, StatusName = "Added" });
            context.ObjectStatus.Add(new Domain.ObjectStatus() { Id = (int)ObjectStatusId.Updated, StatusName = "Updated" });
            context.ObjectStatus.Add(new Domain.ObjectStatus() { Id = (int)ObjectStatusId.PendingDelete, StatusName = "PendingDelete" });

            context.Groups.Add(new Group() { Id = 1, ADName = "GSAPC5D_WBIF-ADMIN", Name = "AD_ADMIN", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = (int)ObjectStatusId.Approved, NextStatusId = (int)ObjectStatusId.Approved });
            context.Groups.Add(new Group() { Id = 2, ADName = "GSAPC5D_WBIF-AUDIT", Name = "AD_AUDIT", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = (int)ObjectStatusId.Approved, NextStatusId = (int)ObjectStatusId.Approved });
            context.Groups.Add(new Group() { Id = 3, ADName = "GSAPC5D_WBIF-BROWSER", Name = "AD_BROWSER", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = (int)ObjectStatusId.Added, NextStatusId = (int)ObjectStatusId.Added });
            context.Groups.Add(new Group() { Id = 4, ADName = "GSAPC5D_WBIF-CADM", Name = "AD_CADM", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = (int)ObjectStatusId.Approved, NextStatusId = (int)ObjectStatusId.Updated });
            context.Groups.Add(new Group() { Id = 5, ADName = "GSAPC5D_WBIF-GLPDM", Name = "AD_GLPDM", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = (int)ObjectStatusId.Approved, NextStatusId = (int)ObjectStatusId.PendingDelete });

            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 1, RightId = 4, PageId = 1, NextRightId = 4, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 2, RightId = 2, PageId = 2, NextRightId = 2, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 2, RightId = 2, PageId = 3, NextRightId = 2, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 3, RightId = 1, PageId = 3, NextRightId = 4, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 3, RightId = 1, PageId = 4, NextRightId = 3, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 4, RightId = 3, PageId = 4, NextRightId = 1, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 4, RightId = 2, PageId = 3, NextRightId = 1, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });

            context.SaveChanges();
        }

        protected IConfiguration GetConfigurationObject()
        {
            var configuration = new Mock<IConfiguration>();
            configuration.Setup(c => c.GetSection("UserGroupsNamePattern").Value).Returns("WBIF");
            return configuration.Object;
        }

        protected IADUserGroups GetAdUserGroupsObject()
        {
            var adUserGroups = new Mock<IADUserGroups>();
            adUserGroups.Setup(adUG => adUG.GetUserGroupsFromAD("WBIF")).Returns(GetAdGroups());
            return adUserGroups.Object;
        }

        protected IMemoryCache GetMemoryCacheObject()
        {
            var cacheEntryOptions = new MemoryCacheOptions();
            var memoryCache = new MemoryCache(cacheEntryOptions);

            return memoryCache;
        }
    }
}
