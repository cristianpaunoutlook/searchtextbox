﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Threading;

namespace ApplicationTests.ProductDetailsTests
{
    [TestClass]
    public class ProductDetailsListTests : ProductDetailsBaseTests
    {
        [TestMethod]
        public void ShouldReturnAllProductDetailsFromDb()
        {
            using (var context = GetDbContext())
            {
                //arrange
              
                var custParams = SetProductDetailsParams(pageNumber: 1, pageSize: 15);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
               var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnAllProductsToApprove()
        {
            using (var context = GetDbContext())
            {
                //arrange

                var custParams = SetProductDetailsParams(pageNumber: 1, pageSize: 15, context: Constants.TOAPPROVE);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items.Count == 4);
            }
        }

        [TestMethod]
        public void ShouldReturnAllProductDetailsFromDbForFirstPage()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var custParams = SetProductDetailsParams(pageNumber: 1, pageSize: 3);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items.Count == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnEmptyListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var custParams = SetProductDetailsParams(pageNumber: 5, pageSize: 10);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "There are no records corresponding to your search!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageNumberIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var custParams = SetProductDetailsParams(pageNumber: -3, pageSize: 10);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(pageNumber: 1, pageSize: 100);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldReturnListOrderedByProductType()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(pageNumber: 1, pageSize: 5);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items[3].ProductType == "TEST3");
            }
        }

        [TestMethod]
        public void ShouldReturnListOrderedByShortName()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(pageNumber: 1, pageSize: 5);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items[0].ShortName == "ShortName_1");
            }
        }

        [TestMethod]
        public void ShouldReturnListOrderedByStatusAdded()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(pageNumber: 1, pageSize: 5);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items[0].Status == ObjectStatus.Added);
            }
        }

        [TestMethod]
        public void ShouldReturnListOrderedByProductTypeThenByShortNameThenByStatus()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(pageNumber: 1, pageSize: 5);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items[0].ProductType == "TEST1" && (productDetails.Items[0].ShortName == "ShortName_1"
                    && productDetails.Items[3].Status == ObjectStatus.Approved));
                    
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredProductDetailsListContainingProductType()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(productType: "TEST1");

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items.Count ==1 && productDetails.Items.Any(c => c.Status == "Added"));
            }
        }
        [TestMethod]
        public void ShouldReturnFilteredProductDetailsListContainingShortName()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(productShortName: "ShortName_1");

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items.Count == 1 && productDetails.Items.Any(c => c.ProductType == "TEST1"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredProductDetailsListContainingStatusPendingDelete()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(statusId: (int) ObjectStatusId.PendingDelete);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items.Count == 1 && productDetails.Items.Any(c => c.ProductType == "TEST5"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredProductDetailsListContainingStatusUpdated()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(statusId: (int)ObjectStatusId.Updated);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items.Count == 1 && productDetails.Items.Any(c => c.ProductType == "TEST2"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredProductDetailsListContainingStatusRejected()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(statusId: (int)ObjectStatusId.Rejected);

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items.Count == 1 && productDetails.Items.Any(c => c.ShortName == "ShortName_4"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredProductDetailsListContainingProductTypeStatusAndShortName()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetProductDetailsParams(productType: "TEST5", statusId: (int)ObjectStatusId.PendingDelete,
                    productShortName: "ShortName_5");

                ArrangeOnProductsList(context, custParams, out var query, out var handler);

                //act
                var productDetails = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(productDetails.Items.Count == 1 && productDetails.Items.Any(c => c.ShortName == "ShortName_5"));
            }
        }
    }
}