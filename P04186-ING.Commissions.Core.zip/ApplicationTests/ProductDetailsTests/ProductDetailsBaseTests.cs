﻿using Application.Commons.Enums;
using Application.DboProductDetails;
using Application.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;
using System;

namespace ApplicationTests.ProductDetailsTests
{
    public class ProductDetailsBaseTests : TestBase
    {
        public void InitProductDetailsTable(CommissionsContext context)
        {
            var statusApproved = GetStatusObject((int)ObjectStatusId.Approved, ObjectStatus.Approved, 4);
            var statusAdded = GetStatusObject((int)ObjectStatusId.Added, ObjectStatus.Added, 1);
            var statusUpdated = GetStatusObject((int)ObjectStatusId.Updated, ObjectStatus.Updated, 2);
            var statusPendingDelete = GetStatusObject((int)ObjectStatusId.PendingDelete, ObjectStatus.PendingDelete, 3);
            var statusRejected = GetStatusObject((int)ObjectStatusId.Rejected, ObjectStatus.Rejected, 5);
            var statusDeleted = GetStatusObject((int)ObjectStatusId.Deleted, ObjectStatus.Deleted, 6);
            var statusRejectAdd = GetStatusObject((int)ObjectStatusId.RejectAdd, ObjectStatus.RejectAdd, 7);

            var expAccount1 = GetExpenseAccount(1, true);
            var expAccount2 = GetExpenseAccount(2, true);
            var expAccount3 = GetExpenseAccount(3, true);
            var expAccount4 = GetExpenseAccount(4, true);
            var expAccount5 = GetExpenseAccount(5, true);
            var expAccount6 = GetExpenseAccount(6, true);
            var expAccount7 = GetExpenseAccount(7, true);

            var objectActionAdd = GetObjectAction(1, "Add");
            var objectActionEdit = GetObjectAction(2, "Edit");
            var objectActionApprove = GetObjectAction(3, "Approve");
            var objectActionReject = GetObjectAction(4, "Reject");
            var objectActionDelete = GetObjectAction(5, "Delete");

            var productAdded = GetProductDetails(1, "TEST1", expAccount1, statusAdded, "sw47gl");
            context.ProductDetailsHistory.Add(GetProductDetailsHistory(1, productAdded, expAccount1, statusAdded, objectActionAdd));
            context.Products.Add(GetProduct(productAdded.ProductType));

            var productUpdated = GetProductDetails(2, "TEST2", expAccount2, statusUpdated, "sw47gl");
            context.ProductDetailsHistory.Add(GetProductDetailsHistory(2, productUpdated, expAccount2, statusUpdated, objectActionEdit));
            context.Products.Add(GetProduct(productUpdated.ProductType));

            var productApproved = GetProductDetails(3, "TEST3", expAccount3, statusApproved, "sw47gl");
            context.ProductDetailsHistory.Add(GetProductDetailsHistory(3, productApproved, expAccount3, statusApproved, objectActionApprove));
            context.Products.Add(GetProduct(productApproved.ProductType));

            var productRejected = GetProductDetails(4, "TEST4", expAccount4, statusRejected, "sw47gl");
            context.ProductDetailsHistory.Add(GetProductDetailsHistory(4, productRejected, expAccount4, statusRejected, objectActionReject));
            context.Products.Add(GetProduct(productRejected.ProductType));

            var productPendingDelete = GetProductDetails(5, "TEST5", expAccount5, statusPendingDelete, "sw47gl");
            context.ProductDetailsHistory.Add(GetProductDetailsHistory(5, productPendingDelete, expAccount5, statusPendingDelete, objectActionEdit));
            context.Products.Add(GetProduct(productPendingDelete.ProductType));

            var productDeleted = GetProductDetails(6, "TEST6", expAccount6, statusDeleted, "UO04XR", 1);
            context.ProductDetailsHistory.Add(GetProductDetailsHistory(6, productDeleted, expAccount6, statusDeleted, objectActionAdd));
            context.Products.Add(GetProduct(productDeleted.ProductType));

            var productRejectedAdd = GetProductDetails(7, "TEST7", expAccount7, statusRejectAdd, "UO04XR", 2);
            context.ProductDetailsHistory.Add(GetProductDetailsHistory(7, productRejectedAdd, expAccount7, statusRejectAdd, objectActionAdd));
            context.Products.Add(GetProduct(productRejectedAdd.ProductType));

            context.Add(GetProduct("ProductForCreateNotInProductDetails"));

            context.ObjectStatus.Add(statusRejectAdd);
            context.ObjectStatus.Add(statusDeleted);
            context.ObjectStatus.Add(statusPendingDelete);
            context.ObjectActions.Add(objectActionDelete);

            context.SaveChanges();
        }

        public void InitStatusExportWithExecutingLineForPreviousMonth(CommissionsContext context)
        {
            var prevMonth = DateTime.Now.AddMonths(-1);
            var monthId = prevMonth.Year * 100 + prevMonth.Month;

            var statusExport = GetStatusExports((int)CommissionsTable.SMECommissions, "Executing", monthId);
            context.StatusExports.Add(statusExport);

            var tableSME = GetTables((int)CommissionsTable.SMECommissions, "SMECommissions");
            context.DWHTables.Add(tableSME);

            context.SaveChanges();
        }

        protected void ArrangeOnProductsList(CommissionsContext context, ProductDetailsParams paginationParams, out List.Query query, out List.Handler handler)
        {
            InitProductDetailsTable(context);

            query = new List.Query() { ProductDetailsParams = paginationParams };
            handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>(), GetMapper());
        }

        protected ProductDetailsParams SetProductDetailsParams(int pageNumber = 1, int pageSize = 15,
             string productType = "", string productShortName = "", short statusId = -1, string context = "")
        {
            return new ProductDetailsParams
            {
                ProductType = productType,
                ShortName = productShortName,
                StatusId = statusId,
                PageNumber = pageNumber,
                PageSize = pageSize,
                Context = context
            };
        }

        protected IConfiguration GetConfigurationObject()
        {
            var configuration = new Mock<IConfiguration>();
            configuration.Setup(c => c.GetSection("Notifications:ApplicationPath").Value).Returns("https://commissions");
            configuration.Setup(c => c.GetSection("Notifications:ProductDetailsEmail").Value).Returns("testemailsmtp@ing.com");
            return configuration.Object;
        }
    }
}
