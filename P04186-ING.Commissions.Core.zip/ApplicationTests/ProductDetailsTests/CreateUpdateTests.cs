﻿using Application.DboProductDetails;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Linq;
using System.Threading;

namespace ApplicationTests.ProductDetailsTests
{
    [TestClass]
    public class CreateUpdateTests : ProductDetailsBaseTests
    {
        #region Create product
        [TestMethod]
        public void AfterCreateProductShouldBeInDb()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var currentNumber = context.ProductDetails.Count();
                // Arrange
                var command = new Create.Command()
                {
                    ProductType = "ProductForCreateNotInProductDetails",
                    ProductDescription = "TestDescription",
                    ProductName = "TestName",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Create.Handler(context, GetMapper(), Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count() == currentNumber + 1);
            }
        }

        [TestMethod]
        public void CreateProductWithSameProductTypeShouldThrowException()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var currentNumber = context.ProductDetails.Count();
                // Arrange
                var command = new Create.Command()
                {
                    ProductType = "ProductForCreateNotInProductDetails",
                    ProductDescription = "TestDescription",
                    ProductName = "TestName",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Create.Handler(context, GetMapper(), Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"Product with type {command.ProductType} can not be added!");
            }
        }

        [TestMethod]
        public void CreateProductWithProductTypeNotInProductsShouldThrowException()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                // Arrange
                var command = new Create.Command()
                {
                    ProductType = "TEST1NotInProducts",
                    ProductDescription = "TestDescriptionFromCreate",
                    ProductName = "TestName",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Create.Handler(context, GetMapper(), Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"Product with type {command.ProductType} can not be added!");
            }
        }

        [TestMethod]
        public void OverwriteProductOnDeletedStateShouldBePersistedInDb()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var currentNumber = context.ProductDetails.Count();
                var currnetNoProductDetailsHistory = context.ProductDetailsHistory.Count();
                // Arrange
                var command = new Create.Command()
                {
                    ProductType = "TEST6",
                    ProductDescription = "TestDescriptionFromCreate",
                    ProductName = "TestName",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Create.Handler(context, GetMapper(), Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count() == currentNumber);
                Assert.IsTrue(context.ProductDetailsHistory.Count() == currnetNoProductDetailsHistory + 1);
                Assert.IsTrue(context.ProductDetails.Where(pd => pd.ProductType == "TEST6"
                                                           && pd.Name == "TestDescriptionFromCreate").Count() == 1);
            }
        }

        [TestMethod]
        public void OverwriteProductOnRejectedAddStateShouldBePersistedInDb()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var currentNumber = context.ProductDetails.Count();
                var currnetNoProductDetailsHistory = context.ProductDetailsHistory.Count();
                // Arrange
                var command = new Create.Command()
                {
                    ProductType = "TEST7",
                    ProductDescription = "TestDescriptionFromCreate",
                    ProductName = "TestName",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Create.Handler(context, GetMapper(), Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count() == currentNumber);
                Assert.IsTrue(context.ProductDetailsHistory.Count() == currnetNoProductDetailsHistory + 1);
                Assert.IsTrue(context.ProductDetails.Where(pd => pd.ProductType == "TEST7"
                                                           && pd.Name == "TestDescriptionFromCreate").Count() == 1);
            }
        }

        [TestMethod]
        public void OverwriteProductWithBadStateShouldThrowException()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                // Arrange
                var command = new Create.Command()
                {
                    ProductType = "TEST1",
                    ProductDescription = "TestDescriptionFromCreate",
                    ProductName = "TestName",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Create.Handler(context, GetMapper(), Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"Product with type {command.ProductType} can not be added!");
            }
        }

        [TestMethod]
        public void CreateShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);

                var currentNumber = context.ProductDetails.Count();
                // Arrange
                var command = new Create.Command()
                {
                    ProductType = "ProductForCreateNotInProductDetails",
                    ProductDescription = "TestDescription",
                    ProductName = "TestName",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Create.Handler(context, GetMapper(), Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot create product because there is a running job in progress");
            }
        }
        #endregion

        #region Update product
        [TestMethod]
        public void UpdatedProductDetailsShouldBePersistedInDb()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var currentNumber = context.ProductDetails.Count();
                var currnetNoProductDetailsHistory = context.ProductDetailsHistory.Count();

                // Arrange
                var command = new Edit.Command()
                {
                    Id = 3,
                    ProductDescription = "TestDescriptionChanged",
                    ProductName = "TestNameChanged",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count() == currentNumber);
                Assert.IsTrue(context.ProductDetails.Where(pd => pd.Name == command.ProductDescription).Count() == 1);
                Assert.IsTrue(context.ProductDetailsHistory.Count() == currnetNoProductDetailsHistory + 1);
                Assert.IsTrue(context.ProductDetailsHistory.Where(pdh => pdh.ProductDetailsId == command.Id).Count() == 2);
            }
        }

        //Editing a product which is not in approved state should throw error
        [TestMethod]
        public void UpdatedProductDetailsNotApprovedShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var currentNumber = context.ProductDetails.Count();
                var currnetNoProductDetailsHistory = context.ProductDetailsHistory.Count();

                // Arrange
                var command = new Edit.Command()
                {
                    ProductType = "TEST1",
                    ProductDescription = "TestDescriptionChanged",
                    ProductName = "TestNameChanged",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"The product {command.ProductType} should be in Approved state to be modified!");
            }
        }
        //Editing a product which not exists in productdetails should throw error
        [TestMethod]
        public void UpdatedProductDetailsThatDoentExistShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var currentNumber = context.ProductDetails.Count();
                var currnetNoProductDetailsHistory = context.ProductDetailsHistory.Count();

                // Arrange
                var command = new Edit.Command()
                {
                    ProductType = "TEST1PRDNotExists",
                    ProductDescription = "TestDescriptionChanged",
                    ProductName = "TestNameChanged",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"The product {command.ProductType} is not in the database");
            }
        }

        [TestMethod]
        public void UpdateShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);

                // Arrange
                var command = new Edit.Command()
                {
                    Id = 3,
                    ProductDescription = "TestDescriptionChanged",
                    ProductName = "TestNameChanged",
                    LastModifiedBy = "UO04XR",
                    ChangeDate = DateTime.Now,
                    ExpenseAccountId = 4
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot edit product because there is a running job in progress");
            }
        }
        #endregion
    }
}
