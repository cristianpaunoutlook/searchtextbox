﻿using Application.DboProductDetails;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;

namespace ApplicationTests.ProductDetailsTests
{
    [TestClass]
    public class DeleteTests : ProductDetailsBaseTests
    {
        [TestMethod]
        public void AfterDeleteProductShouldNotBeInDb()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var currentNumber = context.ProductDetails.Count();
                var currentNumberHistory = context.ProductDetailsHistory.Count();
                // Arrange
                var command = new Delete.Command()
                {
                    Id = 3,
                    UserKey = "ABCDEF"
                };

                var handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count() == currentNumber);
                Assert.IsTrue(context.ProductDetails.Where(pd => pd.Id == command.Id && pd.StatusId == (short)Application.Commons.Enums.ObjectStatusId.PendingDelete).Count() == 1);
                Assert.IsTrue(context.ProductDetailsHistory.Count() == currentNumberHistory + 1);
            }
        }

        [TestMethod]
        public void DeleteWithInvalidProductTypeThrowEx()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                // Arrange
                var command = new Delete.Command()
                {
                    Id = 99,
                    UserKey = "AAAABB"
                };

                var handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                var result = handler.Handle(command, (new CancellationTokenSource()).Token);


                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Invalid product type!");
            }
        }

        [TestMethod]
        public void DeleteProductNotApprovedProductTypeThrowEx()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                // Arrange
                var command = new Delete.Command()
                {
                    Id = 1,
                    UserKey = "AAAABB"
                };

                var handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "The product should be approved!");
            }
        }

        public void DeleteShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);

                // Arrange
                var command = new Delete.Command()
                {
                    Id = 3,
                    UserKey = "ABCDEF"
                };

                var handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot delete product because there is a running job in progress");
            }
        }

    }
}
