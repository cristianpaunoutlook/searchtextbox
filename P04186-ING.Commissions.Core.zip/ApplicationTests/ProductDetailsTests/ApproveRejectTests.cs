﻿using Application.Commons.Enums;
using Application.DboProductDetails;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;

namespace ApplicationTests.ProductDetailsTests
{
    [TestClass]
    public class ApproveRejectTests : ProductDetailsBaseTests
    {
        #region approve
        [TestMethod]
        public void ApproveAddedProductShouldChangeToApprovedState()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Approve.Command()
                {
                    ProductDetailsId = 1,
                    UserKey = "AABBCC"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Added) == currentAddedProductDetail - 1);
                Assert.IsTrue(context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void ApproveModifiedProductShouldChangeToApprovedState()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Approve.Command()
                {
                    ProductDetailsId = 2,
                    UserKey = "AABBCC"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Updated);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Updated && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Updated) == currentAddedProductDetail - 1);
                Assert.IsTrue(context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString() && ph.ProductType == "TEST2") == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void ApprovePendingDeleteProductShouldChangeToDeletedState()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Approve.Command()
                {
                    ProductDetailsId = 5,
                    UserKey = "AABBCC"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.PendingDelete);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Deleted && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.PendingDelete) == currentAddedProductDetail - 1);
                Assert.IsTrue(context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Deleted && ph.Action.ActionName == ObjectAction.Approve.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void ApproveWithSameUserThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Approve.Command()
                {
                    ProductDetailsId = 1,
                    UserKey = "User_2"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't approve with same user!");
            }
        }

        [TestMethod]
        public void ApproveOnStatusApprovedThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Approve.Command()
                {
                    ProductDetailsId = 3,
                    UserKey = "AAABBB"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't approve an approved product!");
            }
        }

        [TestMethod]
        public void ApproveOnInvalidProductThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Approve.Command()
                {
                    ProductDetailsId = 99,
                    UserKey = "AAABBB"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Invalid product!");
            }
        }

        public void ApproveShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);
                var command = new Approve.Command()
                {
                    ProductDetailsId = 1,
                    UserKey = "AABBCC"
                };

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot approve product because there is a running job in progress");
            }
        }
        #endregion

        #region reject
        [TestMethod]
        public void RejectAddedProductShouldChangeToRejectAddState()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Reject.Command()
                {
                    ProductDetailsId = 1,
                    UserKey = "AABBCC",
                    RejectReason = "reject reason"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.RejectAdd && ph.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Added) == currentAddedProductDetail - 1);
                Assert.IsTrue(context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.RejectAdd && ph.Action.ActionName == ObjectAction.Reject.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void RejectModifiedProductShouldChangeToRejectState()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Reject.Command()
                {
                    ProductDetailsId = 2,
                    UserKey = "AABBCC"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Updated);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Rejected && ph.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Updated) == currentAddedProductDetail - 1);
                Assert.IsTrue(context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Rejected && ph.Action.ActionName == ObjectAction.Reject.ToString()) == currentHistCount + 1);
            }
        }


        [TestMethod]
        public void RejectPendingDeleteProductShouldChangeToApprovedState()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Reject.Command()
                {
                    ProductDetailsId = 5,
                    UserKey = "AABBCC"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.PendingDelete);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.PendingDelete) == currentAddedProductDetail - 1);
                Assert.IsTrue(context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Reject.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void RejectWithSameUserThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Reject.Command()
                {
                    ProductType = "TEST",
                    UserKey = "User_2"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't reject with same user!");
            }
        }

        [TestMethod]
        public void RejectOnStatusApprovedThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Reject.Command()
                {
                    ProductType = "TEST",
                    UserKey = "AAABBB"
                };

                var currentAddedProductDetail = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't reject an approved product!");
            }
        }

        [TestMethod]
        public void RejectOnInvalidProductThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                var command = new Reject.Command()
                {
                    ProductType = "TEST",
                    UserKey = "AAABBB"
                };

                var currentAddedNumber = context.ProductDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.ProductDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Invalid product!");
            }
        }

        [TestMethod]
        public void RejectShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitProductDetailsTable(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);
                var command = new Reject.Command()
                {
                    ProductDetailsId = 1,
                    UserKey = "AABBCC",
                    RejectReason = "reject reason"
                };

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot reject product because there is a running job in progress");
            }
        }
        #endregion
    }

}