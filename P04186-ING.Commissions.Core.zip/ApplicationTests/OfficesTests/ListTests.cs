﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ApplicationTests.OfficesTests
{
    [TestClass]
    public class ListTests : OfficeBaseTests
    {
        [TestMethod]
        public void ShouldReturnAllOfficessFromDb()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams();

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnAllOfficessToApprove()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(context: Constants.TOAPPROVE);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 4);
            }
        }

        [TestMethod]
        public void ShouldReturnAllOfficessWithoutData()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(context: Constants.TOFILLREQ);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 6);
            }
        }


        [TestMethod]
        public void ShouldReturnAllOfficesFromDbForFirstPage()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(1, 3);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 3);
            }
        }
        
        [TestMethod]
        public void ShouldReturnEmptyListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(5, 10);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "There are no records corresponding to your search!");
            }
        }
        
        [TestMethod]
        public void ShouldReturnFirstPageNumberIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(-3, 10);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 5);
            }
        }
        
        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var officeParams = GetOfficeParams(1, 100);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldReturnListSortedByStatusFirst()
        {
            using (var context = GetDbContext())
            {
                //arange
                var officeParams = GetOfficeParams(1, 5);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items[0].StatusName == ObjectStatus.Added);
            }
        }

        [TestMethod]
        public void ShouldReturnListSortedByStatusFirstThenByName()
        {
            using (var context = GetDbContext())
            {
                //arange
                var officeParams = GetOfficeParams(1, 5);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items[0].StatusName == ObjectStatus.Added && offices.Items[3].BranchName == "BranchName_1");
            }
        }

        [TestMethod]
        public void FilterByStatusShouldReturnOfficesByStatus()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(1, 15, statusId: (int) ObjectStatusId.Added);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 1);
                Assert.IsTrue(offices.Items.Count(o => o.StatusId == (int)ObjectStatusId.Added) == 1);
            }
        }

        [TestMethod]
        public void FilterByAgentShouldReturnOfficesByAgentCode()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(1, 15, agentCode: 11112);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 1);
                Assert.IsTrue(offices.Items.Count(o => o.AgentCode == 11112) == 1);
            }
        }

        [TestMethod]
        public void FilterByBranchCodeShouldReturnOfficesByBranchCode()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(1, 15, branchCode: 5501);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 5);
                Assert.IsTrue(offices.Items.Count(o => o.BranchCode == 5501) == 5);
            }
        }

        [TestMethod]
        public void FilterByBranchNameShouldReturnOfficesByBranchName()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(1, 15, branchName: "BranchName_1");

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 1);
                Assert.IsTrue(offices.Items.Count(o => o.BranchName == "BranchName_1") == 1);
            }
        }

        [TestMethod]
        public void FilterByPartialBranchNameShouldReturnOfficesContainingBranchName()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(1, 15, branchName: "BranchName");

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 5);
                Assert.IsTrue(offices.Items.Count(o => o.BranchName.Contains("BranchName")) == 5);
            }
        }

        [TestMethod]
        public void FilterByMultipleCriteriaReturnOfficesWithAllCriteria()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(1, 15, agentCode: 11112, branchCode: 5501);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 1);
                Assert.IsTrue(offices.Items.Count(o => o.AgentCode == 11112 && o.BranchCode == 5501) == 1);
            }
        }

        [TestMethod]
        public void FilterBySMEClubShouldReturnOfficesBySMEClub()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var officeParams = GetOfficeParams(1, 15, isSMEClub: true);

                ArrangeOnOfficeList(context, officeParams, out var query, out var handler);

                //act
                var offices = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(offices.Items.Count == 2);
                Assert.IsTrue(offices.Items.Count(o => o.IsSMEClub == true) == 2);
            }
        }
    }
}
