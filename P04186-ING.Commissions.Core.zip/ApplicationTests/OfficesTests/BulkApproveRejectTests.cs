﻿using Application.Commons.Enums;
using Application.DboOffices;
using Application.Errors;
using Application.Helpers;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;

namespace ApplicationTests.OfficesTests
{
    [TestClass]
    public class BulkApproveRejectTests : OfficeBaseTests
    {
        #region bulkapprove
        [TestMethod]
        public void BulkApproveWithoutFilterValuesShouldApproveAllModifiedOffices()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions();
                var command = new BulkApprove.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter
                };
                var currentModifiedNo = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added ||
                                                                   o.Status.StatusName == ObjectStatus.Updated ||
                                                                   o.Status.StatusName == ObjectStatus.PendingDelete);
                var currentPendingDeleteNo = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.PendingDelete);
                var currentApprovedHistNo = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                        && oh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new BulkApprove.Handler(context, GetMapper(), Mock.Of<ILogger<BulkApprove.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added ||
                                                         o.Status.StatusName == ObjectStatus.Updated ||
                                                         o.Status.StatusName == ObjectStatus.PendingDelete) == 0);
                Assert.IsTrue(context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                        && oh.Action.ActionName == ObjectAction.Approve.ToString()) == currentApprovedHistNo + currentModifiedNo - currentPendingDeleteNo);
            }
        }

        [TestMethod]
        public void BulkApproveWithFilterShouldApproveFilteredOffices()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions(11113, 5501, "BranchName_2");
                var command = new BulkApprove.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter
                };
                var currentModifiedNo = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added ||
                                                                   o.Status.StatusName == ObjectStatus.Updated ||
                                                                   o.Status.StatusName == ObjectStatus.PendingDelete);
                var currentApprovedHistNo = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                        && oh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new BulkApprove.Handler(context, GetMapper(), Mock.Of<ILogger<BulkApprove.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added ||
                                                         o.Status.StatusName == ObjectStatus.Updated ||
                                                         o.Status.StatusName == ObjectStatus.PendingDelete) == currentModifiedNo - 1);
                Assert.IsTrue(context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                        && oh.Action.ActionName == ObjectAction.Approve.ToString()) == currentApprovedHistNo + 1);
            }

        }

        [TestMethod]
        public void BulkApproveWithSameUserShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions(11113, 5501, "BranchName_2");
                var command = new BulkApprove.Command()
                {
                    UserId = "User_2",
                    Filter = filter
                };

                var handler = new BulkApprove.Handler(context, GetMapper(), Mock.Of<ILogger<BulkApprove.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't approve offices modified by the same user!");
            }

        }

        [TestMethod]
        public void BulkApproveWithBadFilterValuesShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions(11113, 999999, "BranchName_2");
                var command = new BulkApprove.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter
                };

                var handler = new BulkApprove.Handler(context, GetMapper(), Mock.Of<ILogger<BulkApprove.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "There are no offices in the database corespondig to your search criterias!");
            }

        }

        [TestMethod]
        public void BulkApproveOnStatusesNotInAddedUpdatedPendingDeleteShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions(11112);
                var command = new BulkApprove.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter
                };

                var handler = new BulkApprove.Handler(context, GetMapper(), Mock.Of<ILogger<BulkApprove.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't approve offices that are not in statuses Added, Updated or Deleted!");
            }

        }

        [TestMethod]
        public void BulkApproveShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);

                var filter = InitFilterForBulkActions();
                var command = new BulkApprove.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter
                };

                var handler = new BulkApprove.Handler(context, GetMapper(), Mock.Of<ILogger<BulkApprove.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot bulk approve offices because there is a running job in progress");
            }
        }
        #endregion

        #region bulkreject
        [TestMethod]
        public void BulkRejectWithoutFilterValuesShouldRejectAllModifiedOffices()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions();
                var command = new BulkReject.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter,
                    RejectReason = "Not OK!"
                };
                var currentModifiedNo = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added ||
                                                                   o.Status.StatusName == ObjectStatus.Updated ||
                                                                   o.Status.StatusName == ObjectStatus.PendingDelete);
                var currentRejectedHistNo = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Rejected || oh.Status.StatusName == ObjectStatus.RejectAdd
                                                                            || oh.Status.StatusName == ObjectStatus.Approved
                                                        && oh.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new BulkReject.Handler(context, GetMapper(), Mock.Of<ILogger<BulkReject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added ||
                                                         o.Status.StatusName == ObjectStatus.Updated ||
                                                         o.Status.StatusName == ObjectStatus.PendingDelete) == 0);
                Assert.IsTrue(context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Rejected || oh.Status.StatusName == ObjectStatus.RejectAdd
                                                                            || oh.Status.StatusName == ObjectStatus.Approved
                                                        && oh.Action.ActionName == ObjectAction.Reject.ToString()) == currentRejectedHistNo + currentModifiedNo);
            }
        }

        [TestMethod]
        public void BulkRejectWithFilterShouldRejectFilteredOffices()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions(11113, 5501, "BranchName_2");
                var command = new BulkReject.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter,
                    RejectReason = "Not OK!"
                };
                var currentModifiedNo = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added ||
                                                                   o.Status.StatusName == ObjectStatus.Updated ||
                                                                   o.Status.StatusName == ObjectStatus.PendingDelete);
                var currentRejecteddHistNo = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Rejected || oh.Status.StatusName == ObjectStatus.RejectAdd
                                                                            || oh.Status.StatusName == ObjectStatus.Approved
                                                                            && oh.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new BulkReject.Handler(context, GetMapper(), Mock.Of<ILogger<BulkReject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added ||
                                                         o.Status.StatusName == ObjectStatus.Updated ||
                                                         o.Status.StatusName == ObjectStatus.PendingDelete) == currentModifiedNo - 1);
                Assert.IsTrue(context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Rejected || oh.Status.StatusName == ObjectStatus.RejectAdd
                                                                            || oh.Status.StatusName == ObjectStatus.Approved
                                                                            && oh.Action.ActionName == ObjectAction.Reject.ToString()) == currentRejecteddHistNo + 1);
            }

        }

        [TestMethod]
        public void BulkRejectWithSameUserShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions(11113, 5501, "BranchName_2");
                var command = new BulkReject.Command()
                {
                    UserId = "User_2",
                    Filter = filter,
                    RejectReason = "Not OK!"
                };

                var handler = new BulkReject.Handler(context, GetMapper(), Mock.Of<ILogger<BulkReject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't reject offices modified by the same user!");
            }

        }

        [TestMethod]
        public void BulkRejectWithBadFilterValuesShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions(11113, 999999, "BranchName_2");
                var command = new BulkReject.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter,
                    RejectReason = "Not OK!"
                };

                var handler = new BulkReject.Handler(context, GetMapper(), Mock.Of<ILogger<BulkReject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "There are no offices in the database corespondig to your search criterias!");
            }

        }

        [TestMethod]
        public void BulkRejectOnStatusesNotInAddedUpdatedPendingDeleteShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions(11112);
                var command = new BulkReject.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter,
                    RejectReason = "Not OK!"
                };

                var handler = new BulkReject.Handler(context, GetMapper(), Mock.Of<ILogger<BulkReject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't reject offices that are not in statuses Added, Updated or Deleted!");
            }

        }

        [TestMethod]
        public void BulkRejectWithoutRejectReasonShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var filter = InitFilterForBulkActions(11112);
                var command = new BulkReject.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter
                };

                var handler = new BulkReject.Handler(context, GetMapper(), Mock.Of<ILogger<BulkReject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Reject reason cannot be null or empty!");
            }

        }

        public void BulkRejectShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);
                var filter = InitFilterForBulkActions();
                var command = new BulkReject.Command()
                {
                    UserId = "AABBCC",
                    Filter = filter,
                    RejectReason = "Not OK!"
                };

                var handler = new BulkReject.Handler(context, GetMapper(), Mock.Of<ILogger<BulkReject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot bulk reject offices because there is a running job in progress");
            }
        }
        #endregion
        public OfficesParams InitFilterForBulkActions(long? AgentCode = null, int? BranchCode = null, string BranchName = null, bool? IsSMEClub = null, short StatusId = -1)
        {

            return new OfficesParams
            {
                AgentCode = AgentCode,
                BranchCode = BranchCode,
                BranchName = BranchName,
                IsSMEClub = IsSMEClub,
                StatusId = StatusId,
            };
        }
    }
}
