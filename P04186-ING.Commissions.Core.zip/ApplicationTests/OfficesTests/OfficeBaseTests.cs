﻿using Application.Commons.Enums;
using Application.DboOffices;
using Application.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;
using System;

namespace ApplicationTests.OfficesTests
{
    public class OfficeBaseTests : TestBase
    {
        public void InitOfficesAndOficessHistoryTables(CommissionsContext context)
        {
            var statusApproved = GetStatusObject((int)ObjectStatusId.Approved, ObjectStatus.Approved, 4);
            var statusAdded = GetStatusObject((int)ObjectStatusId.Added, ObjectStatus.Added, 1);
            var statusUpdated = GetStatusObject((int)ObjectStatusId.Updated, ObjectStatus.Updated, 2);
            var statusPendingDelete = GetStatusObject((int)ObjectStatusId.PendingDelete, ObjectStatus.PendingDelete, 3);
            var statusRejected = GetStatusObject((int)ObjectStatusId.Rejected, ObjectStatus.Rejected, 5);
            var statusDeleted = GetStatusObject((int)ObjectStatusId.Deleted, ObjectStatus.Deleted, 6);
            var statusRejectAdd = GetStatusObject((int)ObjectStatusId.RejectAdd, ObjectStatus.RejectAdd, 7);

            var objectActionAdd = GetObjectAction(1, "Add");
            var objectActionEdit = GetObjectAction(2, "Edit");
            var objectActionApprove = GetObjectAction(3, "Approve");
            var objectActionReject = GetObjectAction(4, "Reject");
            var objectActionDelete = GetObjectAction(5, "Delete");

            var officeActive = GetOffice(1, statusApproved);
            context.OfficesHistory.Add(GetOfficeHistory(1, officeActive, statusApproved, objectActionAdd));

            var officeAdded = GetOffice(2, statusAdded);
            context.OfficesHistory.Add(GetOfficeHistory(2, officeAdded, statusAdded, objectActionAdd));

            var officeUpdated = GetOffice(3, statusUpdated);
            context.OfficesHistory.Add(GetOfficeHistory(3, officeUpdated, statusUpdated, objectActionEdit));

            var officeDelete = GetOffice(4, statusPendingDelete);
            context.OfficesHistory.Add(GetOfficeHistory(4, officeDelete, statusPendingDelete, objectActionEdit));

            var officeRejected = GetOffice(5, statusRejected);
            context.OfficesHistory.Add(GetOfficeHistory(5, officeRejected, statusRejected, objectActionReject));

            var officeDeleted = GetOffice(6, statusDeleted);
            context.OfficesHistory.Add(GetOfficeHistory(6, officeDeleted, statusDeleted, objectActionDelete));

            context.ObjectActions.Add(objectActionApprove);
            context.ObjectStatus.Add(statusRejectAdd);
            context.SaveChanges();

        }

        public void InitStatusExportWithExecutingLineForPreviousMonth(CommissionsContext context)
        {
            var prevMonth = DateTime.Now.AddMonths(-1);
            var monthId = prevMonth.Year * 100 + prevMonth.Month;

            var statusExport = GetStatusExports((int)CommissionsTable.SMECommissions, "Executing", monthId);
            context.StatusExports.Add(statusExport);

            var tableSME = GetTables((int)CommissionsTable.SMECommissions, "SMECommissions");
            context.DWHTables.Add(tableSME);

            context.SaveChanges();
        }

        protected void ArrangeOnOfficeList(CommissionsContext context, OfficesParams officeParams, out List.Query query, out List.Handler handler)
        {
            InitOfficesAndOficessHistoryTables(context);

            query = new List.Query() { OfficesParams = officeParams };
            handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>(), GetMapper());
        }

        protected OfficesParams GetOfficeParams(int pageNumber = 1, int pageSize = 15,
            long? agentCode = null, int? branchCode = null, string branchName = "",
            bool? isSMEClub = null, short statusId = -1, string context = "")
        {
            return new OfficesParams()
            {
                PageSize = pageSize,
                PageNumber = pageNumber,
                AgentCode = agentCode,
                BranchCode = branchCode,
                BranchName = branchName,
                IsSMEClub = isSMEClub,
                StatusId = statusId,
                Context = context,
            };
        }

        protected void ArrangeOnOfficesEdit(CommissionsContext context, int id, bool isSMEClub, int? minDigitalSale, int? minLevel1, int? maxLevel1,
            out Edit.Command command, out Edit.Handler handler, string modifiedBy = "UO04XR", decimal? csatPrevQ = 3)
        {
            InitOfficesAndOficessHistoryTables(context);

            command = new Edit.Command()
            {
                Id = id,
                IsSMEClub = isSMEClub,
                MinDigitalSale = minDigitalSale,
                MinLevel1 = minLevel1,
                MaxLevel1 = maxLevel1,
                ModifiedBy = modifiedBy,
                CsatPrevQ = csatPrevQ
            };

            handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());
        }

        protected IConfiguration GetConfigurationObject()
        {
            var configuration = new Mock<IConfiguration>();
            configuration.Setup(c => c.GetSection("Notifications:ApplicationPath").Value).Returns("https://commissions");
            return configuration.Object;
        }
    }
}
