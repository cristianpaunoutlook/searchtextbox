﻿using Application.Commons.Enums;
using Application.DboOffices;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;

namespace ApplicationTests.OfficesTests
{
    [TestClass]
    public class ApproveRejectTests : OfficeBaseTests
    {
        #region approve
        [TestMethod]
        public void ApproveAddedOfficeShouldChangeToApprovedState()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Approve.Command()
                {
                    Id = 2,
                    UserKey = "AABBCC"
                };

                var currentAddedNumber = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                        && oh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added) == currentAddedNumber - 1);
                Assert.IsTrue(context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                        && oh.Action.ActionName == ObjectAction.Approve.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void ApproveModifiedOfficeShouldChangeToApprovedState()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Approve.Command()
                {
                    Id = 3,
                    UserKey = "AABBCC"
                };

                var currentAddedNumber = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Updated);
                var currentHistCount = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Updated
                                                && oh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Updated) == currentAddedNumber - 1);
                Assert.IsTrue(context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                && oh.Action.ActionName == ObjectAction.Approve.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void ApproveWithSameUserThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Approve.Command()
                {
                    Id = 2,
                    UserKey = "User_2"
                };

                var currentAddedNumber = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                            && oh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't approve with same user!");
            }
        }

        [TestMethod]
        public void ApproveOnStatusApprovedThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Approve.Command()
                {
                    Id = 1,
                    UserKey = "AAABBB"
                };

                var currentAddedNumber = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                            && oh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't approve an approved office!");
            }
        }

        [TestMethod]
        public void ApproveOnInvalidParamThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Approve.Command()
                {
                    Id = 0,
                    UserKey = "AAABBB"
                };

                var currentAddedNumber = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                && oh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Invalid office!");
            }
        }

        [TestMethod]
        public void ApproveShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);
                var command = new Approve.Command()
                {
                    Id = 2,
                    UserKey = "AABBCC"
                };

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot approve office because there is a running job in progress");
            }
        }
        #endregion

        #region reject
        [TestMethod]
        public void RejectAddedOfficeShouldChangeToRejectAddState()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 2,
                    UserKey = "AABBCC",
                    RejectReason = "reject reason"
                };

                var currentAddedNumber = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.RejectAdd
                                                    && oh.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added) == currentAddedNumber - 1);
                Assert.IsTrue(context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.RejectAdd
                                                && oh.Action.ActionName == ObjectAction.Reject.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void RejectModifiedOfficeShouldChangeToRejectState()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 3,
                    UserKey = "AABBCC"
                };

                var currentAddedNumber = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Updated);
                var currentHistCount = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Rejected
                                                && oh.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Updated) == currentAddedNumber - 1);
                Assert.IsTrue(context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Rejected
                                                && oh.Action.ActionName == ObjectAction.Reject.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void RejectWithSameUserThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 2,
                    UserKey = "User_2"
                };

                var currentAddedNumber = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                && oh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't reject with same user!");
            }
        }

        [TestMethod]
        public void RejectOnStatusApprovedThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 1,
                    UserKey = "AAABBB"
                };

                var currentAddedNumber = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                && oh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't reject an approved office!");
            }
        }

        [TestMethod]
        public void RejectOnInvalidOfficeThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 0,
                    UserKey = "AAABBB"
                };

                var currentAddedNumber = context.Offices.Count(o => o.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.OfficesHistory.Count(oh => oh.Status.StatusName == ObjectStatus.Approved
                                                && oh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Invalid office!");
            }
        }

        [TestMethod]
        public void RejectShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitOfficesAndOficessHistoryTables(context);
                var command = new Reject.Command()
                {
                    Id = 2,
                    UserKey = "AABBCC",
                    RejectReason = "reject reason"
                };

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot reject office because there is a running job in progress");
            }
        }
        #endregion
    }
}
