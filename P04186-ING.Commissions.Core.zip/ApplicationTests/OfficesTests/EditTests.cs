﻿using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Threading;

namespace ApplicationTests.OfficesTests
{
    [TestClass]
    public class EditTests : OfficeBaseTests
    {

        #region Update product
        [TestMethod]
        public void UpdatedOfficeShouldBePersistedInDb()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnOfficesEdit(context, 1, true, 40, 20, 60, out var command, out var handler);

                var currentNumber = context.Offices.Count();
                var currnetNoOfficesHistory = context.OfficesHistory.Count();

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Offices.Count() == currentNumber);
                Assert.IsTrue(context.OfficesHistory.Where(o => o.OfficeId == command.Id).Count() == 2);
            }
        }
        [TestMethod]
        public void UpdatedOfficeMinLevel1GreaterThanMaxLevel1ShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnOfficesEdit(context, 1, true, 40, 80, 60, out var command, out var handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"Max Level 1 { command.MaxLevel1 } must be greater than Min Level 1 { command.MinLevel1}!");
            }
        }
        [TestMethod]
        public void UpdatedWithSameValuesShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnOfficesEdit(context, 1, true, 50, 30, 40, out var command, out var handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"Max Level 1 { command.MaxLevel1 } must be greater than Min Level 1 { command.MinLevel1}!");
            }
        }

        //Editing an office which is not in approved state should throw error
        [TestMethod]
        public void UpdatedOfficeNotApprovedShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnOfficesEdit(context, 2, true, 40, 20, 60, out var command, out var handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"The office with code should be in Approved state to be modified!");
            }
        }
        //Editing an office which not exists in productdetails should throw error
        [TestMethod]
        public void UpdatedOfficeThatDoentExistShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnOfficesEdit(context, 200, true, 40, 20, 60, out var command, out var handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"The office is not in the database");
            }
        }

        [TestMethod]
        public void UpdatedOfficesWithCsatPrevQLessThan1AndGreaterThan5ThrowsError()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnOfficesEdit(context, 1, true, 40, 20, 60, out var command, out var handler, csatPrevQ: 7);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"CSATPrevQ must be between 1 and 5");
            }
        }

        [TestMethod]
        public void UpdatedOfficeWithFieldsNullAndOfficeThrowsError()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnOfficesEdit(context, 1, true, null, 20, 60, out var command, out var handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"All fields are mandatory for offices");
            }
        }

        [TestMethod]
        public void UpdateShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitStatusExportWithExecutingLineForPreviousMonth(context);
                // Arrange
                ArrangeOnOfficesEdit(context, 1, true, 40, 20, 60, out var command, out var handler);

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot edit office because there is a running job in progress");
            }
        }
        #endregion
    }
}
