﻿using Application.DboBehaviorDetails;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;

namespace ApplicationTests.BehaviorDetailsTests
{
    [TestClass]
    public class CreateUpdateTests : BehaviorDetailsBaseTests
    {
        #region Create
        [TestMethod]
        public void AfterCreateBehaviorDetailsShouldBeInDb()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var currentNumber = context.BehaviorDetails.Count();
                var currentHistoryNumber = context.BehaviorDetails.Count();
                // Arrange
                var command = new Create.Command()
                {
                    Type = "ProductForCreateNotInProductDetails",
                    Description = "TestDescription",
                    ExpenseAccountId = 1,
                    CommissionBehaviorTablesId = 1,
                    CommissionBehaviorColumnsId = 1,
                    CustomerCodeRange = "",
                    UserKey = "UO04XR",
                };

                var handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count() == currentNumber + 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count() == currentHistoryNumber + 1);
            }
        }

        [TestMethod]
        public void AfterCreateBehDetForExistingBehDetInDeletedStatusShouldBeInDb()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var currentNumber = context.BehaviorDetails.Count();
                var currentHistoryNumber = context.BehaviorDetails.Count();

                // Arrange
                var command = new Create.Command()
                {
                    Type = "Type_6",
                    Description = "Description_6",
                    ExpenseAccountId = 1,
                    CommissionBehaviorTablesId = 1,
                    CommissionBehaviorColumnsId = 1,
                    CustomerCodeRange = "",
                    UserKey = "UO04XR",
                };

                var handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count() == currentNumber);
                Assert.IsTrue(context.BehaviorDetails.Where(bd => bd.Type == command.Type &&
                            bd.StatusId == (short)Application.Commons.Enums.ObjectStatusId.Added).Count() == 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count() == currentHistoryNumber + 1);

            }
        }

        [TestMethod]
        public void AfterCreateBehDetForExistingBehDetInRejectAddStatusShouldBeInDb()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var currentNumber = context.BehaviorDetails.Count();
                var currentHistoryNumber = context.BehaviorDetails.Count();

                // Arrange
                var command = new Create.Command()
                {
                    Type = "Type_7",
                    Description = "Description_7",
                    ExpenseAccountId = 1,
                    CommissionBehaviorTablesId = 1,
                    CommissionBehaviorColumnsId = 1,
                    CustomerCodeRange = "",
                    UserKey = "UO04XR",
                };

                var handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count() == currentNumber);
                Assert.IsTrue(context.BehaviorDetails.Where(bd => bd.Type == command.Type &&
                            bd.StatusId == (short)Application.Commons.Enums.ObjectStatusId.Added).Count() == 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count() == currentHistoryNumber + 1);

            }
        }

        [TestMethod]
        public void CreateBehDetWithSameTypeAndStatusNotDeletedOrRejectedAddShouldThrowException()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                // Arrange
                var command = new Create.Command()
                {
                    Type = "Type_1",
                    Description = "Description_1",
                    ExpenseAccountId = 1,
                    CommissionBehaviorTablesId = 1,
                    CommissionBehaviorColumnsId = 1,
                    CustomerCodeRange = "",
                    UserKey = "UO04XR",
                };
                var handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), $"There is already a behavior with this info " +
                        $"{command.Type} {command.Description} in the database!");
            }
        }

        [TestMethod]
        public void CreateShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);

                // Arrange
                var command = new Create.Command()
                {
                    Type = "ProductForCreateNotInProductDetails",
                    Description = "TestDescription",
                    ExpenseAccountId = 1,
                    CommissionBehaviorTablesId = 1,
                    CommissionBehaviorColumnsId = 1,
                    CustomerCodeRange = "",
                    UserKey = "UO04XR",
                };

                var handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot create behavior because there is a running job in progress");
            }
        }
        #endregion

        #region Update
        [TestMethod]
        public void UpdatedBehaviorDetailsShouldBePersistedInDb()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var currentNumber = context.BehaviorDetails.Count();
                var currentHistoryNumber = context.BehaviorDetailsHistory.Count();

                // Arrange
                var command = new Edit.Command()
                {
                    Id = 1,
                    Type = "Type_1",
                    Description = "Description_1_for_ut",
                    ExpenseAccountId = 1,
                    CommissionBehaviorTablesId = 1,
                    CommissionBehaviorColumnsId = 1,
                    CustomerCodeRange = "",
                    UserKey = "UO04XR",
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count() == currentNumber);
                Assert.IsTrue(context.BehaviorDetails.Where(bd => bd.Type == command.Type).Count() == 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count() == currentHistoryNumber + 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Where(bdh => bdh.Type == command.Type).Count() == 2);
            }
        }

        [TestMethod]
        public void UpdatedBehaviorDetailsNotInDbShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);

                // Arrange
                var command = new Edit.Command()
                {
                    Id = 99,
                    Type = "Type_1",
                    Description = "Description_1_for_ut",
                    ExpenseAccountId = 1,
                    CommissionBehaviorTablesId = 1,
                    CommissionBehaviorColumnsId = 1,
                    CustomerCodeRange = "",
                    UserKey = "UO04XR",
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    $"The behavior details with type {command.Type} is not in the database!");
            }
        }

        [TestMethod]
        public void UpdatedBehaviorDetailsNotApprovedShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);

                // Arrange
                var command = new Edit.Command()
                {
                    Id = 2,
                    Type = "Type_1",
                    Description = "Description_1_for_ut",
                    ExpenseAccountId = 1,
                    CommissionBehaviorTablesId = 1,
                    CommissionBehaviorColumnsId = 1,
                    CustomerCodeRange = "",
                    UserKey = "UO04XR",
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    $"Behavior details with type { command.Type} should be in Approved state to be modified!");
            }
        }

        [TestMethod]
        public void UpdatedBehaviorDetailsSameInfoShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);

                // Arrange
                var command = new Edit.Command()
                {
                    Id = 8,
                    Type = "Type_1",
                    Description = "Description_1",
                    ExpenseAccountId = 1,
                    CommissionBehaviorTablesId = 1,
                    CommissionBehaviorColumnsId = 1,
                    CustomerCodeRange = "CustomerCodeRange_1",
                    UserKey = "SYSTEM",
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    $"There is already behavior details with this info {command.Type} {command.Description} in the database!");
            }
        }

        [TestMethod]
        public void UpdateShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);

                // Arrange
                var command = new Edit.Command()
                {
                    Id = 1,
                    Type = "Type_1",
                    Description = "Description_1_for_ut",
                    ExpenseAccountId = 1,
                    CommissionBehaviorTablesId = 1,
                    CommissionBehaviorColumnsId = 1,
                    CustomerCodeRange = "",
                    UserKey = "UO04XR",
                };

                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot edit behavior because there is a running job in progress");
            }
        }
        #endregion
    }
}
