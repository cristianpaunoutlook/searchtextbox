﻿using Application.Commons.Enums;
using Application.DboBehaviorDetails;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;

namespace ApplicationTests.BehaviorDetailsTests
{
    [TestClass]
    public class ApproveRejectTests : BehaviorDetailsBaseTests
    {
        #region approve
        [TestMethod]
        public void ApproveAddedBehaviorShouldChangeToApprovedState()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Approve.Command()
                {
                    BehaviorDetailsId = 2,
                    UserKey = "AABBCC"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(b => b.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.BehaviorDetailsHistory.Count(bh => bh.Status.StatusName == ObjectStatus.Approved && bh.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count(b => b.Status.StatusName == ObjectStatus.Added) == currentBehaviorDetail - 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count(bh => bh.Status.StatusName == ObjectStatus.Approved && bh.Action.ActionName == ObjectAction.Approve.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void ApproveModifiedBehaviorShouldChangeToApprovedState()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Approve.Command()
                {
                    BehaviorDetailsId = 3,
                    UserKey = "AABBCC"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Updated);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Updated && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Updated) == currentBehaviorDetail - 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString() && ph.Type == "Type_3") == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void ApprovePendingDeleteBehaviorShouldChangeToDeletedState()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Approve.Command()
                {
                    BehaviorDetailsId = 4,
                    UserKey = "AABBCC"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.PendingDelete);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Deleted && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.PendingDelete) == currentBehaviorDetail - 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Deleted && ph.Action.ActionName == ObjectAction.Approve.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void ApproveWithSameUserThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Approve.Command()
                {
                    BehaviorDetailsId = 1,
                    UserKey = "User_2"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't approve with same user!");
            }
        }

        [TestMethod]
        public void ApproveOnStatusApprovedThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Approve.Command()
                {
                    BehaviorDetailsId = 3,
                    UserKey = "AAABBB"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't approve an approved behavior!");
            }
        }

        [TestMethod]
        public void ApproveOnInvalidBehaviorThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Approve.Command()
                {
                    BehaviorDetailsId = 99,
                    UserKey = "AAABBB"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Invalid behavior!");
            }
        }

        [TestMethod]
        public void ApproveShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);

                var command = new Approve.Command()
                {
                    BehaviorDetailsId = 2,
                    UserKey = "AABBCC"
                };

                var handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot approve behavior because there is a running job in progress");
            }
        }
        #endregion

        #region reject
        [TestMethod]
        public void RejectAddedBehaviorShouldChangeToRejectAddState()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Reject.Command()
                {
                    BehaviorDetailsId = 2,
                    UserKey = "AABBCC",
                    RejectReason = "reject reason"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.RejectAdd && ph.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Added) == currentBehaviorDetail - 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.RejectAdd && ph.Action.ActionName == ObjectAction.Reject.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void RejectModifiedBehaviorShouldChangeToRejectState()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Reject.Command()
                {
                    BehaviorDetailsId = 3,
                    UserKey = "AABBCC"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Updated);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Rejected && ph.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Updated) == currentBehaviorDetail - 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Rejected && ph.Action.ActionName == ObjectAction.Reject.ToString()) == currentHistCount + 1);
            }
        }


        [TestMethod]
        public void RejectPendingDeleteBehaviorShouldChangeToApprovedState()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Reject.Command()
                {
                    BehaviorDetailsId = 4,
                    UserKey = "AABBCC"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.PendingDelete);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Reject.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.PendingDelete) == currentBehaviorDetail - 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Reject.ToString()) == currentHistCount + 1);
            }
        }

        [TestMethod]
        public void RejectWithSameUserThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Reject.Command()
                {
                    BehaviorDetailsId = 1,
                    UserKey = "User_2"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't reject with same user!");
            }
        }

        [TestMethod]
        public void RejectOnStatusApprovedThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Reject.Command()
                {
                    BehaviorDetailsId = 1,
                    UserKey = "AAABBB"
                };

                var currentBehaviorDetail = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Can't reject an approved behavior!");
            }
        }

        [TestMethod]
        public void RejectOnInvalidBehaviorThrowsError()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var command = new Reject.Command()
                {
                    BehaviorDetailsId = 11,
                    UserKey = "AAABBB"
                };

                var currentAddedNumber = context.BehaviorDetails.Count(p => p.Status.StatusName == ObjectStatus.Added);
                var currentHistCount = context.BehaviorDetailsHistory.Count(ph => ph.Status.StatusName == ObjectStatus.Approved && ph.Action.ActionName == ObjectAction.Approve.ToString());

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Invalid behavior!");
            }
        }

        public void RejectShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);
                var command = new Reject.Command()
                {
                    BehaviorDetailsId = 2,
                    UserKey = "AABBCC",
                    RejectReason = "reject reason"
                };

                var handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot reject behavior because there is a running job in progress");
            }
        }
        #endregion
    }

}