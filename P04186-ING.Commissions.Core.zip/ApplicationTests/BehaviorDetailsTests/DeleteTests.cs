﻿using Application.Commons.Enums;
using Application.DboBehaviorDetails;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;

namespace ApplicationTests.BehaviorDetailsTests
{
    [TestClass]
    public class DeleteTests : BehaviorDetailsBaseTests
    {
        [TestMethod]
        public void AfterDeleteBehaviorShouldNotBeInDb()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                var currentNumber = context.BehaviorDetails.Count();
                var currentNumberHistory = context.BehaviorDetailsHistory.Count();
                // Arrange
                var command = new Delete.Command()
                {
                    Id = 1,
                    UserKey = "ABCDEF"
                };

                var handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.BehaviorDetails.Count() == currentNumber);
                Assert.IsTrue(context.BehaviorDetails.Where(pd => pd.Id == command.Id && pd.StatusId == (short)ObjectStatusId.PendingDelete).Count() == 1);
                Assert.IsTrue(context.BehaviorDetailsHistory.Count() == currentNumberHistory + 1);
            }
        }

        [TestMethod]
        public void DeleteWithInvalidBehaviorTypeThrowEx()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                // Arrange
                var command = new Delete.Command()
                {
                    Id = 99,
                    UserKey = "AAAABB"
                };

                var handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                var result = handler.Handle(command, (new CancellationTokenSource()).Token);


                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "Invalid behavior type!");
            }
        }

        [TestMethod]
        public void DeleteBehaviorNotApprovedBehaviorTypeThrowEx()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                // Arrange
                var command = new Delete.Command()
                {
                    Id = 1,
                    UserKey = "AAAABB"
                };

                var handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "The behavior should be approved!");
            }
        }

        [TestMethod]
        public void DeleteShouldThrowErrorIfAnyJobIsRunning()
        {
            using (var context = GetDbContext())
            {
                InitBehAnBehHistoryTables(context);
                InitStatusExportWithExecutingLineForPreviousMonth(context);

                // Arrange
                var command = new Delete.Command()
                {
                    Id = 1,
                    UserKey = "ABCDEF"
                };

                var handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>(), GetMapper(), GetConfigurationObject(), GetEmailSenderObject());

                //Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                   "Cannot delete behavior because there is a running job in progress");
            }
        }

    }
}
