﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Threading;

namespace ApplicationTests.BehaviorDetailsTests
{
    [TestClass]
    public class ListTests : BehaviorDetailsBaseTests
    {
        [TestMethod]
        public void ShouldReturnAllParamsFromDb()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var behaviorParams = GetBehaviorParam();

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items.Count == 6);
            }
        }

        [TestMethod]
        public void ShouldReturnAllParamsToApprove()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var behaviorParams = GetBehaviorParam(context: Constants.TOAPPROVE);

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items.Count == 4);
            }
        }

        [TestMethod]
        public void ShouldReturnAllParametersFromDbForFirstPage()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var behaviorParams = GetBehaviorParam(1, 3);

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items.Count == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnEmptyListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var behaviorParams = GetBehaviorParam(5, 10);

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "There are no records corresponding to your search!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageNumberIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var behaviorParams = GetBehaviorParam(-3, 10);

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items.Count == 6);
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var behaviorParams = GetBehaviorParam(1, 100);

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldReturnListSortedByStatusFirst()
        {
            using (var context = GetDbContext())
            {
                //arange
                var behaviorParams = GetBehaviorParam(1, 5);

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items[0].Status == ObjectStatus.Added);
            }
        }

        [TestMethod]
        public void ShouldReturnListSortedByStatusFirstThenByName()
        {
            using (var context = GetDbContext())
            {
                //arange
                var behaviorParams = GetBehaviorParam(1, 5);

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items[0].Status == ObjectStatus.Added && behaviors.Items[3].Type == "Type_1");
            }
        }

        [TestMethod]
        public void FilterByStatusShouldReturnBehaviorsByStatus()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var behaviorParams = GetBehaviorParam(1, 15, statusId: (int)ObjectStatusId.Added);

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items.Count == 1);
                Assert.IsTrue(behaviors.Items.Count(o => o.StatusId == (int)ObjectStatusId.Added) == 1);
            }
        }

        [TestMethod]
        public void FilterByDescriptionShouldReturnBehaviorsByShortName()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var behaviorParams = GetBehaviorParam(1, 15, description: "Description_1");

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items.Count == 1);
                Assert.IsTrue(behaviors.Items.Count(o => o.Description == "Description_1") == 1);
            }
        }

        [TestMethod]
        public void FilterByTypeShouldReturnBehaviorsByType()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var behaviorParams = GetBehaviorParam(1, 15, behaviorType: "Type_1");

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items.Count == 1);
                Assert.IsTrue(behaviors.Items.Count(o => o.Type == "Type_1") == 1);
            }
        }

        [TestMethod]
        public void FilterByCommTableShouldReturnBehaviorsByCommTable()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var behaviorParams = GetBehaviorParam(1, 15, commissionsTableId: 1);

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items.Count == 4);
                Assert.IsTrue(behaviors.Items.Count(o => o.CommissionTableId == 1) == 4);
            }
        }

        [TestMethod]
        public void FilterByMultipleCriteriaReturnBehaviorsWithAllCriteria()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var behaviorParams = GetBehaviorParam(1, 15, description: "Description_1", behaviorType: "Type_1",
                    commissionsTableId: 1, statusId: (int)ObjectStatusId.Approved);

                ArrangeOnBehaviorsList(context, behaviorParams, out var query, out var handler);

                //act
                var behaviors = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(behaviors.Items.Count == 1);
                Assert.IsTrue(behaviors.Items.Count(o => o.Description == "Description_1" && o.Type == "Type_1") == 1);
            }
        }
    }
}
