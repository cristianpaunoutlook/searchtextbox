﻿using Application.Commons.Enums;
using Application.DboBehaviorDetails;
using Application.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;
using System;

namespace ApplicationTests.BehaviorDetailsTests
{
    public class BehaviorDetailsBaseTests : TestBase
    {
        public void InitBehAnBehHistoryTables(CommissionsContext context)
        {
            var statusApproved = GetStatusObject((short)ObjectStatusId.Approved, ObjectStatus.Approved, 4);
            var statusAdded = GetStatusObject((short)ObjectStatusId.Added, ObjectStatus.Added, 1);
            var statusUpdated = GetStatusObject((short)ObjectStatusId.Updated, ObjectStatus.Updated, 2);
            var statusPendingDelete = GetStatusObject((short)ObjectStatusId.PendingDelete, ObjectStatus.PendingDelete, 3);
            var statusRejected = GetStatusObject((short)ObjectStatusId.Rejected, ObjectStatus.Rejected, 5);
            var statusDeleted = GetStatusObject((short)ObjectStatusId.Deleted, ObjectStatus.Deleted, 6);
            var statusRejectAdd = GetStatusObject((short)ObjectStatusId.RejectAdd, ObjectStatus.RejectAdd, 7);

            var objectActionAdd = GetObjectAction(1, "Add");
            var objectActionEdit = GetObjectAction(2, "Edit");
            var objectActionApprove = GetObjectAction(3, "Approve");
            var objectActionReject = GetObjectAction(4, "Reject");
            var objectActionDelete = GetObjectAction(5, "Delete");

            var commBehaviorTableSME = GetTableObject(1);
            var commBehaviorTableBEH = GetTableObject(2);

            var commBehaviorColumnSME = GetTableColumnObject(1, commBehaviorTableSME, "SMEColumn");
            var commBehaviorColumnBEH = GetTableColumnObject(2, commBehaviorTableBEH, "BEHColumn");

            var expAccountActive = GetExpenseAccount(1, true);

            var behaviorActive = GetBehaviorDetails(1, expAccountActive, commBehaviorTableSME, commBehaviorColumnSME, statusApproved);
            context.BehaviorDetailsHistory.Add(GetBehaviorDetailsHistory(1, behaviorActive, expAccountActive, commBehaviorTableSME,
                commBehaviorColumnSME, statusApproved, objectActionApprove));

            var behaviorAdded = GetBehaviorDetails(2, expAccountActive, commBehaviorTableSME, commBehaviorColumnSME, statusAdded);
            context.BehaviorDetailsHistory.Add(GetBehaviorDetailsHistory(2, behaviorAdded, expAccountActive, commBehaviorTableSME, commBehaviorColumnSME, statusAdded, objectActionAdd));

            var behaviorUpdated = GetBehaviorDetails(3, expAccountActive, commBehaviorTableSME, commBehaviorColumnSME, statusUpdated);
            context.BehaviorDetailsHistory.Add(GetBehaviorDetailsHistory(3, behaviorUpdated, expAccountActive, commBehaviorTableSME, commBehaviorColumnSME, statusUpdated, objectActionEdit));

            var behaviorPendingDelete = GetBehaviorDetails(4, expAccountActive, commBehaviorTableBEH, commBehaviorColumnBEH, statusPendingDelete);
            context.BehaviorDetailsHistory.Add(GetBehaviorDetailsHistory(4, behaviorPendingDelete, expAccountActive, commBehaviorTableBEH, commBehaviorColumnBEH, statusPendingDelete, objectActionEdit));

            var behaviorRejected = GetBehaviorDetails(5, expAccountActive, commBehaviorTableBEH, commBehaviorColumnBEH, statusRejected);
            context.BehaviorDetailsHistory.Add(GetBehaviorDetailsHistory(5, behaviorRejected, expAccountActive, commBehaviorTableBEH, commBehaviorColumnBEH, statusRejected, objectActionReject));

            var behaviorDeleted = GetBehaviorDetails(6, expAccountActive, commBehaviorTableBEH, commBehaviorColumnBEH, statusDeleted);
            context.BehaviorDetailsHistory.Add(GetBehaviorDetailsHistory(6, behaviorDeleted, expAccountActive, commBehaviorTableBEH, commBehaviorColumnBEH, statusDeleted, objectActionDelete));

            var behaviorRejectedAdd = GetBehaviorDetails(7, expAccountActive, commBehaviorTableBEH, commBehaviorColumnBEH, statusRejectAdd);
            context.BehaviorDetailsHistory.Add(GetBehaviorDetailsHistory(7, behaviorRejectedAdd, expAccountActive, commBehaviorTableBEH, commBehaviorColumnBEH, statusRejectAdd, objectActionReject));

            var behaviorSecondActive = GetBehaviorDetails(8, expAccountActive, commBehaviorTableSME, commBehaviorColumnSME, statusApproved);
            context.BehaviorDetailsHistory.Add(GetBehaviorDetailsHistory(8, behaviorSecondActive, expAccountActive, commBehaviorTableBEH, commBehaviorColumnBEH, statusApproved, objectActionAdd));

            context.SaveChanges();

        }

        public void InitStatusExportWithExecutingLineForPreviousMonth(CommissionsContext context)
        {
            var prevMonth = DateTime.Now.AddMonths(-1);
            var monthId = prevMonth.Year * 100 + prevMonth.Month;

            var statusExport = GetStatusExports((int)CommissionsTable.SMECommissions, "Executing", monthId);
            context.StatusExports.Add(statusExport);

            var tableSME = GetTables((int)CommissionsTable.SMECommissions, "SMECommissions");
            context.DWHTables.Add(tableSME);

            context.SaveChanges();
        }

        protected void ArrangeOnBehaviorsList(CommissionsContext context, BehaviorParams behaviorParams, out List.Query query, out List.Handler handler)
        {
            InitBehAnBehHistoryTables(context);

            query = new List.Query() { BehaviorParams = behaviorParams };
            handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>(), GetMapper());
        }

        protected BehaviorParams GetBehaviorParam(int pageNumber = 1, int pageSize = 15, string behaviorType = "",
            string description = "", int statusId = -1, int commissionsTableId = -1, string context = "")
        {
            return new BehaviorParams
            {
                PageNumber = pageNumber,
                PageSize = pageSize,
                BehaviorType = behaviorType,
                Description = description,
                StatusId = statusId,
                CommissionsTableId = commissionsTableId,
                Context = context
            };
        }

        protected IConfiguration GetConfigurationObject()
        {
            var configuration = new Mock<IConfiguration>();
            configuration.Setup(c => c.GetSection("Notifications:ApplicationPath").Value).Returns("https://commissions");
            configuration.Setup(c => c.GetSection("Notifications:BehaviorDetailsEmail").Value).Returns("testemailsmtp@ing.com");
            return configuration.Object;
        }
    }
}
