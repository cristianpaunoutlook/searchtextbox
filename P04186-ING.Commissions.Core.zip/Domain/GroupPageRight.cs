﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class GroupPageRight
    {
        public int GroupId { get; set; }
        public virtual Group Group { get; set; }
        public int PageId { get; set; }
        public virtual Page Page { get; set; }
        public int RightId { get; set; }
        public virtual Right Right { get; set; }
        public int NextRightId { get; set; }
        public virtual Right NextRight { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime LastModifiedDate { get; set; }
    }
}
