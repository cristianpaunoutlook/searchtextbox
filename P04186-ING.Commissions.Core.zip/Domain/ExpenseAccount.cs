﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ExpenseAccount
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public long Number { get; set; }
        public bool IsVisible { get; set; }

    }
}
