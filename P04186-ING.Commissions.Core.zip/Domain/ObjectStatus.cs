﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ObjectStatus
    {
        public short Id { get; set; }
        public string StatusName { get; set; }
        public byte DisplayOrder { get; set; }
    }
}
