﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class SL2Commissions
    {
        public int Id { get; set; }

        public long AgentCode { get; set; }

        public int BranchCode { get; set; }

        public long AccountNo { get; set; }

        public string ProductType { get; set; }

        public string ProductShortName { get; set; }

        public string ProductName { get; set; }

        public long CustomerNo { get; set; }

        public int CustomerCode { get; set; }

        public DateTime CustomerOpenedDate { get; set; }

        public DateTime? ActivatedDate { get; set; }

        public DateTime? OpenedDate { get; set; }

        public int? SourceOfBusiness { get; set; }

        public string ReferralCode { get; set; }

        public string Currency { get; set; }

        public decimal? SalaryLevel { get; set; }

        public string FeePlan { get; set; }

        public bool? HasIncomingConvention { get; set; }

        public string CUI { get; set; }

        public bool? IsLeadFromSalaryAgreement { get; set; }

        public decimal OMCommission { get; set; }

        public decimal? TotalIncomingM3 { get; set; }

        public decimal? TotalIncomingPOSM3 { get; set; }

        public short? NoOfTransactionsM3 { get; set; }

        public byte? NoOfProducts { get; set; }

        public decimal? MaxBalance { get; set; }

        public decimal? TurnOver { get; set; }

        public DateTime? RegistrationDate { get; set; }

        public string LegalForm { get; set; }

        public int IsSMEClub { get; set; }

        public short? NoOfActivityMonths { get; set; }

        public short? INGFixPackageFlag { get; set; }

        public short? NoOfTransactionsM6 { get; set; }

        public decimal? TotalIncomingM6 { get; set; }

        public int? NrExcSucces { get; set; }

        public int? NbrTransactions { get; set; }

        public bool? ProdusInteresFM { get; set; }

        public int? LeadBroker { get; set; }

        public string NumeBroker { get; set; }
    }
}
