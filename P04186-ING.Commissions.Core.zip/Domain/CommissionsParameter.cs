﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class CommissionsParameter
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public string OldValue { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string ApprovedRejectedBy { get; set; }
        public DateTime? ApprovedRejectedDate { get; set; }
        public string RejectReason { get; set; }
        public short StatusId { get; set; }
        public virtual ObjectStatus Status { get; set; }
        public int TableId { get; set; }
        public virtual Table Table { get; set; }
    }
}
