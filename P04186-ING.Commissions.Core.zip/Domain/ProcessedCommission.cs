﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ProcessedCommission
    {
        public string TableName { get; set; }

        public int? TableId { get; set; }

        public string ProcessStatus { get; set; }
        public DateTime? RefDate { get; set; }

        public int? NoOfRecords { get; set; }
        public bool DisplayGenerate { get; set; }
        public bool DisplayDownload { get; set; }
    }
}
