﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ProductDetails
    {
        public int Id { get; set; }
        public string ProductType { get; set; }
        public string Name { get; set; }
        public string ShortName { get; set; }
        public string UserId { get; set; }
        public string ApproveRejectId { get; set; }
        public DateTime ChangeDate{ get; set; }
        public DateTime? ApproveRejectDate{ get; set; }
        public short StatusId{ get; set; }
        public virtual ObjectStatus Status { get; set; }
        public int ExpenseAccountId { get; set; }
        public virtual ExpenseAccount ExpenseAccount { get; set; }
        public string RejectReason { get; set; }

    }
}
