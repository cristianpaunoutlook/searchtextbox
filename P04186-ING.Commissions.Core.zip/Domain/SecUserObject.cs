﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class SecUserObject
    {
        public int ObjectId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string TableName { get; set; }

    }
}
