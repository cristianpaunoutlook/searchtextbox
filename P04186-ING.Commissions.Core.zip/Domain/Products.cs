﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Products
    {
        public int ProductCode { get; set; }
        public string ProductName { get; set; }
        public string Code { get; set; }
    }
}
