﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class SecUserAction
    {
        public int ActionId { get; set; }
        public string Name { get; set; }
        public bool Visible { get; set; }
    }
}
