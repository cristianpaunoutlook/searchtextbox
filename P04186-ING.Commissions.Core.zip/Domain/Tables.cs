﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Tables
    {
        public int Id { get; set; }
        public string TableName { get; set; }
        public string TableDescription { get; set; }
    }
}
