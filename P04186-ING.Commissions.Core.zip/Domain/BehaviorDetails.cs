﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class BehaviorDetails
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        public int ExpenseAccountId { get; set; }
        public virtual ExpenseAccount ExpenseAccount { get; set; }
        public int CommissionBehaviorTablesId { get; set; }
        public virtual Table CommissionBehaviorTables { get; set; }
        public int CommissionBehaviorColumnsId { get; set; }
        public virtual TableColumn CommissionBehaviorColumns { get; set; }
        public string CustomerCodeRange { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string ApproveRejectBy { get; set; }
        public DateTime? ApproveRejectDate { get; set; }
        public string RejectReason { get; set; }
        public short StatusId { get; set; }
        public virtual ObjectStatus Status { get; set; }

    }
}
