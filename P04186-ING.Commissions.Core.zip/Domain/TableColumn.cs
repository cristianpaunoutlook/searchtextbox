﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class TableColumn
    {
        public int Id { get; set; }
        public int TableId { get; set; }
        public virtual Table Table { get; set; }
        public string ColumnName { get; set; }
    }
}
