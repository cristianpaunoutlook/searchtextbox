﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class SMECommissions
    {
        public int Id { get; set; }

        public int BranchCode { get; set; }

        public int ProductType { get; set; }

        public long CustomerNo { get; set; }

        public int CustomerCode { get; set; }

        public decimal TotalLiabilities { get; set; }

        public string NonDelqLoan { get; set; }

        public decimal MaxLiabilities { get; set; }

        public int AccountNoDebitTran { get; set; }

        public string FeePlan { get; set; }

        public decimal TotalRevolving { get; set; }

        public decimal TotalTermLoans { get; set; }

        public decimal RevolvingCommission { get; set; }

        public decimal TermLoansCommission { get; set; }

        public decimal ServiceCommission { get; set; }

        public decimal TotalSMECommission { get; set; }

        public decimal? TotalIncoming { get; set; }

        public decimal? TotalIncomingPOS { get; set; }

        public decimal? POSIncomingCommission { get; set; }

        public decimal TotalFX_EUR { get; set; }

        public decimal FXCommission { get; set; }

        public int IsSMEClub { get; set; }

        public bool? Active_Client { get; set; }

        public decimal MCSEDailyBankingCommission { get; set; }

        public decimal MCSELendingCommission { get; set; }
    }
}
