﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class TLSCommissions
    {
        public int Id { get; set; }

        public int AgentCode { get; set; }

        public int BranchCode { get; set; }

        public long AccountNo { get; set; }

        public string ProductType { get; set; }

        public long CustomerNo { get; set; }

        public int CustomerCode { get; set; }

        public DateTime CustomerOpenedDate { get; set; }

        public DateTime OpenedDate { get; set; }

        public string Currency { get; set; }

        public decimal CreditLimit { get; set; }

        public decimal? NewAmount { get; set; }

        public decimal? DisbursedAmount { get; set; }

        public DateTime? DisbursedDate { get; set; }

        public int SourceOfBusiness { get; set; }

        public string ReferralCode { get; set; }

        public string ProductName { get; set; }

        public string ProductShortName { get; set; }

        public decimal OMCommission { get; set; }

        public string PurposeCode { get; set; }

        public int BenCode { get; set; }

        public int SourceOfRefferral { get; set; }

        public int IsSMEClub { get; set; }

        public DateTime? CalcCredit { get; set; }

        public DateTime? RecordInteraction { get; set; }

        public DateTime? NextReviewDateOldValue { get; set; }

        public DateTime? NextReviewDateNewValue { get; set; }

        public DateTime? LastReviewDate { get; set; }

        public int? LeadBroker { get; set; }

        public string NumeBroker { get; set; }
    }
}
