﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ProcessHistory
    {
        public int Id { get; set; }

        public int TableId { get; set; }

        public string RunBy { get; set; }

        public DateTime RunDate { get; set; }

        public virtual Tables Table { get; set; }

    }
}
