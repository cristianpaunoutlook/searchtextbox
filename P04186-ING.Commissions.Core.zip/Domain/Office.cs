﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Office
    {
        public int Id { get; set; }
        public long AgentCode { get; set; }
        public int BranchCode { get; set; }
        public string BranchName { get; set; }
        public string BranchType { get; set; }
        public long OwnerNo{ get; set; }
        public string CompanyName { get; set; }
        public DateTime OpenedDate { get; set; }
        public bool IsSMEClub { get; set; }
        public short StatusId { get; set; }
        public virtual ObjectStatus Status { get; set; }
        public int? MinDigitalSale { get; set; }
        public int? MinLevel1 { get; set; }
        public int? MaxLevel1 { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ApprovedRejectedBy { get; set; }
        public DateTime? ApprovedRejectedDate { get; set; }
        public string RejectReason { get; set; }
        public decimal? CsatPrevQ { get; set; }
        public int? NoDigitalSales { get; set; }
        public decimal? DigitalSales { get; set; }
    }
}
