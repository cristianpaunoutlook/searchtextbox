﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class StatusExport
    {
        public int IdTable { get; set; }
        public string ProcessStatus { get; set; }
        public DateTime RefDate { get; set; }

        public int? NoOfRecords { get; set; }
        public int MonthId { get; set; }
    }
}
