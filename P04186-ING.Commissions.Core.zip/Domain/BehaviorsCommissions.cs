﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class BehaviorsCommissions
    {
        public int Id  { get; set; }
        public int BranchCode { get; set; }
        public long CustomerNo { get; set; }
        public int CustomerCode { get; set; }
        public decimal MediumBalanceCurrentAccountRON { get; set; }
        public decimal MediumBalanceCurrentAccountFCY { get; set; }
        public decimal MediumBalanceSavingRON { get; set; }
        public decimal MediumBalanceDepositRON { get; set; }
        public decimal MediumBalanceDepositFCY { get; set; }
        public decimal MediumBalanceExtraROLDPD0 { get; set; }
        public decimal MediumBalanceExtraROLDPD { get; set; }
        public decimal MediumBalanceCreditCardDPD0 { get; set; }
        public decimal MediumBalanceCreditCardDPD { get; set; }
        public decimal MediumBalancePersonalLoanDPD0 { get; set; }
        public decimal MediumBalancePersonalLoanDPD { get; set; }
        public decimal MediumBalanceMBDPD0 { get; set; }
        public decimal MediumBalanceMortgageBackDPD { get; set; }
        public int CashIN { get; set; }
        public int CashOUT { get; set; }
        public int Payments { get; set; }
        public int POS { get; set; }
        public int FXOUT { get; set; }
        public int FastLaneNoOfTransaction1 { get; set; }
        public int FastLaneNoOfTransaction2 { get; set; }
        public decimal IncomeSum { get; set; }
        public int IncomeType1CntMnths { get; set; }
        public int IncomeType2CntMnths { get; set; }
        public bool HasHomeBankFlag { get; set; }
        public bool HasSMSFlag { get; set; }
        public bool HasCurrentAccountEURFlag { get; set; }
        public bool HasCurrentAccountEURFlagOffice { get; set; }
        public int CntMasterCard { get; set; }
        public int CntPictureCard { get; set; }
        public int CntGoldCard { get; set; }
        public int CntVisaCardEUR { get; set; }
        public int CntINGPayCard { get; set; }
        public int CntVitaProtect { get; set; }
        public int CntTravelProtect { get; set; }
        public int CntLocuintaInsurance { get; set; }
        public int CntCascoInsurance { get; set; }
        public int CntRCAInsurance { get; set; }
        public int CntCrediProtect { get; set; }
        public int CntMediProtect { get; set; }
        public bool HasAcademicaFlag { get; set; }
        public bool HasRegalFlag { get; set; }
        public bool HasPrudentFlag { get; set; }
        public bool HasSmartFlag { get; set; }
        public decimal SoldEcDep { get; set; }
        public decimal SoldLN { get; set; }
        public int TransNo { get; set; }
        public int OptionsNo { get; set; }
        public decimal MediumBalanceExtraROLDPD0Office { get; set; }
        public decimal MediumBalanceExtraROLDPDOffice { get; set; }
        public decimal MediumBalanceCreditCardDPD0Office { get; set; }
        public decimal MediumBalanceCreditCardDPDOffice { get; set; }
        public decimal MediumBalancePersonalLoanDPD0Office { get; set; }
        public decimal MediumBalancePersonalLoanDPDOffice { get; set; }
        public decimal MediumBalanceMBDPD0Office { get; set; }
        public decimal MediumBalanceMortgageBackDPDOffice { get; set; }
        public decimal SoldLNOffice { get; set; }
        public int CntMasterCardOffice { get; set; }
        public int CntPictureCardOffice { get; set; }
        public int CntGoldCardOffice { get; set; }
        public int CntVisaCardEUROffice { get; set; }
        public int CntVitaProtectOffice { get; set; }
        public int CntLocuintaInsuranceOffice { get; set; }
        public int CntCrediProtectOffice { get; set; }
        public int NrOptiuniOffice { get; set; }
        public decimal InvestmentValueRON { get; set; }
        public bool HasHBServiceFlag { get; set; }
        public decimal ExtraRolCommission{ get; set; }
        public decimal CreditCardCommission { get; set; }
        public decimal PersonalLoanCommission { get; set; }
        public decimal MortgageCommission{ get; set; }
        public decimal TotalBehaviorsCommission { get; set; }
        public int ActiveClient { get; set; }
        public decimal DailyBankingBehaviorCommissions { get; set; }
        public decimal LendingComplexBehaviorCommissions { get; set; }
        public decimal PrepareYourFutureBehaviorCommissions { get; set; }
        public int DailyBankingBehavior { get; set; }
        public int LendingComplexBehavior { get; set; }
        public int PrepareYourFutureBehavior { get; set; }
        public bool ComportamentDigital { get; set; }
        public bool PrimaryClient { get; set; }
        public int NrLogariReferinta { get; set; }
        public bool MedieVenit3Luni { get; set; }
        public bool CDDReviewFlag { get; set; }
    }
}
