﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Table
    {
        public int Id { get; set; }
        public string TableName { get; set; }
        public bool? CommParams { get; set; }
        public bool? BehDetails { get; set; }
    }
}
