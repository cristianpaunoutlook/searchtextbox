﻿using System.Diagnostics.CodeAnalysis;

namespace Domain.UserDefinedTable
{
    [ExcludeFromCodeCoverage]
    public class IntList
    {
        public int Id { get; set; }
    }
}
