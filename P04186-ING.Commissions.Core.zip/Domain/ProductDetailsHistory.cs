﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ProductDetailsHistory
    {
        public int Id { get; set; }
        public int ProductDetailsId { get; set; }
        public virtual ProductDetails ProductDetails { get; set; }
        public string ProductType { get; set; }
        public string Name { get; set; }
        public string ShortName { get; set; }
        public int ExpenseAccountId { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string UpdateBy { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public string ApprovedBy { get; set; }
        public short StatusId { get; set; }
        public virtual ObjectStatus Status { get; set; }
        public short ActionId { get; set; }
        public virtual ObjectAction Action { get; set; }
        public string RejectReason { get; set; }
        public virtual ExpenseAccount ExpenseAccount { get; set; }
    }
}
