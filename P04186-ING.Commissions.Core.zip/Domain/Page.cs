﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Page
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public int OrderNo { get; set; }
    }
}
