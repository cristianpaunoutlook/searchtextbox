using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ObjectAction
    {
        public short Id { get; set; }
        public string ActionName { get; set; }
        public string Description { get; set; }
    }
}
