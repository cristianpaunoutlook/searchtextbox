﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Product
    {
        public string ProductType { get; set; }
    }
}
