﻿using Application.MapProfile;
using AutoMapper;
using Domain;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System;

namespace ApplicationTests
{
    public class TestBase
    {
        private bool useSqlite;

        public IMapper GetMapper()
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile(typeof(MappingProfile)));
            IMapper mapper = config.CreateMapper();
            return mapper;
        }

        public PhoenixContext GetDbContext(bool isSqlLite = false)
        {
            useSqlite = isSqlLite;
            DbContextOptionsBuilder<PhoenixContext> builder = new DbContextOptionsBuilder<PhoenixContext>();
            if (useSqlite)
            {
                // Use Sqlite DB.
                builder.UseSqlite("DataSource=:memory:", x => { });
            }
            else
            {
                // Use In-Memory DB.
                builder.UseInMemoryDatabase(Guid.NewGuid().ToString());
            }

            PhoenixContext dbContext = new PhoenixContext(builder.Options);
            if (useSqlite)
            {
                dbContext.Database.OpenConnection();
            }

            dbContext.Database.EnsureCreated();

            return dbContext;
        }

        public void UseSqlite()
        {
            useSqlite = true;
        }

        #region GetEntitiesObjects
        protected Domain.ObjectStatus GetStatusObject(byte id, string status)
        {
            return new Domain.ObjectStatus
            {
                ObjectStatusId = id,
                ObjectStatusName = status,
                Visible = true
            };
        }

        protected Domain.ProcessingFrequency GetProcessingFrequencyObject(byte id, string name)
        {
            return new Domain.ProcessingFrequency
            {
                ProcessingFrequencyId = id,
                ProcessingFrequencyName = name,
                Deleted = false
            };
        }

        protected Domain.DlfilesTblNonWorkingDays GetNonWorkingDaysObject(DateTime date, string comment)
        {
            return new Domain.DlfilesTblNonWorkingDays
            {
                Date = date,
                Comment = comment
            };
        }

        protected Currency GetCurrencyObject(byte id, string code)
        {
            return new Currency
            {
                CurrencyId = id,
                CurrencyCode = code,
                ActiveYN = true
            };
        }

        protected SecObjectAction GetObjectAction(int actionId, string name)
        {
            return new SecObjectAction
            {
                ActionId = actionId,
                Name = name,
                Visible = true,
                AllowAll = false
            };
        }

        protected Account GetAccount(string customerid, long accountShort, string iban, string coreBanking, string gridId = null, string cui = null)
        {
            return new Account
            {
                CustomerId = customerid,
                CustomerName = $"Name {customerid}",
                CurrencyCode = "EUR",
                BranchCode = "ROBUC",
                AccountShort = accountShort,
                IBAN = iban,
                DateOpened = DateTime.Now,
                BlockedDR = 0,
                CustomerBranch = "ROBUC",
                CoreBanking = coreBanking,
                IsActive = "Y",
                CustomerTypeHO = string.Empty,
                Type = "CHRE",
                GridID = gridId,
                CUI = cui,
            };
        }

        protected Payment GetPayment(int id, Session session, ApplicationLog applicationLog, ChargeType chargeType, Currency currency, CustomerDetails customerDetails, 
            decimal amountDebited, string customerId, int statusId = 1)
        {
            return new Payment
            {
                PaymentId = id,
                ExportSessionId = id * 100,
                Session = session,
                ApplicationLog = applicationLog,
                ChargeTypeId = id * 10,
                ChargeType = chargeType,
                Currency = currency,
                AmountDebited = amountDebited,
                CustomerAtlasId = customerId,
                CustomerDetails = customerDetails,
                CustomerName = "",
                DebitAccount = $"RO51INGB00009999000011{id.ToString().PadLeft(2, '0')}",
                IBANDebitAccount = $"RO51INGB00009999000011{id.ToString().PadLeft(2, '0')}",
                DebitAccountDescription = "DebitAccountDescription",
                CreditAccount = $"RO51INGB00009999000012{id.ToString().PadLeft(2, '0')}",
                IBANCreditAccount = $"RO51INGB00009999000012{id.ToString().PadLeft(2, '0')}",
                CreditAccountDescription = "CreditAccountDescription",
                PaymentDetails = "",
                Processed = statusId,
                TRID = "",
                BaseCurrencyId = 1,
                REF_ID_CCM = 1,
                ChargeId = id,
                RejectReason = ""
            };
        }

        protected CustomerDetails GetCustomerDetails(string customerId)
        {
            return new CustomerDetails
            {
                CustomerId = customerId,
                Address = $"Adress:{customerId}",
                RegistrationNumber = $"J-{customerId}",
            };
        }
        protected Session GetSession(int id, int objectTypeId)
        {
            return new Session
            {
                SessionId = id,
                ObjectTypeId = objectTypeId,
            };
        }

        protected ApplicationLog GetApplicationLog(int id, int sessionId, int objectTypeId, DateTime recordStamp, string userId = "System")
        {
            return new ApplicationLog()
            {
                ApplicationLogId = id,
                UserId = userId,
                ObjectTypeId = objectTypeId,
                SessionId = sessionId,
                RecordStamp = recordStamp,
            };
        }
        protected Customer GetCustomer(string atlasiId, byte statusId, string comments = "", string lastModifiedBy = "", DateTime? lastModififedDate = null)
        {
            return new Customer
            {
                AtlasID = atlasiId,
                StatusId = statusId,
                Comments = comments,
                UserID = lastModifiedBy,
                DateLastUpdate = lastModififedDate
            };
        }

        protected ChargeType GetChargeTypeObject(int id, Currency currency, Domain.ProcessingFrequency frequency,
            Domain.ObjectStatus objectStatus, bool hasVat = false, int groupId = 1, long creditAccountShort = 7510002001, string paymentDetail="")
        {
            return new ChargeType()
            {
                ChargeTypeId = id,
                ChargeTypeCode = $"ABC{id}",
                ChargeTypeDescription = $"Test{id}",
                Curr = currency,
                DefaultAmount = id * 10,
                Frequency = frequency,
                PaymentDetail = paymentDetail == string.Empty ? $"Payment Detail {id}":paymentDetail,
                Status = objectStatus,
                LastRunDate = DateTime.Now,
                ForDepartment = 10,
                CreditAccountId = 15,
                AmountProduct = id * 20,
                CreditAccountShort = creditAccountShort,
                NextRunDay = DateTime.Now,
                RunDay = (byte?)id,
                LastModifiedBy = "CP28XQ",
                LastModifiedDate = DateTime.Now,
                HasVAT = hasVat,
                GroupId = groupId
            };
        }

        protected ChargeTypeHistory GetChargeTypeHistoryObject(int id, Currency currency, Domain.ProcessingFrequency frequency, SecObjectAction action,
            Domain.ObjectStatus objectStatus, ChargeType chargeType, string user = "CP28XQ", DateTime? lastModifyDate = null)
        {
            return new ChargeTypeHistory()
            {
                ChargeType = chargeType,
                ChargeTypeId = id,
                ChargeTypeCode = $"ABC{id}",
                ChargeTypeDescription = $"Test{id}",
                Curr = currency,
                DefaultAmount = id * 10,
                Frequency = frequency,
                PaymentDetail = $"Payment Detail {id}",
                Status = objectStatus,
                LastRunDate = DateTime.Now,
                ForDepartment = 10,
                CreditAccountId = 15,
                AmountProduct = id * 20,
                CreditAccountShort = 123456,
                NextRunDay = DateTime.Now,
                RunDay = (byte?)id,
                LastModifiedBy = user,
                LastModifiedDate = lastModifyDate ?? DateTime.Now,
                ObjectAction = action,
                GroupId = 1
            };
        }

        protected Charge GetChargeObject(int id, string customerId, ChargeType chargeType, ObjectStatus objectStatus, Currency currency,
            ChargeAccountState accountState, int sessionId = 0, string lastModifyBy = "AABBCC", DateTime? lastModifiedDate = null, string paymentDetails = null, string debitAccount = "")
        {
            return new Charge()
            {
                ChargeId = id,
                AtlasId = customerId,
                ChargeType = chargeType,
                SpecialAmount = id * 10,
                DebitAccount = string.IsNullOrEmpty(debitAccount)? $"RO51INGB00009999000011{id.ToString().PadLeft(2, '0')}" : debitAccount,
                ChargedItems = id,
                Status = objectStatus,
                CustomerChargeTypeId = id % 2 + 1,
                RejectReason = "",
                Currency = currency,
                REF_ID_CCM = 100 * id,
                CreditAccountShort = id * 10000000000,
                LastModifiedBy = lastModifyBy,
                LastModifiedDate = lastModifiedDate ?? DateTime.Now,
                ChargeAccountState = accountState,
                SessionId = sessionId,
                PaymentDetails = paymentDetails
            };
        }

        protected ChargeHistory GetChargeHistoryObject(int id, string customerId, Charge charge, ChargeType chargeType, SecObjectAction action, ObjectStatus objectStatus, Currency currency, string debitAccount = null, string lastModifyBy = null, DateTime? lastModifyDate = null, string paymentDetails = "")
        {
            return new ChargeHistory()
            {
                ChargeHistoryId = id,
                Charge = charge,
                AtlasId = customerId,
                ChargeType = chargeType,
                SpecialAmount = id * 10,
                DebitAccount = debitAccount ?? $"RO51INGB00009999000011{id.ToString().PadLeft(2, '0')}",
                ChargedItems = id,
                Status = objectStatus,
                CustomerChargeTypeId = id % 2 + 1,
                RejectReason = "",
                Currency = currency,
                REF_ID_CCM = 100 * id,
                CreditAccountShort = id * 10000000000,
                LastModifiedBy = lastModifyBy ?? "AABBCC",
                LastModifiedDate = lastModifyDate ?? DateTime.Now,
                ObjectAction = action,
                PaymentDetails = paymentDetails
            };
        }

        protected DeletedChargeHistory GetDeletedChargeHistoryObject(int id, string customerId, int chargeTypeId, byte statusId, int currencyId, int actionId, int sessionId, string debitAccount = null, string lastModifyBy = null, DateTime? lastModifyDate = null)
        {
            return new DeletedChargeHistory()
            {
                DeletedChargeHistoryId = id,
                ChargeHistoryId = id,
                ChargeId = id + 100,
                AtlasId = customerId,
                ChargeTypeId = chargeTypeId,
                SpecialAmount = id * 10,
                DebitAccount = debitAccount ?? $"RO51INGB00009999000011{id.ToString().PadLeft(2, '0')}",
                ChargedItems = id,
                StatusId = statusId,
                CustomerChargeTypeId = id % 2 + 1,
                RejectReason = "",
                CurrencyId = currencyId,
                REF_ID_CCM = 100 * id,
                CreditAccountShort = id * 10000000000,
                LastModifiedBy = lastModifyBy ?? "AABBCC",
                LastModifiedDate = lastModifyDate ?? DateTime.Now,
                ActionId = actionId,
                SessionId = sessionId
            };
        }

        protected CustomerChargeType GetCustomerChargeTypeObject(int id, string description)
        {
            return new CustomerChargeType()
            {
                Id = id,
                Description = description
            };
        }

        protected Account GetAccountObject(long accountShort, string coreBanking, string customerId, string type, short typeId)
        {
            return new Account()
            {
                AccountShort = accountShort,
                BlockedDR = 0,
                BranchCode = "ROBUC",
                CoreBanking = coreBanking,
                CUI = customerId.PadLeft(7, '9'),
                CurrencyCode = "RON",
                CustomerBranch = "ROFRC",
                CustomerId = customerId,
                CustomerName = $"Name{customerId}",
                DateOpened = DateTime.Now.AddYears(-1),
                Description = $"description {accountShort % 10}",
                IBAN = $"RO51INGB00009999000011{(accountShort % 10).ToString().PadLeft(2, '0')}",
                IsActive = "Y",
                Status = 0,
                Type = type,
                TypeId = typeId,
            };
        }

        protected Customer GetCustomerObject(int customerId, string atlasID, string comments, byte statusId)
        {
            return new Customer()
            {
                CustomerId = customerId,
                AtlasID = atlasID,
                Comments = comments,
                DateLastUpdate = DateTime.Now,
                StatusId = statusId,
                UserID = "AABBCC"
            };
        }

        protected GBSDebitAccountType GetGbsDebitAccountType(string code)
        {
            return new GBSDebitAccountType()
            {
                Code = code,
                Description = "Type description"
            };
        }

        protected PRFDebitAccountType GetPrfDebitAccountType(int cifTypeId, string code)
        {
            return new PRFDebitAccountType()
            {
                CifTypeId = cifTypeId,
                Code = code,
                Description = "Type description"
            };
        }

        protected GBSCreditAccountType GetGBSCreditAccountType(string code)
        {
            return new GBSCreditAccountType()
            {
                Code = code,
                Description = $"Description for {code}"
            };
        }

        protected PRFCreditAccountType GetPRFCreditAccountType(string code, int cifTypeId)
        {
            return new PRFCreditAccountType()
            {
                CifTypeId = 9,
                Code = code,
                Description = $"Description for {code}"
            };
        }

        protected ChargeAccountState GetChargeAccountState(int status, string code)
        {
            return new ChargeAccountState()
            {
                Status = status,
                Code = code,
                Description = $"Description {code}"
            };
        }

        protected ImportedPayments GetImportedPaymentsObject(int sessionId, int lineNumber, Session session, string chargeCode, string atlasId,
            bool isImported)
        {
            return new ImportedPayments()
            {
                SessionId = sessionId,
                LineNumber = lineNumber,
                Session = session,
                ChargeCode = chargeCode,
                AtlasId = atlasId,
                DebitAccount = "RO73INGB0000999908631724",
                CreditAccount = "999908069866",
                ChargedItems = "1",
                SpecialAmount = "50.00",
                IsImported = isImported,
                Message = "Ok",
                CustomerChargeType = "Per transaction",
                CurrencyCode = "1",
                REF_ID_CCM = null,
                VATDebitAccount = null,
                VATCreditAccount = null
            };
        }

        protected Group GetGroupObject(int id, string name, string adName, ObjectStatus objectStatus, ObjectStatus nextObjectStatus, string lastModifiedBy, DateTime lastModifiedDate)
        {
            return new Group()
            {
                Id = id,
                Name = name,
                ADName = adName,
                Status = objectStatus,
                NextStatus = nextObjectStatus,
                LastModifiedBy = lastModifiedBy,
                LastModifiedDate = lastModifiedDate
            };
        }
        protected MailList GetMailAddress(int id, string code, string displayName, string email, string description)
        {
            return new MailList()
            {
                Id = id,
                Code = code,
                DisplayName = displayName,
                Email = email,
                Description = description,
                
            };
        }
        #endregion
    }
}
