﻿using Application.Commons.Enums;
using Application.DboChargeType;
using Application.Errors;
using Application.Helpers;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Persistence;
using System;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboChargeTypeHistoryReportTest
{
    [TestClass]
    public class ListChargeTypeHistoryReportTest : TestBase
    {
        [TestMethod]
        public void ShouldReturnAllChargeTypesHistoryFromDb()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams();

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query,
                    out ListForChargeTypeHistoryReport.Handler handler);

                //act
                var chargeTypeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 7);
            }
        }

        [TestMethod]
        public void ShouldReturnPaginatedChargeTypeHistoryReportList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query, 
                    out ListForChargeTypeHistoryReport.Handler handler);
                //act
                var chargeTypeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 2 &&
                    chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC1") &&
                    chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC3"));
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(pageNumber: 1, pageSize: 100);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query,
                       out ListForChargeTypeHistoryReport.Handler handler);

                //act
                var chargeTypeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeTypeList.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldReturnEmptyListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(pageNumber: 20, pageSize: 2);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query, 
                    out ListForChargeTypeHistoryReport.Handler handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                     "The searched charge type history does not exist in the database!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(pageNumber: 0, pageSize: 2);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query, 
                    out ListForChargeTypeHistoryReport.Handler handler);

                //act
                var chargeTypeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeTypeList.CurrentPage == 1
                    && chargeTypeList.Items.Count == 2
                    && chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC1")
                    && chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC3"));
            }
        }

        [TestMethod]
        public void ShouldReturnAscSortedChargeTypeHistoryReportList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(sortField: "chargeTypeCode", sortOrder: "asc", pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query, 
                    out ListForChargeTypeHistoryReport.Handler handler);

                //act
                var chargeTypeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 2
                    && chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC1")
                    && chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC2"));
            }
        }

        [TestMethod]
        public void ShouldReturnDescSortedChargeTypeHistoryReportList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(sortField: "lastModifiedDate", sortOrder: "desc", pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query,
                    out ListForChargeTypeHistoryReport.Handler handler);

                //act
                var chargeTypeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 2
                    && chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC3")
                    && chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC1"));
            }
        }

        [TestMethod]
        public void ShouldReturnChargeTypeSortedByLastModifiedDateWhenNoSortingProvided()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query, 
                    out ListForChargeTypeHistoryReport.Handler handler);

                //act
                var chargeTypeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 2
                    && chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC3")
                    && chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC1"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredChargeTypeHistoryReportListContainingChargeTypeCode()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(chargeTypeId: 3, pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query, 
                    out ListForChargeTypeHistoryReport.Handler handler);

                //act
                var chargeTypeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 1 &&
                    chargeTypeList.Items.Where(c => c.ChargeTypeCode.Contains("ABC3")).Count() == 1);
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredChargeTypeHistoryListListWithManyFilters()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(chargeTypeId: 4, actionId: (int)ObjectAction.APPROVE, userId: "ABCDEF", 
                    pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query, 
                    out ListForChargeTypeHistoryReport.Handler handler);

                //act
                var chargeTypeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 1 &&
                    chargeTypeList.Items.Any(c => c.ChargeTypeCode.Contains("ABC4")) &&
                    chargeTypeList.Items.Any(c => c.PaymentDetail.Contains("Payment Detail 7")));
            }
        }

        [TestMethod]
        public void ShouldThrowWrrorIfFiltersDontMatch()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(chargeTypeId: 10, pageNumber: 1, pageSize: 10);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query,
                   out ListForChargeTypeHistoryReport.Handler handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                     "The searched charge type history does not exist in the database!");
            }
        }

        [TestMethod]
        public void ShouldReturnPaginatedFilteredSortedChargeTypeHistoryReportList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(sortField: "lastModifiedDate", sortOrder: "asc", chargeTypeId: 4,
                    pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeHistoryReportList(context, chargeTypeParams, out ListForChargeTypeHistoryReport.Query query,
                   out ListForChargeTypeHistoryReport.Handler handler);

                //act
                var chargeTypeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 2 && chargeTypeList.CurrentPage == 1 &&
                    chargeTypeList.Items.Select(c => c.PaymentDetail).FirstOrDefault() == "Payment Detail 7");
            }
        }

        private void InitChargeTypeAndHistoryTables(PhoenixContext context)
        {
            var statusActive = GetStatusObject(0, ObjectStatus.Active);
            var statusVerificationAdd = GetStatusObject(4, ObjectStatus.VerificationAdd);
            var statusVerificationDelete = GetStatusObject(6, ObjectStatus.VerificationDelete);
            var statusDeleted = GetStatusObject(1, ObjectStatus.Deleted);

            var processingFrequencyMonthly = GetProcessingFrequencyObject((int)ProcessingFrequency.Monthly, "Monthly");
            var processingFrequencyOnce = GetProcessingFrequencyObject((int)ProcessingFrequency.Once, "Once");
            var processingFrequencyQuarterly = GetProcessingFrequencyObject((int)ProcessingFrequency.Quarterly, "Quarterly");

            var currency = GetCurrencyObject(1, "RON");

            var objectAction = GetObjectAction(10, "PCM");
            var objectActionAdd = GetObjectAction((int)ObjectAction.ADD, ObjectAction.ADD.ToString());
            var objectActionApprove = GetObjectAction((int)ObjectAction.APPROVE, ObjectAction.APPROVE.ToString());
            var objectActionEdit = GetObjectAction((int)ObjectAction.EDIT, ObjectAction.EDIT.ToString());
            var objectActionDelete = GetObjectAction((int)ObjectAction.DELETE, ObjectAction.DELETE.ToString());
            context.ObjectActions.Add(objectAction);
            context.ObjectActions.Add(objectActionAdd);
            context.ObjectActions.Add(objectActionApprove);
            context.ObjectActions.Add(objectActionEdit);
            context.ObjectActions.Add(objectActionDelete);

            // add one CT and CTH deleted
            var chargeTypeDeleted = GetChargeTypeObject(1, currency, processingFrequencyOnce, statusDeleted);
            context.ChargeTypes.Add(chargeTypeDeleted);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(1, currency, processingFrequencyOnce, objectActionDelete, statusDeleted, chargeTypeDeleted, lastModifyDate: DateTime.Now.AddDays(-1)));

            // add CT & CTH active
            var chargeTypeActive = GetChargeTypeObject(2, currency, processingFrequencyMonthly, statusActive);
            context.ChargeTypes.Add(chargeTypeActive);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(2, currency, processingFrequencyMonthly, objectActionApprove, statusActive, chargeTypeActive, lastModifyDate: DateTime.Now.AddDays(-2)));

            // add CT & CTH in VerificationAdd
            var chargeTypeVerificationAdd = GetChargeTypeObject(3, currency, processingFrequencyOnce, statusVerificationAdd);
            context.ChargeTypes.Add(chargeTypeVerificationAdd);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(3, currency, processingFrequencyOnce, objectActionAdd, statusVerificationAdd, chargeTypeVerificationAdd, lastModifyDate: DateTime.Now));

            // add CT active with many CTH
            var chargeTypeWithManyCTH = GetChargeTypeObject(4, currency, processingFrequencyMonthly, statusActive);
            context.ChargeTypes.Add(chargeTypeWithManyCTH);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(4, currency, processingFrequencyOnce, objectActionAdd, statusVerificationAdd, chargeTypeWithManyCTH, "CP28XQ", lastModifyDate: DateTime.Now.AddDays(-3)));
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(5, currency, processingFrequencyMonthly, objectActionApprove, statusActive, chargeTypeWithManyCTH, "KK70XR", lastModifyDate: DateTime.Now.AddDays(-4)));
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(6, currency, processingFrequencyMonthly, objectActionDelete, statusVerificationDelete, chargeTypeWithManyCTH, "CP28XQ", lastModifyDate: DateTime.Now.AddDays(-5)));
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(7, currency, processingFrequencyQuarterly, objectActionApprove, statusActive, chargeTypeWithManyCTH, "ABCDEF", lastModifyDate: DateTime.Now.AddDays(-6)));

            context.SaveChanges();
        }

        private ChargeTypeHistoryReportParams SetChargeTypeParams(string sortField = "", string sortOrder = "", int chargeTypeId = -1,
            int statusId = -1, string userId = "", int actionId = -1, DateTime? startDate = null, DateTime? endDate = null,
            int pageNumber = 1, int pageSize = 15)
        {
            return new ChargeTypeHistoryReportParams
            {
                SortField = sortField,
                SortOrder = sortOrder,
                ChargeTypeId = chargeTypeId,
                StatusId = statusId,
                UserId = userId,
                ActionId = actionId,
                StartDate = startDate,
                EndDate = endDate,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }

        private void ArrangeOnChargeTypeHistoryReportList(PhoenixContext context, ChargeTypeHistoryReportParams chargeTypeHistoryReportParams,
                out ListForChargeTypeHistoryReport.Query query, out ListForChargeTypeHistoryReport.Handler handler)
        {
            InitChargeTypeAndHistoryTables(context);

            query = new ListForChargeTypeHistoryReport.Query() { ChargeTypeHistoryReportParams = chargeTypeHistoryReportParams };
            handler = new ListForChargeTypeHistoryReport.Handler(context, GetMapper(), Mock.Of<ILogger<ListForChargeTypeHistoryReport.Handler>>());
        }

    }
}
