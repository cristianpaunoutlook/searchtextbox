﻿using Application.DboSession;
using Application.Errors;
using Domain;
using Persistence;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ApplicationTests.DboSessionTests
{
    [TestClass]
    public class CreateEditAndDeleteSessionTest : SessionBase
    {
        [TestMethod]
        public void AfterCreateShouldHaveOneSessionInDb()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                var command = new Create.Command()
                {
                    GeneratedFileName = "test.txt",
                    ObjectTypeId = 6,
                    Status = 1
                };
                var handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Sessions.Where(s => s.GeneratedFileName == "test.txt").Count() == 1);
            }
        }

        [TestMethod]
        public void EditedSessionShouldBePersistedInDb()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitSessionTable(context);
                var newDate = DateTime.Now;
                var command = new Edit.Command()
                {
                    SessionId = 1,
                    GeneratedFileName = "test1_updated.txt",
                    ObjectTypeId = 7,
                    RecordStamp = newDate,
                    Status = 2
                };
                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Sessions
                                .Where(s => s.GeneratedFileName == "test1_updated.txt" &&
                                            s.ObjectTypeId == 7 &&
                                            s.Status == 2 &&
                                            s.RecordStamp == newDate)
                                .Count() == 1);
            }
        }

        [TestMethod]
        public void EditSessionWithBadIdShouldThrowException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitSessionTable(context);
                var newDate = DateTime.Now;
                var command = new Edit.Command()
                {
                    SessionId = 10,
                    GeneratedFileName = "test1_updated.txt",
                    ObjectTypeId = 7,
                    RecordStamp = newDate,
                    Status = 2
                };
                //Act
                var handler = new Edit.Handler(context, Mock.Of<ILogger<Edit.Handler>>());
                //Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token));
            }
        }

        [TestMethod]
        public void DeleteSessionThenNoLongerInDb()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitSessionTable(context);
                var command = new Delete.Command() { SessionId = 1 };
                var handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>());
                //Act
                var unit = handler.Handle(command, (new CancellationTokenSource()).Token);
                //Assert
                Assert.IsTrue(context.Sessions.Count() == 7);
            }
        }

        [TestMethod]
        public void TryToDeleteInvalidSessionWillThrowException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitSessionTable(context);
                var command = new Delete.Command() { SessionId = 10 };
                var handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>());

                //Act
                //Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token));
            }
        }
    }
}
