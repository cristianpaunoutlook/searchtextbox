﻿using Application.Helpers;
using Application.DboSession;
using Application.Errors;
using Domain;
using Persistence;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ApplicationTests.DboSessionTests
{
    [TestClass]
    public class ListAndDetailsSessionTest : SessionBase
    {
        [TestMethod]
        public void ShouldReturnAllSessionsInDb()
        {
            using (var context = GetDbContext())
            {
                //arange

                var sessionParams = new SessionParams();

                InitSessionTable(context);
                var command = new List.Query() { SessionParams = sessionParams };
                var handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>());

                //act
                var listOfSessions = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(listOfSessions.Items.Count == 8);
            }
        }

        [TestMethod]
        public void ShouldReturnPaginatedSessionList()
        {
            using (var context = GetDbContext())
            {
                //arange

                var sessionParams = new SessionParams();
                sessionParams.PageNumber = 2;
                sessionParams.PageSize = 2;

                InitSessionTable(context);
                var command = new List.Query() { SessionParams = sessionParams };
                var handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>());

                //act
                var listOfSessions = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(listOfSessions.Items.Count == 2 &&
                    listOfSessions.Items.Exists(s => s.SessionId == 3) &&
                    listOfSessions.Items.Exists(s => s.SessionId == 4));
            }
        }

        [TestMethod]
        public void ShouldReturnFilterdSessionList()
        {
            using (var context = GetDbContext())
            {
                //arange

                var sessionParams = new SessionParams();
                sessionParams.SessionId = 5;

                InitSessionTable(context);
                var command = new List.Query() { SessionParams = sessionParams };
                var handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>());

                //act
                var listOfSessions = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(listOfSessions.Items.Count == 1 && listOfSessions.Items.Exists(s => s.SessionId == 5)
                    && listOfSessions.Items.Exists(s => s.GeneratedFileName == "test5.txt"));
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange

                var sessionParams = new SessionParams();
                sessionParams.PageNumber = 1;
                sessionParams.PageSize = 55;

                InitSessionTable(context);
                var command = new List.Query() { SessionParams = sessionParams };
                var handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>());

                //act
                var listOfSessions = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(listOfSessions.Items.Count <= 50);
            }
        }

        [TestMethod]
        public void ShouldReturnEmptyListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange

                var sessionParams = new SessionParams();
                sessionParams.PageNumber = 20;
                sessionParams.PageSize = 2;

                InitSessionTable(context);
                var command = new List.Query() { SessionParams = sessionParams };
                var handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>());

                //act
                var listOfSessions = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(listOfSessions.Items.Count == 0);
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arange

                var sessionParams = new SessionParams();
                sessionParams.PageNumber = 0;
                sessionParams.PageSize = 3;

                InitSessionTable(context);
                var command = new List.Query() { SessionParams = sessionParams };
                var handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>());

                //act
                var listOfSessions = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(listOfSessions.CurrentPage == 1
                    && listOfSessions.Items.Count == 3
                    && listOfSessions.Items.Exists(s => s.SessionId == 1));
            }
        }

        [TestMethod]
        public void ShouldReturnSessionWithSpecifiedId()
        {

            using (var context = GetDbContext())
            {
                //arange
                InitSessionTable(context);
                var command = new Details.Query() { Id = 1 };
                var handler = new Details.Handler(context, GetMapper(), Mock.Of<ILogger<Details.Handler>>());

                //act
                var listOfSessions = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(listOfSessions.SessionId == 1 && listOfSessions.GeneratedFileName == "test1.txt" && listOfSessions.ObjectTypeId == 6);
            }
        }

        [TestMethod]
        public void ShouldThrowRestExceptionIfSessionIsNotInDatabase()
        {
            using (var context = GetDbContext())
            {
                //arange
                InitSessionTable(context);
                var command = new Details.Query() { Id = 10 };
                var handler = new Details.Handler(context, GetMapper(), Mock.Of<ILogger<Details.Handler>>());

                //act
                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token));
            }
        }
    }
}
