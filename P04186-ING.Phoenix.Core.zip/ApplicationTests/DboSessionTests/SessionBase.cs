﻿using Domain;
using Persistence;
using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationTests.DboSessionTests
{
    public class SessionBase : TestBase
    {
        public void InitSessionTable(PhoenixContext context)
        {
            for (int i = 1; i < 9; i++)
            {
                var sessionToAdd = new Session()
                {
                    SessionId = i,
                    GeneratedFileName = $"test{i}.txt",
                    ObjectTypeId = 6,
                    RecordStamp = DateTime.Now,
                    Status = 1
                };

                context.Sessions.Add(sessionToAdd);
            }

            context.SaveChanges();
        }
    }
}
