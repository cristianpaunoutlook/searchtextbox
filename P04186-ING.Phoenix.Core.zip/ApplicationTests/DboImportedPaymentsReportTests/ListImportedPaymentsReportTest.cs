﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.DboImportedPayments;
using Application.Errors;
using Application.Helpers;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Persistence;
using System;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboImportedPaymentsReportTests
{
    [TestClass]
    public class ListImportedPaymentsReportTest : TestBase
    {
        [TestMethod]
        public void ShouldReturnAllImportedPaymentsFromDb()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams();

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.Items.Count == 6);
            }
        }

        [TestMethod]
        public void ShouldReturnPaginatedImportedPaymentsReportList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(pageNumber: 1, pageSize: 2);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);
                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.Items.Count == 2 &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 3 && ip.LineNumber == 1) &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 2 && ip.LineNumber == 2));
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(pageNumber: 1, pageSize: 100);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                       out ImportedPaymentsForReport.Handler handler);

                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldReturnEmptyListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(pageNumber: 20, pageSize: 2);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                     "The searched imported payments does not exist in the database!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(pageNumber: 0, pageSize: 2);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.CurrentPage == 1 &&
                    importedPaymentsList.Items.Count == 2 &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 3 && ip.LineNumber == 1) &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 2 && ip.LineNumber == 2));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredImportedPaymentsReportWithSessionId()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(sessionId: "3", pageNumber: 1, pageSize: 2);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.Items.Count == 1 &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 3));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredImportedPaymentsReportWithCustomerId()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(customerId: "Megima", pageNumber: 1, pageSize: 2);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.Items.Count == 2 &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 1 && ip.LineNumber == 1) &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 1 && ip.LineNumber == 2));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredImportedPaymentsReportWithChargeCode()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(chargeCode: "AEGRM", pageNumber: 1, pageSize: 2);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.Items.Count == 1 &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 3 && ip.LineNumber == 1));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredImportedPaymentsReportWithUserId()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(userId: "RV72DR", pageNumber: 1, pageSize: 2);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.Items.Count == 1 &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 3 && ip.LineNumber == 1));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredImportedPaymentsReportWithStartDate()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(startDate: DateTime.Now.AddDays(-1), pageNumber: 1, pageSize: 5);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.Items.Count == 3 &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 1 && ip.LineNumber == 1) &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 1 && ip.LineNumber == 2) &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 1 && ip.LineNumber == 3));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredImportedPaymentsReportWithEndDate()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(endDate: DateTime.Now.AddDays(-2), pageNumber: 1, pageSize: 5);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.Items.Count == 3 &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 2 && ip.LineNumber == 1) &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 2 && ip.LineNumber == 2) &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 3 && ip.LineNumber == 1));
            }
        }
        [TestMethod]
        public void ShouldReturnFilteredChargeTypeHistoryListListWithManyFilters()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(sessionId: "1", customerId: "Megima", chargeCode: "POSPRF",
                    userId: "CP28XQ", startDate: DateTime.Now.AddDays(-2), endDate: DateTime.Now, isImported: 0, pageNumber: 1, pageSize: 2);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act
                var importedPaymentsList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(importedPaymentsList.Items.Count == 1 &&
                    importedPaymentsList.Items.Any(ip => ip.SessionId == 1 && ip.LineNumber == 2));
            }
        }

        [TestMethod]
        public void ShouldThrowWrrorIfFiltersDontMatch()
        {
            using (var context = GetDbContext())
            {
                //arange
                var importedPaymentsParams = SetImportedPaymentsReportParams(sessionId: "4", pageNumber: 1, pageSize: 10);

                ArrangeOnImportedPaymentsReportList(context, importedPaymentsParams, out ImportedPaymentsForReport.Query query,
                    out ImportedPaymentsForReport.Handler handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                     "The searched imported payments does not exist in the database!");
            }
        }

        private void InitImportedPaymentsAndApplicationLogTables(PhoenixContext context)
        {
            var sessionToAdd1 = GetSession(1, (int)ObjectType.SessionImport);
            var sessionToAdd2 = GetSession(2, (int)ObjectType.SessionImport);
            var sessionToAdd3 = GetSession(3, (int)ObjectType.SessionImport);
            var currency = GetCurrencyObject(1, "RON");
            var statusActive = GetStatusObject(1, ObjectStatus.Active.ToString());
            var freq = new Domain.ProcessingFrequency();
            freq.ProcessingFrequencyId = 1;
            freq.ProcessingFrequencyName = Constants.PER_TRANSACTION;
            var ctCheque = GetChargeTypeObject(1, currency, freq, statusActive);
            ctCheque.ChargeTypeCode = Constants.CHEQUE;
            context.ChargeTypes.Add(ctCheque);
            var importedPayment1 = GetImportedPaymentsObject(1, 1, sessionToAdd1, " ", "Megima", true);
            var importedPayment2 = GetImportedPaymentsObject(1, 2, sessionToAdd1, "POSPRF", "Megima", false);
            var importedPayment3 = GetImportedPaymentsObject(1, 3, sessionToAdd1, "POSGBS", "123456", true);
            var importedPayment4 = GetImportedPaymentsObject(2, 1, sessionToAdd2, "RF", "INKPRI", true);
            var importedPayment5 = GetImportedPaymentsObject(2, 2, sessionToAdd2, "AMF", "APACANA", true);
            var importedPayment6 = GetImportedPaymentsObject(3, 1, sessionToAdd3, "AEGRM", "123999", true);

            context.ImportedPayments.Add(importedPayment1);
            context.ImportedPayments.Add(importedPayment2);
            context.ImportedPayments.Add(importedPayment3);
            context.ImportedPayments.Add(importedPayment4);
            context.ImportedPayments.Add(importedPayment5);
            context.ImportedPayments.Add(importedPayment6);

            //add corresponding application log to imported payments
            var applicationLog1 = GetApplicationLog(1, 1, (int)ObjectType.SessionImport, DateTime.Now.AddDays(-1), "CP28XQ");
            var applicationLog2 = GetApplicationLog(2, 2, (int)ObjectType.SessionImport, DateTime.Now.AddDays(-10), "System");
            var applicationLog3 = GetApplicationLog(3, 3, (int)ObjectType.SessionImport, DateTime.Now.AddDays(-5), "RV72DR");

            context.ApplicationLogs.Add(applicationLog1);
            context.ApplicationLogs.Add(applicationLog2);
            context.ApplicationLogs.Add(applicationLog3);

            context.SaveChanges();
        }

        private ImportedPaymentsReportParams SetImportedPaymentsReportParams(string sessionId = "", string customerId = "",
            string chargeCode = "", string userId = "", DateTime? startDate = null, DateTime? endDate = null, sbyte isImported = -1,
            int pageNumber = 1, int pageSize = 15)
        {
            return new ImportedPaymentsReportParams
            {
                SessionId = sessionId,
                CustomerId = customerId,
                ChargeCode = chargeCode,
                UserId = userId,
                StartDate = startDate,
                EndDate = endDate,
                IsImported = isImported,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }

        private void ArrangeOnImportedPaymentsReportList(PhoenixContext context, ImportedPaymentsReportParams importedPaymentsReportParams,
                out ImportedPaymentsForReport.Query query, out ImportedPaymentsForReport.Handler handler)
        {
            InitImportedPaymentsAndApplicationLogTables(context);

            query = new ImportedPaymentsForReport.Query() { ImportedPaymentsReportParams = importedPaymentsReportParams };
            handler = new ImportedPaymentsForReport.Handler(context, GetMapper(), Mock.Of<ILogger<ImportedPaymentsForReport.Handler>>());
        }

    }
}
