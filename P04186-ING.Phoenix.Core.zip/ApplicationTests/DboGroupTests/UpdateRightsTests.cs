﻿using Application.Commons.Enums;
using Application.DboGroup;
using Application.DTO;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;
using Enum = Application.Commons.Enums;

namespace ApplicationTests.DboGroupTests
{
    [TestClass]
    public class UpdateRightsTests : GroupBaseTest
    {
        [TestMethod]
        public void SaveRightsForActiveGroup()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToUpdate = 1;
                // Arrange
                PrepareData(context, true);
                UpdateRights.Command command = new UpdateRights.Command()
                {
                    UserKey = UserToSave,
                    RightsToUpdate = new GroupPagesRightsDTO[] {
                        new GroupPagesRightsDTO(){ GroupId = groupToUpdate, PageId = 1, RightValue = 3, NextRightValue = 2, LastModifiedBy = UserToSave  }
                    },
                    SessionId = SecSession
                };
                UpdateRights.Handler handler = new UpdateRights.Handler(context, Mock.Of<ILogger<UpdateRights.Handler>>());

                // Act
                System.Threading.Tasks.Task<MediatR.Unit> result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Groups.Where(g =>
                            g.Id == groupToUpdate &&
                            g.Status.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.NextStatus.ObjectStatusName == Enum.ObjectStatus.VerificationModify &&
                            g.LastModifiedBy == UserToSave)
                    .Count() == 1);

                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToUpdate && ugr.LastModifiedBy == UserToSave).Count() == 1);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToUpdate && ugr.NextRight.Value == 2 && ugr.Right.Value == 3).Count() == 1);
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == UserToSave && ul.ActionId == (int)UserAction.ModifyEdit && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == groupToUpdate.ToString()).Count() == 1);
            }
        }

        [TestMethod]
        public void SaveNewRightsForActiveGroup()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToUpdate = 2;
                // Arrange
                PrepareData(context, true);
                UpdateRights.Command command = new UpdateRights.Command()
                {
                    UserKey = UserToSave,
                    RightsToUpdate = new GroupPagesRightsDTO[] {
                        new GroupPagesRightsDTO(){ GroupId = groupToUpdate, PageId = 4, RightValue = 0, NextRightValue = 3, LastModifiedBy = UserToSave  }
                    },
                    SessionId = SecSession
                };
                UpdateRights.Handler handler = new UpdateRights.Handler(context, Mock.Of<ILogger<UpdateRights.Handler>>());

                // Act
                System.Threading.Tasks.Task<MediatR.Unit> result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Groups.Where(g =>
                            g.Id == groupToUpdate &&
                            g.Status.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.NextStatus.ObjectStatusName == Enum.ObjectStatus.VerificationModify &&
                            g.LastModifiedBy == UserToSave)
                    .Count() == 1);

                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToUpdate).Count() == 3);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToUpdate && ugr.NextRight.Value == 3 && ugr.Right.Value == 0).Count() == 1);
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == UserToSave && ul.ActionId == (int)UserAction.ModifyEdit && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == groupToUpdate.ToString()).Count() == 1);

            }
        }

        [TestMethod]
        public void DeleteRightsForActiveGroup()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToUpdate = 2;
                // Arrange
                PrepareData(context, true);
                UpdateRights.Command command = new UpdateRights.Command()
                {
                    UserKey = UserToSave,
                    RightsToUpdate = new GroupPagesRightsDTO[] {
                        new GroupPagesRightsDTO(){ GroupId = groupToUpdate, PageId = 2, RightValue = 1, NextRightValue = 0, LastModifiedBy = UserToSave  }
                    },
                    SessionId = SecSession
                };
                UpdateRights.Handler handler = new UpdateRights.Handler(context, Mock.Of<ILogger<UpdateRights.Handler>>());

                // Act
                System.Threading.Tasks.Task<MediatR.Unit> result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Groups.Where(g =>
                            g.Id == groupToUpdate &&
                            g.Status.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.NextStatus.ObjectStatusName == Enum.ObjectStatus.VerificationModify &&
                            g.LastModifiedBy == UserToSave)
                    .Count() == 1);

                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToUpdate).Count() == 2);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToUpdate && ugr.NextRight.Value == 0 && ugr.Right.Value == 1).Count() == 1);
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == UserToSave && ul.ActionId == (int)UserAction.ModifyEdit && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == groupToUpdate.ToString()).Count() == 1);

            }
        }

        [TestMethod]
        [DataRow(3)]
        [DataRow(4)]
        [DataRow(5)]
        public void SaveRightsForNotActiveGroupShouldThrowexception(int groupToUpdate)
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {

                // Arrange
                PrepareData(context);
                UpdateRights.Command command = new UpdateRights.Command()
                {
                    UserKey = UserToSave,
                    RightsToUpdate = new GroupPagesRightsDTO[] {
                        new GroupPagesRightsDTO(){ GroupId = groupToUpdate, PageId = 3, RightValue = 2, NextRightValue = 3, LastModifiedBy = UserToSave  },
                        new GroupPagesRightsDTO(){ GroupId = groupToUpdate, PageId = 4, RightValue = 3, NextRightValue = 1, LastModifiedBy = UserToSave  },
                        new GroupPagesRightsDTO(){ GroupId = groupToUpdate, PageId = 2, RightValue = 3, NextRightValue = 0, LastModifiedBy = UserToSave  }
                    },
                    SessionId = SecSession
                };
                UpdateRights.Handler handler = new UpdateRights.Handler(context, Mock.Of<ILogger<UpdateRights.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "You can edit rights for groups only if status is active!");
            }
        }

        [TestMethod]
        public void SaveRightsForInvalidGroupThrowsException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {

                // Arrange
                PrepareData(context);
                int groupToUpdate = int.MaxValue;
                UpdateRights.Command command = new UpdateRights.Command()
                {
                    UserKey = UserToSave,
                    RightsToUpdate = new GroupPagesRightsDTO[] {
                        new GroupPagesRightsDTO(){ GroupId = groupToUpdate, PageId = 3, RightValue = 2, NextRightValue = 3, LastModifiedBy = UserToSave  }
                    },
                    SessionId = SecSession
                };
                UpdateRights.Handler handler = new UpdateRights.Handler(context, Mock.Of<ILogger<UpdateRights.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Group with specified id is not in the database!");
            }
        }

        [TestMethod]
        public void SaveGroupWithoutChangesThrowsException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                // Arrange
                PrepareData(context);
                int groupToUpdate = 1;
                UpdateRights.Command command = new UpdateRights.Command()
                {
                    UserKey = UserToSave,
                    RightsToUpdate = new GroupPagesRightsDTO[] {
                        new GroupPagesRightsDTO(){ GroupId = groupToUpdate, PageId = 1, RightValue = 3, NextRightValue = 3, LastModifiedBy = UserToSave  }
                    },
                    SessionId = SecSession
                };
                UpdateRights.Handler handler = new UpdateRights.Handler(context, Mock.Of<ILogger<UpdateRights.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Group with specified id is not in the database!");
            }
        }

        [TestMethod]
        public void SaveGroupWithoutSessionShouldThrowsException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                // Arrange
                PrepareData(context, true);
                int groupToUpdate = 1;
                UpdateRights.Command command = new UpdateRights.Command()
                {
                    UserKey = UserToSave,
                    RightsToUpdate = new GroupPagesRightsDTO[] {
                        new GroupPagesRightsDTO(){ GroupId = groupToUpdate, PageId = 1, RightValue = 3, NextRightValue = 3, LastModifiedBy = UserToSave  }
                    },
                    SessionId = SecSession
                };
                UpdateRights.Handler handler = new UpdateRights.Handler(context, Mock.Of<ILogger<UpdateRights.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "The session is not registred!");
            }
        }
    }
}
