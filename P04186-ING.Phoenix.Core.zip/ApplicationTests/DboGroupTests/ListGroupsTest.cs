﻿using System.Threading;
using Application.DboGroup;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ApplicationTests.DboGroupTests
{
    [TestClass]
    public class ListGroupsTest : GroupBaseTest
    {
        [TestMethod]
        public void ShouldReturnAllGroupsForAppFromDb()
        {
            using (var context = GetDbContext())
            {
                ArrangeOnGroupsList(context, "WBIF", out List.Query query, out List.Handler handler);
                var appGroup = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(appGroup.Groups.Count == 4);
            }
        }

        [TestMethod]
        public void ShouldReturnErrorIfPatternNotMatched()
        {
            using (var context = GetDbContext())
            {
                ArrangeOnGroupsList(context, "PNTF", out List.Query query, out List.Handler handler);
                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token));
            }
        }
    }
}


