﻿using Application.Commons.Enums;
using Application.DboGroup;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboGroupTests
{
    [TestClass]
    public class DeleteTests : GroupBaseTest
    {
        [TestMethod]
        public void DeleteGroupShouldChangeStatusToVerificationDelete()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToDelete = 1;
                // Arrange
                PrepareData(context, true);
                Delete.Command command = new Delete.Command()
                {
                    LastModifiedBy = UserToSave,
                    GroupId = groupToDelete,
                    SessionId = SecSession
                };
                Delete.Handler handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>());

                // Act
                System.Threading.Tasks.Task<MediatR.Unit> result = handler.Handle(command, (new CancellationTokenSource()).Token);

                //Assert
                Assert.IsTrue(context.Groups.Where(g => g.Id == groupToDelete &&
                                                        g.NextStatus.ObjectStatusName == Application.Commons.Enums.ObjectStatus.VerificationDelete &&
                                                        g.Status.ObjectStatusName == Application.Commons.Enums.ObjectStatus.Active &&
                                                        g.LastModifiedBy == UserToSave).Count() == 1);

                Assert.IsTrue(context.GroupsPagesRights.Where(gpr => gpr.GroupId == groupToDelete && gpr.NextRight.Value == (int)RightsCode.NORIGHT).Count() == 1);
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == UserToSave && ul.ActionId == (int)UserAction.Delete && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == groupToDelete.ToString()).Count() == 1);
            }
        }

        [TestMethod]
        [DataRow(3)]
        [DataRow(4)]
        [DataRow(5)]
        public void DeleteNotActiveGroupShouldThrowexception(int groupToDelete)
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {

                // Arrange
                PrepareData(context);
                Delete.Command command = new Delete.Command()
                {
                    LastModifiedBy = UserToSave,
                    GroupId = groupToDelete,
                    SessionId = SecSession
                };
                Delete.Handler handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "You can delte a group only if status is active!");
            }
        }

        [TestMethod]
        public void DeleteInvalidGroupThrowsException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {

                // Arrange
                PrepareData(context);
                int groupToDelete = int.MaxValue;
                Delete.Command command = new Delete.Command()
                {
                    LastModifiedBy = UserToSave,
                    GroupId = groupToDelete,
                    SessionId = SecSession
                };
                Delete.Handler handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Group with specified id is not in the database!");
            }
        }
        [TestMethod]
        public void DeleteGroupWithoutSessionShouldThrowsException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {

                // Arrange
                PrepareData(context);
                int groupToDelete = int.MaxValue;
                Delete.Command command = new Delete.Command()
                {
                    LastModifiedBy = UserToSave,
                    GroupId = groupToDelete,
                    SessionId = SecSession
                };
                Delete.Handler handler = new Delete.Handler(context, Mock.Of<ILogger<Delete.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "The session is not registred!");
            }
        }
    }
}
