﻿using System;
using Application.Commons.Enums;
using Application.DboGroup;
using Domain;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;

namespace ApplicationTests.DboGroupTests
{
    public class GroupBaseTest : TestBase
    {
        public const string UserToSave = "CCBBAA";
        public const string SameUser = "AABBCC";
        public const string SecSession = "sessionKey";

        protected void InitGroups(PhoenixContext context)
        {
            var statusActive = GetStatusObject(0, Application.Commons.Enums.ObjectStatus.Active);
            var statusVerificationAdd = GetStatusObject(4, Application.Commons.Enums.ObjectStatus.VerificationAdd);
            var group1 = GetGroupObject(1, "AD_ADMIN", "GSAPC5D_WBIF-ADMIN", statusActive, statusActive, "UO04XR", DateTime.Now);
            var group2 = GetGroupObject(2, "AD_ADMIN", "GSAPC5D_WBIF-ADMIN", statusActive, statusVerificationAdd, "UO04XR", DateTime.Now);
            var group3 = GetGroupObject(3, "AD_ADMIN", "GSAPC5D_WBIF-ADMIN", statusVerificationAdd, statusActive, "UO04XR", DateTime.Now);
            var group4 = GetGroupObject(4, "AD_ADMIN", "GSAPC5D_COMM-ADMIN", statusVerificationAdd, statusActive, "UO04XR", DateTime.Now);
            context.Groups.Add(group1);
            context.Groups.Add(group2);
            context.Groups.Add(group3);
            context.Groups.Add(group4);

            context.SaveChanges();
        }

        protected void PrepareData(PhoenixContext context, bool isWithSession = false)
        {
            context.Pages.Add(new Page() { Id = 1, Code = "SEC", Name = "Security", OrderNo = 1 });
            context.Pages.Add(new Page() { Id = 2, Code = "PG1", Name = "Page 1", OrderNo = 2 });
            context.Pages.Add(new Page() { Id = 3, Code = "PG2", Name = "Page 2", OrderNo = 3 });
            context.Pages.Add(new Page() { Id = 4, Code = "PG3", Name = "Page 3", OrderNo = 4 });

            context.Rights.Add(new Right() { Id = 1, Code = "NORIGHT", Description = "User has no rights", Value = 0 });
            context.Rights.Add(new Right() { Id = 2, Code = "READ", Description = "Right to read or export", Value = 1 });
            context.Rights.Add(new Right() { Id = 3, Code = "EDIT", Description = "Right to add, modify or delete an entity", Value = 2 });
            context.Rights.Add(new Right() { Id = 4, Code = "APPROVE", Description = "Right to approve or reject a change on an entity", Value = 3 });

            context.ObjectStatus.Add(new Domain.ObjectStatus() { ObjectStatusId = 0, ObjectStatusName = "Active", Visible = true });
            context.ObjectStatus.Add(new Domain.ObjectStatus() { ObjectStatusId = 4, ObjectStatusName = "VerificationAdd", Visible = true });
            context.ObjectStatus.Add(new Domain.ObjectStatus() { ObjectStatusId = 5, ObjectStatusName = "VerificationModify", Visible = true });
            context.ObjectStatus.Add(new Domain.ObjectStatus() { ObjectStatusId = 6, ObjectStatusName = "VerificationDelete", Visible = true });

            context.Groups.Add(new Group() { Id = 1, ADName = "GSAPC5D_WBIF-ADMIN", Name = "AD_ADMIN", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 0, NextStatusId = 0 });
            context.Groups.Add(new Group() { Id = 2, ADName = "GSAPC5D_WBIF-AUDIT", Name = "AD_AUDIT", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 0, NextStatusId = 0 });
            context.Groups.Add(new Group() { Id = 3, ADName = "GSAPC5D_WBIF-BROWSER", Name = "AD_BROWSER", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 4, NextStatusId = 4 });
            context.Groups.Add(new Group() { Id = 4, ADName = "GSAPC5D_WBIF-CADM", Name = "AD_CADM", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 0, NextStatusId = 5 });
            context.Groups.Add(new Group() { Id = 5, ADName = "GSAPC5D_WBIF-GLPDM", Name = "AD_GLPDM", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 0, NextStatusId = 6 });
            context.Groups.Add(new Group() { Id = 6, ADName = "GSAPC5D_WBIF-APIJOBS", Name = "AD_JOBS", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 0, NextStatusId = 0 });

            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 1, RightId = 4, PageId = 1, NextRightId = 4, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 2, RightId = 2, PageId = 2, NextRightId = 2, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 2, RightId = 2, PageId = 3, NextRightId = 2, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 3, RightId = 1, PageId = 3, NextRightId = 4, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 3, RightId = 1, PageId = 4, NextRightId = 3, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 4, RightId = 3, PageId = 4, NextRightId = 1, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 4, RightId = 2, PageId = 3, NextRightId = 4, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 5, RightId = 3, PageId = 4, NextRightId = 3, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 5, RightId = 2, PageId = 3, NextRightId = 2, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });

            if (isWithSession)
                context.SecSessions.Add(new SecSession(){SessionId = 1, CountFailedLogin = 0, IP = "1.0.0.0", Session = "sessionKey", SessionDate = DateTime.Now, UserId = "AABBCC",Workstation = "workstation"});
            context.SaveChanges();
        }

        protected void ArrangeOnGroupsList(PhoenixContext context, string pattern,
        out List.Query query, out List.Handler handler)
        {
            InitGroups(context);

            query = new List.Query() { };
            handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>());
        }

        protected IConfiguration GetConfigurationObject()
        {
            var configuration = new Mock<IConfiguration>();
            configuration.Setup(c => c.GetSection("UserGroupsNamePattern").Value).Returns("PNTF");
            return configuration.Object;
        }
    }
}
