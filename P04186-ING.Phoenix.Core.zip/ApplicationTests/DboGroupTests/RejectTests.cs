﻿using Application.Commons.Enums;
using Application.DboGroup;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;
using Enum = Application.Commons.Enums;

namespace ApplicationTests.DboGroupTests
{
    [TestClass]
    public class RejectTests : GroupBaseTest
    {
        [TestMethod]
        public void RejectGroupVerificationAddRemoveGroup()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToReject = 3;
                // Arrange
                PrepareData(context, true);
                Reject.Command command = new Reject.Command()
                {
                    UserKey = UserToSave,
                    GroupId = groupToReject,
                    SessionId = SecSession
                };
                Reject.Handler handler = new Reject.Handler(context, Mock.Of<ILogger<Reject.Handler>>());

                // Act
                System.Threading.Tasks.Task<MediatR.Unit> result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Groups.Where(g => g.Id == groupToReject).Count() == 0);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToReject).Count() == 0);
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == UserToSave && ul.ActionId == (int)UserAction.Reject && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == groupToReject.ToString()).Count() == 1);
            }
        }

        [TestMethod]
        public void RejectGroupVerificationModifyActivateGroup()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToReject = 4;
                // Arrange
                PrepareData(context, true);
                Reject.Command command = new Reject.Command()
                {
                    UserKey = UserToSave,
                    GroupId = groupToReject,
                    SessionId = SecSession
                };
                Reject.Handler handler = new Reject.Handler(context, Mock.Of<ILogger<Reject.Handler>>());

                // Act
                System.Threading.Tasks.Task<MediatR.Unit> result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Groups.Where(g =>
                            g.Id == groupToReject &&
                            g.Status.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.NextStatus.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.LastModifiedBy == UserToSave)
                    .Count() == 1);

                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToReject).Count() == 2);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToReject && ugr.NextRight.Value == 2 && ugr.Right.Value == 2 && ugr.PageId == 4).Count() == 1);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToReject && ugr.NextRight.Value == 1 && ugr.Right.Value == 1 && ugr.PageId == 3).Count() == 1);
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == UserToSave && ul.ActionId == (int)UserAction.Reject && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == groupToReject.ToString()).Count() == 1);
            }
        }

        [TestMethod]
        public void RejectGroupVerificationDeleteShouldActivateGroup()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToReject = 5;
                // Arrange
                PrepareData(context, true);
                Reject.Command command = new Reject.Command()
                {
                    UserKey = UserToSave,
                    GroupId = groupToReject,
                    SessionId = SecSession
                };
                Reject.Handler handler = new Reject.Handler(context, Mock.Of<ILogger<Reject.Handler>>());

                // Act
                System.Threading.Tasks.Task<MediatR.Unit> result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Groups.Where(g =>
                            g.Id == groupToReject &&
                            g.Status.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.NextStatus.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.LastModifiedBy == UserToSave)
                    .Count() == 1);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToReject).Count() == 2);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToReject && ugr.NextRight.Value == 2 && ugr.Right.Value == 2 && ugr.PageId == 4).Count() == 1);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToReject && ugr.NextRight.Value == 1 && ugr.Right.Value == 1 && ugr.PageId == 3).Count() == 1);
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == UserToSave && ul.ActionId == (int)UserAction.Reject && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == groupToReject.ToString()).Count() == 1);
            }
        }

        [TestMethod]
        public void RejectForActiveGroupShouldThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {

                // Arrange
                PrepareData(context);
                Reject.Command command = new Reject.Command()
                {
                    UserKey = UserToSave,
                    GroupId = 1,
                    SessionId = SecSession
                };
                Reject.Handler handler = new Reject.Handler(context, Mock.Of<ILogger<Reject.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "You can reject groups only if status is approve add, approve modify or approve delete!");
            }
        }

        [TestMethod]
        public void RejectForInvalidGroupThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {

                // Arrange
                PrepareData(context);
                Reject.Command command = new Reject.Command()
                {
                    UserKey = UserToSave,
                    GroupId = int.MaxValue,
                    SessionId = SecSession
                };
                Reject.Handler handler = new Reject.Handler(context, Mock.Of<ILogger<Reject.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Group with specified id is not in the database!");
            }
        }

        [TestMethod]
        public void RejectWithSameUserShouldThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToApprove = 3;
                // Arrange
                PrepareData(context);
                Reject.Command command = new Reject.Command()
                {
                    UserKey = SameUser,
                    GroupId = groupToApprove,
                    SessionId = SecSession
                };
                Reject.Handler handler = new Reject.Handler(context, Mock.Of<ILogger<Reject.Handler>>());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Approve should be made by a different user!");
            }
        }

        [TestMethod]
        public void RejectWithoutSessionShouldThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToApprove = 3;
                // Arrange
                PrepareData(context, true);
                Reject.Command command = new Reject.Command()
                {
                    UserKey = SameUser,
                    GroupId = groupToApprove,
                    SessionId = SecSession
                };
                Reject.Handler handler = new Reject.Handler(context, Mock.Of<ILogger<Reject.Handler>>());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "The session is not registred!");
            }
        }
    }
}
