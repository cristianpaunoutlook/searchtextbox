﻿using Application.Commons.Enums;
using Application.DboGroup;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;
using System.Threading;
using Enum = Application.Commons.Enums;

namespace ApplicationTests.DboGroupTests
{
    [TestClass]
    public class ApproveTests : GroupBaseTest
    {
        [TestMethod]
        public void ApproveGroupVerificationAddActivateGroup()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToApprove = 3;

                // Arrange
                PrepareData(context, true);
                Approve.Command command = new Approve.Command()
                {
                    UserKey = UserToSave,
                    GroupId = groupToApprove,
                    SessionId = SecSession
                };
                Approve.Handler handler = new Approve.Handler(context, Mock.Of<ILogger<Approve.Handler>>());

                // Act
                System.Threading.Tasks.Task<MediatR.Unit> result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Groups.Where(g =>
                            g.Id == groupToApprove &&
                            g.Status.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.NextStatus.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.LastModifiedBy == UserToSave)
                    .Count() == 1);

                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToApprove && ugr.LastModifiedBy == UserToSave).Count() == 2);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToApprove && ugr.NextRight.Value == 2 && ugr.Right.Value == 2 && ugr.PageId == 4).Count() == 1);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToApprove && ugr.NextRight.Value == 3 && ugr.Right.Value == 3 && ugr.PageId == 3).Count() == 1);
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == UserToSave && ul.ActionId == (int)UserAction.Approve && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == groupToApprove.ToString()).Count() == 1);
            }
        }

        [TestMethod]
        public void ApproveGroupVerificationModifyActivateGroup()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToApprove = 4;
                // Arrange
                PrepareData(context, true);
                Approve.Command command = new Approve.Command()
                {
                    UserKey = UserToSave,
                    GroupId = groupToApprove,
                    SessionId = SecSession
                };
                Approve.Handler handler = new Approve.Handler(context, Mock.Of<ILogger<Approve.Handler>>());

                // Act
                System.Threading.Tasks.Task<MediatR.Unit> result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Groups.Where(g =>
                            g.Id == groupToApprove &&
                            g.Status.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.NextStatus.ObjectStatusName == Enum.ObjectStatus.Active &&
                            g.LastModifiedBy == UserToSave)
                    .Count() == 1);

                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToApprove).Count() == 1);
                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.GroupId == groupToApprove && ugr.NextRight.Value == 3 && ugr.Right.Value == 3 && ugr.PageId == 3).Count() == 1);
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == UserToSave && ul.ActionId == (int)UserAction.Approve && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == groupToApprove.ToString()).Count() == 1);
            }
        }

        [TestMethod]
        public void ApproveGroupVerificationDeleteShouldDeleteGroup()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToApprove = 5;
                // Arrange
                PrepareData(context, true);
                Approve.Command command = new Approve.Command()
                {
                    UserKey = UserToSave,
                    GroupId = groupToApprove,
                    SessionId = SecSession
                };
                Approve.Handler handler = new Approve.Handler(context, Mock.Of<ILogger<Approve.Handler>>());

                // Act
                System.Threading.Tasks.Task<MediatR.Unit> result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(!context.Groups.Any(g => g.Id == groupToApprove));
                Assert.IsTrue(!context.GroupsPagesRights.Any(ugr => ugr.GroupId == groupToApprove));
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == UserToSave && ul.ActionId == (int)UserAction.Approve && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == groupToApprove.ToString()).Count() == 1);
            }
        }

        [TestMethod]
        public void ApproveForActiveGroupShouldThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {

                // Arrange
                PrepareData(context);
                Approve.Command command = new Approve.Command()
                {
                    UserKey = UserToSave,
                    GroupId = 1,
                    SessionId = SecSession
                };
                Approve.Handler handler = new Approve.Handler(context, Mock.Of<ILogger<Approve.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "You can approve groups only if status is approve add, approve modify or approve delete!");
            }
        }

        [TestMethod]
        public void ApproveForInvalidGroupThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {

                // Arrange
                PrepareData(context);
                Approve.Command command = new Approve.Command()
                {
                    UserKey = UserToSave,
                    GroupId = int.MaxValue,
                    SessionId = SecSession
                };
                Approve.Handler handler = new Approve.Handler(context, Mock.Of<ILogger<Approve.Handler>>());

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Group with specified id is not in the database!");
            }
        }

        [TestMethod]
        public void ApproveWithSameUserShouldThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToApprove = 3;
                // Arrange
                PrepareData(context);
                Approve.Command command = new Approve.Command()
                {
                    UserKey = SameUser,
                    GroupId = groupToApprove,
                    SessionId = SecSession
                };
                Approve.Handler handler = new Approve.Handler(context, Mock.Of<ILogger<Approve.Handler>>());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Approve should be made by a different user!");
            }
        }

        [TestMethod]
        public void ApproveWithoutSessionShouldThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                int groupToApprove = 3;
                // Arrange
                PrepareData(context, true);
                Approve.Command command = new Approve.Command()
                {
                    UserKey = SameUser,
                    GroupId = groupToApprove,
                    SessionId = SecSession
                };
                Approve.Handler handler = new Approve.Handler(context, Mock.Of<ILogger<Approve.Handler>>());

                // Act && Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "The session is not registred!");
            }
        }
    }
}
