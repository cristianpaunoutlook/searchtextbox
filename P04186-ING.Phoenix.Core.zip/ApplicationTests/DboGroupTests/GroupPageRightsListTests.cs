﻿using Application.Commons.Enums;
using Application.DboGroup;
using Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Persistence;
using System;
using System.Linq;
using System.Threading;
using ObjectStatus = Domain.ObjectStatus;

namespace ApplicationTests.DboGroupTests
{
    [TestClass]
    public class GroupPageRightsListTests : GroupBaseTest
    {
        [TestMethod]
        public void ShouldReturnAllPagesAndRights()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                PrepareData(context);
                var command = new RightsList.Query()
                {
                    GroupId = 1
                };
                var handler = new RightsList.Handler(context);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Count() == 4 && result.Where(gr => gr.RightValue > (int) RightsCode.NORIGHT).Count() == 1);

            }
        }

        [TestMethod]
        public void ShouldReturnAllPagesForGroupWithoutRights()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                PrepareData(context);
                var command = new RightsList.Query()
                {
                    GroupId = 6
                };
                var handler = new RightsList.Handler(context);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Count() == 4 && result.Where(gr => gr.RightValue > (int)RightsCode.NORIGHT).Count() == 0);

            }
        }
    }
}
