﻿using Application.Commons.Enums;
using Application.DboGroup;
using Application.DTO;
using Application.Errors;
using Domain;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboGroupTests
{
    [TestClass]
    public class CreateTests : GroupBaseTest
    {
        [TestMethod]
        public void SaveRightsForActiveGroup()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                string adName = "GSAPC5D_PNTF-BROWSER";
                // Arrange
                PrepareData(context, true);
                Create.Command command = new Create.Command()
                {
                    LastModifiedDate = DateTime.Now,
                    LastModifiedBy = SameUser,
                    AdName = adName,
                    Name = "Group_CD",
                    PageRight = new GroupPageRightDTO[] {
                        new GroupPageRightDTO() { NextRightValue = 3, PageId = 1 }
                    },
                    SessionId = SecSession
                };
                Create.Handler handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(context.Groups.Where(g => g.ADName == adName && g.StatusId == (int)ObjectStatusId.VerificationAdd).Count() == 1);

                Assert.IsTrue(context.GroupsPagesRights.Where(ugr => ugr.Group.ADName == adName &&
                                                                        ugr.LastModifiedBy == SameUser &&
                                                                        ugr.PageId == 1 &&
                                                                        ugr.NextRight.Value == 3 &&
                                                                        ugr.Right.Value == 0
                                                            )
                                                        .Count() == 1);
                Assert.IsTrue(context.UserLogs.Where(ul => ul.UserId == SameUser && ul.ActionId == (int)UserAction.Add && ul.ObjectId == (int)UserObject.UserGroup && ul.RecordId == context.Groups.Where(g => g.ADName == adName && g.StatusId == (int)ObjectStatusId.VerificationAdd).FirstOrDefault().Id.ToString()).Count() == 1);
            }
        }

        [TestMethod]
        public void AddGroupWirhoutPatternShouldThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                string adName = "WITHOUT_PATTERN";
                // Arrange
                PrepareData(context);
                Create.Command command = new Create.Command()
                {
                    LastModifiedDate = DateTime.Now,
                    LastModifiedBy = SameUser,
                    AdName = adName,
                    Name = "GROUP_CD",
                    PageRight = new GroupPageRightDTO[] {
                        new GroupPageRightDTO() { NextRightValue = 3, PageId = 1 }
                    },
                    SessionId = SecSession
                };
                Create.Handler handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject());

                // Act
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), "ADName without pattern!");
            }
        }

        [TestMethod]
        public void AddDuplicateGroupNameShouldThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                string adName = "ENV_PNTF-GROUP";
                // Arrange
                PrepareData(context);
                Create.Command command = new Create.Command()
                {
                    LastModifiedDate = DateTime.Now,
                    LastModifiedBy = SameUser,
                    AdName = adName,
                    Name = "AD_ADMIN",
                    PageRight = new GroupPageRightDTO[] {
                        new GroupPageRightDTO() { NextRightValue = 3, PageId = 1 }
                    },
                    SessionId = SecSession
                };
                Create.Handler handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject());


                // Act
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Group already exists for selected application! Please modify existing group!");
            }
        }

        [TestMethod]
        public void AddGroupWithoutRightsShouldThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                string adName = "ENV_PNTF-GROUP";
                // Arrange
                PrepareData(context);
                Create.Command command = new Create.Command()
                {
                    LastModifiedDate = DateTime.Now,
                    LastModifiedBy = SameUser,
                    AdName = adName,
                    Name = "Group_CD",
                    PageRight = new GroupPageRightDTO[] { },
                    SessionId = SecSession
                };
                Create.Handler handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject());

                // Act
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Group should have at least one right selected!");
            }
        }

        [TestMethod]
        public void AddSecAndFunctionalRightsShouldThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                string adName = "ENV_PNTF-GROUP";
                // Arrange
                PrepareData(context);
                Create.Command command = new Create.Command()
                {
                    LastModifiedDate = DateTime.Now,
                    LastModifiedBy = SameUser,
                    AdName = adName,
                    Name = "Group_CD",
                    PageRight = new GroupPageRightDTO[] {
                        new GroupPageRightDTO() { NextRightValue = 3, PageId = 1 },
                        new GroupPageRightDTO() { NextRightValue = 2, PageId = 2}
                    },
                    SessionId = SecSession
                };
                Create.Handler handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject());

                // Act
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "A group can not have rights in security module and in a functional module in the same time!");
            }
        }


        [TestMethod]
        public void AddGroupWithoutSessionThrowException()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                string adName = "ENV_PNTF-GROUP";
                // Arrange
                PrepareData(context, true);
                Create.Command command = new Create.Command()
                {
                    LastModifiedDate = DateTime.Now,
                    LastModifiedBy = SameUser,
                    AdName = adName,
                    Name = "Group_CD",
                    PageRight = new GroupPageRightDTO[] { },
                    SessionId = SecSession
                };
                Create.Handler handler = new Create.Handler(context, Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject());

                // Act
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "The session is not registred!");
            }
        }
    }
}
