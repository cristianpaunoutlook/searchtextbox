﻿using Application.Errors;
using Application.Security;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Security.Principal;
using System.Threading;

namespace ApplicationTests.Security
{
    [TestClass]
    public class UserGroupsTest : SecurityBase
    {
        public object ADUserGroups { get; private set; }

        [TestMethod]
        public void UserIsNotInAppGroupsThrowsRestExceptions()
        {

            //arange
            var query = new UserGroups.Query() { User = new GenericIdentity("username") };
            var configuration = GetConfigurationObject();
            var adUserGroups = GetAdUserGroupsObject();

            using (var context = GetDbContext())
            {
                var handler = new UserGroups.Handler(context, configuration, adUserGroups);

                //act
                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token));
            }
        }

        [TestMethod]
        public void AllUserGroupInactiveThenThrowsRestExceptions()
        {

            //arange
            var query = new UserGroups.Query() { User = new GenericIdentity("username") };
            var configuration = GetConfigurationObject();
            var adUserGroups = GetAdUserGroupsObject();

            using (var context = GetDbContext())
            {
                var handler = new UserGroups.Handler(context, configuration, adUserGroups);
                InitUserGroupRights(context);
                DisableUserGroup(context, 1);
                DisableUserGroup(context, 2);
                //act
                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token));
            }
        }

        [TestMethod]
        public void AllUserGroupRightsInactiveThenThrowsRestExceptions()
        {

            //arange
            var query = new UserGroups.Query() { User = new GenericIdentity("username") };
            var configuration = GetConfigurationObject();
            var adUserGroups = GetAdUserGroupsObject();

            using (var context = GetDbContext())
            {
                var handler = new UserGroups.Handler(context, configuration, adUserGroups);
                InitUserGroupRights(context);
                foreach (var ugr in context.UserGroupRights.ToList())
                    DisableUserGroupRight(context, ugr.RightId);
                //act
                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token));
            }
        }

        [TestMethod]
        public void UserHasRightsToAPPReturnCorrectNumber()
        {
            //arange
            var query = new UserGroups.Query() { User = new GenericIdentity("username") };
            var configuration = GetConfigurationObject();
            var adUserGroups = GetAdUserGroupsObject();

            using (var context = GetDbContext())
            {
                PrepareData(context);
                InitUserGroupRights(context);
                var handler = new UserGroups.Handler(context, configuration, adUserGroups);

                //act
                var listOfGroupRights = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(listOfGroupRights.Count == 4);
            }
        }

    }
}
