﻿using System;
using System.Collections.Generic;
using Application.Interfaces;
using Domain;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Moq;
using Persistence;

namespace ApplicationTests.Security
{
    public class SecurityBase : TestBase
    {
        protected List<string> GetAdGroups()
        {
            return new List<string> { "AD\\\\GSAPC5D_WBIF-ADMIN",
                                        "AD\\\\GSAPC5D_WBIF-AUDIT",
                                        "AD\\\\GSAPC5D_WBIF-BROWSER",
                                        "AD\\\\GSAPC5D_WBIF-CADM",
                                        "AD\\\\GSAPC5A_POPRINT-Client",
                                        "AD\\\\GSAPC5D_INGCollection"
                                    };
        }

        protected void InitUserGroupsTable(PhoenixContext context)
        {
            var userGroup = new UserGroup() { GroupId = 1, GroupName = "AD_ADMIN", ADName = "GSAPC5D_WBIF-ADMIN", StatusId = 1 };
            context.UserGroups.Add(userGroup);
            userGroup = new UserGroup() { GroupId = 2, GroupName = "AD_AUDIT", ADName = "GSAPC5D_WBIF-AUDIT", StatusId = 1 };
            context.UserGroups.Add(userGroup);
            userGroup = new UserGroup() { GroupId = 3, GroupName = "AD_BROWSER", ADName = "GSAPC5D_WBIF-BROWSER", StatusId = 1 };
            context.UserGroups.Add(userGroup);
            userGroup = new UserGroup() { GroupId = 4, GroupName = "AD_CADM", ADName = "GSAPC5D_WBIF-CADM", StatusId = 1 };
            context.UserGroups.Add(userGroup);
            userGroup = new UserGroup() { GroupId = 5, GroupName = "AD_READONLY", ADName = "GSAPC5D_WBIF-READONLY", StatusId = 1 };
            context.UserGroups.Add(userGroup);
            userGroup = new UserGroup() { GroupId = 6, GroupName = "AD_GLPDM", ADName = "GSAPC5D_WBIF-GLPDM", StatusId = 1 };
            context.UserGroups.Add(userGroup);
            userGroup = new UserGroup() { GroupId = 7, GroupName = "AD_Charges", ADName = "GSAPC5D_WBIF-Charges", StatusId = 1 };
            context.UserGroups.Add(userGroup);
            context.SaveChanges();
        }

        protected void PrepareData(PhoenixContext context)
        {
            context.Pages.Add(new Page() { Id = 1, Code = "SEC", Name = "Security" });
            context.Pages.Add(new Page() { Id = 2, Code = "PG1", Name = "Page 1" });
            context.Pages.Add(new Page() { Id = 3, Code = "PG2", Name = "Page 2" });
            context.Pages.Add(new Page() { Id = 4, Code = "PG3", Name = "Page 3" });

            context.Rights.Add(new Right() { Id = 1, Code = "NORIGHT", Description = "User has no rights", Value = 0 });
            context.Rights.Add(new Right() { Id = 2, Code = "READ", Description = "Right to read or export", Value = 1 });
            context.Rights.Add(new Right() { Id = 3, Code = "EDIT", Description = "Right to add, modify or delete an entity", Value = 2 });
            context.Rights.Add(new Right() { Id = 4, Code = "APPROVE", Description = "Right to approve or reject a change on an entity", Value = 3 });

            context.ObjectStatus.Add(new ObjectStatus() { ObjectStatusId = 0, ObjectStatusName = "Active", Visible = true });
            context.ObjectStatus.Add(new ObjectStatus() { ObjectStatusId = 4, ObjectStatusName = "VerificationAdd", Visible = true });
            context.ObjectStatus.Add(new ObjectStatus() { ObjectStatusId = 5, ObjectStatusName = "VerificationModify", Visible = true });
            context.ObjectStatus.Add(new ObjectStatus() { ObjectStatusId = 6, ObjectStatusName = "VerificationDelete", Visible = true });

            context.Groups.Add(new Group() { Id = 1, ADName = "GSAPC5D_WBIF-ADMIN", Name = "AD_ADMIN", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 0, NextStatusId = 0 });
            context.Groups.Add(new Group() { Id = 2, ADName = "GSAPC5D_WBIF-AUDIT", Name = "AD_AUDIT", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 0, NextStatusId = 0 });
            context.Groups.Add(new Group() { Id = 3, ADName = "GSAPC5D_WBIF-BROWSER", Name = "AD_BROWSER", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 4, NextStatusId = 4 });
            context.Groups.Add(new Group() { Id = 4, ADName = "GSAPC5D_WBIF-CADM", Name = "AD_CADM", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 0, NextStatusId = 5 });
            context.Groups.Add(new Group() { Id = 5, ADName = "GSAPC5D_WBIF-GLPDM", Name = "AD_GLPDM", LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now, StatusId = 0, NextStatusId = 6 });

            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 1, RightId = 4, PageId = 1, NextRightId = 4, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 2, RightId = 2, PageId = 2, NextRightId = 2, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 2, RightId = 2, PageId = 3, NextRightId = 2, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 3, RightId = 1, PageId = 3, NextRightId = 4, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 3, RightId = 1, PageId = 4, NextRightId = 3, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 4, RightId = 3, PageId = 4, NextRightId = 1, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });
            context.GroupsPagesRights.Add(new GroupPageRight() { GroupId = 4, RightId = 2, PageId = 3, NextRightId = 1, LastModifiedBy = "AABBCC", LastModifiedDate = DateTime.Now });

            context.SaveChanges();
        }

        protected void InitObjectAction(PhoenixContext context)
        {
            var objectAction = new SecObjectAction() { ActionId = 1, AllowAll = true, Description = "Edit", Name = "Edit", Visible = true };
            context.ObjectActions.Add(objectAction);
            objectAction = new SecObjectAction() { ActionId = 2, AllowAll = true, Description = "New", Name = "New", Visible = true };
            context.ObjectActions.Add(objectAction);
            objectAction = new SecObjectAction() { ActionId = 3, AllowAll = true, Description = "Aprove", Name = "Aprove", Visible = true };
            context.ObjectActions.Add(objectAction);
            objectAction = new SecObjectAction() { ActionId = 4, AllowAll = true, Description = "Print", Name = "Print", Visible = true };
            context.ObjectActions.Add(objectAction);
            objectAction = new SecObjectAction() { ActionId = 5, AllowAll = true, Description = "Delete", Name = "Delete", Visible = true };
            context.ObjectActions.Add(objectAction);
            context.SaveChanges();
        }

        protected void InitUserPage(PhoenixContext context)
        {
            var userPage = new SecUserPage() { PageId = 1, PageName = "Charges Page", Description = "Charges", Folder = "", FunctionId = 1, IsDefault = true, IsVisible = true, MenuIndex = 1 };
            context.UserPages.Add(userPage);
            userPage = new SecUserPage() { PageId = 2, PageName = "Reports Page", Description = "Reports", Folder = "", FunctionId = 1, IsDefault = true, IsVisible = true, MenuIndex = 1 };
            context.UserPages.Add(userPage);
            userPage = new SecUserPage() { PageId = 3, PageName = "Admin Page", Description = "Admin", Folder = "", FunctionId = 1, IsDefault = true, IsVisible = true, MenuIndex = 1 };
            context.UserPages.Add(userPage);
            context.SaveChanges();
        }

        protected void InitUserGroupRights(PhoenixContext context)
        {
            InitUserGroupsTable(context);
            InitUserPage(context);
            InitObjectAction(context);
            var userGroupRight = new SecUserGroupRights() { RightId = 1, GroupId = 1, StatusId = 1, PageId = 1, PageActionId = 1 };
            context.UserGroupRights.Add(userGroupRight);
            userGroupRight = new SecUserGroupRights() { RightId = 2, GroupId = 1, StatusId = 1, PageId = 1, PageActionId = 2 };
            context.UserGroupRights.Add(userGroupRight);
            userGroupRight = new SecUserGroupRights() { RightId = 3, GroupId = 1, StatusId = 1, PageId = 2, PageActionId = 4 };
            context.UserGroupRights.Add(userGroupRight);
            userGroupRight = new SecUserGroupRights() { RightId = 4, GroupId = 2, StatusId = 1, PageId = 2, PageActionId = 5 };
            context.UserGroupRights.Add(userGroupRight);
            context.SaveChanges();
        }

        protected void DisableUserGroup(PhoenixContext context, int userGroupId)
        {
            var ug = context.UserGroups.Find(userGroupId);
            ug.StatusId = 2;
            context.SaveChanges();
        }

        protected void DisableUserGroupRight(PhoenixContext context, int userGroupRightId)
        {
            var ugr = context.UserGroupRights.Find(userGroupRightId);
            ugr.StatusId = 2;
            context.SaveChanges();
        }

        protected IConfiguration GetConfigurationObject()
        {
            var configuration = new Mock<IConfiguration>();
            configuration.Setup(c => c.GetSection("UserGroupsNamePattern").Value).Returns("WBIF");
            return configuration.Object;
        }

        protected IADUserGroups GetAdUserGroupsObject()
        {
            var adUserGroups = new Mock<IADUserGroups>();
            adUserGroups.Setup(adUG => adUG.GetUserGroupsFromAD("WBIF")).Returns(GetAdGroups());
            return adUserGroups.Object;
        }

        protected IMemoryCache GetMemoryCacheObject()
        {
            var cacheEntryOptions = new MemoryCacheOptions();
            var memoryCache = new MemoryCache(cacheEntryOptions);

            return memoryCache;
        }
    }
}
