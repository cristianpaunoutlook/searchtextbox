﻿using Application.Commons.Constants;
using Application.DboCustomers;
using Application.Helpers;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;

namespace ApplicationTests.DboCustomersTests
{
    public class CustomerBaseTest : TestBase
    {

        protected const int ChargeActive = 1;
        protected const int ChargeTypeActive = 1;
        protected const int StatusActive = 0;
        protected const string invalidAccountType = "????";
        protected const long ValidAccountShort = 10000000000;

        protected void InitCustomers(PhoenixContext context)
        {
            //data source for testing customers:
            //2 accounts for the same GBS customer => 1 record returned from list method
            //1 GBS account but invalid type => not returned by list method
            //1 GBS account with 2 charges => 1 record returned from list method
            //2 accounts for the same PRF customer => 1 record returned from list method
            //1 PRF account but invalid type => not returned by list method
            //1 PRF account but invalid type id => not returned by list method
            //1 PRF account with 2 charges => 1 record returned from list method

            var statusActive = GetStatusObject(0, Application.Commons.Enums.ObjectStatus.Active);
            var statusVerificationAdd = GetStatusObject(4, Application.Commons.Enums.ObjectStatus.VerificationAdd);
            var processingFrequencyMonthly = GetProcessingFrequencyObject(4, "Monthly");

            var currency = GetCurrencyObject(1, "RON");

            var chargeTypeActive = GetChargeTypeObject(1, currency, processingFrequencyMonthly, statusActive);
            context.ChargeTypes.Add(chargeTypeActive);
            var chargeAccState = GetChargeAccountState(0, "OK");
            context.ChargeAccountStates.Add(chargeAccState);
            context.Customers.Add(GetCustomerObject(1, "1", "old comment", 0));
            context.Customers.Add(GetCustomerObject(2, "2", null, 0));
            var objectAction = GetObjectAction(10, "PCM");
            context.ObjectActions.Add(objectAction);
            //gbs account without charge
            var account = GetAccountObject(ValidAccountShort, Application.Commons.Enums.CoreBanking.GBS.ToString(), "1", Constants.GBS_ACCOUNT_TYPES_FOR_CHARGE[0], 5);
            context.Accounts.Add(account);
            //second account for customer 1 => should return only 1 customer
            var account2 = GetAccountObject(2 * ValidAccountShort, Application.Commons.Enums.CoreBanking.GBS.ToString(), "1", Constants.GBS_ACCOUNT_TYPES_FOR_CHARGE[1], 5);
            context.Accounts.Add(account2);
            //gbs account with invalid type = should not be returned from list method
            var account3 = GetAccountObject(3 * ValidAccountShort, Application.Commons.Enums.CoreBanking.GBS.ToString(), "2", invalidAccountType, 5);
            context.Accounts.Add(account3);
            //gbs account with 2 charges = returned in customer list
            var account4 = GetAccountObject(4 * ValidAccountShort, Application.Commons.Enums.CoreBanking.GBS.ToString(), "3", Constants.GBS_ACCOUNT_TYPES_FOR_CHARGE[0], 5);
            var charge1 = GetChargeObject(1, "3", chargeTypeActive, statusActive, currency, chargeAccState);
            var chargeHistory1 = GetChargeHistoryObject(1, "3", charge1, chargeTypeActive, objectAction, statusVerificationAdd, currency);
            var chargeHistory2 = GetChargeHistoryObject(2, "3", charge1, chargeTypeActive, objectAction, statusActive, currency);
            var charge2 = GetChargeObject(2, "3", chargeTypeActive, statusActive, currency, chargeAccState);
            var chargeHistory3 = GetChargeHistoryObject(3, "3", charge2, chargeTypeActive, objectAction, statusVerificationAdd, currency);
            var chargeHistory4 = GetChargeHistoryObject(4, "3", charge2, chargeTypeActive, objectAction, statusActive, currency);
            context.Accounts.Add(account4);
            context.Charges.Add(charge1);
            context.ChargesHistory.Add(chargeHistory1);
            context.ChargesHistory.Add(chargeHistory2);
            context.Charges.Add(charge2);
            context.ChargesHistory.Add(chargeHistory3);
            context.ChargesHistory.Add(chargeHistory4);

            //PRF account without charge
            var account5 = GetAccountObject(5 * ValidAccountShort, Application.Commons.Enums.CoreBanking.PRF.ToString(), "4", Constants.PRF_ACCOUNT_TYPES_FOR_CHARGE[0], Constants.DLF_ACCOUNT_TYPES_FOR_CHARGE[0]);
            context.Accounts.Add(account5);
            //second account for customer 4 => should return only 1 customer
            var account6 = GetAccountObject(6 * ValidAccountShort, Application.Commons.Enums.CoreBanking.PRF.ToString(), "4", Constants.PRF_ACCOUNT_TYPES_FOR_CHARGE[1], Constants.DLF_ACCOUNT_TYPES_FOR_CHARGE[1]);
            context.Accounts.Add(account6);
            //PRF account with invalid type = should not be returned from list method
            var account7 = GetAccountObject(7 * ValidAccountShort, Application.Commons.Enums.CoreBanking.PRF.ToString(), "5", invalidAccountType, Constants.DLF_ACCOUNT_TYPES_FOR_CHARGE[0]);
            context.Accounts.Add(account7);
            //PRF account with invalid type id = should not be returned from list method
            var account8 = GetAccountObject(8 * ValidAccountShort, Application.Commons.Enums.CoreBanking.PRF.ToString(), "8", Constants.PRF_ACCOUNT_TYPES_FOR_CHARGE[1], -1);
            context.Accounts.Add(account8);
            //PRF account with 2 charges = returned in customer list
            var account9 = GetAccountObject(9 * ValidAccountShort, Application.Commons.Enums.CoreBanking.PRF.ToString(), "9", Constants.PRF_ACCOUNT_TYPES_FOR_CHARGE[0], Constants.DLF_ACCOUNT_TYPES_FOR_CHARGE[1]);
            var charge3 = GetChargeObject(3, "9", chargeTypeActive, statusActive, currency, chargeAccState);
            var chargeHistory5 = GetChargeHistoryObject(5, "9", charge3, chargeTypeActive, objectAction, statusVerificationAdd, currency);
            var chargeHistory6 = GetChargeHistoryObject(6, "9", charge3, chargeTypeActive, objectAction, statusActive, currency);
            var charge4 = GetChargeObject(4, "9", chargeTypeActive, statusActive, currency, chargeAccState);
            var chargeHistory7 = GetChargeHistoryObject(7, "9", charge4, chargeTypeActive, objectAction, statusVerificationAdd, currency);
            var chargeHistory8 = GetChargeHistoryObject(8, "9", charge4, chargeTypeActive, objectAction, statusActive, currency);
            context.Accounts.Add(account9);
            context.Charges.Add(charge3);
            context.ChargesHistory.Add(chargeHistory5);
            context.ChargesHistory.Add(chargeHistory6);
            context.Charges.Add(charge4);
            context.ChargesHistory.Add(chargeHistory7);
            context.ChargesHistory.Add(chargeHistory8);

            //add GBS Debit Accounts parameters
            var gbsDebitAccountCurr = GetGbsDebitAccountType("CURR");
            var gbsDebitAccountloro = GetGbsDebitAccountType("LORO");
            context.GBSDebitAccountTypes.Add(gbsDebitAccountCurr);
            context.GBSDebitAccountTypes.Add(gbsDebitAccountloro);

            //ad PRF Debit Accounts paramters
            var prfDebitAccountFor4801Cif1 = GetPrfDebitAccountType(1, "4801");
            var prfDebitAccountFor4801Cif3 = GetPrfDebitAccountType(3, "4801");
            var prfDebitAccountFor4802Cif3 = GetPrfDebitAccountType(3, "4802");
            context.PRFDebitAccountTypes.Add(prfDebitAccountFor4801Cif1);
            context.PRFDebitAccountTypes.Add(prfDebitAccountFor4801Cif3);
            context.PRFDebitAccountTypes.Add(prfDebitAccountFor4802Cif3);

            context.SaveChanges();
        }

        protected CustomerParams SetCustomersParams(int pageNumber = 1, int pageSize = 15, string sortField = "", string sortOrder = "",
            string cui = "", string name = "", int chargeTypeId = -1, int statusId = -1, string custormerId = "")
        {
            return new CustomerParams
            {
                SortField = sortField,
                SortOrder = sortOrder,
                PageNumber = pageNumber,
                PageSize = pageSize,
                ChargeTypeId = chargeTypeId,
                StatusId = statusId,
                CUI = cui,
                CustomerId = custormerId,
                Name = name
            };
        }

        protected void ArrangeOnCustomersList(PhoenixContext context, CustomerParams chargeParams,
                out List.Query query, out List.Handler handler)
        {
            InitCustomers(context);

            query = new List.Query() { CustomerParams = chargeParams };
            handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>());
        }

        protected void ArrangeOnEditComments(PhoenixContext context, string customerId, string comments, out SaveComments.Command command, out SaveComments.Handler handler)
        {
            InitCustomers(context);

            command = new SaveComments.Command() { CustomerId = customerId, Comments = comments };
            handler = new SaveComments.Handler(context, Mock.Of<ILogger<SaveComments.Handler>>());
        }

    }
}
