﻿using Application.DboCustomers;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ApplicationTests.DboCustomersTests
{
    [TestClass]
    public class EditCommentsTests : CustomerBaseTest
    {
        [DataRow("1")]
        [DataRow("2")]
        [DataTestMethod]
        public void UpdateCustomerComments(string customerId)
        {
            using(var context = GetDbContext())
            {
                //arange
                var newComment = "comment to save for test";
                ArrangeOnEditComments(context, customerId, newComment, out SaveComments.Command command, out SaveComments.Handler handler);

                //Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Customers.Any(ct => ct.AtlasID == customerId && ct.Comments == newComment));
            }
        }

        [TestMethod]
        public void TryUpdateCommentsForInexistingCustShouldInsertCustomer()
        {
            using (var context = GetDbContext())
            {
                //arange
                var NoClientId = "999";
                var newComment = "comment to save for test";
                ArrangeOnEditComments(context, NoClientId, newComment, out SaveComments.Command command, out SaveComments.Handler handler);

                //Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.Customers.Any(ct => ct.AtlasID == NoClientId && ct.Comments == newComment));
            }
        }
    }
}
