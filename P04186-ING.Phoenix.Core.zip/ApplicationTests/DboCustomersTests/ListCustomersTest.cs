﻿using Application.DboCustomers;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboCustomersTests
{
    [TestClass]
    public class ListCustomersTest : CustomerBaseTest
    {
        [TestMethod]
        public void ShouldReturnAllCustomersFromDb()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams();

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 4);
            }
        }

        [TestMethod]
        public void ShouldReturnPaginatedAccountsList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(pageNumber: 1, pageSize: 2);

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);
                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 2 &&
                    customersList.Items.Any(c => c.Name == "Name1") &&
                    customersList.Items.Any(c => c.Name == "Name3"));
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(pageNumber: 1, pageSize: 100);

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;


                //assert
                Assert.IsTrue(customersList.PageSize == 50 && customersList.Items.Count == 4);
            }
        }

        [TestMethod]
        public void ShouldThrowErrorIfListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(pageNumber: 20, pageSize: 2);

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                  "There are no records corresponding to your search!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(pageNumber: 0, pageSize: 2);

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.CurrentPage == 1
                    && customersList.Items.Count == 2
                    && customersList.Items.Any(c => c.Name == "Name1"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredCustomersListContainingName()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(name: "Name1");

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 1 && customersList.Items.Any(c => c.Name == "Name1"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredCustomersListContainingCUI()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(cui: "9999993");

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 1 && customersList.Items.Any(c => c.Name == "Name3"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredCustomersListContainingCUIWitSpace()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(cui: "9999993 ");

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 1 && customersList.Items.Any(c => c.Name == "Name3"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredCustomersListContainingId()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(custormerId: "3");

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 1 && customersList.Items.Any(c => c.Name == "Name3"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredCustomersListContainingIdWithSpace()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(custormerId: "3 ");

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 1 && customersList.Items.Any(c => c.Name == "Name3"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredCustomersListByStatusId()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(statusId: StatusActive);

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 2
                        && customersList.Items.Any(c => c.Name == "Name3")
                        && customersList.Items.Any(c => c.Name == "Name9"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredCustomersListContainingChargeType()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(chargeTypeId: ChargeTypeActive);

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 2);
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredCustomersListWithManyFilters()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(chargeTypeId: ChargeTypeActive, cui: "9999993", name: "Name",
                    pageNumber: 1, pageSize: 2);

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 1 &&
                    customersList.Items.Any(c => c.Name.Contains("Name")) &&
                    customersList.Items.Any(c => c.CUI == "9999993"));
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredCustomersListWithManyFiltersWithSpace()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(chargeTypeId: ChargeTypeActive, cui: "9999993 ", name: "Name ",
                    pageNumber: 1, pageSize: 2);

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //act
                var customersList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customersList.Items.Count == 1 &&
                    customersList.Items.Any(c => c.Name.Contains("Name")) &&
                    customersList.Items.Any(c => c.CUI == "9999993"));
            }
        }

        [TestMethod]
        public void ShouldThrowErrorIfCustomersListIfFiltersDontMatch()
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(chargeTypeId: 99, cui: "1111111");

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                  "There are no records corresponding to your search!");
            }
        }

        [DataRow("2")]
        [DataRow("5")]
        [DataRow("6")]
        [DataTestMethod]
        public void ShouldThrowErrorIfCustomersListIfInvalidTypeAccount(string customerId)
        {
            using (var context = GetDbContext())
            {
                //arange
                var custParams = SetCustomersParams(custormerId: customerId);

                ArrangeOnCustomersList(context, custParams, out List.Query query, out List.Handler handler);

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                  "There are no records corresponding to your search!");
            }
        }
    }
}
