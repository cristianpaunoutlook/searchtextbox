﻿using Application.DboChargeType;
using Application.Helpers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using Application.DTO;
using Application.Commons.Enums;
using Application.Errors;
using System.Threading;

namespace ApplicationTests.DboChargeTypeTests
{
    [TestClass]
    public class ListChargeTypeTest : ChargeTypeBase
    {
        [TestMethod]
        public void ShouldReturnAllChargeTypesFromDb()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams();

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //act
                ActOnChargeTypeList(query, handler, out PagedList<ChargeTypeListDTO> chargeTypeList);

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 5 &&
                    !chargeTypeList.Items.Any(c => c.StatusName != ObjectStatus.Active && c.StatusName != ObjectStatus.VerificationAdd));
            }
        }

        [TestMethod]
        public void ShouldReturnPaginatedChargeTypeList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);
                //act
                ActOnChargeTypeList(query, handler, out PagedList<ChargeTypeListDTO> chargeTypeList);

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 2 &&
                    chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC4") &&
                    chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC5"));
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(pageNumber: 1, pageSize: 100);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //act
                ActOnChargeTypeList(query, handler, out PagedList<ChargeTypeListDTO> chargeTypeList);

                //assert
                Assert.IsTrue(chargeTypeList.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldThrowErrorIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(pageNumber: 20, pageSize: 2);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                  "There are no records corresponding to your search!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(pageNumber: 0, pageSize: 2);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //act
                ActOnChargeTypeList(query, handler, out PagedList<ChargeTypeListDTO> chargeTypeList);

                //assert
                Assert.IsTrue(chargeTypeList.CurrentPage == 1
                    && chargeTypeList.Items.Count == 2
                    && chargeTypeList.Items.Any(c => c.ChargeTypeCode == "ABC5"));
            }
        }

        [TestMethod]
        public void ShouldReturnAscSortedChargeTypeList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(sortField: "chargeTypeCode", sortOrder: "asc", pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //act
                ActOnChargeTypeList(query, handler, out PagedList<ChargeTypeListDTO> chargeTypeList);

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 2
                    && chargeTypeList.Items.Select(c => c.ChargeTypeCode).FirstOrDefault() == "ABC2");
            }
        }

        [TestMethod]
        public void ShouldReturnDescSortedChargeTypeList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(sortField: "paymentDetail", sortOrder: "desc", pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //act
                ActOnChargeTypeList(query, handler, out PagedList<ChargeTypeListDTO> chargeTypeList);

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 2
                    && chargeTypeList.Items.Select(c => c.PaymentDetail).FirstOrDefault() == "Payment Detail 8");
            }
        }

        [TestMethod]
        public void ShouldReturnChargeTypeSortedByChargeTypehistoryStatusIdWhenNoSortingProvided()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //act
                ActOnChargeTypeList(query, handler, out PagedList<ChargeTypeListDTO> chargeTypeList);

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 2
                    && chargeTypeList.Items.Select(c => c.ChargeTypeCode).FirstOrDefault() == "ABC5");
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredChargeTypeListContainingChargeTypeCode()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(chargeTypeCode: "ABC5", pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //act
                ActOnChargeTypeList(query, handler, out PagedList<ChargeTypeListDTO> chargeTypeList);

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 1 &&
                    chargeTypeList.Items.Where(c => c.ChargeTypeCode.Contains("ABC5")).Count() == 1);
            }
        }

        [TestMethod]
        public void ShouldReturnFilteredChargeTypeListWithManyFilters()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(frequencyId: 1, chargeTypeCode: "ABC", chargeTypeDescription: "Test3",
                    pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //act
                ActOnChargeTypeList(query, handler, out PagedList<ChargeTypeListDTO> chargeTypeList);

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 1 &&
                    chargeTypeList.Items.Any(c => c.ChargeTypeCode.Contains("ABC")) &&
                    chargeTypeList.Items.Any(c => c.ChargeTypeDescription.Contains("Test3")));
            }
        }

        [TestMethod]
        public void ShouldThrowErrorIfNoRecordFound()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(frequencyId: 2, statusId: 8, chargeTypeCode: "AMF", chargeTypeDescription: "test",
                    pageNumber: 1, pageSize: 10);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                  "There are no records corresponding to your search!");
            }
        }

        [TestMethod]
        public void ShouldReturnPaginatedFilteredSortedChargeTypeList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var chargeTypeParams = SetChargeTypeParams(frequencyId: 1, sortField: "paymentDetail", sortOrder: "desc", chargeTypeCode: "ABC", chargeTypeDescription: "Test4",
                    pageNumber: 1, pageSize: 2);

                ArrangeOnChargeTypeList(context, chargeTypeParams, out List.Query query, out List.Handler handler);

                //act
                ActOnChargeTypeList(query, handler, out PagedList<ChargeTypeListDTO> chargeTypeList);

                //assert
                Assert.IsTrue(chargeTypeList.Items.Count == 1 && chargeTypeList.CurrentPage == 1 &&
                    chargeTypeList.Items.Select(c => c.ChargeTypeCode).FirstOrDefault() == "ABC4" &&
                    chargeTypeList.Items.Select(c => c.ChargeTypeDescription).FirstOrDefault() == "Test4");
            }
        }
    }
}
