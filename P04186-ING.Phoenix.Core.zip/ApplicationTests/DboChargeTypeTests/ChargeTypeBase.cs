﻿using Application.Commons.Enums;
using Application.DboChargeType;
using Application.DTO;
using Application.Helpers;
using Application.Interfaces;
using Domain;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboChargeTypeTests
{
    public class ChargeTypeBase : TestBase
    {
        protected const int ChargeTypeActive = 2;
        protected const int ChargeTypeNotActive = 4;
        protected const int ChargeTypeNotValid = 10;
        protected const int ChargeTypeWithoutCTH = 7;
        protected const int ChargeTypeActiveQuarterly = 8;
        protected const long ValidAccountShort = 10000000000;

        protected void InitChargeTypeAndHistoryTables(PhoenixContext context)
        {
            var standarGroupCT = new Domain.ChargeTypeGroup() { Id = 1, Code = "DEFAULT"};
            context.ChargeTypeGroups.Add(standarGroupCT);
            var fcomGroupCT = new Domain.ChargeTypeGroup() { Id = 2, Code = "FCOM"};
            context.ChargeTypeGroups.Add(fcomGroupCT);
            var statusActive = GetStatusObject(0, Application.Commons.Enums.ObjectStatus.Active);
            var statusVerificationAdd = GetStatusObject(4, Application.Commons.Enums.ObjectStatus.VerificationAdd);
            var statusVerificationModify = GetStatusObject(5, Application.Commons.Enums.ObjectStatus.VerificationModify);
            var statusVerificationDelete = GetStatusObject(6, Application.Commons.Enums.ObjectStatus.VerificationDelete);
            var statusDeleted = GetStatusObject(1, Application.Commons.Enums.ObjectStatus.Deleted);
            var statusRejectAdd = GetStatusObject(7, Application.Commons.Enums.ObjectStatus.RejectAdd);
            var gbsCreditAccountType = GetGBSCreditAccountType("ACPA");
            context.GBSCreditAccountTypes.Add(gbsCreditAccountType);
            var creditAccountGBS = GetAccountObject(ValidAccountShort, "GBS", "ABCDEF", "ACPA", 1);
            context.Accounts.Add(creditAccountGBS);
            var creditAccountforLeadingZeros = GetAccountObject(131310, "GBS", "ABCDEF", "ACPA", 1);
            context.Accounts.Add(creditAccountforLeadingZeros);


            var processingFrequencyMonthly = GetProcessingFrequencyObject((int)Application.Commons.Enums.ProcessingFrequency.Monthly, "Monthly");
            var processingFrequencyOnce = GetProcessingFrequencyObject((int)Application.Commons.Enums.ProcessingFrequency.Once, "Once");
            var processingFrequencyQuarterly = GetProcessingFrequencyObject((int)Application.Commons.Enums.ProcessingFrequency.Quarterly, "Quarterly");

            var nonWorkingDay1 = GetNonWorkingDaysObject(new DateTime(2020, (int)Month.December, 1), "National Day");
            var nonWorkingDay2 = GetNonWorkingDaysObject(new DateTime(2020, (int)Month.December, 25), "Christmas Day");
            var nonWorkingDay3 = GetNonWorkingDaysObject(new DateTime(2020, (int)Month.August, 15), "Assumption Day");

            context.NonWorkingDays.Add(nonWorkingDay1);
            context.NonWorkingDays.Add(nonWorkingDay2);
            context.NonWorkingDays.Add(nonWorkingDay3);

            var currency = GetCurrencyObject(1, "RON");

            var objectAction = GetObjectAction(10, "PCM");
            context.ObjectActions.Add(objectAction);

            //add CT & CTH both deleted in order to test that they are not displayed in the list
            var chargeTypeDeleted = GetChargeTypeObject(1, currency, processingFrequencyOnce, statusDeleted);
            context.ChargeTypes.Add(chargeTypeDeleted);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(1, currency, processingFrequencyOnce, objectAction, statusDeleted, chargeTypeDeleted));

            // add CT & CTH both actives in order to test edit & delete
            var chargeTypeActive = GetChargeTypeObject(2, currency, processingFrequencyMonthly, statusActive);
            context.ChargeTypes.Add(chargeTypeActive);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(2, currency, processingFrequencyMonthly, objectAction, statusActive, chargeTypeActive));

            // add CT & CTH in VerificationAdd status in order to test approve / reject 
            var chargeTypeVerificationAdd = GetChargeTypeObject(3, currency, processingFrequencyOnce, statusVerificationAdd);
            context.ChargeTypes.Add(chargeTypeVerificationAdd);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(3, currency, processingFrequencyOnce, objectAction, statusVerificationAdd, chargeTypeVerificationAdd));

            //add active CT & verificationModify in CTH in order to test approve / reject
            var chargeTypeActiveModified = GetChargeTypeObject(4, currency, processingFrequencyOnce, statusActive);
            context.ChargeTypes.Add(chargeTypeActiveModified);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(4, currency, processingFrequencyOnce, objectAction, statusVerificationModify, chargeTypeActiveModified));

            //add active CT & VerificationDelete in CTH in order to test approve / reject 
            var chargeTypeActiveDeleted = GetChargeTypeObject(5, currency, processingFrequencyOnce, statusActive);
            context.ChargeTypes.Add(chargeTypeActiveDeleted);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(5, currency, processingFrequencyOnce, objectAction, statusVerificationDelete, chargeTypeActiveDeleted));

            // add rejectAdd CT & CTH in order to test that they are not displayed in the list
            var chargeTypeRejectAdd = GetChargeTypeObject(6, currency, processingFrequencyOnce, statusRejectAdd);
            context.ChargeTypes.Add(chargeTypeRejectAdd);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(6, currency, processingFrequencyOnce, objectAction, statusRejectAdd, chargeTypeRejectAdd));

            //add CT which does not have associated CTH to test that it throws exception
            var chargeTypeWithoutCTH = GetChargeTypeObject(7, currency, processingFrequencyOnce, statusRejectAdd);
            context.ChargeTypes.Add(chargeTypeWithoutCTH);

            // add CT & CTH both actives in order to test edit & delete
            var chargeTypeActiveQuarterly = GetChargeTypeObject(8, currency, processingFrequencyQuarterly, statusActive);
            context.ChargeTypes.Add(chargeTypeActiveQuarterly);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(7, currency, processingFrequencyQuarterly, objectAction, statusActive, chargeTypeActiveQuarterly));

            context.SaveChanges();
        }

        protected static void AsertOnReject(ChargeType chargeType, Reject.Command command,
                List<ChargeTypeHistory> chargeTypeHistory, string chargeStatus)
        {
            Assert.IsNotNull(chargeType, "Charge type should still exist after reject");
            Assert.IsTrue(chargeType.Status.ObjectStatusName == chargeStatus && chargeType.RejectReason == command.RejectReason,
                                $"Charge type should have status ${chargeStatus} after reject!");
            Assert.IsNotNull(chargeTypeHistory.Count == 2, "After reject we should have 2 lines in history table!");
            Assert.IsTrue(chargeTypeHistory[0].Status.ObjectStatusName == chargeStatus && chargeTypeHistory[0].RejectReason == command.RejectReason,
                                $"Charge type history should have status ${chargeStatus} after reject!");
        }

        protected static void ActOnReject(PhoenixContext context, Reject.Command command, Reject.Handler handler,
                out ChargeType chargeType, out List<ChargeTypeHistory> chargeTypeHistory)
        {
            var rejectResult = handler.Handle(command, (new CancellationTokenSource()).Token).Result;
            chargeType = context.ChargeTypes.Where(ct => ct.ChargeTypeCode == command.ChargeTypeCode).FirstOrDefault();
            chargeTypeHistory = context.ChargeTypeHistories
                .Where(cth => cth.ChargeTypeCode == command.ChargeTypeCode)
                .OrderByDescending(cth => cth.ChargeTypeHistoryId)
                .ToList();
        }

        protected void ArrangeOnReject(PhoenixContext context, string userKey,
                                    string chargeTypeCD, out Reject.Command command, out Reject.Handler handler)
        {
            InitChargeTypeAndHistoryTables(context);

            command = new Reject.Command() { ChargeTypeCode = chargeTypeCD, UserKey = userKey, RejectReason = "Reject reason for ct!" };
            handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());
        }

        protected static void AsertOnApprove(ChargeType chargeType, List<ChargeTypeHistory> chargeTypeHistory, string chargeStatus)
        {
            Assert.IsTrue(chargeType.Status.ObjectStatusName == chargeStatus,
                                $"Charge type should have status ${chargeStatus} after approve!");
            Assert.IsNotNull(chargeTypeHistory.Count == 2, "After approve we should have 2 lines in history table!");
        }

        protected static void ActOnApprove(PhoenixContext context, Approve.Command command, Approve.Handler handler,
                out ChargeType chargeType, out List<ChargeTypeHistory> chargeTypeHistory)
        {
            var approveResult = handler.Handle(command, (new CancellationTokenSource()).Token).Result;
            chargeType = context.ChargeTypes.Where(ct => ct.ChargeTypeCode == command.ChargeTypeCode).FirstOrDefault();
            chargeTypeHistory = context.ChargeTypeHistories
                .Where(cth => cth.ChargeTypeCode == command.ChargeTypeCode)
                .OrderByDescending(cth => cth.ChargeTypeHistoryId)
                .ToList();
        }

        protected void ArrangeOnApprove(PhoenixContext context, string userKey,
                                    string chargeTypeCD, out Approve.Command command, out Approve.Handler handler)
        {
            InitChargeTypeAndHistoryTables(context);

            command = new Approve.Command() { ChargeTypeCode = chargeTypeCD, UserKey = userKey };
            handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());
        }

        protected void ArrangeOnChargeTypeList(PhoenixContext context, ChargeTypeParams chargeTypeParams,
                out List.Query query, out List.Handler handler)
        {
            InitChargeTypeAndHistoryTables(context);

            query = new List.Query() { ChargeTypeParams = chargeTypeParams };
            handler = new List.Handler(context, GetMapper(), Mock.Of<ILogger<List.Handler>>());
        }

        protected static void ActOnChargeTypeList(List.Query query, List.Handler handler, out PagedList<ChargeTypeListDTO> chargeType)
        {
            chargeType = handler.Handle(query, (new CancellationTokenSource()).Token).Result;
        }

        protected void ArrangeOnChargeTypeCreate(PhoenixContext context, string chargeTypeCode, long? creditAccountShort, out Create.Command command, 
                out Create.Handler handler, int frequencyId = 3, byte? runDay = 3, DateTime? currentDate = null)
        {
            InitChargeTypeAndHistoryTables(context);

            command = new Create.Command()
            {
                ChargeTypeCode = chargeTypeCode,
                ChargeTypeDescription = $"Charge Type Description {chargeTypeCode}",
                PaymentDetails = $"Payment Details {chargeTypeCode}",
                CreditAccountShort = creditAccountShort,
                CurrId = 1,
                FrequencyId = frequencyId,
                Amount_Unit = 100,
                Amount_Product = 150,
                RunDay = runDay,
                CurrentDate = currentDate ?? DateTime.Now
            };

            handler = new Create.Handler(context, GetMapper(), Mock.Of<ILogger<Create.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());
        }

        protected static void ActOnChargeTypeCreate(Create.Command command, Create.Handler handler)
        {
            var result = handler.Handle(command, (new CancellationTokenSource()).Token);
        }

        protected void ArrangeOnChargeTypeEdit(PhoenixContext context, int chargeTypeId, int frequencyId, long? creditAccountShort, out Edit.Command command, out Edit.Handler handler, byte? runDay = null, DateTime? currentDate = null)
        {
            InitChargeTypeAndHistoryTables(context);

            command = new Edit.Command()
            {
                ChargeTypeCode = $"ABC{chargeTypeId}",
                ChargeTypeId = chargeTypeId,
                ChargeTypeDescription = $"Charge Type Description {chargeTypeId}",
                PaymentDetails = $"Edited Details {chargeTypeId}",
                CreditAccountShort = creditAccountShort,
                CurrId = 1,
                Amount_Unit = 40,
                Amount_Product = 50,
                FrequencyId = frequencyId,
                RunDay = runDay,
                LastModifiedBy = "UO04XR",
                LastModifiedDate = DateTime.Now,
                CurrentDate = currentDate ?? DateTime.Now
            };

            handler = new Edit.Handler(context, GetMapper(), Mock.Of<ILogger<Edit.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());
        }

        protected void ActOnChargeTypeEdit(Edit.Command command, Edit.Handler handler)
        {
            var result = handler.Handle(command, (new CancellationTokenSource()).Token);
        }

        protected void ArrangeOnChargeTypeDelete(PhoenixContext context, int chargeTypeId, out Delete.Command command, out Delete.Handler handler)
        {
            InitChargeTypeAndHistoryTables(context);

            command = new Delete.Command()
            {
                ChargeTypeId = chargeTypeId,
            };

            handler = new Delete.Handler(context, GetMapper(), Mock.Of<ILogger<Delete.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());
        }

        protected void ActOnChargeTypeDelete(Delete.Command command, Delete.Handler handler)
        {
            var result = handler.Handle(command, (new CancellationTokenSource()).Token);
        }

        protected ChargeTypeParams SetChargeTypeParams(int? frequencyId = -1, int? statusId = -1, string sortField = "", string sortOrder = "",
            string chargeTypeCode = "", string chargeTypeDescription = "", int pageNumber = 1, int pageSize = 15)
        {
            return new ChargeTypeParams
            {
                SortField = sortField,
                SortOrder = sortOrder,
                ChargeTypeCode = chargeTypeCode,
                ChargeTypeDescription = chargeTypeDescription,
                FrequencyId = frequencyId,
                StatusId = statusId,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }

        protected IEmailSender GetEmailSenderObject()
        {
            var mockEmailSender = new Mock<IEmailSender>();
            mockEmailSender.Setup(x => x.SendEmailAsync(It.IsAny<string[]>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<byte[]>()));
            return mockEmailSender.Object;
        }

        protected IConfiguration GetConfigurationObject()
        {
            var configuration = new Mock<IConfiguration>();
            configuration.Setup(c => c.GetSection("PhoenixChargeTypeUrl").Value).Returns("https://phoenixURL");
            configuration.Setup(c => c.GetSection("ChargeManagementNotification").Value).Returns("testemailsmtp@ing.com");
            return configuration.Object;
        }
    }
}
