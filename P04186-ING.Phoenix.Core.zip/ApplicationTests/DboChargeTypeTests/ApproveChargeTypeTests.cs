﻿using Application.DboChargeType;
using Application.Errors;
using Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Threading;

namespace ApplicationTests.DboChargeTypeTests
{
    [TestClass]
    public class ApproveChargeTypeTests : ChargeTypeBase
    {
        [DataRow("KK70XR", "ABC3", "Active")]
        [DataRow("KK70XR", "ABC4", "Active")]
        [DataRow("KK70XR", "ABC5", "Deleted")]
        [DataTestMethod]
        public void ApproveVerificationAddDeleteAndModify(string userKey, string chargeTypeCode, string status)
        {
            using(var context = GetDbContext())
            {
                //arrange
                Approve.Command command;
                Approve.Handler handler;
                ChargeType chargeType;
                List<ChargeTypeHistory> chargeTypeHistory;

                ArrangeOnApprove(context, userKey, chargeTypeCode, out command, out handler);

                //act
                ActOnApprove(context, command, handler, out chargeType, out chargeTypeHistory);

                //assert
                AsertOnApprove(chargeType, chargeTypeHistory, status);
            }
        }

        [DataRow("KK70XR", "ABC5", "A charge type in active status cannot be approved!")]
        [DataRow("CP28XQ", "ABC4", "A charge type cannot be approved by the same user who propesed the change!")]
        [DataTestMethod]
        public void ApproveChargeTypeActiveOrSameUserShouldThrowException(string userKey, string chargeTypeCode, string errorMsg)
        {
            using (var context = GetDbContext())
            {
                //arrange
                Approve.Command command;
                Approve.Handler handler;

                ArrangeOnApprove(context, userKey, chargeTypeCode, out command, out handler);

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), errorMsg);
            }
        }
    }
}
