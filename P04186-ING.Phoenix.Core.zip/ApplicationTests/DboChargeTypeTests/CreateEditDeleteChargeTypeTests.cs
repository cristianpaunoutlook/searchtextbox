﻿using Application.Commons.Enums;
using Application.DboChargeType;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboChargeTypeTests
{
    [TestClass]
    public class CreateEditDeleteChargeTypeTests : ChargeTypeBase
    {
        #region Create
        [TestMethod]
        public void ShouldAddChargeType()
        {
            using (var context = GetDbContext())
            {
                //arange
                ArrangeOnChargeTypeCreate(context, "test3", ValidAccountShort, out Create.Command command, out Create.Handler handler);

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Any(ct => ct.ChargeTypeCode == "test3" &&
                    ct.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
                Assert.IsTrue(context.ChargeTypeHistories.Any(cth => cth.ChargeTypeCode == "test3" &&
                    cth.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
            }
        }

        [TestMethod]
        public void ShouldAddChargeTypeOnceWithNullRunDate()
        {
            using (var context = GetDbContext())
            {
                //arange
                ArrangeOnChargeTypeCreate(context, "test3", ValidAccountShort, out Create.Command command, out Create.Handler handler, (int)ProcessingFrequency.Once);

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Any(ct => ct.ChargeTypeCode == "test3" &&
                    ct.RunDay == null &&
                    ct.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
                Assert.IsTrue(context.ChargeTypeHistories.Any(cth => cth.ChargeTypeCode == "test3" &&
                    cth.RunDay == null &&
                    cth.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
            }
        }

        [TestMethod]
        public void ShouldAddChargeTypeQuarterlyWithFirstDayRunDate()
        {
            using (var context = GetDbContext())
            {
                //arange
                ArrangeOnChargeTypeCreate(context, "test3", ValidAccountShort, out Create.Command command, out Create.Handler handler, (int)ProcessingFrequency.Quarterly);

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Any(ct => ct.ChargeTypeCode == "test3" &&
                    ct.RunDay == 1 &&
                    ct.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
                Assert.IsTrue(context.ChargeTypeHistories.Any(cth => cth.ChargeTypeCode == "test3" &&
                    cth.RunDay == 1 &&
                    cth.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
            }
        }

        [TestMethod]
        public void ShouldNotAddDuplicateChargeType()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeTypeCreate(context, "ABC1", ValidAccountShort, out Create.Command command, out Create.Handler handler);

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot add duplicate charge type code!");
            }
        }

        [TestMethod]
        public void AddChargeTypeWithSameCodeOnRejectAddThrowsException()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeTypeCreate(context, "ABC7", ValidAccountShort, out Create.Command command, out Create.Handler handler);

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot add duplicate charge type code!");
            }
        }

        [TestMethod]
        public void ShouldNotAddMonthlyChargeTypeWithoutRunDay()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeTypeCreate(context, "MNRD", ValidAccountShort, out Create.Command command, out Create.Handler handler, (int)ProcessingFrequency.Monthly, null);

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot add montly charge type code without run day!");
            }
        }

        [TestMethod]
        public void ShouldHaveNullNextRunDayForFrequencyOnce()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeTypeCreate(context, "CT01", ValidAccountShort, out Create.Command command, out Create.Handler handler, (int)ProcessingFrequency.Once);

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Where(ct => ct.ChargeTypeCode == "CT01").Select(ct => ct.NextRunDay).FirstOrDefault() == null);
            }
        }

        [TestMethod]
        public void ShouldHaveCorrectNextRunDayForFrequencyMonthlyAndRunDayZero()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeTypeCreate(context, "CT01", ValidAccountShort, out Create.Command command, out Create.Handler handler, (int)ProcessingFrequency.Monthly,
                    0, new DateTime(2020, (int)Month.July, 28));

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Where(ct => ct.ChargeTypeCode == "CT01")
                                                 .Select(ct => ct.NextRunDay)
                                                 .FirstOrDefault() == new DateTime(2020, (int)Month.August, 31));
            }
        }

        [TestMethod]
        public void ShouldHaveCorrectNextRunDayForFrequencyMonthlyAndRunDayOtherThanZero()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeTypeCreate(context, "CT01", ValidAccountShort, out Create.Command command, out Create.Handler handler, (int)ProcessingFrequency.Monthly,
                    6, new DateTime(2020, (int)Month.July, 28));

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Where(ct => ct.ChargeTypeCode == "CT01")
                                                 .Select(ct => ct.NextRunDay)
                                                 .FirstOrDefault() == new DateTime(2020, (int)Month.August, 10));
            }
        }

        [TestMethod]
        public void ShouldHaveCorrectNextRunDayForFrequencyQuarterlyAndFirstQuarter()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeTypeCreate(context, "CT01", ValidAccountShort, out Create.Command command, out Create.Handler handler, (int)ProcessingFrequency.Quarterly,
                    0, new DateTime(2020, (int)Month.February, 18));

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Where(ct => ct.ChargeTypeCode == "CT01")
                                                 .Select(ct => ct.NextRunDay)
                                                 .FirstOrDefault() == new DateTime(2020, (int)Month.April, 1));
            }
        }

        [TestMethod]
        public void ShouldHaveCorrectNextRunDayForFrequencyQuarterlyAndSecondQuarter()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeTypeCreate(context, "CT01", ValidAccountShort, out Create.Command command, out Create.Handler handler, (int)ProcessingFrequency.Quarterly,
                    0, new DateTime(2020, (int)Month.July, 18));

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Where(ct => ct.ChargeTypeCode == "CT01")
                                                 .Select(ct => ct.NextRunDay)
                                                 .FirstOrDefault() == new DateTime(2020, (int)Month.August, 3));
            }
        }

        [TestMethod]
        public void ShouldHaveCorrectNextRunDayForFrequencyQuarterlyAndThirdQuarter()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeTypeCreate(context, "CT01", ValidAccountShort, out Create.Command command, out Create.Handler handler, (int)ProcessingFrequency.Quarterly,
                    0, new DateTime(2020, (int)Month.October, 18));

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Where(ct => ct.ChargeTypeCode == "CT01")
                                                 .Select(ct => ct.NextRunDay)
                                                 .FirstOrDefault() == new DateTime(2020, (int)Month.December, 2));
            }
        }

        [TestMethod]
        public void ShouldHaveCorrectNextRunDayForFrequencyQuarterlyAndFourthQuarter()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeTypeCreate(context, "CT01", ValidAccountShort, out Create.Command command, out Create.Handler handler, (int)ProcessingFrequency.Quarterly,
                    0, new DateTime(2020, (int)Month.December, 18));

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Where(ct => ct.ChargeTypeCode == "CT01")
                                                 .Select(ct => ct.NextRunDay)
                                                 .FirstOrDefault() == new DateTime(2021, (int)Month.April, 1));
            }
        }

        [TestMethod]
        public void ShouldRemoveLeadingZerosFromCreditAccountShort()
        {
            using (var context = GetDbContext())
            {
                //arange
                ArrangeOnChargeTypeCreate(context, "test3", 0000131310, out Create.Command command, out Create.Handler handler);

                //Act
                ActOnChargeTypeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Any(ct => ct.ChargeTypeCode == "test3" &&
                   ct.CreditAccountShort == 131310 && ct.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
                Assert.IsTrue(context.ChargeTypeHistories.Any(cth => cth.ChargeTypeCode == "test3" &&
                cth.CreditAccountShort == 131310 && cth.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
            }
        }
        #endregion Create


        #region Edit
        [TestMethod]
        public void EditedChargeTypeShouldBePersistedInDb()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeEdit(context, ChargeTypeActive, (int)ProcessingFrequency.Once, ValidAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Act
                ActOnChargeTypeEdit(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Any(ct => ct.ChargeTypeCode == "ABC2" &&
                                                            ct.ChargeTypeDescription == "Test2" &&
                                                            ct.PaymentDetail == "Payment Detail 2" &&
                                                            ct.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargeTypeHistories.Any(cth => cth.ChargeTypeCode == "ABC2" &&
                                                                     cth.ChargeTypeDescription == "Charge Type Description 2" &&
                                                                     cth.PaymentDetail == "Edited Details 2" &&
                                                                     cth.Status.ObjectStatusName == ObjectStatus.VerificationModify));
            }
        }

        [TestMethod]
        public void EditNotActiveChargeTypeThrowsException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeEdit(context, ChargeTypeNotActive, (int)ProcessingFrequency.Once, ValidAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Act
                ActOnChargeTypeEdit(command, handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot edit a charge type that is not active!");
            }
        }

        [TestMethod]
        public void EditNotValidChargeTypeThrowsException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeEdit(context, ChargeTypeNotValid, (int)ProcessingFrequency.Once, ValidAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Act
                ActOnChargeTypeEdit(command, handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot edit a charge type that does not exist in the database!");
            }
        }

        [TestMethod]
        public void EditChargeTypeWithoutAssociatedChargeTypeHistoryThrowsException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeEdit(context, ChargeTypeWithoutCTH, (int)ProcessingFrequency.Once, ValidAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Act
                ActOnChargeTypeEdit(command, handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot edit a charge type that does not have asssociated charge type history!");
            }
        }

        [TestMethod]
        public void EditChargeTypeThatIsNotDirtyDoesNotSaveVerificationModifyStateInCTH()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitChargeTypeAndHistoryTables(context);

                var chargeType = context.ChargeTypes.Where(c => c.ChargeTypeCode == "ABC2").FirstOrDefault();

                var command = new Edit.Command()
                {
                    ChargeTypeCode = chargeType.ChargeTypeCode,
                    ChargeTypeId = chargeType.ChargeTypeId,
                    ChargeTypeDescription = chargeType.ChargeTypeDescription,
                    PaymentDetails = chargeType.PaymentDetail,
                    CreditAccountShort = chargeType.CreditAccountShort,
                    CurrId = chargeType.CurrId,
                    Amount_Unit = chargeType.DefaultAmount,
                    Amount_Product = chargeType.AmountProduct,
                    FrequencyId = chargeType.FrequencyId,
                    LastModifiedBy = "UO04XR",
                    LastModifiedDate = DateTime.Now,
                };

                var handler = new Edit.Handler(context, GetMapper(), Mock.Of<ILogger<Edit.Handler>>(), GetConfigurationObject(), GetEmailSenderObject());

                //Act
                ActOnChargeTypeEdit(command, handler);

                Assert.IsTrue(!context.ChargeTypeHistories.Any(cth => cth.ChargeTypeCode == chargeType.ChargeTypeCode &&
                    cth.Status.ObjectStatusName == ObjectStatus.VerificationModify));
                Assert.IsTrue(context.ChargeTypeHistories.Where(cth => cth.ChargeTypeCode == chargeType.ChargeTypeCode).Count() == 1);
            }
        }

        [TestMethod]
        public void EditChargeTypeInFrequencyQuarterlyIsSavedCorrectly()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeEdit(context, ChargeTypeActive, (int)ProcessingFrequency.Quarterly, ValidAccountShort, out Edit.Command command, out Edit.Handler handler, null, new DateTime(2020, (int)Month.August, 28));

                // Act
                ActOnChargeTypeEdit(command, handler);


                // Assert
                Assert.IsTrue(context.ChargeTypes.Any(ct => ct.ChargeTypeCode == "ABC2" &&
                                                            ct.FrequencyId == (int)ProcessingFrequency.Monthly &&
                                                            ct.RunDay == 2 &&
                                                            ct.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargeTypeHistories.Any(cth => cth.ChargeTypeCode == "ABC2" &&
                                                                     cth.RunDay == 1 &&
                                                                     cth.FrequencyId == (int)ProcessingFrequency.Quarterly &&
                                                                     (cth.NextRunDay ?? DateTime.Now).Date == new DateTime(2020, (int)Month.December, 2).Date &&
                                                                     cth.Status.ObjectStatusName == ObjectStatus.VerificationModify));
            }
        }

        [TestMethod]
        public void EditChargeTypeInMonthlyWithRunDayNullAndFrequencyChangedThrowsException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeEdit(context, ChargeTypeActiveQuarterly, (int)ProcessingFrequency.Monthly, ValidAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "You should provide run day for this charge type!");
            }
        }

        [TestMethod]
        public void EditChargeTypeInFrequencyOnceIsSavedCorrectly()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeEdit(context, ChargeTypeActive, (int)ProcessingFrequency.Once, ValidAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Act
                ActOnChargeTypeEdit(command, handler);


                // Assert
                Assert.IsTrue(context.ChargeTypes.Any(ct => ct.ChargeTypeCode == "ABC2" &&
                                                            ct.FrequencyId == (int)ProcessingFrequency.Monthly &&
                                                            ct.RunDay == 2 &&
                                                            ct.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargeTypeHistories.Any(cth => cth.ChargeTypeCode == "ABC2" &&
                                                                     cth.RunDay == null &&
                                                                     cth.NextRunDay == null &&
                                                                     cth.FrequencyId == (int)ProcessingFrequency.Once &&
                                                                     cth.Status.ObjectStatusName == ObjectStatus.VerificationModify));
            }
        }

        [TestMethod]
        public void EditChargeTypeFromOtherFrequencyToMonthlyIsSavedCorrectly()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeEdit(context, ChargeTypeActiveQuarterly, (int)ProcessingFrequency.Monthly, ValidAccountShort, out Edit.Command command, out Edit.Handler handler, 9, new DateTime(2020, (int)Month.August, 20));

                // Act
                ActOnChargeTypeEdit(command, handler);


                // Assert
                Assert.IsTrue(context.ChargeTypes.Any(ct => ct.ChargeTypeCode == "ABC8" &&
                                                            ct.FrequencyId == (int)ProcessingFrequency.Quarterly &&
                                                            ct.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargeTypeHistories.Any(cth => cth.ChargeTypeCode == "ABC8" &&
                                                                     cth.RunDay == 9 &&
                                                                     (cth.NextRunDay ?? DateTime.Now).Date == new DateTime(2020, (int)Month.September, 11).Date &&
                                                                     cth.FrequencyId == (int)ProcessingFrequency.Monthly &&
                                                                     cth.Status.ObjectStatusName == ObjectStatus.VerificationModify));
            }
        }

        [TestMethod]
        public void EditedChargeTypeShouldRemoveLeadingZeros()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeEdit(context, ChargeTypeActive, (int)ProcessingFrequency.Once, 0000131310, out Edit.Command command, out Edit.Handler handler);

                // Act
                ActOnChargeTypeEdit(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Any(ct => ct.ChargeTypeCode == "ABC2" &&
                                                            ct.ChargeTypeDescription == "Test2" &&
                                                            ct.PaymentDetail == "Payment Detail 2" &&
                                                            ct.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargeTypeHistories.Any(cth => cth.ChargeTypeCode == "ABC2" &&
                                                                     cth.ChargeTypeDescription == "Charge Type Description 2" &&
                                                                     cth.PaymentDetail == "Edited Details 2" &&
                                                                     cth.CreditAccountShort == 131310 &&
                                                                     cth.Status.ObjectStatusName == ObjectStatus.VerificationModify));
            }
        }
        #endregion Edit

        #region
        [TestMethod]
        public void ShouldRemoveChargeType()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeDelete(context, ChargeTypeActive, out Delete.Command command, out Delete.Handler handler);

                // Act
                ActOnChargeTypeDelete(command, handler);

                // Assert
                Assert.IsTrue(context.ChargeTypes.Any(c => c.ChargeTypeId == ChargeTypeActive && c.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargeTypeHistories
                                .Any(cth => cth.ChargeTypeId == ChargeTypeActive && cth.Status.ObjectStatusName == ObjectStatus.VerificationDelete));
            }
        }

        [TestMethod]
        public void TryingToDeleteNotActiveChargeTypeShouldReturnRestException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeDelete(context, ChargeTypeNotActive, out Delete.Command command, out Delete.Handler handler);

                // Act
                ActOnChargeTypeDelete(command, handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot delete a charge type that is not active!");
            }
        }

        [TestMethod]
        public void TryingToDeleteInvalidChargeTypeShouldReturnException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeDelete(context, ChargeTypeNotValid, out Delete.Command command, out Delete.Handler handler);

                // Act
                ActOnChargeTypeDelete(command, handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot delete a charge type that does not exist!");
            }
        }

        [TestMethod]
        public void DeleteChargeTypeWithoutAssociatedChargeTypeHistoryThrowsError()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeTypeDelete(context, ChargeTypeWithoutCTH, out Delete.Command command, out Delete.Handler handler);

                // Act
                ActOnChargeTypeDelete(command, handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot delete a charge type that does not have an associated charge type history!");
            }
        }
        #endregion
    }
}
