﻿using Application.DboChargeType;
using Application.Errors;
using Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Threading;

namespace ApplicationTests.DboChargeTypeTests
{
    [TestClass]
    public class RejectChargeTypeTests : ChargeTypeBase
    {
        [DataRow("KK70XR", "ABC3", "RejectAdd")]
        [DataRow("KK70XR", "ABC4", "Active")]
        [DataRow("KK70XR", "ABC5", "Active")]
        [DataTestMethod]
        public void RejectChargeTypeOnAddModifyDelete(string userKey, string chargeCd, string statusCd)
        {
            using (var context = GetDbContext())
            {
                //arrange
                Reject.Command command;
                Reject.Handler handler;
                ChargeType chargeType;
                List<ChargeTypeHistory> chargeTypeHistory;
                ArrangeOnReject(context, userKey, chargeCd, out command, out handler);

                //act
                ActOnReject(context, command, handler, out chargeType, out chargeTypeHistory);
                //assert
                AsertOnReject(chargeType, command, chargeTypeHistory, statusCd);
            }
        }

        [DataRow("KK70XR", "ABC2", "A charge type in active status can not be rejected!")]
        [DataRow("CP28XQ", "ABC5", "A charge type can not be rejected by the same user that proposed the change!")]
        [DataTestMethod]
        public void RejectActiveOrSameUserThrowException(string userKey, string chargeTypeCd, string errorMsg)
        {
            using (var context = GetDbContext())
            {
                //arrange
                Reject.Command command;
                Reject.Handler handler;
                ArrangeOnReject(context, userKey, chargeTypeCd, out command, out handler);

                //act
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token), errorMsg);
            }
        }

    }
}
