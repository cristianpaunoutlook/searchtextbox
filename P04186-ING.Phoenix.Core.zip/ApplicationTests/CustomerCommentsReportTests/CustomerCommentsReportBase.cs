﻿using Application.Reports.CustomerComments;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;
using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationTests.CustomerCommentsReportTests
{
    public class CustomerCommentsReportBase : TestBase
    {
        protected void InitCustomerAndAccountTables(PhoenixContext context)
        {
            var statusActive = (byte)Application.Commons.Enums.ObjectStatusId.Active;
            var statusNotSet = (byte)Application.Commons.Enums.ObjectStatusId.NotSet;

            var accountState = GetChargeAccountState(0, "OK");
            context.ChargeAccountStates.Add(accountState);

            var account1 = GetAccount("MEGIMA", 7510002001, "RO51INGB0000999900001101", "GBS");
            var account2 = GetAccount("KAUROM", 8213560710, "RO51INGB0000999900001102", "GBS");
            var account3 = GetAccount("ZARA", 7510002991, "RO51INGB0000999900001103", "GBS");
            var account4 = GetAccount("ZARAHOME", 7511302991, "RO51INGB0000999900001104", "GBS");
            var account5 = GetAccount("MANGO", 9911302991, "RO51INGB0000999900001105", "GBS");
            context.Accounts.Add(account1);
            context.Accounts.Add(account2);
            context.Accounts.Add(account3);
            context.Accounts.Add(account4);
            context.Accounts.Add(account5);

            var customer1 = GetCustomer("MEGIMA", statusActive,"comments1","User1", DateTime.Now.AddDays(-9));
            var customer2 = GetCustomer("TEST", statusActive, "comments2", "User1", DateTime.Now.AddDays(-8));
            var customer3 = GetCustomer("MEGIMA", statusNotSet, "comments3", "User2", DateTime.Now.AddDays(-7));

            var customer4 = GetCustomer("KAUROM", statusActive, "comments4", "User1", DateTime.Now.AddDays(-6));
            var customer5 = GetCustomer("ZARA", statusActive, "comments1", "User1", DateTime.Now.AddDays(-5));
            var customer6 = GetCustomer("ZARAHOME", statusActive, "comments1", "User1", DateTime.Now.AddDays(-5));
            var customer7 = GetCustomer("MEGIMA", statusActive, "comments1", "User1", DateTime.Now.AddDays(-5));
            var customer8 = GetCustomer("MANGO", statusActive, "comments1", "User1", DateTime.Now.AddDays(-5));
            var customer9 = GetCustomer("MEGIMA", statusActive, "", "User9", DateTime.Now.AddDays(-5));
            var customer10 = GetCustomer("MEGIMA", statusActive, "comments10", "User3", DateTime.Now.AddDays(-3));
            var customer11 = GetCustomer("MEGIMA", statusNotSet, "comments11", "User4", DateTime.Now.AddDays(-2));
            var customer12 = GetCustomer("MEGIMA", statusActive, "comments12", "User1", DateTime.Now.AddDays(-1));
            var customer13 = GetCustomer("MEGIMA", statusActive, "comments13", "User1", DateTime.Now.AddDays(-5));

            context.Customers.Add(customer1);
            context.Customers.Add(customer2 );
            context.Customers.Add(customer3 );
            context.Customers.Add(customer4 );
            context.Customers.Add(customer5 );
            context.Customers.Add(customer6 );
            context.Customers.Add(customer7 );
            context.Customers.Add(customer8 );
            context.Customers.Add(customer9 );
            context.Customers.Add(customer10);
            context.Customers.Add(customer11);
            context.Customers.Add(customer12);
            context.Customers.Add(customer13);

            context.SaveChanges();
        }

        protected CustomerCommentsFilter SetCustomerCommentsFilter(string customerId = "", string customerName="", string lastModifiedBy = "All", DateTime? lastModifiedDate = null, int pageNumber = 1, int pageSize = 15)
        {
            return new CustomerCommentsFilter
            {
                CustomerId = customerId,
                CustomerName = customerName,
                LastModifiedBy = lastModifiedBy,
                LastModifiedDate = lastModifiedDate,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }

        protected void ArrangeOnCustomerCommentsReportList(PhoenixContext context, CustomerCommentsFilter filter, out ListForCustomerCommentsReport.Query query, 
            out ListForCustomerCommentsReport.Handler handler)
        {
            InitCustomerAndAccountTables(context);
            query = new ListForCustomerCommentsReport.Query() { CustomerCommentsFilter = filter };
            handler = new ListForCustomerCommentsReport.Handler(context, Mock.Of<ILogger<ListForCustomerCommentsReport.Handler>>());
        }
    }
}
