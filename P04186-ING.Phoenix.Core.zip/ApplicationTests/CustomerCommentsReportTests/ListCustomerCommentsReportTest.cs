﻿using Application.Errors;
using Application.Reports.CustomerComments;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Threading;

namespace ApplicationTests.CustomerCommentsReportTests
{
    [TestClass]
    public class ListCustomerCommentsReportTest : CustomerCommentsReportBase
    {
        [TestMethod]
        public void ShouldReturnAllActiveCustomersWithCommentsFromDb()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                //arrange
                CustomerCommentsFilter customerCommentsFilter = SetCustomerCommentsFilter(pageSize: 20);

                ArrangeOnCustomerCommentsReportList(context, customerCommentsFilter, out ListForCustomerCommentsReport.Query query,
                   out ListForCustomerCommentsReport.Handler handler);

                //act
                Application.Helpers.PagedList<Application.DTO.CustomerCommentsDTO> customerComments = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerComments.Items.Count == 9);
            }
        }

        [TestMethod]
        public void ShouldReturnAllActiveCustomersWithCommentsFromDbForFirstPage()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                //arrange
                CustomerCommentsFilter customerCommentsFilter = SetCustomerCommentsFilter(pageNumber: 1, pageSize: 5);

                ArrangeOnCustomerCommentsReportList(context, customerCommentsFilter, out ListForCustomerCommentsReport.Query query,
                   out ListForCustomerCommentsReport.Handler handler);

                //act
                Application.Helpers.PagedList<Application.DTO.CustomerCommentsDTO> customerComments = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerComments.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldThrowExceptionIfPageNumberIsOutOfRange()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                //arrange
                CustomerCommentsFilter customerCommentsFilter = SetCustomerCommentsFilter(pageNumber: 3, pageSize: 15);

                ArrangeOnCustomerCommentsReportList(context, customerCommentsFilter, out ListForCustomerCommentsReport.Query query,
                   out ListForCustomerCommentsReport.Handler handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "Customer comments for the values from filters does not exist in the database!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageNumberIfPageNumberIsLessOrEqualThanZero()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                //arrange
                CustomerCommentsFilter customerCommentsFilter = SetCustomerCommentsFilter(pageNumber: -1, pageSize: 5);

                ArrangeOnCustomerCommentsReportList(context, customerCommentsFilter, out ListForCustomerCommentsReport.Query query,
                   out ListForCustomerCommentsReport.Handler handler);

                //act
                Application.Helpers.PagedList<Application.DTO.CustomerCommentsDTO> customerComments = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerComments.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                //arrange
                CustomerCommentsFilter customerCommentsFilter = SetCustomerCommentsFilter(pageNumber: 1, pageSize: 50);

                ArrangeOnCustomerCommentsReportList(context, customerCommentsFilter, out ListForCustomerCommentsReport.Query query,
                   out ListForCustomerCommentsReport.Handler handler);

                //act
                Application.Helpers.PagedList<Application.DTO.CustomerCommentsDTO> customerComments = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerComments.Items.Count == 9);
            }
        }

        [TestMethod]
        public void ShouldReturnAllActiveCustomersWithCommentsFromDbFilteredByCustomerId()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                CustomerCommentsFilter customerCommentsFilter = SetCustomerCommentsFilter(customerId: "MEGIMA", pageNumber: 1, pageSize: 15);

                ArrangeOnCustomerCommentsReportList(context, customerCommentsFilter, out ListForCustomerCommentsReport.Query query,
                   out ListForCustomerCommentsReport.Handler handler);

                //act
                Application.Helpers.PagedList<Application.DTO.CustomerCommentsDTO> customerComments = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerComments.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnAllActiveCustomersWithCommentsFromDbFilteredByCustomerName()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                CustomerCommentsFilter customerCommentsFilter = SetCustomerCommentsFilter(customerName: "Name MEGIMA", pageNumber: 1, pageSize: 15);

                ArrangeOnCustomerCommentsReportList(context, customerCommentsFilter, out ListForCustomerCommentsReport.Query query,
                   out ListForCustomerCommentsReport.Handler handler);

                //act
                Application.Helpers.PagedList<Application.DTO.CustomerCommentsDTO> customerComments = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerComments.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnAllActiveCustomersWithCommentsFromDbFilteredByLastModifiedByUser()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                CustomerCommentsFilter customerCommentsFilter = SetCustomerCommentsFilter(lastModifiedBy: "User3", pageNumber: 1, pageSize: 15);

                ArrangeOnCustomerCommentsReportList(context, customerCommentsFilter, out ListForCustomerCommentsReport.Query query,
                   out ListForCustomerCommentsReport.Handler handler);

                //act
                Application.Helpers.PagedList<Application.DTO.CustomerCommentsDTO> customerComments = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerComments.Items.Count == 1);
            }
        }

        [TestMethod]
        public void ShouldReturnAllActiveCustomersWithCommentsFromDbFilteredByLastModifiedDate()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                CustomerCommentsFilter customerCommentsFilter = SetCustomerCommentsFilter(lastModifiedDate: DateTime.Now.AddDays(-5).Date, pageNumber: 1, pageSize: 15);

                ArrangeOnCustomerCommentsReportList(context, customerCommentsFilter, out ListForCustomerCommentsReport.Query query,
                   out ListForCustomerCommentsReport.Handler handler);

                //act
                Application.Helpers.PagedList<Application.DTO.CustomerCommentsDTO> customerComments = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerComments.Items.Count == 7);
            }
        }

        [TestMethod]
        public void ShouldReturnAllActiveCustomersWithCommentsFromDbFilteredByMultipleValues()
        {
            using (Persistence.PhoenixContext context = GetDbContext())
            {
                CustomerCommentsFilter customerCommentsFilter = SetCustomerCommentsFilter(customerId: "MEGIMA", lastModifiedDate: DateTime.Now.AddDays(-5).Date, pageNumber: 1, pageSize: 15);

                ArrangeOnCustomerCommentsReportList(context, customerCommentsFilter, out ListForCustomerCommentsReport.Query query,
                   out ListForCustomerCommentsReport.Handler handler);

                //act
                Application.Helpers.PagedList<Application.DTO.CustomerCommentsDTO> customerComments = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerComments.Items.Count == 4);
            }
        }

    }
}
