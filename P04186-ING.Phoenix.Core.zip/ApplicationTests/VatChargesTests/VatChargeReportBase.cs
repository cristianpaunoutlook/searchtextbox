﻿using System;
using Application.Commons.Enums;
using Application.Reports.VatCharges;
using Domain;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;

namespace ApplicationTests.VatChargesTests
{
    public class VatChargeReportBase : TestBase
    {
        protected void InitVatChargeTabels(PhoenixContext context)
        {
            var sessionExport1 = GetSession(100, (int)Application.Commons.Enums.ObjectType.SessionExport);
            var sessionImport2 = GetSession(200, (int)Application.Commons.Enums.ObjectType.SessionImport);
            context.Sessions.Add(sessionExport1);
            context.Sessions.Add(sessionImport2);

            var applicationLog1 = GetApplicationLog(1, 100, (int)Application.Commons.Enums.ObjectType.SessionExport, DateTime.Now.AddMonths(-1));
            var applicationLog2 = GetApplicationLog(2, 200, (int)Application.Commons.Enums.ObjectType.SessionImport, DateTime.Now.AddMonths(-1));
            var applicationLog3 = GetApplicationLog(3, 300, (int)Application.Commons.Enums.ObjectType.SessionExport, DateTime.Now.AddMonths(-4));

            context.ApplicationLogs.Add(applicationLog1);
            context.ApplicationLogs.Add(applicationLog2);
            context.ApplicationLogs.Add(applicationLog3);

            var account1 = GetAccount("MEGIMA", 7510002001, "RO51INGB0000999900001101", "GBS", "GRIDMEGIMA", "CUIMEGIMA");
            var account2 = GetAccount("1", 8213560710, "RO51INGB0000999900001102", "GBS", "GRIDMEGIMA");
            var account3 = GetAccount("10", 7510002991, "RO51INGB0000999900001103", "GBS", "GRIDMEGIMA");
            var account4 = GetAccount("Customer", 7511302991, "RO51INGB0000999900001104", "GBS");
            var account5 = GetAccount("TestCustomer", 9911302991, "RO51INGB0000999900001105", "GBS");
            var accountForLeadingZeros = GetAccount("Customer", 131310, string.Empty, "GBS");
            context.Accounts.Add(account1);
            context.Accounts.Add(account2);
            context.Accounts.Add(account3);
            context.Accounts.Add(account4);
            context.Accounts.Add(account5);
            context.Accounts.Add(accountForLeadingZeros);

            var currency = GetCurrencyObject(1, "RON");
            var processingFrequencyMonthly = GetProcessingFrequencyObject((int)Application.Commons.Enums.ProcessingFrequency.Monthly, "Monthly");
            var statusActive = GetStatusObject(0, Application.Commons.Enums.ObjectStatus.Active);

            var chargeTypeActive1 = GetChargeTypeObject(1, currency, processingFrequencyMonthly, statusActive, true);
            var chargeTypeActive2 = GetChargeTypeObject(2, currency, processingFrequencyMonthly, statusActive, true);

            context.ChargeTypes.Add(chargeTypeActive1);
            context.ChargeTypes.Add(chargeTypeActive2);

            var customerDetails1 = GetCustomerDetails("MEGIMA");
            var customerDetails2 = GetCustomerDetails("1");
            var customerDetails3 = GetCustomerDetails("10");
            var customerDetails4 = GetCustomerDetails("Customer");
            context.CustomersDetails.Add(customerDetails1);
            context.CustomersDetails.Add(customerDetails2);
            context.CustomersDetails.Add(customerDetails3);
            context.CustomersDetails.Add(customerDetails4);


            var payment1 = GetPayment(1, sessionExport1, applicationLog3, chargeTypeActive1, currency, customerDetails1, 10, "MEGIMA");
            var payment2 = GetPayment(2, sessionExport1, applicationLog1, chargeTypeActive1, currency, customerDetails2, 15, "1");
            var payment3 = GetPayment(3, sessionExport1, applicationLog1, chargeTypeActive2, currency, customerDetails3, 23, "10");
            var payment4 = GetPayment(4, sessionExport1, applicationLog1, chargeTypeActive1, currency, customerDetails4, 5, "Customer", statusId: 0);

            var payment5 = GetPayment(5, sessionImport2, applicationLog2, chargeTypeActive1, currency, customerDetails1, 10, "MEGIMA");
            var payment6 = GetPayment(6, sessionImport2, applicationLog2, chargeTypeActive2, currency, customerDetails2, 15, "1");

            var payment7 = GetPayment(7, sessionExport1, applicationLog3, chargeTypeActive1, currency, customerDetails4, 5, "Customer");

            context.Payments.Add(payment1);
            context.Payments.Add(payment2);
            context.Payments.Add(payment3);
            context.Payments.Add(payment4);
            context.Payments.Add(payment5);
            context.Payments.Add(payment6);
            context.Payments.Add(payment7);

            var parameter = new PhxParameter()
            {
                ParamName = "VATValue",
                ParamValue = "0.19"
            };
            context.Parameters.Add(parameter);
            context.SaveChanges();
        }

        protected VatChargesFilter SetVatChargesFilter(string customerID = "", string gridID = "", string cui = "", int chargeTypeId = -1, int statusId = -1, 
            DateTime? startDate = null, DateTime? endDate = null,
        int pageNumber = 1, int pageSize = 15)
        {
            return new VatChargesFilter
            {
                CustomerId = customerID,
                GridId = gridID,
                CUI = cui,
                ChargeTypeId = chargeTypeId,
                StatusId = statusId,
                StartDate = startDate,
                EndDate = endDate,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }

        protected void ArrangeOnVatChargesReportList(PhoenixContext context, VatChargesFilter vatChargesFilter,
        out ListForVatReport.Query query, out ListForVatReport.Handler handler)
        {
            InitVatChargeTabels(context);

            query = new ListForVatReport.Query() { VatChargesFilter = vatChargesFilter };
            handler = new ListForVatReport.Handler(context, Mock.Of<ILogger<ListForVatReport.Handler>>());
        }
    }
}
