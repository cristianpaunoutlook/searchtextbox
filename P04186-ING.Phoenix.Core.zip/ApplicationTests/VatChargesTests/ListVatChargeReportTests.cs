﻿using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using System.Threading;

namespace ApplicationTests.VatChargesTests
{
    [TestClass]
    public class ListVatChargeReportTests : VatChargeReportBase
    {
        [TestMethod]
        public void ShouldReturnAllVatChargesFromDb()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(pageSize: 15);

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.Items.Count == 4);
            }
        }

        [TestMethod]
        public void ShouldReturnAllVatChargesFromDbForFirstPage()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(pageNumber: 1, pageSize: 2);

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.Items.Count == 2);
            }
        }

        [TestMethod]
        public void ShouldReturnEmptyListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(pageNumber: 4, pageSize: 15);

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "Vat charges for the values from filters does not exist in the database!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageNumberIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(pageNumber: -3, pageSize: 15);

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.Items.Count == 4);
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var vatChargesFilter = SetVatChargesFilter(pageNumber: 1, pageSize: 100);

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                  out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByCustomerId()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(customerID: "Customer");

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.Items.Count == 1);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByGridId()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(gridID: "GRIDMEGIMA");

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.Items.Count == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByCUI()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(cui: "CUIMEGIMA");

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.Items.Count == 1);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByChargeType()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(chargeTypeId: 1);

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.Items.Count == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredMultipleValues()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(chargeTypeId: 1, gridID: "GRIDMEGIMA");

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.Items.Count == 2);
            }
        }

        [TestMethod]
        public void ShouldThrowErrorWhenFilteredValuesDontMatch()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(customerID: "TestCustomer");

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "Vat charges for the values from filters does not exist in the database!");
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByStatus()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(statusId: 0);

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.Items.Count == 1 && vatCharges.Items.Any(vc => vc.CustomerAtlasId == "Customer"));
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByDate()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var vatChargesFilter = SetVatChargesFilter(startDate: DateTime.Now.AddMonths(-4), endDate: DateTime.Now.AddMonths(-3));

                ArrangeOnVatChargesReportList(context, vatChargesFilter, out var query,
                   out var handler);

                //act
                var vatCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(vatCharges.Items.Count == 1);
            }
        }
    }
}