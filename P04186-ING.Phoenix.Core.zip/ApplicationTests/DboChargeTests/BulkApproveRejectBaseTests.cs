﻿using Application.Commons.Enums;
using Application.DboCharge;
using Application.Helpers;
using Domain;
using Persistence;
using System;

namespace ApplicationTests.DboChargeTests
{
    public class BulkApproveRejectBaseTests : TestBase
    {
        protected BulkReject.Query GetRequestObject()
        {
            return new BulkReject.Query()
            {
                ChargeIds = new int[] { 1, 2 },
                ListToExclude = false,
                RejectReason = "Test reject reason",
                UserKey = "ABCDEF",
                Filter = new ValidationParams()
                {
                    ChargeTypeId = -1,
                    CustomerId = "",
                    CustomerName = "",
                    ImportDate = null,
                    SessionId = -1,
                    StatusId = -1,
                    PageNumber = 1,
                    PageSize = 15,
                    UserId = ""
                }
            };
        }

        protected BulkApprove.Query GetRequestObjectForApprove()
        {
            return new BulkApprove.Query()
            {
                ChargeIds = new int[] { 1, 2 },
                ListToExclude = false,
                UserKey = "ABCDEF",
                Filter = new ValidationParams()
                {
                    ChargeTypeId = -1,
                    CustomerId = "",
                    CustomerName = "",
                    ImportDate = null,
                    SessionId = -1,
                    StatusId = -1,
                    PageNumber = 1,
                    PageSize = 15,
                    UserId = ""
                }
            };
        }

        protected void InitDataForTest(PhoenixContext context)
        {
            var account1 = GetAccount("ID1", 9999900001, "RO51INGB0000999900001101", "PRF");
            var account2 = GetAccount("ID2", 9999900002, "RO51INGB0000999900001102", "PRF");
            context.Accounts.Add(account1);
            context.Accounts.Add(account2);
            var custChargeType1 = new Domain.CustomerChargeType() { Id = 1, Description = "Per product" };
            var custChargeType2 = new Domain.CustomerChargeType() { Id = 2, Description = "Per transaction" };
            context.CustomerChargeTypes.Add(custChargeType1);
            context.CustomerChargeTypes.Add(custChargeType2);
            var currEUR = new Currency() { CurrencyId = 1, CurrencyCode = "EUR" };
            context.Currencies.Add(currEUR);
            var statusVerifAdd = new Domain.ObjectStatus() { ObjectStatusId = (int)ObjectStatusId.VerificationAdd, ObjectStatusName = Application.Commons.Enums.ObjectStatus.VerificationAdd };
            var statusVerifModify = new Domain.ObjectStatus() { ObjectStatusId = (int)ObjectStatusId.VerificationModify, ObjectStatusName = Application.Commons.Enums.ObjectStatus.VerificationModify };
            var statusVerifDelete = new Domain.ObjectStatus() { ObjectStatusId = (int)ObjectStatusId.VerificationDelete, ObjectStatusName = Application.Commons.Enums.ObjectStatus.VerificationDelete };
            var statusActive = new Domain.ObjectStatus() { ObjectStatusId = (int)ObjectStatusId.Active, ObjectStatusName = Application.Commons.Enums.ObjectStatus.Active };
            var ct1 = new ChargeType() { ChargeTypeId = 1, AmountProduct = 10, ChargeTypeCode = "CT1", CreditAccountShort = 999990001, Curr = currEUR, DefaultAmount = 11, Status = statusActive };
            var ct2 = new ChargeType() { ChargeTypeId = 2, AmountProduct = 20, ChargeTypeCode = "CT2", CreditAccountShort = 999990002, Curr = currEUR, DefaultAmount = 21, Status = statusActive };
            var c1 = new Charge() { ChargeId = 1, Status = statusActive, Currency = currEUR, AtlasId = "ID1", ChargeType = ct1, CreditAccountShort = 9999900001, DebitAccount = "RO51INGB0000999900001101", CustomerChargeType = custChargeType1 };
            var ch1 = new ChargeHistory() { ChargeHistoryId = 1, Charge = c1, AtlasId = "ID1", ChargeType = ct1, Currency = currEUR, LastModifiedBy = "AABBCC", Status = statusVerifAdd, LastModifiedDate = DateTime.Now.AddDays(-1) };
            var c2 = new Charge() { ChargeId = 2, Status = statusActive, Currency = currEUR, AtlasId = "ID2", ChargeType = ct2, CreditAccountShort = 9999900002, DebitAccount = "RO51INGB0000999900001102", CustomerChargeType = custChargeType1, SessionId = 2 };
            var ch2 = new ChargeHistory() { ChargeHistoryId = 2, Charge = c2, AtlasId = "ID2", ChargeType = ct2, Currency = currEUR, LastModifiedBy = "abcdef", Status = statusVerifModify, LastModifiedDate = DateTime.Now.AddDays(-2) };
            var c3 = new Charge() { ChargeId = 3, Status = statusActive, Currency = currEUR, AtlasId = "ID1", ChargeType = ct1, CreditAccountShort = 9999900001, DebitAccount = "RO51INGB0000999900001101", CustomerChargeType = custChargeType1, SessionId = 3 };
            var ch3 = new ChargeHistory() { ChargeHistoryId = 3, Charge = c3, AtlasId = "ID1", ChargeType = ct1, Currency = currEUR, LastModifiedBy = "AABBCC", Status = statusVerifDelete, LastModifiedDate = DateTime.Now.AddDays(-3) };
            var c4 = new Charge() { ChargeId = 4, Status = statusActive, Currency = currEUR, AtlasId = "ID1", ChargeType = ct1, CreditAccountShort = 9999900001, DebitAccount = "RO51INGB0000999900001101", CustomerChargeType = custChargeType2 };
            var ch4 = new ChargeHistory() { ChargeHistoryId = 4, Charge = c4, AtlasId = "ID1", ChargeType = ct1, Currency = currEUR, LastModifiedBy = "AABBCC", Status = statusActive, LastModifiedDate = DateTime.Now.AddDays(-1) };
            context.ChargesHistory.Add(ch1);
            context.ChargesHistory.Add(ch2);
            context.ChargesHistory.Add(ch3);
            context.ChargesHistory.Add(ch4);
            context.SaveChanges();
        }
    }
}
