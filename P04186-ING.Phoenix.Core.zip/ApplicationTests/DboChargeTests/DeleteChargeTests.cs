﻿using System.Linq;
using System.Threading;
using Application.Commons.Enums;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ApplicationTests.DboChargeTests
{
    [TestClass]
    public class DeleteChargeTests : ChargeBaseTests
    {
        [TestMethod]
        public void ShouldRemoveChargeType()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeDelete(context, ChargeActive, out var command, out var handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(context.Charges.Any(c => c.ChargeId == ChargeActive && c.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargesHistory.Any(cth => cth.ChargeId == ChargeActive && cth.Status.ObjectStatusName == ObjectStatus.VerificationDelete));
            }
        }

        [TestMethod]
        public void TryingToDeleteNotActiveChargeShouldReturnRestException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeDelete(context, ChargeDeleted, out var command, out var handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot delete a charge type that is not active!");
            }
        }


        [TestMethod]
        public void TryingToDeleteInvalidChargeShouldReturnException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeDelete(context, ChargeNotValid, out var command, out var handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot delete a charge type that does not exist!");
            }
        }

        [TestMethod]
        public void DeleteChargeWithoutAssociatedChargeTypeHistoryThrowsError()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeDelete(context, ChargeWithoutHist, out var command, out var handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot delete a charge type that does not have an associated charge type history!");
            }
        }

        [TestMethod]
        public void TryingToDeleteNotActiveChargeHistoryShouldReturnRestException()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeDelete(context, ChargeHistoryNotActive, out var command, out var handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot delete a charge type with history is not active!");
            }
        }
    }
}
