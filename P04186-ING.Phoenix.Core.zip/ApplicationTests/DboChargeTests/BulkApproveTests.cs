﻿using Application.DboCharge;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Linq;

namespace ApplicationTests.DboChargeTests
{
    [TestClass]
    public class BulkApproveTests : BulkApproveRejectBaseTests
    {
        [TestMethod]
        public void IfListToExcludeGetIdsFromDb()
        {
            var query = GetRequestObjectForApprove();
            query.ListToExclude = true;
            using (var context = GetDbContext())
            {
                var handler = new BulkApprove.Handler(context, Mock.Of<ILogger<BulkApprove.Handler>>());
                InitDataForTest(context);
                //Act
                var ids = handler.GetIdsForApproveReject(query.ListToExclude, query.ChargeIds, query.Filter, context, "AAAAAA");

                //Act && Assert
                Assert.IsTrue(ids.Length == 1 && ids[0] == 3);
            }
        }

        [TestMethod]
        public void IfNotListToExcludeReturnIdsFromRequest()
        {
            //Arange
            var query = GetRequestObjectForApprove();
            using (var context = GetDbContext())
            {
                var handler = new BulkApprove.Handler(context, Mock.Of<ILogger<BulkApprove.Handler>>());

                //Act
                var ids = handler.GetIdsForApproveReject(query.ListToExclude, query.ChargeIds, query.Filter, context, "AAAAAA");

                //Act && Assert
                Assert.IsTrue(ids.SequenceEqual(query.ChargeIds));
            }
        }
    }
}
