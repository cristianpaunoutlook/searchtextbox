﻿using Application.Commons.Enums;
using Application.DboCharge;
using Application.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Persistence;
using System;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboChargeTests
{
    [TestClass]
    public class EditChargeTests : ChargeBaseTests
    {
        [TestMethod]
        public void EditedChargeShouldBePersistedInDb()
        {
            using (PhoenixContext context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeEdit(context, ChargeActive, AtlasIdActive, ChargeTypeActive, CustomerChargeTypePerProduct,
                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler, paymentdetails: "Payment Detail 2");

                // Act
                ActOnChargeEdit(command, handler);

                // Assert
                Assert.IsTrue(context.Charges.Any(c => c.ChargeId == ChargeActive &&
                                                            c.CustomerChargeTypeId == CustomerChargeTypePerTransaction &&
                                                            c.CreditAccountShort == ActiveChargeCreditAccountShort &&
                                                            c.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.ChargeId == ChargeActive &&
                                                            ch.CustomerChargeTypeId == CustomerChargeTypePerProduct &&
                                                            ch.CreditAccountShort == ValidCreditAccountShort &&
                                                            ch.Status.ObjectStatusName == ObjectStatus.VerificationModify));
            }
        }

        [TestMethod]
        public void EditedRecoChargeWithDifferentPaymentDetailsShouldBePersistedInDb()
        {
            using (PhoenixContext context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeEdit(context, 22, AtlasIdActive, ChargeTypeRECO, CustomerChargeTypePerProduct,
                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler, paymentdetails: "RE0210125308746");

                // Act
                ActOnChargeEdit(command, handler);

                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.ChargeType.GroupId == 3 && ch.PaymentDetails == "RE0210125308746"));
            }
        }

        [TestMethod]
        public void EditedRecoChargeWithSamePaymentDetailsShoulThrowException()
        {
            using (PhoenixContext context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeEdit(context, 23, AtlasPerTransaction, ChargeTypeRECO, CustomerChargeTypePerProduct,
                                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler, paymentdetails: "RE0210125308745");

                // Act
                //ActOnChargeEdit(command, handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Charge code already exits on same debit account!");
            }
        }

        [TestMethod]
        public void EditNotActiveChargeThrowsException()
        {
            using (PhoenixContext context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeEdit(context, ChargeVerificationAdd, AtlasIdActive, ChargeTypeActive, CustomerChargeTypePerProduct,
                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot edit a charge that is not active!");
            }
        }

        [TestMethod]
        public void EditChargeWithoutAssociatedChargeTypeHistoryThrowsException()
        {
            using (PhoenixContext context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeEdit(context, ChargeWithoutHist, AtlasIdActive, ChargeTypeActive, CustomerChargeTypePerProduct,
                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot edit a charge that does not have asssociated charge history!");
            }
        }

        [TestMethod]
        public void ShouldNotEditChargeIfChargeTypeIsInvalid()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeEdit(context, ChargeActive, AtlasIdActive, InvalidChargeType, CustomerChargeTypePerProduct,
                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "You cannot edit this charge because charge type does not exists in the database!");
            }
        }

        [TestMethod]
        public void ShouldNotEditChargeIfStandardAndCrrencyOrAmountNotNull()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeEdit(context, ChargeActive, AtlasIdActive, ChargeTypeActive, CustomerChargeTypePerProduct,
                    StandardValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "You cannot edit this charge for standard value amount and currency must be null!");
            }
        }

        [TestMethod]
        public void ShouldNotEditChargeWithIncorrectCreditAccountShort()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeEdit(context, ChargeActive, AtlasIdActive, ChargeTypeActive, CustomerChargeTypePerProduct,
                    NegotiatedValue, InvalidCreditAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Credit account short is invalid");
            }
        }

        [TestMethod]
        public void ShouldNotEditChargeWithPerProductIfAlreadyExistsPerTransaction()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeEdit(context, ChargeActivePerProduct, AtlasPerTransaction, ChargeTypeActive, CustomerChargeTypePerProduct,
                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Charge already has per transaction!");
            }
        }

        [TestMethod]
        public void ShouldNotEditChargeWithPerTransactionIfAlreadyExistsPerProduct()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeEdit(context, ChargeActive, AtlasIdPerProduct, ChargeTypeActive, CustomerChargeTypePerTransaction,
                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Charge already has per product!");
            }
        }

        [TestMethod]
        public void ShouldAddCustomerInTheDbOnEditIfNotExists()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeEdit(context, ChargeActive, AtlasIdNotInTheDb, ChargeTypeActive, CustomerChargeTypePerProduct,
                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler, paymentdetails: "Payment Detail 2");

                //Act
                ActOnChargeEdit(command, handler);

                // Assert
                Assert.IsTrue(context.Customers.Any(c => c.AtlasID == AtlasIdNotInTheDb && c.StatusId == (byte)ObjectStatusId.Active));
            }
        }

        [TestMethod]
        public void ShouldUpdateCustomerStatusToActiveOnEditIfItIsNotActive()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeEdit(context, ChargeActive, AtlasIdNotActiveInTheDb, ChargeTypeActive, CustomerChargeTypePerProduct,
                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler, paymentdetails: "Payment Detail 2");

                //Act
                ActOnChargeEdit(command, handler);

                // Assert
                Assert.IsTrue(context.Customers.Any(c => c.AtlasID == AtlasIdNotActiveInTheDb && c.StatusId == (byte)ObjectStatusId.Active));
            }
        }

        [TestMethod]
        public void EditChargeTypeThatIsNotDirtyDoesNotSaveVerificationModifyStateInCTH()
        {
            using (PhoenixContext context = GetDbContext())
            {
                // Arrange
                InitChargeAndChargeHistory(context);

                Domain.Charge charge = context.Charges.Where(c => c.ChargeId == ChargeActive).FirstOrDefault();

                Edit.Command command = new Edit.Command()
                {
                    ChargeId = charge.ChargeId,
                    AtlasId = charge.AtlasId,
                    ChargeTypeId = charge.ChargeTypeId,
                    CustomerChargeTypeId = charge.CustomerChargeTypeId ?? 0,
                    SpecialAmount = charge.SpecialAmount,
                    CurrencyId = charge.CurrencyId,
                    ChargedItems = charge.ChargedItems ?? 0,
                    DebitAccount = charge.DebitAccount,
                    CreditAccountShort = charge.CreditAccountShort,
                    LastModifiedBy = "CP28XQ",
                    LastModifiedDate = DateTime.Now
                };

                Edit.Handler handler = new Edit.Handler(context, GetMapper(), Mock.Of<ILogger<Edit.Handler>>());

                //Act
                ActOnChargeEdit(command, handler);

                //Asert
                Assert.IsTrue(!context.ChargesHistory.Any(ch => ch.ChargeId == charge.ChargeId &&
                    ch.Status.ObjectStatusName == ObjectStatus.VerificationModify));
                Assert.IsTrue(context.ChargesHistory.Where(ch => ch.ChargeId == charge.ChargeId).Count() == 2);
            }
        }

        [TestMethod]
        public void EditedChargeShouldRemoveLeadingZerosFromCreditAccountShort()
        {
            using (PhoenixContext context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeEdit(context, ChargeActive, AtlasIdActive, ChargeTypeActiveForLeadingZeros, CustomerChargeTypePerProduct,
                    NegotiatedValue, 0000131310, out Edit.Command command, out Edit.Handler handler, paymentdetails: "Payment Detail 4");

                // Act
                ActOnChargeEdit(command, handler);

                // Assert
                Assert.IsTrue(context.Charges.Any(c => c.ChargeId == ChargeActive &&
                                                            c.CustomerChargeTypeId == CustomerChargeTypePerTransaction &&
                                                            c.CreditAccountShort == ActiveChargeCreditAccountShort &&
                                                            c.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.ChargeId == ChargeActive &&
                                                            ch.CustomerChargeTypeId == CustomerChargeTypePerProduct &&
                                                            ch.CreditAccountShort == 131310 &&
                                                            ch.Status.ObjectStatusName == ObjectStatus.VerificationModify));
            }
        }

        [TestMethod]
        public void EditChargeWithPaymentDetailDifferentThanCTAndOtherThanOnceShouldThrowError()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeEdit(context, ChargeActive, AtlasIdActive, ChargeTypeActive, CustomerChargeTypePerProduct,
                   NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler, paymentdetails: "Payment Detail Different");

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "For charge other than once payment details for customer charge must be the same with payment details for charge!");
            }
        }

        [TestMethod]
        public void IfCTOnceAndChargePaymentDetailsEmptyAddPaymentDetailsFromCT()
        {
            using (PhoenixContext context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeEdit(context, ChargeActive, AtlasIdActive, ChargeTypeOnce, CustomerChargeTypePerProduct,
                    NegotiatedValue, ValidCreditAccountShort, out Edit.Command command, out Edit.Handler handler, paymentdetails: "");

                // Act
                ActOnChargeEdit(command, handler);

                // Assert
                Assert.IsTrue(context.Charges.Any(c => c.ChargeId == ChargeActive &&
                                                            c.AtlasId == AtlasPerTransaction &&
                                                            c.CreditAccountShort == 10000000000 &&
                                                            c.Status.ObjectStatusName == ObjectStatus.Active &&
                                                            c.ChargeTypeId == ChargeTypeActive &&
                                                            c.PaymentDetails == null));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.ChargeId == ChargeActive &&
                                                            ch.AtlasId == AtlasIdActive &&
                                                            ch.CreditAccountShort == ValidCreditAccountShort &&
                                                            ch.Status.ObjectStatusName == ObjectStatus.VerificationModify &&
                                                            ch.ChargeTypeId == ChargeTypeOnce &&
                                                            ch.PaymentDetails == "Payment Detail 6"));
            }
        }
    }
}
