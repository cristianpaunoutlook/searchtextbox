﻿using Application.DboCharge;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading;

namespace ApplicationTests.DboChargeTests
{
    [TestClass]
    public class ListCharges : ChargeBaseTests
    {
        [TestMethod]
        public void ShouldReturnAllCustomerChargesFromDb()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cusotmerId = "5";

                ArrangeOnChargeTypeList(context, cusotmerId, out List.Query query, out List.Handler handler);

                //act
                var customerChargesList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerChargesList.Charges.Count == 3);
            }
        }
    }
}