﻿using Application.Commons.Enums;
using Application.DboCharge;
using Application.Errors;
using Application.Helpers;
using Domain;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Persistence;
using System;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboChargeTests
{
    [TestClass]
    public class VerificationTests : TestBase
    {
        [TestMethod]
        public void ShouldReturnAllChargesToValidate()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams() { ChargeTypeId = -1, CustomerId = "", CustomerName = "", SessionId = -1, StatusId = -1, UserId = "", ImportDate = null }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                // Act
                var result = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Items.Count == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnChargesCorespondingToChargeType()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams() { ChargeTypeId = 2, CustomerId = "", CustomerName = "", SessionId = -1, StatusId = -1, UserId = "", ImportDate = null }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                // Act
                var result = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Items.Count == 1 && result.Items[0].ChargeTypeId == 2);
            }
        }

        [TestMethod]
        public void ShouldReturnChargesCorespondingToCustomerId()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams() { ChargeTypeId = -1, CustomerId = "ID2", CustomerName = "", SessionId = -1, StatusId = -1, UserId = "", ImportDate = null }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                // Act
                var result = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Items.Count == 1 && result.Items[0].CustomerId == "ID2");
            }
        }

        [TestMethod]
        public void ShouldReturnChargesCorespondingToCustomerName()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams() { ChargeTypeId = -1, CustomerId = "", CustomerName = "Name ID2", SessionId = -1, StatusId = -1, UserId = "", ImportDate = null }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                // Act
                var result = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Items.Count == 1 && result.Items[0].CustomerName == "Name ID2");
            }
        }

        [TestMethod]
        public void ShouldReturnChargesCorespondingToSession()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams() { ChargeTypeId = -1, CustomerId = "", CustomerName = "", SessionId = 2, StatusId = -1, UserId = "", ImportDate = null }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                // Act
                var result = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Items.Count == 1 && result.Items[0].CustomerName == "Name ID2");
            }
        }

        [TestMethod]
        public void ShouldReturnChargesCorespondingToStatus()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams() { ChargeTypeId = -1, CustomerId = "", CustomerName = "", SessionId = -1, StatusId = (int)ObjectStatusId.VerificationModify, UserId = "", ImportDate = null }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                // Act
                var result = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Items.Count == 1 && result.Items[0].CustomerName == "Name ID2");
            }
        }

        [TestMethod]
        public void ShouldReturnChargesCorespondingToUser()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams() { ChargeTypeId = -1, CustomerId = "", CustomerName = "", SessionId = -1, StatusId = -1, UserId = "abcdef", ImportDate = null }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                // Act
                var result = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Items.Count == 1 && result.Items[0].CustomerName == "Name ID2");
            }
        }

        [TestMethod]
        public void ShouldReturnChargesCorespondingToImportDate()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams() { ChargeTypeId = -1, CustomerId = "", CustomerName = "", SessionId = -1, StatusId = -1, UserId = "", ImportDate = DateTime.Now.AddDays(-2).Date }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                // Act
                var result = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Items.Count == 1 && result.Items[0].CustomerName == "Name ID2");
            }
        }

        [TestMethod]
        public void ShouldNotReturnChargesWithoutVaidationState()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams() { ChargeTypeId = -1, CustomerId = "", CustomerName = "", SessionId = -1, StatusId = -1, UserId = "", ImportDate = null }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                // Act
                var result = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Items.Count == 3 && result.Items.Where(c => c.StatusId == (int)ObjectStatusId.Active).Count() == 0);
            }
        }

        [TestMethod]
        public void ShouldNotReturnChargesForAllFilter()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams()
                    {
                        ChargeTypeId = 1,
                        CustomerId = "ID1",
                        CustomerName = "Name ID1",
                        SessionId = 3,
                        StatusId = (int)ObjectStatusId.VerificationDelete,
                        UserId = "AABBCC",
                        ImportDate = DateTime.Now.AddDays(-3).Date
                    }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                // Act
                var result = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(result.Items.Count == 1 && result.Items[0].ChargeId == 3);
            }
        }

        [TestMethod]
        public void ShouldThrowErrorIfNoRecordFound()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                InitDataForTest(context);
                var query = new Verification.Query()
                {
                    ValidationParams = new ValidationParams() { ChargeTypeId = -1, CustomerId = "", CustomerName = "TestNoCharges", SessionId = -1, StatusId = -1, UserId = "", ImportDate = null }
                };
                var handler = new Verification.Handler(context, Mock.Of<ILogger<Verification.Handler>>());

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "There are no records corresponding to your search!");
            }
        }

        public void InitDataForTest(PhoenixContext context)
        {
            var account1 = GetAccount("ID1", 9999900001, "RO51INGB0000999900001101", "PRF");
            var account2 = GetAccount("ID2", 9999900002, "RO51INGB0000999900001102", "PRF");
            context.Accounts.Add(account1);
            context.Accounts.Add(account2);
            var custChargeType1 = new Domain.CustomerChargeType() { Id = 1, Description = "Per product" };
            var custChargeType2 = new Domain.CustomerChargeType() { Id = 2, Description = "Per transaction" };
            context.CustomerChargeTypes.Add(custChargeType1);
            context.CustomerChargeTypes.Add(custChargeType2);
            var currEUR = new Currency() { CurrencyId = 1, CurrencyCode = "EUR" };
            context.Currencies.Add(currEUR);
            var statusVerifAdd = new Domain.ObjectStatus() { ObjectStatusId = (int)ObjectStatusId.VerificationAdd, ObjectStatusName = Application.Commons.Enums.ObjectStatus.VerificationAdd };
            var statusVerifModify = new Domain.ObjectStatus() { ObjectStatusId = (int)ObjectStatusId.VerificationModify, ObjectStatusName = Application.Commons.Enums.ObjectStatus.VerificationModify };
            var statusVerifDelete = new Domain.ObjectStatus() { ObjectStatusId = (int)ObjectStatusId.VerificationDelete, ObjectStatusName = Application.Commons.Enums.ObjectStatus.VerificationDelete };
            var statusActive = new Domain.ObjectStatus() { ObjectStatusId = (int)ObjectStatusId.Active, ObjectStatusName = Application.Commons.Enums.ObjectStatus.Active };
            var ct1 = new ChargeType() { ChargeTypeId = 1, AmountProduct = 10, ChargeTypeCode = "CT1", CreditAccountShort = 999990001, Curr = currEUR, DefaultAmount = 11, Status = statusActive };
            var ct2 = new ChargeType() { ChargeTypeId = 2, AmountProduct = 20, ChargeTypeCode = "CT2", CreditAccountShort = 999990002, Curr = currEUR, DefaultAmount = 21, Status = statusActive };
            var c1 = new Charge() { ChargeId = 1, Status = statusActive, Currency = currEUR, AtlasId = "ID1", ChargeType = ct1, CreditAccountShort = 9999900001, DebitAccount = "RO51INGB0000999900001101", CustomerChargeType = custChargeType1 };
            var ch1 = new ChargeHistory() { ChargeHistoryId = 1, Charge = c1, AtlasId = "ID1", ChargeType = ct1, Currency = currEUR, LastModifiedBy = "AABBCC", Status = statusVerifAdd, LastModifiedDate = DateTime.Now.AddDays(-1) };
            var c2 = new Charge() { ChargeId = 2, Status = statusActive, Currency = currEUR, AtlasId = "ID2", ChargeType = ct2, CreditAccountShort = 9999900002, DebitAccount = "RO51INGB0000999900001102", CustomerChargeType = custChargeType1, SessionId = 2 };
            var ch2 = new ChargeHistory() { ChargeHistoryId = 2, Charge = c2, AtlasId = "ID2", ChargeType = ct2, Currency = currEUR, LastModifiedBy = "abcdef", Status = statusVerifModify, LastModifiedDate = DateTime.Now.AddDays(-2) };
            var c3 = new Charge() { ChargeId = 3, Status = statusActive, Currency = currEUR, AtlasId = "ID1", ChargeType = ct1, CreditAccountShort = 9999900001, DebitAccount = "RO51INGB0000999900001101", CustomerChargeType = custChargeType1, SessionId = 3 };
            var ch3 = new ChargeHistory() { ChargeHistoryId = 3, Charge = c3, AtlasId = "ID1", ChargeType = ct1, Currency = currEUR, LastModifiedBy = "AABBCC", Status = statusVerifDelete, LastModifiedDate = DateTime.Now.AddDays(-3) };
            var c4 = new Charge() { ChargeId = 4, Status = statusActive, Currency = currEUR, AtlasId = "ID1", ChargeType = ct1, CreditAccountShort = 9999900001, DebitAccount = "RO51INGB0000999900001101", CustomerChargeType = custChargeType2 };
            var ch4 = new ChargeHistory() { ChargeHistoryId = 4, Charge = c4, AtlasId = "ID1", ChargeType = ct1, Currency = currEUR, LastModifiedBy = "AABBCC", Status = statusActive, LastModifiedDate = DateTime.Now.AddDays(-1) };
            context.ChargesHistory.Add(ch1);
            context.ChargesHistory.Add(ch2);
            context.ChargesHistory.Add(ch3);
            context.ChargesHistory.Add(ch4);
            context.SaveChanges();
        }
    }
}
