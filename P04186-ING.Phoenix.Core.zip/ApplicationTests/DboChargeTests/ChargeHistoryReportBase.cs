﻿using System;
using Application.Commons.Enums;
using Application.Reports.CustomerCharges;
using Domain;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;

namespace ApplicationTests.DboChargeTests
{
    public class ChargeHistoryReportBase : TestBase
    {
        protected void InitChargeAndHistoryTabels(PhoenixContext context)
        {
            var statusActive = GetStatusObject(0, Application.Commons.Enums.ObjectStatus.Active);
            var statusVerificationAdd = GetStatusObject(4, Application.Commons.Enums.ObjectStatus.VerificationAdd);
            var statusVerificationModify = GetStatusObject(5, Application.Commons.Enums.ObjectStatus.VerificationModify);
            var statusVerificationDelete = GetStatusObject(6, Application.Commons.Enums.ObjectStatus.VerificationDelete);
            var statusDeleted = GetStatusObject(1, Application.Commons.Enums.ObjectStatus.Deleted);

            var processingFrequencyMonthly = GetProcessingFrequencyObject((int)Application.Commons.Enums.ProcessingFrequency.Monthly, "Monthly");
            var processingFrequencyOnce = GetProcessingFrequencyObject((int)Application.Commons.Enums.ProcessingFrequency.Once, "Once");
            var processingFrequencyQuarterly = GetProcessingFrequencyObject((int)Application.Commons.Enums.ProcessingFrequency.Quarterly, "Quarterly");

            var currency = GetCurrencyObject(1, "RON");

            var objectAction = GetObjectAction(10, "PCM");
            var objectActionAdd = GetObjectAction((int)ObjectAction.ADD, ObjectAction.ADD.ToString());
            var objectActionEdit = GetObjectAction((int)ObjectAction.EDIT, ObjectAction.EDIT.ToString());
            var objectActionDelete = GetObjectAction((int)ObjectAction.DELETE, ObjectAction.DELETE.ToString());
            var objectActionApprove = GetObjectAction((int)ObjectAction.APPROVE, ObjectAction.APPROVE.ToString());
            var objectActionReject = GetObjectAction((int)ObjectAction.REJECT, ObjectAction.REJECT.ToString());
            var objectActionImport = GetObjectAction((int)ObjectAction.IMPORT, ObjectAction.IMPORT.ToString());

            context.ObjectActions.Add(objectAction);
            context.ObjectActions.Add(objectActionAdd);
            context.ObjectActions.Add(objectActionEdit);
            context.ObjectActions.Add(objectActionDelete);
            context.ObjectActions.Add(objectActionApprove);
            context.ObjectActions.Add(objectActionReject);
            context.ObjectActions.Add(objectActionImport);

            var chargeTypeActive1 = GetChargeTypeObject(1, currency, processingFrequencyMonthly, statusActive);
            var chargeTypeActive2 = GetChargeTypeObject(2, currency, processingFrequencyMonthly, statusActive);
            context.ChargeTypes.Add(chargeTypeActive1);
            context.ChargeTypes.Add(chargeTypeActive2);

            var accountState = GetChargeAccountState(0, "OK");
            context.ChargeAccountStates.Add(accountState);

            var account1 = GetAccount("MEGIMA", 7510002001, "RO51INGB0000999900001101", "GBS");
            var account2 = GetAccount("KAUROM", 8213560710, "RO51INGB0000999900001102", "GBS");
            var account3 = GetAccount("ZARA", 7510002991, "RO51INGB0000999900001103", "GBS");
            var account4 = GetAccount("ZARAHOME", 7511302991, "RO51INGB0000999900001104", "GBS");
            var account5 = GetAccount("MANGO", 9911302991, "RO51INGB0000999900001105", "GBS");
            context.Accounts.Add(account1);
            context.Accounts.Add(account2);
            context.Accounts.Add(account3);
            context.Accounts.Add(account4);
            context.Accounts.Add(account5);

            // add one charge and chargeHistory for verification delete
            var chargeDeleted = GetChargeObject(1, "1", chargeTypeActive1, statusDeleted, currency, accountState);
            context.Charges.Add(chargeDeleted);
            context.ChargesHistory.Add(GetChargeHistoryObject(1, "1", chargeDeleted, chargeTypeActive1, objectActionDelete, statusVerificationDelete, currency, account1.IBAN, lastModifyDate: DateTime.Now.AddDays(-1)));
            context.ChargesHistory.Add(GetChargeHistoryObject(2, "1", chargeDeleted, chargeTypeActive1, objectActionApprove, statusDeleted, currency, account1.IBAN, lastModifyDate: DateTime.Now));

            // add one charge and chargeHistory for verification add
            var chargeActive = GetChargeObject(2, "2", chargeTypeActive1, statusActive, currency, accountState);
            context.Charges.Add(chargeActive);
            context.ChargesHistory.Add(GetChargeHistoryObject(3, "2", chargeActive, chargeTypeActive1, objectActionAdd, statusVerificationAdd, currency, account2.IBAN, lastModifyDate: DateTime.Now.AddDays(-1)));
            context.ChargesHistory.Add(GetChargeHistoryObject(4, "2", chargeActive, chargeTypeActive1, objectActionApprove, statusActive, currency, account2.IBAN, lastModifyDate: DateTime.Now));

            // add one charge active and chargeHistory for verification modify approve
            var chargeVerificationModifyApprove = GetChargeObject(3, "3", chargeTypeActive1, statusActive, currency, accountState);
            context.Charges.Add(chargeActive);
            context.ChargesHistory.Add(GetChargeHistoryObject(5, "3", chargeVerificationModifyApprove, chargeTypeActive1, objectActionEdit, statusVerificationModify, currency, account3.IBAN, lastModifyDate: DateTime.Now.AddDays(-1)));
            context.ChargesHistory.Add(GetChargeHistoryObject(6, "3", chargeVerificationModifyApprove, chargeTypeActive1, objectActionApprove, statusActive, currency, account3.IBAN, lastModifyDate: DateTime.Now));


            // add one charge active and chargeHistory for verification modify reject
            var chargeVerificationModifyReject = GetChargeObject(4, "4", chargeTypeActive1, statusActive, currency, accountState);
            context.Charges.Add(chargeActive);
            context.ChargesHistory.Add(GetChargeHistoryObject(7, "4", chargeVerificationModifyReject, chargeTypeActive1, objectActionEdit, statusVerificationModify, currency, account4.IBAN, lastModifyDate: DateTime.Now.AddDays(-1)));
            context.ChargesHistory.Add(GetChargeHistoryObject(8, "4", chargeVerificationModifyReject, chargeTypeActive1, objectActionReject, statusActive, currency, account4.IBAN, lastModifyDate: DateTime.Now));

            // add one charge active and chargeHistory for verification modify reject
            var chargeWithManyModifications = GetChargeObject(5, "5", chargeTypeActive2, statusActive, currency, accountState);
            context.Charges.Add(chargeActive);
            context.ChargesHistory.Add(GetChargeHistoryObject(9, "5", chargeWithManyModifications, chargeTypeActive2, objectActionAdd, statusVerificationAdd, currency, account5.IBAN, lastModifyDate: DateTime.Now.AddDays(-9)));
            context.ChargesHistory.Add(GetChargeHistoryObject(10, "5", chargeWithManyModifications, chargeTypeActive2, objectActionApprove, statusActive, currency, account5.IBAN, lastModifyBy: "AMAN", lastModifyDate: DateTime.Now.AddDays(-8)));
            context.ChargesHistory.Add(GetChargeHistoryObject(11, "5", chargeWithManyModifications, chargeTypeActive2, objectActionEdit, statusVerificationModify, currency, account5.IBAN, lastModifyDate: DateTime.Now.AddDays(-6)));
            context.ChargesHistory.Add(GetChargeHistoryObject(12, "5", chargeWithManyModifications, chargeTypeActive2, objectActionApprove, statusActive, currency, account5.IBAN, lastModifyBy: "AMAN", lastModifyDate: DateTime.Now.AddDays(-5)));
            context.ChargesHistory.Add(GetChargeHistoryObject(13, "5", chargeWithManyModifications, chargeTypeActive2, objectActionEdit, statusVerificationModify, currency, account5.IBAN, lastModifyDate: DateTime.Now.AddDays(-4)));
            context.ChargesHistory.Add(GetChargeHistoryObject(14, "5", chargeWithManyModifications, chargeTypeActive2, objectActionReject, statusActive, currency, account5.IBAN, lastModifyBy: "AMAN", lastModifyDate: DateTime.Now.AddDays(-3)));
            context.ChargesHistory.Add(GetChargeHistoryObject(15, "5", chargeWithManyModifications, chargeTypeActive2, objectActionDelete, statusVerificationDelete, currency, account5.IBAN, lastModifyDate: DateTime.Now.AddDays(-2)));
            context.ChargesHistory.Add(GetChargeHistoryObject(16, "5", chargeWithManyModifications, chargeTypeActive2, objectActionReject, statusActive, currency, account5.IBAN, lastModifyBy: "AMAN", lastModifyDate: DateTime.Now));

            var customerChargeType1 = GetCustomerChargeTypeObject(1, "PerProduct");
            var customerChargeType2 = GetCustomerChargeTypeObject(2, "PerTransaction");
            context.CustomerChargeTypes.Add(customerChargeType1);
            context.CustomerChargeTypes.Add(customerChargeType2);

            context.DeletedChargesHistory.Add(GetDeletedChargeHistoryObject(1, account3.CustomerId, chargeTypeActive1.ChargeTypeId, statusVerificationAdd.ObjectStatusId, currency.CurrencyId,
                objectActionImport.ActionId, 1111, account3.IBAN, lastModifyBy: "AMAN", lastModifyDate: DateTime.Now));
            context.DeletedChargesHistory.Add(GetDeletedChargeHistoryObject(2, account3.CustomerId, chargeTypeActive1.ChargeTypeId, statusDeleted.ObjectStatusId, currency.CurrencyId,
                objectActionApprove.ActionId, 1111, account3.IBAN, lastModifyBy: "AMAN", lastModifyDate: DateTime.Now));
            context.SaveChanges();
        }

        protected CustomerChargesFilter SetCustomerChargesFilter(string sortField = "", string sortOrder = "", string customerID = "", string customerName = "", int chargeTypeId = -1,
            string user = "All", int actionId = -1, int statusId = -1, DateTime? dateStart = null, DateTime? dateEnd = null,
            int pageNumber = 1, int pageSize = 15)
        {
            return new CustomerChargesFilter
            {
                SortField = sortField,
                SortOrder = sortOrder,
                CustomerID = customerID,
                CustomerName = customerName,
                ChargeTypeId = chargeTypeId,
                User = user,
                ActionId = actionId,
                StatusId = statusId,
                DateStart = dateStart,
                DateEnd = dateEnd,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }

        protected void ArrangeOnChargesHistoryReportList(PhoenixContext context, CustomerChargesFilter customerChargesFilter,
                out ListForReport.Query query, out ListForReport.Handler handler)
        {
            InitChargeAndHistoryTabels(context);

            query = new ListForReport.Query() { CustomerChargesFilter = customerChargesFilter };
            handler = new ListForReport.Handler(context, Mock.Of<ILogger<ListForReport.Handler>>());
        }
    }
}
