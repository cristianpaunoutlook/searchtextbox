﻿using Application.Commons.Enums;
using Application.DboCharge;
using Microsoft.Extensions.Logging;
using Moq;
using Persistence;
using System.Threading;

namespace ApplicationTests.DboChargeTests
{
    public class ChargeBaseTests : TestBase
    {
        protected const int ChargeActive = 1;
        protected const int ChargeDeleted = 3;
        protected const int ChargeNotValid = 99;
        protected const int ChargeWithoutHist = 2;
        protected const int ChargeHistoryNotActive = 4;
        protected const int ChargeVerificationAdd = 15;
        protected const int ChargeActivePerProduct = 14;

        protected const string AtlasIdActive = "MEGIMA";
        protected const string AtlasPerTransaction = "1";
        protected const string AtlasIdPerProduct = "10";
        protected const string AtlasIdNotInTheDb = "Customer";
        protected const string AtlasIdNotActiveInTheDb = "TestCustomer";

        protected const string CustomerIdActive = "TestCustomerUpdate";
        protected const string CustomerIdActiveForReject = "TestCustomerReject";

        protected const int ChargeTypeActive = 2;
        protected const int ChargeTypeFCOM = 3;
        protected const int ChargeTypeRECO = 5;
        protected const int InvalidChargeType = 1000;
        protected const int ChargeTypeActiveForLeadingZeros = 4;
        protected const int ChargeTypeOnce = 6;

        protected const int CustomerChargeTypePerProduct = 1;
        protected const int CustomerChargeTypePerTransaction = 2;

        protected const int StandardValue = 1;
        protected const int NegotiatedValue = 2;

        protected const long ValidCreditAccountShort = 7510002001;
        protected const long InvalidCreditAccountShort = 1231231230;
        protected const long ActiveChargeCreditAccountShort = 10000000000;

        public void InitChargeAndChargeHistory(PhoenixContext context)
        {
            var standarGroupCT = new Domain.ChargeTypeGroup() { Id = 1, Code = "DEFAULT" };
            context.ChargeTypeGroups.Add(standarGroupCT);
            var fcomGroupCT = new Domain.ChargeTypeGroup() { Id = 2, Code = "FCOM" };
            context.ChargeTypeGroups.Add(fcomGroupCT);
            var recoGroupCT = new Domain.ChargeTypeGroup() { Id = 3, Code = "RECO" };
            context.ChargeTypeGroups.Add(recoGroupCT);

            var statusActive = GetStatusObject(0, Application.Commons.Enums.ObjectStatus.Active);
            var statusVerificationAdd = GetStatusObject(4, Application.Commons.Enums.ObjectStatus.VerificationAdd);
            var statusVerificationModify = GetStatusObject(5, Application.Commons.Enums.ObjectStatus.VerificationModify);
            var statusVerificationDelete = GetStatusObject(6, Application.Commons.Enums.ObjectStatus.VerificationDelete);
            var statusDeleted = GetStatusObject(1, Application.Commons.Enums.ObjectStatus.Deleted);
            var statusRejectAdd = GetStatusObject(7, Application.Commons.Enums.ObjectStatus.RejectAdd);

            var processingFrequencyMonthly = GetProcessingFrequencyObject(4, "Monthly");
            var processingFrequencyOnce = GetProcessingFrequencyObject(1, "Once");

            var currency = GetCurrencyObject(1, "RON");

            var objectAction = GetObjectAction(10, "PCM");
            context.ObjectActions.Add(objectAction);
            context.ObjectStatus.Add(statusRejectAdd);
            var gbsDebitAccountType = GetGBSCreditAccountType("CHRE");
            var accountState = GetChargeAccountState(0, "OK");
            context.ChargeAccountStates.Add(accountState);
            context.Add(gbsDebitAccountType);
            var account1 = GetAccount("MEGIMA", 7510002001, string.Empty, "GBS");
            var account2 = GetAccount("1", 8213560710, "RO59INGB0001008213560710", "GBS");
            var account3 = GetAccount("10", 7510002991, string.Empty, "GBS");
            var account4 = GetAccount("Customer", 7511302991, string.Empty, "GBS");
            var account5 = GetAccount("TestCustomer", 9911302991, string.Empty, "GBS");
            var accountForLeadingZeros = GetAccount("Customer", 131310, string.Empty, "GBS");
            context.Accounts.Add(account1);
            context.Accounts.Add(account2);
            context.Accounts.Add(account3);
            context.Accounts.Add(account4);
            context.Accounts.Add(account5);
            context.Accounts.Add(accountForLeadingZeros);

            var customerInactive = GetCustomer("TestCustomer", (byte)ObjectStatusId.NotSet);
            context.Customers.Add(customerInactive);

            var customerActive = GetCustomer("TestCustomerUpdate", (byte)ObjectStatusId.Active);
            context.Customers.Add(customerActive);

            var customerActiveForReject = GetCustomer("TestCustomerReject", (byte)ObjectStatusId.Active);
            context.Customers.Add(customerActiveForReject);

            var customerDeleted = GetCustomer("10", (byte)ObjectStatusId.Deleted);
            context.Customers.Add(customerDeleted);

            var customerDeleted2 = GetCustomer("9", (byte)ObjectStatusId.Deleted);
            context.Customers.Add(customerDeleted2);


            //add CT & CTH both deleted in order to test that associated charges can not be modified
            var chargeTypeDeleted = GetChargeTypeObject(1, currency, processingFrequencyOnce, statusDeleted);
            context.ChargeTypes.Add(chargeTypeDeleted);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(1, currency, processingFrequencyOnce, objectAction, statusDeleted, chargeTypeDeleted));

            // add CT & CTH both actives in order to asociate it to charges
            var chargeTypeActive = GetChargeTypeObject(ChargeTypeActive, currency, processingFrequencyMonthly, statusActive);
            context.ChargeTypes.Add(chargeTypeActive);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(3, currency, processingFrequencyMonthly, objectAction, statusActive, chargeTypeActive));

            // add CT & CTH both actives in order to asociate it to charges
            var chargeTypeActiveForLeadingZeros = GetChargeTypeObject(ChargeTypeActiveForLeadingZeros, currency, processingFrequencyMonthly, statusActive, creditAccountShort: 131310);
            context.ChargeTypes.Add(chargeTypeActiveForLeadingZeros);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(3, currency, processingFrequencyMonthly, objectAction, statusActive, chargeTypeActiveForLeadingZeros));

            // add CT & CTH both actives in order to asociate it to charges
            var fcomChargeType = GetChargeTypeObject(ChargeTypeFCOM, currency, processingFrequencyMonthly, statusActive, groupId: 2);
            context.ChargeTypes.Add(fcomChargeType);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(4, currency, processingFrequencyMonthly, objectAction, statusActive, fcomChargeType));

            // add CT & CTH both actives in order to asociate it to charges
            var recoChargeType = GetChargeTypeObject(ChargeTypeRECO, currency, processingFrequencyOnce, statusActive, groupId: recoGroupCT.Id);
            context.ChargeTypes.Add(recoChargeType);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(5, currency, processingFrequencyOnce, objectAction, statusActive, recoChargeType));
            
 		var chargeTypeOnce = GetChargeTypeObject(ChargeTypeOnce, currency, processingFrequencyOnce, statusActive, groupId: 2);
            context.ChargeTypes.Add(chargeTypeOnce);
            context.ChargeTypeHistories.Add(GetChargeTypeHistoryObject(4, currency, processingFrequencyOnce, objectAction, statusActive, chargeTypeOnce));

            //add Charge and ChargeHistory status Active to test RECO charges
            var chargeActiveForReco = GetChargeObject(22, "1", recoChargeType, statusActive, currency, accountState,paymentDetails: "testRE0210125308745test",debitAccount: "RO59INGB0001008213560710");
            context.ChargesHistory.Add(GetChargeHistoryObject(29, "1", chargeActiveForReco, recoChargeType, objectAction, statusVerificationAdd, currency, debitAccount: "RO59INGB0001008213560710", paymentDetails: "testRE0210125308745test"));
            context.ChargesHistory.Add(GetChargeHistoryObject(30, "1", chargeActiveForReco, recoChargeType, objectAction, statusActive, currency, debitAccount: "RO59INGB0001008213560710", paymentDetails: "testRE0210125308745test"));
            var chargeActiveForReco2 = GetChargeObject(23, "1", recoChargeType, statusActive, currency, accountState, paymentDetails: "testPA0210125308745test", debitAccount: "RO59INGB0001008213560710");
            context.ChargesHistory.Add(GetChargeHistoryObject(31, "1", chargeActiveForReco2, recoChargeType, objectAction, statusVerificationAdd, currency, debitAccount: "RO59INGB0001008213560710", paymentDetails: "testPA0210125308745test"));
            context.ChargesHistory.Add(GetChargeHistoryObject(32, "1", chargeActiveForReco2, recoChargeType, objectAction, statusActive, currency, debitAccount: "RO59INGB0001008213560710", paymentDetails: "testPA0210125308745test"));
            // add Charge and ChargeHistory status Active per product to test delete => after delete status for charge is active and for history verificationDelete
            var chargeActivePerTransaction = GetChargeObject(1, "1", chargeTypeActive, statusActive, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(1, "1", chargeActivePerTransaction, chargeTypeActive, objectAction, statusVerificationAdd, currency));
            context.ChargesHistory.Add(GetChargeHistoryObject(2, "1", chargeActivePerTransaction, chargeTypeActive, objectAction, statusActive, currency));

            // add Charge and ChargeHistory status Active per transaction to test delete => after delete status for charge is active and for history verificationDelete
            var chargeActivePerProduct = GetChargeObject(14, "10", chargeTypeActive, statusActive, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(20, "10", chargeActivePerProduct, chargeTypeActive, objectAction, statusVerificationAdd, currency));
            context.ChargesHistory.Add(GetChargeHistoryObject(21, "10", chargeActivePerProduct, chargeTypeActive, objectAction, statusActive, currency));

            // add Charge without ChargeHistory to test delete => throw exception
            var chargeActiveNoHistory = GetChargeObject(2, "2", chargeTypeActive, statusActive, currency, accountState);
            context.Charges.Add(chargeActiveNoHistory);

            // add charge status deleted and history active => on delete throw exception
            var chargeActiveDeletedHistoryDeleted = GetChargeObject(3, "3", chargeTypeActive, statusDeleted, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(3, "3", chargeActiveDeletedHistoryDeleted, chargeTypeActive, objectAction, statusActive, currency));

            // add charge status active and history verificationDelete => on delete throw exception
            var chargeActiveHistoryDeleted = GetChargeObject(4, "4", chargeTypeActive, statusActive, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(4, "4", chargeActiveHistoryDeleted, chargeTypeActive, objectAction, statusVerificationDelete, currency));

            var chargeActiveList1 = GetChargeObject(5, "5", chargeTypeActive, statusActive, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(5, "5", chargeActiveList1, chargeTypeActive, objectAction, statusVerificationAdd, currency));
            context.ChargesHistory.Add(GetChargeHistoryObject(6, "5", chargeActiveList1, chargeTypeActive, objectAction, statusActive, currency));

            var chargeActiveList2 = GetChargeObject(6, "5", chargeTypeActive, statusActive, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(7, "5", chargeActiveList2, chargeTypeActive, objectAction, statusVerificationAdd, currency));
            context.ChargesHistory.Add(GetChargeHistoryObject(8, "5", chargeActiveList2, chargeTypeActive, objectAction, statusActive, currency));

            var chargeActiveList3 = GetChargeObject(7, "5", chargeTypeActive, statusActive, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(9, "5", chargeActiveList3, chargeTypeActive, objectAction, statusVerificationAdd, currency));
            context.ChargesHistory.Add(GetChargeHistoryObject(10, "5", chargeActiveList3, chargeTypeActive, objectAction, statusActive, currency));

            var chargeActiveList4 = GetChargeObject(8, "5", chargeTypeActive, statusDeleted, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(11, "5", chargeActiveList4, chargeTypeActive, objectAction, statusActive, currency));
            context.ChargesHistory.Add(GetChargeHistoryObject(12, "5", chargeActiveList4, chargeTypeActive, objectAction, statusDeleted, currency));

            var chargeActiveList5 = GetChargeObject(9, "6", chargeTypeActive, statusDeleted, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(13, "6", chargeActiveList5, chargeTypeActive, objectAction, statusVerificationDelete, currency));
            context.ChargesHistory.Add(GetChargeHistoryObject(14, "6", chargeActiveList5, chargeTypeActive, objectAction, statusDeleted, currency));

            //ad CT and CTH in status Verification Add in order to check that throws exeption if try to edit
            var chargeVerificationAdd = GetChargeObject(15, "Customer", chargeTypeActive, statusVerificationAdd, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(22, "Customer", chargeVerificationAdd, chargeTypeActive, objectAction, statusVerificationAdd, currency));

            #region approve-reject
            var chargeActiveVerificationModify = GetChargeObject(10, "7", chargeTypeActive, statusActive, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(15, "7", chargeActiveVerificationModify, chargeTypeActive, objectAction, statusActive, currency));
            context.ChargesHistory.Add(GetChargeHistoryObject(16, "7", chargeActiveVerificationModify, chargeTypeActive, objectAction, statusVerificationModify, currency));


            var chargeAdded = GetChargeObject(11, "9", chargeTypeActive, statusVerificationAdd, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(17, "9", chargeAdded, chargeTypeActive, objectAction, statusVerificationAdd, currency));

            var secondChargeAdded = GetChargeObject(16, "1", chargeTypeActive, statusVerificationAdd, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(23, "1", secondChargeAdded, chargeTypeActive, objectAction, statusVerificationAdd, currency));

            var chargeActiveVerificationDelete = GetChargeObject(12, "10", chargeTypeActive, statusActive, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(18, "10", chargeActiveVerificationDelete, chargeTypeActive, objectAction, statusActive, currency));
            context.ChargesHistory.Add(GetChargeHistoryObject(19, "10", chargeActiveVerificationDelete, chargeTypeActive, objectAction, statusVerificationDelete, currency));

            //ad charge active and ch in verification delete in order to test approve delete for customer
            var chargeActiveForCustomer = GetChargeObject(17, "CustomerTest", chargeTypeActive, statusActive, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(24, "CustomerTest", chargeActiveForCustomer, chargeTypeActive, objectAction, statusVerificationDelete, currency));

            //ad charge active and ch in verification delete in order to test approve delete for customer
            var chargeActiveForCustomerUpdate = GetChargeObject(18, "TestCustomerUpdate", chargeTypeActive, statusActive, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(25, "TestCustomerUpdate", chargeActiveForCustomerUpdate, chargeTypeActive, objectAction, statusVerificationDelete, currency));

            // ad charge and ch in reject add to test approve delete for customer
            var chargeRejectAddForCustomerUpdate = GetChargeObject(19, "TestCustomerUpdate", chargeTypeActive, statusRejectAdd, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(26, "TestCustomerUpdate", chargeRejectAddForCustomerUpdate, chargeTypeActive, objectAction, statusRejectAdd, currency));

            //ad charge deleted and cth deleted to test reject add for cutomer
            var chargeDeletedForCustomerUpdate = GetChargeObject(20, "TestCustomerReject", chargeTypeActive, statusDeleted, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(27, "TestCustomerReject", chargeDeletedForCustomerUpdate, chargeTypeActive, objectAction, statusDeleted, currency));

            // ad charge and ch in verificationadd to test approve delete for customer
            var chargeActiveForRejectCustomerUpdate = GetChargeObject(21, "TestCustomerReject", chargeTypeActive, statusVerificationAdd, currency, accountState);
            context.ChargesHistory.Add(GetChargeHistoryObject(28, "TestCustomerReject", chargeActiveForRejectCustomerUpdate, chargeTypeActive, objectAction, statusVerificationAdd, currency));
            #endregion approve-reject

            context.SaveChanges();
        }

        protected void ArrangeOnChargeDelete(PhoenixContext context, int chargeTypeId, out Delete.Command command, out Delete.Handler handler)
        {
            InitChargeAndChargeHistory(context);

            command = new Delete.Command()
            {
                ChargeId = chargeTypeId,
            };

            handler = new Delete.Handler(context, GetMapper(), Mock.Of<ILogger<Delete.Handler>>());
        }

        protected void ArrangeOnChargeTypeList(PhoenixContext context, string customerid, out List.Query query, out List.Handler handler)
        {
            InitChargeAndChargeHistory(context);

            query = new List.Query() { CustomerId = customerid };
            handler = new List.Handler(context, Mock.Of<ILogger<List.Handler>>());
        }

        protected void ArrangeOnChargeCreate(PhoenixContext context, string atlasiId, int chargeTypeId, int customerChargeTypeId, int valueId, 
            long creditAccountShort, out Create.Command command, out Create.Handler handler, int? currencyId = 1, decimal? specialAmount = 100, string paymentDetails = "")
        {
            InitChargeAndChargeHistory(context);

            command = new Create.Command()
            {
                AtlasId = atlasiId,
                ValueId = valueId,
                ChargeTypeId = chargeTypeId,
                CustomerChargeTypeId = customerChargeTypeId,
                SpecialAmount = specialAmount,
                CurrencyId = currencyId,
                ChargedItems = 1,
                DebitAccount = "RO59INGB0001008213560710",
                CreditAccountShort = creditAccountShort,
                PaymentDetails = paymentDetails
            };

            handler = new Create.Handler(context, GetMapper(), Mock.Of<ILogger<Create.Handler>>());
        }

        protected static void ActOnChargeCreate(Create.Command command, Create.Handler handler)
        {
            var result = handler.Handle(command, (new CancellationTokenSource()).Token);
        }

        protected void ArrangeOnChargeEdit(PhoenixContext context, int chargeId, string atlasiId, int chargeTypeId, int customerChargeTypeId, 
            int valueId, long creditAccountShort, out Edit.Command command, out Edit.Handler handler, string paymentdetails = "")
        {
            InitChargeAndChargeHistory(context);

            command = new Edit.Command()
            {
                ChargeId = chargeId,
                AtlasId = atlasiId,
                ValueId = valueId,
                ChargeTypeId = chargeTypeId,
                CustomerChargeTypeId = customerChargeTypeId,
                SpecialAmount = 100,
                CurrencyId = 1,
                ChargedItems = 1,
                DebitAccount = "RO59INGB0001008213560710",
                CreditAccountShort = creditAccountShort,
                PaymentDetails = paymentdetails
            };

            handler = new Edit.Handler(context, GetMapper(), Mock.Of<ILogger<Edit.Handler>>());
        }

        protected void ActOnChargeEdit(Edit.Command command, Edit.Handler handler)
        {
            var result = handler.Handle(command, (new CancellationTokenSource()).Token);
        }
        protected void ArrangeOnChargeApprove(PhoenixContext context, int chargeId, string userKey, out Approve.Command command, out Approve.Handler handler)
        {
            InitChargeAndChargeHistory(context);

            command = new Approve.Command()
            {
                ChargeId = chargeId,
                UserKey = userKey,
            };

            handler = new Approve.Handler(context, GetMapper(), Mock.Of<ILogger<Approve.Handler>>());
        }

        protected void ArrangeOnChargeReject(PhoenixContext context, int chargeId, string userKey, string rejectReason, out Reject.Command command, out Reject.Handler handler)
        {
            InitChargeAndChargeHistory(context);

            command = new Reject.Command()
            {
                ChargeId = chargeId,
                RejectReason = rejectReason,
                UserKey = userKey,
            };

            handler = new Reject.Handler(context, GetMapper(), Mock.Of<ILogger<Reject.Handler>>());
        }
    }
}
