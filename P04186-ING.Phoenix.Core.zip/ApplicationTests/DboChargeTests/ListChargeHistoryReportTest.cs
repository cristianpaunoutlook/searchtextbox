﻿using System;
using System.Threading;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ApplicationTests.DboChargeTests
{
    [TestClass]
    public class ListChargeHistoryReportTest : ChargeHistoryReportBase
    {
        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDb()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(pageSize: 20);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 18);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbForFirstPage()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(pageNumber: 1, pageSize: 5);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 5);
            }
        }

        [TestMethod]
        public void ShouldReturnEmptyListIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(pageNumber: 4, pageSize: 15);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "Customer charges history for the values from filters does not exist in the database!") ;
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageNumberIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(pageNumber: -3, pageSize: 15);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 15);
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var customerChargesFilter = SetCustomerChargesFilter(pageNumber: 1, pageSize: 100);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                  out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbSortedAscByStatusId()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(sortField: "statusId", sortOrder: "asc", chargeTypeId: 2, pageNumber: 1, pageSize: 20);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 8 && customerCharges.Items[0].StatusId == 0);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbSortedDescByStatusId()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(sortField: "statusId", sortOrder: "desc", chargeTypeId: 2, pageNumber: 1, pageSize: 20);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 8 && customerCharges.Items[0].StatusId == 6);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByCustomerId()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(customerID: "1");

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 2);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByCustomerName()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(customerName: "Name MEGIMA");

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 2);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByChargeType()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(chargeTypeId: 2);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 8);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByDate()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(dateStart: DateTime.Now.AddDays(-3), dateEnd: DateTime.Now);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 13);
            }
        }

        [TestMethod]
        public void ShouldThrowErrorWhenFilteredByDateAndDateStartGreaterThanDateEnd()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(dateStart: DateTime.Now, dateEnd: DateTime.Now.AddDays(-1));

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "Start date cannot be greater than end date!");
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByUser()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(user: "AMAN");

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 6);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByAction()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(actionId: 5);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 2);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByStatus()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(statusId: 5);

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 4);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByMultipleValuesNoDateEnd()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(user: "AMAN", statusId: 0, dateStart: DateTime.Now.AddDays(-3));

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 1);
            }
        }

        [TestMethod]
        public void ShouldReturnAllChargesHistoryFromDbFilteredByMultipleValuesNoStartDate()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(user: "AMAN", statusId: 0, dateEnd: DateTime.Now.AddDays(-2));

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act
                var customerCharges = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(customerCharges.Items.Count == 1);
            }
        }

        [TestMethod]
        public void ShouldThrowErrorWhenFilteredValuesDontMatch()
        {
            using (var context = GetDbContext())
            {
                //arrange
                var customerChargesFilter = SetCustomerChargesFilter(customerID: "TestCustomer");

                ArrangeOnChargesHistoryReportList(context, customerChargesFilter, out var query,
                   out var handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                    "Customer charges history for the values from filters does not exist in the database!");
            }
        }
    }
}
