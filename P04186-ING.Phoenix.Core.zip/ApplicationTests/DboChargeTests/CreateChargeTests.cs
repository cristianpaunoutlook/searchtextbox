﻿using Application.Commons.Enums;
using Application.DboCharge;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Persistence;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboChargeTests
{
    [TestClass]
    public class CreateChargeTests : ChargeBaseTests
    {
        [TestMethod]
        public void ShouldAddCharge()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arange
                ArrangeOnChargeCreate(context, AtlasIdActive, ChargeTypeActive, CustomerChargeTypePerProduct, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler, paymentDetails: "Payment Detail 2");

                //Act
                ActOnChargeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.Charges.Any(c => c.AtlasId == AtlasIdActive && c.ChargeTypeId == ChargeTypeActive &&
                    c.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.AtlasId == AtlasIdActive && ch.ChargeTypeId == ChargeTypeActive &&
                    ch.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
            }
        }

        [TestMethod]
        public void ShouldAddChargeForRecoSamePaymentDetails()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arange
                ArrangeOnChargeCreate(context, AtlasIdActive, ChargeTypeRECO, CustomerChargeTypePerProduct, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler, paymentDetails: "other test");

                //Act
                ActOnChargeCreate(command, handler);

                // Assert 
                Assert.IsTrue(context.Charges.Any(c => c.ChargeType.GroupId == 3 && c.PaymentDetails== "other test"));
            }
        }

        [TestMethod]
        public void ShouldNotAddChargeForRecoSamePaymentDetails()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arange
                ArrangeOnChargeCreate(context, AtlasIdActive, ChargeTypeRECO, CustomerChargeTypePerProduct, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler, paymentDetails: "RE0210125308745");

                //Act
                ActOnChargeCreate(command, handler);

                // Assert 
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                "Charge code RECOCRAMS already exits on same debit account!");
            }
        }

        [TestMethod]
        public void ShouldNotAddChargeWithIncorrectCreditAccountShort()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasIdActive, ChargeTypeActive, CustomerChargeTypePerProduct, NegotiatedValue,
                    InvalidCreditAccountShort, out Create.Command command, out Create.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Credit account short is invalid");
            }
        }

        [TestMethod]
        public void ShouldNotAddFCOMWithStandardValue()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasIdActive, ChargeTypeFCOM, CustomerChargeTypePerProduct, StandardValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler, currencyId: null, specialAmount: null);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "FCOM charge type should have negociated value");
            }
        }

        [TestMethod]
        public void ShouldAddFCOMWithNegociatedValueAndPerTransaction()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasIdActive, ChargeTypeFCOM, CustomerChargeTypePerProduct, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler, paymentDetails: "Payment Detail 3");

                // Act
                ActOnChargeCreate(command, handler);

                // Asert
                Assert.IsTrue(context.Charges.Any(c => c.ChargeType.ChargeTypeGroup.Code == "FCOM"));
            }
        }

        [TestMethod]
        public void ShouldNotAddFCOMWithPerTransaction()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasIdActive, ChargeTypeFCOM, CustomerChargeTypePerTransaction, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "FCOM charge should have per product customer charge type");
            }
        }


        [TestMethod]
        public void ShouldNotAddChargeWithPerProductIfAlreadyExistsPerTransaction()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasPerTransaction, ChargeTypeActive, CustomerChargeTypePerProduct, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Charge already has per transaction!");
            }
        }

        [TestMethod]
        public void ShouldNotAddChargeWithPerTransactionIfAlreadyExistsPerProduct()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasIdPerProduct, ChargeTypeActive, CustomerChargeTypePerTransaction, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Charge already has per product!");
            }
        }

        [TestMethod]
        public void ShouldAddCustomerInTheDbIfNotExists()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasIdNotInTheDb, ChargeTypeActive, CustomerChargeTypePerProduct, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler, paymentDetails: "Payment Detail 2");

                //Act
                ActOnChargeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.Customers.Any(c => c.AtlasID == AtlasIdNotInTheDb && c.StatusId == (byte)ObjectStatusId.Active));
            }
        }

        [TestMethod]
        public void ShouldUpdateCustomerStatusToActiveIfItIsNotActive()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasIdNotActiveInTheDb, ChargeTypeActive, CustomerChargeTypePerProduct, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler, paymentDetails: "Payment Detail 2");

                //Act
                ActOnChargeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.Customers.Any(c => c.AtlasID == AtlasIdNotActiveInTheDb && c.StatusId == (byte)ObjectStatusId.Active));
            }
        }

        [TestMethod]
        public void ShouldNotAddChargeIfChargeTypeIsInvalid()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasIdActive, InvalidChargeType, CustomerChargeTypePerProduct, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "You cannot add this charge because charge type does not exists in the database!");
            }
        }

        [TestMethod]
        public void ShouldNotAddChargeIfStandardAndCrrencyOrAmountNotNull()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasIdActive, ChargeTypeActive, CustomerChargeTypePerProduct, StandardValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler);

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "You cannot add this charge for standard amount and currency must be null!");
            }
        }

        [TestMethod]
        public void ShouldRemoveLeadingZerosFromCreditAccountShort()
        {
            using (PhoenixContext context = GetDbContext())
            {
                //arange
                ArrangeOnChargeCreate(context, AtlasIdActive, ChargeTypeActiveForLeadingZeros, CustomerChargeTypePerProduct, NegotiatedValue,
                    0000131310, out Create.Command command, out Create.Handler handler, paymentDetails: "Payment Detail 4");

                //Act
                ActOnChargeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.Charges.Any(c => c.AtlasId == AtlasIdActive && c.ChargeTypeId == ChargeTypeActiveForLeadingZeros &&
                    c.CreditAccountShort == 131310 && c.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.AtlasId == AtlasIdActive && ch.ChargeTypeId == ChargeTypeActiveForLeadingZeros &&
                    ch.CreditAccountShort == 131310 && ch.Status.ObjectStatusName == ObjectStatus.VerificationAdd));
            }
        }

        [TestMethod]
        public void ChargeWithPaymentDetailDifferentThanCTAndOtherThanOnceShouldThrowError()
        {
            using (var context = GetDbContext())
            {
                //arrange
                ArrangeOnChargeCreate(context, AtlasIdPerProduct, ChargeTypeActive, CustomerChargeTypePerTransaction, NegotiatedValue,
                    ValidCreditAccountShort, out Create.Command command, out Create.Handler handler, paymentDetails: "Payment Details Different");

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "For charge other than once payment details for customer charge must be the same with payment details for charge!");
            }
        }

        [TestMethod]
        public void IfCTOnceAndChargePaymentDetailsEmptyAddPaymentDetailsFromCT()
        {
            using (var context = GetDbContext())
            {
                //arange
                ArrangeOnChargeCreate(context, AtlasIdActive, ChargeTypeOnce, CustomerChargeTypePerProduct, NegotiatedValue,
                    7510002001, out Create.Command command, out Create.Handler handler, paymentDetails: "");

                //Act
                ActOnChargeCreate(command, handler);

                // Assert
                Assert.IsTrue(context.Charges.Any(c => c.AtlasId == AtlasIdActive && c.ChargeTypeId == ChargeTypeOnce &&
                    c.CreditAccountShort == 7510002001 && c.Status.ObjectStatusName == ObjectStatus.VerificationAdd && c.PaymentDetails == $"Payment Detail 6"));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.AtlasId == AtlasIdActive && ch.ChargeTypeId == ChargeTypeOnce &&
                    ch.CreditAccountShort == 7510002001 && ch.Status.ObjectStatusName == ObjectStatus.VerificationAdd && ch.PaymentDetails == $"Payment Detail 6"));
            }
        }
    }
}
