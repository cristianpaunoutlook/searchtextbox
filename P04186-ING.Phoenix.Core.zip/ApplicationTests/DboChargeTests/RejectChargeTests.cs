﻿using System.Linq;
using System.Threading;
using Application.Commons.Enums;
using Application.DboCharge;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ApplicationTests.DboChargeTests
{
    [TestClass]
    public class RejectChargeTests : ChargeBaseTests
    {
        [TestMethod]
        public void ShouldCanRejectChargeModified()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeReject(context, 10, "AABBDD", "not needed", out Reject.Command command, out Reject.Handler handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(context.Charges.Any(c => (c.ChargeId == 10) && c.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.ChargeId == 10 && ch.Status.ObjectStatusName == ObjectStatus.Active));
            }
        }

        [TestMethod]
        public void ShouldCanNotRejectChargeModifiedByTheSameUser()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeReject(context, 10, "AABBCC", "not needed", out Reject.Command command, out Reject.Handler handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot reject a charge modified by the same user!");
            }
        }

        [TestMethod]
        public void ShouldCanRejectChargeAdded()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeReject(context, 11, "AABBDD", "not needed", out Reject.Command command, out Reject.Handler handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(context.Charges.Any(c => (c.ChargeId == 11) && c.Status.ObjectStatusName == ObjectStatus.RejectAdd));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.ChargeId == 11 && ch.Status.ObjectStatusName == ObjectStatus.RejectAdd));
            }
        }

        [TestMethod]
        public void ShouldCanNotRejectChargeAddedSameUser()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeReject(context, 11, "AABBCC", "not needed", out Reject.Command command, out Reject.Handler handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot reject a charge added by the same user!");
            }
        }

        [TestMethod]
        public void ShouldCanRejectChargeDeleted()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeReject(context, 12, "AABBDD", "not needed", out Reject.Command command, out Reject.Handler handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(context.Charges.Any(c => (c.ChargeId == 12) && c.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.ChargeId == 12 && ch.Status.ObjectStatusName == ObjectStatus.Active));
            }
        }

        [TestMethod]
        public void ShouldCanNotRejectChargeDeleted()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeReject(context, 12, "AABBCC", "not needed", out Reject.Command command, out Reject.Handler handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot reject a charge deleted by the same user!");
            }
        }

        [TestMethod]
        public void ShouldCanNotRejectChargeModifiedWithEmptyRejectReason()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeReject(context, 10, "AABBCC", "", out Reject.Command command, out Reject.Handler handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot reject a charge with an empty reject reason!");
            }
        }

        [TestMethod]
        public void ShouldCanNotRejectChargeModifiedWithNullRejectReason()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeReject(context, 10, "AABBCC", null, out Reject.Command command, out Reject.Handler handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot reject a charge with a null reject reason!");
            }
        }

        [TestMethod]
        public void ShouldUpdateCustomerStatusToNotSetIfAllItsChargesAreInStatusDeletedOrRejectAdd()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeReject(context, 21, "CP28XQ", null, out Reject.Command command, out Reject.Handler handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(context.Customers.Any(c => c.AtlasID == CustomerIdActiveForReject && c.StatusId == (byte)ObjectStatusId.NotSet));
            }
        }
    }
}
