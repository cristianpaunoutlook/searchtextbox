﻿using Application.Commons.Enums;
using Application.DboCharge;
using Application.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboChargeTests
{
    [TestClass]
    public class ApproveChargeTests : ChargeBaseTests
    {
        [TestMethod]
        public void ShouldCanApproveChargeModified()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeApprove(context, 10, "AABBDD", out Approve.Command command, out Approve.Handler handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(context.Charges.Any(c => (c.ChargeId == 10) && c.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.ChargeId == 10 && ch.Status.ObjectStatusName == ObjectStatus.Active));
            }
        }

        [TestMethod]
        public void ShouldCanNotApproveChargeModifiedByTheSameUser()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeApprove(context, 10, "AABBCC", out Approve.Command command, out Approve.Handler handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot approve a charge modified by the same user!");
            }
        }

        [TestMethod]
        public void ShouldCanApproveChargeAdded()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeApprove(context, 11, "AABBDD", out Approve.Command command, out Approve.Handler handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(context.Charges.Any(c => (c.ChargeId == 11) && c.Status.ObjectStatusName == ObjectStatus.Active));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.ChargeId == 11 && ch.Status.ObjectStatusName == ObjectStatus.Active));
            }
        }

        [TestMethod]
        public void ShouldCanNotApproveChargeAddedSameUser()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeApprove(context, 11, "AABBCC", out Approve.Command command, out Approve.Handler handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot approve a charge added by the same user!");
            }
        }

        [TestMethod]
        public void ShouldCanApproveChargeDeleted()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeApprove(context, 12, "AABBDD", out Approve.Command command, out Approve.Handler handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(context.Charges.Any(c => (c.ChargeId == 12) && c.Status.ObjectStatusName == ObjectStatus.Deleted));
                Assert.IsTrue(context.ChargesHistory.Any(ch => ch.ChargeId == 12 && ch.Status.ObjectStatusName == ObjectStatus.Deleted));
            }
        }

        [TestMethod]
        public void ShouldCanNotApproveChargeDeleted()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeApprove(context, 12, "AABBCC", out Approve.Command command, out Approve.Handler handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot approve a charge deleted by the same user!");
            }
        }

        [TestMethod]
        public void CannotApproveAPerProductIfAlreadyExistsPerTransaction()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeApprove(context, 16, "1", out Approve.Command command, out Approve.Handler handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Cannot approve a per product if already exists per transaction!");
            }
        }

        [TestMethod]
        public void ShouldThrowExceptionOnApproveDeleteIfCustomerDoesNotExist()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeApprove(context, 17, "CP28XQ", out Approve.Command command, out Approve.Handler handler);

                // Act

                // Assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                    "Customer for atlasId does not exist in the database.");
            }
        }

        [TestMethod]
        public void ShouldUpdateCustomerStatusToNotSetIfAllItsChargesAreInStatusDeletedOrRejectAdd()
        {
            using (var context = GetDbContext())
            {
                // Arrange
                ArrangeOnChargeApprove(context, 18, "CP28XQ", out Approve.Command command, out Approve.Handler handler);

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token).Result;

                // Assert
                Assert.IsTrue(context.Customers.Any(c => c.AtlasID == CustomerIdActive && c.StatusId == (byte)ObjectStatusId.NotSet));
            }
        }

    }
}
