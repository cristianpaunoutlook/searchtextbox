﻿using Domain;
using Persistence;
using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationTests.DboImportedPayments
{
    public class ImportedPaymentsBase:TestBase
    {
        public void InitImportedPaymentsTable(PhoenixContext context)
        {
            var sessionToAdd1 = new Session()
            {
                SessionId = 1,
                GeneratedFileName = "test1.txt",
                ObjectTypeId = 6,
                RecordStamp = DateTime.Now,
                Status = 1
            };
            var sessionToAdd2 = new Session()
            {
                SessionId = 2,
                GeneratedFileName = "test2.txt",
                ObjectTypeId = 6,
                RecordStamp = DateTime.Now,
                Status = 1
            };

            var sessionToAdd3 = new Session()
            {
                SessionId = 3,
                GeneratedFileName = "test3.txt",
                ObjectTypeId = 6,
                RecordStamp = DateTime.Now,
                Status = 1
            };

            context.Sessions.Add(sessionToAdd1);
            context.Sessions.Add(sessionToAdd2);
            context.Sessions.Add(sessionToAdd3);

            var importedPyament1 = new ImportedPayments()
            {
                SessionId = 1,
                LineNumber = 1,
                Session = sessionToAdd1,
                ChargeCode = "POSPRF",
                AtlasId = "993948",
                DebitAccount = "RO73INGB0000999908631724",
                CreditAccount = "999908069866",
                ChargedItems = "1",
                SpecialAmount = "50.00",
                IsImported = true,
                Message = "Ok",
                CustomerChargeType = "Per transaction",
                CurrencyCode = "1",
                REF_ID_CCM = null,
                VATDebitAccount = null,
                VATCreditAccount = null
            };

            var importedPyament2 = new ImportedPayments()
            {
                SessionId = 1,
                LineNumber = 2,
                Session = sessionToAdd1,
                ChargeCode = "POSPRF",
                AtlasId = "993948",
                DebitAccount = "RO73INGB0000999908631724",
                CreditAccount = "999908069866",
                ChargedItems = "1",
                SpecialAmount = "50.00",
                IsImported = true,
                Message = "Ok",
                CustomerChargeType = "Per transaction",
                CurrencyCode = "1",
                REF_ID_CCM = null,
                VATDebitAccount = null,
                VATCreditAccount = null
            };


            var importedPyament3 = new ImportedPayments()
            {
                SessionId = 2,
                LineNumber = 1,
                Session = sessionToAdd2,
                ChargeCode = "RF",
                AtlasId = "INKPRI",
                DebitAccount = "RO17INGB0001008166928910",
                CreditAccount = "7029962002",
                ChargedItems = "1",
                SpecialAmount = "11250.00",
                IsImported = true,
                Message = "Ok",
                CustomerChargeType = "Per Product",
                CurrencyCode = "RON",
                REF_ID_CCM = 11867,
                VATDebitAccount = null,
                VATCreditAccount = null
            };

            context.ImportedPayments.Add(importedPyament1);
            context.ImportedPayments.Add(importedPyament2);
            context.ImportedPayments.Add(importedPyament3);

            context.SaveChanges();
        }
    }
}
