﻿using Application.DboImportedPayments;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading;
using System;
using System.Collections.Generic;
using System.Text;
using Application.Errors;

namespace ApplicationTests.DboImportedPayments
{
    [TestClass]
    public class ListImportedPaymentsTest:ImportedPaymentsBase
    {
        [TestMethod]
        public void ShouldReturnImportedPayments()
        {
            using (var context = GetDbContext())
            {
                //arange
                InitImportedPaymentsTable(context);
                var command = new List.Query() { ImportedPaymentsParams = new Application.Helpers.ImportedPaymentsParams() { SessionId = 1, Imported = -1}, UserId="userid" };
                var handler = new List.Handler(context,GetMapper());

                //act
                var importedPayments = handler.Handle(command,new CancellationToken()).Result;
                //assert
                Assert.IsTrue(importedPayments.ImportedPayments.TotalCount == 2,"Expected 2 importedpayments for session 1!");
            }
        }

        [TestMethod]
        public void IfNoPaymentsOnSessionShouldThrowRestExceptions()
        {
            using(var context = GetDbContext())
            {
                //arrange
                InitImportedPaymentsTable(context);
                var command = new List.Query() { ImportedPaymentsParams = new Application.Helpers.ImportedPaymentsParams() { SessionId = 3, Imported = -1 }, UserId = "userid" };
                var handler = new List.Handler(context, GetMapper());

                //act
               
                Assert.ThrowsExceptionAsync<RestException> (() =>  handler.Handle(command, new CancellationToken()));
            }
        }
        
        [TestMethod]
        public void IfSessionNotExistsShouldThrowRestExceptions()
        {
            using (var context = GetDbContext())
            {
                //arrange
                InitImportedPaymentsTable(context);
                var command = new List.Query() { ImportedPaymentsParams = new Application.Helpers.ImportedPaymentsParams() { SessionId = 4, Imported = -1 }, UserId = "userid" };
                var handler = new List.Handler(context, GetMapper());

                //act

                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, new CancellationToken()));
            }
        }
    }
}
