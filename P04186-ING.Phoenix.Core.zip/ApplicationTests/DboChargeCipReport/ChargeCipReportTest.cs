﻿using Application.Commons.Constants;
using Application.DboCharge;
using Application.Errors;
using Application.Helpers;
using Domain;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Persistence;
using System;
using System.Linq;
using System.Threading;

namespace ApplicationTests.DboChargeCipReport
{
    [TestClass]
    public class ChargeCipReportTest : TestBase
    {
        [TestMethod]
        public void ShouldReturnAllCipChargesFromDb()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams();

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var chargeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeList.Items.Count == 6);
            }
        }

        [TestMethod]
        public void ShouldReturnProductAmountIfSpecialAmtIsNullAndPerProductCIP()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams();

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var chargeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeList.Items.Where(c => c.Amount == 20).Count() == 1, "Special amount is null then take product amount if per product charge type!");
            }
        }

        [TestMethod]
        public void ShouldReturnDefaultAmountIfSpecialAmtIsNullAndPerTransactionCIP()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams();

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var chargeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeList.Items.Where(c => c.Amount == 10).Count() == 1, "Special amount is null then take default amount if per transaction charge type!");
            }
        }

        [TestMethod]
        public void ShouldReturnSpecialAmountIfExistInCharge()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams();

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var chargeList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(chargeList.Items.Where(c => c.Amount == 1).Count() == 1, "Special amount should be returned if defined in cip charge!");
            }
        }

        [TestMethod]
        public void ShouldReturnPaginatedCipReportList()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams(pageNumber: 1, pageSize: 2);

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);
                //act
                var cipList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(cipList.Items.Count == 2);
            }
        }

        [TestMethod]
        public void ShouldReturnMaxPageSizeIfPageSizeIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams(pageNumber: 1, pageSize: 100);

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var cipList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(cipList.PageSize == 50);
            }
        }

        [TestMethod]
        public void ShouldThrowExceptionIfPageNumberIsOutOfRange()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams(pageNumber: 10);

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(query, (new CancellationTokenSource()).Token),
                     "The searched charge type history does not exist in the database!");
            }
        }

        [TestMethod]
        public void ShouldReturnFirstPageIfPageNumberIsLessOrEqualThanZero()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams(pageNumber: 0, pageSize: 2);

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var cipList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(cipList.CurrentPage == 1);

                //assert
                Assert.IsTrue(cipList.CurrentPage == 1 && cipList.Items.Count == 2);
            }
        }

        [TestMethod]
        public void ShouldReturnCipFilterByClient()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams(customerId: "1");

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var cipList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(cipList.Items.Count == 3 &&  cipList.Items.Where(c => c.CustomerId == "1").Count() == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnCipFilterByBranch()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams(branch: "ROBRV");

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var cipList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(cipList.Items.Count == 3 && cipList.Items.Where(c => c.Branch == "ROBRV").Count() == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnCipFilterByGrid()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams(gridId: "0001");

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var cipList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(cipList.Items.Count == 3 && cipList.Items.Where(c => c.GridId == "0001").Count() == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnCipFilterByCUI()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams(cui: "0001");

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var cipList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(cipList.Items.Count == 3 && cipList.Items.Where(c => c.CUI == "0001").Count() == 3);
            }
        }

        [TestMethod]
        public void ShouldReturnCipWithMultipleFilters()
        {
            using (var context = GetDbContext())
            {
                //arange
                var cipParams = SetCipParams(cui: "0002", customerId: "2", branch: "ROBRV", gridId: "002");

                ArrangeOnChargeForCipReportList(context, cipParams, out CipReport.Query query, out CipReport.Handler handler);

                //act
                var cipList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(cipList.Items.Count == 3);
            }
        }

        private void InitChargeForCipTables(PhoenixContext context)
        {
            var statusActive = GetStatusObject(0, Application.Commons.Enums.ObjectStatus.Active);
            var processingFrequencyOnce = GetProcessingFrequencyObject((int)Application.Commons.Enums.ProcessingFrequency.Once, "Once");
            var currency = GetCurrencyObject(1, "RON");
            var vatParameter = new PhxParameter() { ParamName = Constants.VAT_PARAMETER_NAME, ParamValue = "19" };
            var defParameter = new PhxParameter() { ParamName = "ParamName", ParamValue = "ParamValue" };
            context.Parameters.Add(vatParameter);
            context.Parameters.Add(defParameter);
            // add one CT for CIP GBS
            var chargeTypeCIP = GetChargeTypeObject(1, currency, processingFrequencyOnce, statusActive);
            chargeTypeCIP.ChargeTypeCode = Constants.CIP_GBS;
            context.ChargeTypes.Add(chargeTypeCIP);
            // add one CT for CIP PRF
            var chargeTypeSMECI = GetChargeTypeObject(3, currency, processingFrequencyOnce, statusActive);
            chargeTypeSMECI.ChargeTypeCode = Constants.CIP_PRF;
            context.ChargeTypes.Add(chargeTypeSMECI);
            // add one CT with different code
            var chargeType = GetChargeTypeObject(5, currency, processingFrequencyOnce, statusActive);
            chargeType.ChargeTypeCode = "AAA";
            context.ChargeTypes.Add(chargeType);
            // add account
            var account1 = GetAccount("1", 1000000001, "RO59INGB0001001000000001", "GBS");
            account1.GridID = "0001";
            account1.CUI = "RO0001";
            var account2 = GetAccount("2", 9000000009, "RO59INGB0001009000000009", "PRF");
            account2.GridID = "0002";
            account2.BranchCode = "ROBRV";
            account2.CUI = "R0002";
            var custDetails1 = new CustomerDetails() { Address = "address 1", CustomerId = "1", RegistrationNumber = "registration 1" };
            var custDetails2 = new CustomerDetails() { Address = "address 2", CustomerId = "2", RegistrationNumber = "registration 2" };

            account2.CustomerDetails = custDetails2;
            account1.CustomerDetails = custDetails1;
            context.Accounts.Add(account1);
            context.Accounts.Add(account2);
            //cip with special amount
            var cipCharge1 = new Charge() { ChargedItems = 1, ChargeId = 1, ChargeType = chargeTypeCIP, DebitAccount = "RO59INGB0001001000000001", SpecialAmount = 1, CustomerChargeTypeId = 1, AtlasId = "1" };
            //cip to return per product amount
            var cipCharge2 = new Charge() { ChargedItems = 2, ChargeId = 2, ChargeType = chargeTypeCIP, DebitAccount = "RO59INGB0001001000000001", SpecialAmount = null, CustomerChargeTypeId = 1, AtlasId = "1" };
            //cip to return default amount
            var cipCharge3 = new Charge() { ChargedItems = 3, ChargeId = 3, ChargeType = chargeTypeCIP, DebitAccount = "RO59INGB0001001000000001", SpecialAmount = null, CustomerChargeTypeId = 2, AtlasId = "1" };
            //Not returned in select because chargeitemes is null
            var cipCharge4 = new Charge() { ChargedItems = null, ChargeId = 4, ChargeType = chargeTypeCIP, DebitAccount = "RO59INGB0001001000000001", SpecialAmount = null, CustomerChargeTypeId = 2, AtlasId = "1" };
            //cip with special amount
            var cipCharge5 = new Charge() { ChargedItems = 1, ChargeId = 5, ChargeType = chargeTypeSMECI, DebitAccount = "RO59INGB0001009000000009", SpecialAmount = 2, CustomerChargeTypeId = 1, AtlasId = "2" };
            //cip to return per product amount
            var cipCharge6 = new Charge() { ChargedItems = 2, ChargeId = 6, ChargeType = chargeTypeSMECI, DebitAccount = "RO59INGB0001009000000009", SpecialAmount = null, CustomerChargeTypeId = 1, AtlasId = "2" };
            //cip to return default amount
            var cipCharge7 = new Charge() { ChargedItems = 3, ChargeId = 7, ChargeType = chargeTypeSMECI, DebitAccount = "RO59INGB0001009000000009", SpecialAmount = null, CustomerChargeTypeId = 2, AtlasId = "2" };
            //Not returned in select because chargeitemes is null
            var cipCharge8 = new Charge() { ChargedItems = null, ChargeId = 8, ChargeType = chargeTypeSMECI, DebitAccount = "RO59INGB0001009000000009", SpecialAmount = null, CustomerChargeTypeId = 2, AtlasId = "2" };
            //charge with non cip type
            var cipCharge9 = new Charge() { ChargedItems = 1, ChargeId = 9, ChargeType = chargeType, DebitAccount = "RO59INGB0001009000000009", SpecialAmount = 30, CustomerChargeTypeId = 1, AtlasId = "2" };

            context.Charges.Add(cipCharge1);
            context.Charges.Add(cipCharge2);
            context.Charges.Add(cipCharge3);
            context.Charges.Add(cipCharge4);
            context.Charges.Add(cipCharge5);
            context.Charges.Add(cipCharge6);
            context.Charges.Add(cipCharge7);
            context.Charges.Add(cipCharge8);
            context.Charges.Add(cipCharge9);

            context.SaveChanges();
        }
        private CipReportParams SetCipParams(string branch = "", string cui = "", string customerId = "", string gridId = "", int pageNumber = 1, int pageSize = 15)
        {
            return new CipReportParams
            {
                PageNumber = pageNumber,
                PageSize = pageSize,
                Branch = branch,
                CUI = cui,
                CustomerId = customerId,
                GridId = gridId
            };
        }
        private void ArrangeOnChargeForCipReportList(PhoenixContext context, CipReportParams cipReportParams, out CipReport.Query query, out CipReport.Handler handler)
        {
            InitChargeForCipTables(context);

            query = new CipReport.Query() { CipReportParams = cipReportParams };
            handler = new CipReport.Handler(context, GetMapper(), Mock.Of<ILogger<CipReport.Handler>>());
        }
    }
}
