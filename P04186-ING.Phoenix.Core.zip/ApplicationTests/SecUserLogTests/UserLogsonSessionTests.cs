﻿using Application.Commons.Enums;
using Application.Errors;
using Application.SECUserLog;
using Domain;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Persistence;
using System;
using System.Linq;
using System.Threading;

namespace ApplicationTests.SecUserLogTests
{
    [TestClass]
    public class UserLogsonSessionTests : TestBase
    {
        [TestMethod]
        public void CreateLoginUserLogShoudPersistedInDb()
        {
            using (var context = GetDbContext())
            {
                SetDataForTest(context);
                // Arrange
                var command = new LogIn.Command()
                {
                    IP = "1.0.0.0",
                    SessionId = "sessionKey",
                    UserId = "KK70XR",
                    Workstation = "workstation1"
                };
                var handler = new LogIn.Handler(context, Mock.Of<ILogger<LogIn.Handler>>());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.
                    UserLogs.
                    Where(ul =>
                        ul.SessionId == 1 &&
                        ul.ObjectId == (int)UserObject.Session &&
                        ul.ActionId == (int)UserAction.Login)
                    .Count() == 1);

            }
        }

        [TestMethod]
        public void CreateForceLogoutUserLogShoudPersistedInDb()
        {
            using (var context = GetDbContext())
            {
                SetDataForTest(context);
                // Arrange
                var command = new SessionExpired.Command()
                {
                    IP = "1.0.0.0",
                    SessionId = "sessionKey",
                    UserId = "KK70XR",
                    Workstation = "workstation1"
                };
                var handler = new SessionExpired.Handler(context, Mock.Of<ILogger<SessionExpired.Handler>>());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.
                    UserLogs.
                    Where(ul =>
                        ul.SessionId == 1 &&
                        ul.ObjectId == (int)UserObject.Session &&
                        ul.ActionId == (int)UserAction.ForcedLogout)
                    .Count() == 1);

            }
        }

        [TestMethod]
        public void CreateInvalidLoginUserLogShoudPersistedInDb()
        {
            using (var context = GetDbContext())
            {
                SetDataForTest(context);
                // Arrange
                var command = new InvalidLogin.Command()
                {
                    IP = "1.0.0.0",
                    UserId = "KK70XR",
                    Workstation = "workstation1"
                };
                var handler = new InvalidLogin.Handler(context, Mock.Of<ILogger<InvalidLogin.Handler>>());

                // Act
                var result = handler.Handle(command, (new CancellationTokenSource()).Token);

                // Assert
                Assert.IsTrue(context.
                    UserLogs.
                    Where(ul =>
                        ul.ObjectId == (int)UserObject.Session &&
                        ul.ActionId == (int)UserAction.FailedLogin)
                    .Count() == 1);

            }
        }

        [TestMethod]
        public void TryToLogSessionExpiredForInvalidSessionShouldThrowException()
        {
            using (var context = GetDbContext())
            {
                //arange
                SetDataForTest(context);
                var command = new SessionExpired.Command()
                {
                    IP = "1.0.0.0",
                    SessionId = "invalid",
                    UserId = "KK70XR",
                    Workstation = "workstation1"
                };

                var handler = new SessionExpired.Handler(context, Mock.Of<ILogger<SessionExpired.Handler>>());

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                     "Invalid session key to log session expired!");
            }
        }

        [TestMethod]
        public void TryToLogLoginForInvalidSessionShouldThrowException()
        {
            using (var context = GetDbContext())
            {
                //arange
                SetDataForTest(context);
                var command = new LogIn.Command()
                {
                    IP = "1.0.0.0",
                    SessionId = "invalid",
                    UserId = "KK70XR",
                    Workstation = "workstation1"
                };

                var handler = new LogIn.Handler(context, Mock.Of<ILogger<LogIn.Handler>>());

                //act

                //assert
                Assert.ThrowsExceptionAsync<RestException>(() => handler.Handle(command, (new CancellationTokenSource()).Token),
                     "Invalid session key to log for login operation!");
            }
        }

        private void SetDataForTest(PhoenixContext context)
        {
            var loginAction = new SecUserAction() { ActionId = 6, Name = "Login", Visible = false };
            var logoutAction = new SecUserAction() { ActionId = 9, Name = "ForcedLogout", Visible = false };
            var failedLoginAction = new SecUserAction() { ActionId = 10, Name = "FailedLogin", Visible = false };

            var userObject = new SecUserObject() { ObjectId = 3, Name = "Session", Description = "Session", TableName = "Session" };

            var secSession = new SecSession()
            {
                SessionId = 1,
                CountFailedLogin = 0,
                IP = "1.0.0.0",
                Session = "sessionKey",
                SessionDate = DateTime.Now,
                UserId = "AABBCC",
                Workstation = "workstation"
            };

            context.UserActions.Add(loginAction);
            context.UserActions.Add(logoutAction);
            context.UserActions.Add(failedLoginAction);
            context.UserObjects.Add(userObject);
            context.SecSessions.Add(secSession);
            context.SaveChanges();
        }
    }
}
