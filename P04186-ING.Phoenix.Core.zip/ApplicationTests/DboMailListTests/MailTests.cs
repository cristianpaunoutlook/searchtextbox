﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using Application.DboMailList;
using System.Threading;
using Application.Errors;
using System.Linq;

namespace ApplicationTests.DboMailListTests
{
    [TestClass]
    public class MailTests : MailListBase
    {
        [TestMethod]
        public void ShouldReturnAllMailAddressesFromDb()
        {
            using (var context = GetDbContext())
            {
                //arange
                ArrangeOnMailList(context, out List.Query query, out List.Handler handler);

                //act
                var mailAddressesList = handler.Handle(query, (new CancellationTokenSource()).Token).Result;

                //assert
                Assert.IsTrue(mailAddressesList.Count == 5);
            }
        }
    }
}