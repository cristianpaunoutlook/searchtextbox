﻿using Persistence;
using System;
using System.Collections.Generic;
using System.Text;
using Application.DboMailList;
using Moq;
using Microsoft.Extensions.Logging;


namespace ApplicationTests.DboMailListTests
{
    public class MailListBase : TestBase
    {
       protected void InitMailAddresses(PhoenixContext context)
       {
            var mailAddress1 = GetMailAddress(1, "CSRO", "CS RO", "cs.ro@ing.com", "");
            var mailAddress2 = GetMailAddress(2, "INVST", "INVESTIGATIONS WB", "Investigations@ing.ro", "");
            var mailAddress3 = GetMailAddress(3, "POS", "POS IMM", "posuriimm@ing.ro", "");
            var mailAddress4 = GetMailAddress(4, "CHARGES", "CHARGES INV", "charges.inv@ing.ro", "");
            var mailAddress5 = GetMailAddress(5, "REBL", "DEXTER", "reporting&billing@ing.ro", "");

            context.MailList.Add(mailAddress1);
            context.MailList.Add(mailAddress2);
            context.MailList.Add(mailAddress3);
            context.MailList.Add(mailAddress4);
            context.MailList.Add(mailAddress5);

            context.SaveChanges();
       }
        protected void ArrangeOnMailList(PhoenixContext context,
               out List.Query query, out List.Handler handler)
        {
            InitMailAddresses(context);

            query = new List.Query();
            handler = new List.Handler(context);
        }
    }
}
