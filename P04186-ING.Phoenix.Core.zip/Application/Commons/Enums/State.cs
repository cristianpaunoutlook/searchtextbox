﻿namespace Application.Commons.Enums
{
    public enum State
    {
        VerificationAdd,
        Active,
        Deleted,
        RejectAdd
    }
}
