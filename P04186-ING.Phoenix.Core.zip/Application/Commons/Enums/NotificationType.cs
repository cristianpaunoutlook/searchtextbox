﻿
namespace Application.Commons.Enums
{
    public enum NotificationType
    {
        Approved,
        Rejected,
        SendToApprove
    }
}
