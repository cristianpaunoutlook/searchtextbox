﻿
namespace Application.Commons.Enums
{
    public enum CoreBanking
    {
        GBS,
        PRF
    }
}
