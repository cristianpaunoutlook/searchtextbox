﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Commons.Enums
{
    public enum ProcessingFrequency
    {
        Once = 1,
        Daily = 2,
        Weekly = 3,
        Monthly = 4,
        Quarterly = 5,
        Yearly = 6
    }
}
