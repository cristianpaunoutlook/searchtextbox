﻿namespace Application.Commons.Enums
{
    public enum ObjectAction
    {
        ADD = 2,
        EDIT = 4,
        DELETE = 5,
        APPROVE = 6,
        IMPORT_FILE = 9,
        REJECT = 12,
        IMPORT = 20
    }
}
