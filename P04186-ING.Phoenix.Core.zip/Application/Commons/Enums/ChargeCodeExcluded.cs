﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Commons.Enums
{
    public enum ChargeCodeExcluded
    {
        SMECI = 214,
        CIP = 97
    }
}
