﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Commons.Enums
{
    public enum GroupRight
    {
        NoRight = 0,
        ViewExport = 1,
        AddEditDelete = 2,
        ApproveReject = 3
    }
}
