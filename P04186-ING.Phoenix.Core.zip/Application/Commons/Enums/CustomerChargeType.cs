﻿namespace Application.Commons.Enums
{
    public enum CustomerChargeType
    {
        PerProduct = 1,
        PerTransaction = 2
    }
}
