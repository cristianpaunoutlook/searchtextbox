﻿namespace Application.Commons.Enums
{
    public enum HistoryState
    {
        VerificationAdd,
        Active,
        Deleted,
        VerificationModify,
        VerificationDelete,
        RejectAdd,
        RejectModify,
        RejectDelete
    }
}
