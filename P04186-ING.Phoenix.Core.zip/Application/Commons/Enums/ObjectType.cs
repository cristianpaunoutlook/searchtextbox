﻿namespace Application.Commons.Enums
{
    public enum ObjectType
    {
        User = 1,
        ChargeType = 2,
        ChargeAccount = 3,
        Charge = 4,
        Customer = 5,
        SessionExport = 6,
        SessionImport = 7
    }
}
