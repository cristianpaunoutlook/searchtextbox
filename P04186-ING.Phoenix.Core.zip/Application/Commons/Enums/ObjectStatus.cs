﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Commons.Enums
{
    public static class ObjectStatus
    {
        public static string Active { get { return "Active"; } }
        public static string Deleted { get { return "Deleted"; } }
        public static string Verification { get { return "Verification"; } }
        public static string NotSet { get { return "Not set"; } }
        public static string VerificationAdd { get { return "VerificationAdd"; } }
        public static string VerificationModify { get { return "VerificationModify"; } }
        public static string VerificationDelete { get { return "VerificationDelete"; } }
        public static string RejectAdd { get { return "RejectAdd"; } }
        public static string RejectModify { get { return "RejectModify "; } }
        public static string RejectDelete { get { return "RejectDelete"; } }
    }
}
