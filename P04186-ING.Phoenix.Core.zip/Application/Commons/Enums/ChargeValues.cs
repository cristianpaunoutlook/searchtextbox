﻿namespace Application.Commons.Enums
{
    public enum ChargeValues
    {
        Standard = 1,
        Negotiated = 2
    }
}
