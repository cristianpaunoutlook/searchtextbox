﻿namespace Application.Commons.Enums
{
    public enum ObjectStatusId
    {
        Active = 0,
        Deleted = 1,
        NotSet = 3,
        VerificationAdd	= 4,
        VerificationModify = 5,
        VerificationDelete = 6,
        RejectAdd = 7,
    }
}
