﻿namespace Application.Commons.Enums
{
    public enum ChargeTypeGroup
    {
        DEFAULT,
        FCOM,
        RECO
    }
}
