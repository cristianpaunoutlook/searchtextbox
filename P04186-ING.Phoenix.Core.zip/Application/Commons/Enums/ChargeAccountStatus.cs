﻿namespace Application.Commons.Enums
{
    public enum ChargeAccountStatus
    {
        AccountActive = 0,
        DebitAccountInactive = 1,
        CreditAccountInactive = 2,
        AccountInactive = 3,

    }
}
