﻿
namespace Application.Commons.Enums
{
    public static class NotificationAction
    {
        public static string Add { get { return "added"; } }
        public static string Edit { get { return "modified"; } }
        public static string Delete { get { return "deleted"; } }
        public static string ApproveRejectAdd { get { return "ADD"; } }
        public static string ApproveRejectModify { get { return "EDIT"; } }
        public static string ApproveRejectDelete { get { return "DELETE"; } }
    }
}
