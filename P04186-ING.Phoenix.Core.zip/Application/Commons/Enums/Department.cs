﻿
namespace Application.Commons.Enums
{
    public enum Department
    {
        PCM = 10,
        Lending = 11
    }
}
