﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Commons.Enums
{
    public enum SessionStatus
    {
        Finished = 1,
        Pending = 2
    }
}
