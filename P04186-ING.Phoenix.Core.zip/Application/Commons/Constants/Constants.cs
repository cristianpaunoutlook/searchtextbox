﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Application.Commons.Constants
{
    [ExcludeFromCodeCoverage]
    public static class Constants
    {
        public const int CORPORATE_KEY_LENGTH = 6;
        public const int SESSION_KEY_LENGTH = 50;
        public const string FILE_IMPORT_PATH = "Import_InputFolder";
        public const string FILE_IMPORT_BACKUP_PATH = "Import_BackupFolder";
        public const string FILE_IMPORT_SESSION_ID = "Import_SessionId";
        public const string FILE_IMPORT_USER_ID = "Import_UserId";

        public static readonly List<string> GBS_ACCOUNT_TYPES_FOR_CHARGE = new List<string> { "CURR", "LORO", "CHRE", "NOST" };
        public static readonly List<string> PRF_ACCOUNT_TYPES_FOR_CHARGE = new List<string> { "4801", "4802", "4803", "4811", "4812", "4901", "4902", "NOST" };
        public static readonly List<short> DLF_ACCOUNT_TYPES_FOR_CHARGE = new List<short> { 1, 3 };
        public static readonly List<string> GBS_ACCOUNT_SHORT_TYPES_FOR_CHARGE = new List<string> { "ACRE", "ACPA", "SSPA", "INRA", "FCRC", "NOST" };
        public static readonly List<short> PRF_ACCOUNT_SHORT_TYPES_FOR_CHARGE = new List<short> { 9 };

        public const string RTPE_SESSIONINFO = "sessioninfo";
        public const string RTPE_PROCESS_PAYMENT = "internalfees/RegularExport";

        public const string NON_TRANSACTIONAL_FEES = "Non Transactional Fees";

        public const string SECURITY_PAGE = "SEC";
        public const int PAYMENTS_REPORT_TIME_INTERVAL = 3;

        public const int DUE_DAY_TVA = 5;
        public const string CIP_GBS = "CIP";
        public const string CIP_PRF = "SME-CI";
        public const string CHEQUE = "CHEQUE";
        public const string VAT_PARAMETER_NAME = "VATValue";
        public const string PER_TRANSACTION = "per transaction";
        public const string PER_PRODUCT = "per transaction";

        public const string IS_IMPORTED = "Yes";
        public const string IS_NOT_IMPORTED = "No";

        public static readonly List<string> CHARES_TYPES_JOBS_BASED_SPECIAL = new List<string> { "POSPRF", "POSGBS" };       
        public static readonly List<string> IMPORT_PAYM_REPORTS_CTS_AMOUNTS = new List<string> { "CHEQUE", "SME-IN" };

        public static readonly string[] INVALID_STRINGS = new string[]
        {
            "insert",
            "update",
            "delete",
            "drop",
            "truncate",
            "select",
            "exec",
            "cmd",
            "=",
        }; 

    }
}
