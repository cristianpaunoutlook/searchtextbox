﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;

namespace Application.Reports.CustomerCharges
{
    public class ListActionsForCustomerCharges
    {
        public class Query : IRequest<List<CustomerChargesActionDTO>> { }

        public class Handler : IRequestHandler<Query, List<CustomerChargesActionDTO>>
        {
            private readonly PhoenixContext _context;

            public Handler(PhoenixContext context)
            {
                _context = context;
            }

            public async Task<List<CustomerChargesActionDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                var customerChargesAction = from ch in _context.ChargesHistory
                                            select new CustomerChargesActionDTO
                                            {
                                                ActionId = ch.ActionId,
                                                ActionName = ch.ObjectAction.Name,
                                            };
                var deletedCustomerChargesAction = from ch in _context.DeletedChargesHistory
                                                   join acc in _context.ObjectActions on ch.ActionId equals acc.ActionId
                                                   select new CustomerChargesActionDTO
                                                   {
                                                       ActionId = ch.ActionId,
                                                       ActionName = acc.Name,
                                                   };
                var customerChargesActions = await customerChargesAction.Union(deletedCustomerChargesAction).OrderBy(ccha => ccha.ActionName).ToListAsync();
                return customerChargesActions;
            }
        }
    }
}
