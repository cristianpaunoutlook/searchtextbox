﻿using System;
using System.Diagnostics.CodeAnalysis;
using Domain;

namespace Application.Reports.CustomerCharges
{
    [ExcludeFromCodeCoverage]
    public class ChargeReportDTO
    {
        public string AtlasId { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeValue { get; set; }
        public string CustomerChargeTypeDescription { get; set; }
        public decimal AmountToDisplay { get; set; }
        public string CurrencyToDisplay { get; set; }
        public string DebitAccount { get; set; }
        public long CreditAccountShort { get; set; }
        public string StatusName { get; set; }
        public string LastModifiedBy { get; set; }
        public int? ChargedItems { get; set; }
        public string ActionName { get; set; }
        public string RejectReason { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public int ChargeTypeId { get; set; }
        public int ActionId { get; set; }
        public int StatusId { get; set; }

    }
}
