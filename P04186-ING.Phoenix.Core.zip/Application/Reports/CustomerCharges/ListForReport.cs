﻿using Application.Errors;
using Application.Helpers;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Reports.CustomerCharges
{
    public class ListForReport
    {
        public class Query : IRequest<PagedList<ChargeReportDTO>>
        {
            public CustomerChargesFilter CustomerChargesFilter { get; set; }
        }

        public class Handler : CustomerChargesReportBase, IRequestHandler<Query, PagedList<ChargeReportDTO>>
        {
            private readonly PhoenixContext _context;
            private readonly ILogger<Handler> _logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                _context = context;
                _logger = logger;
            }

            public async Task<PagedList<ChargeReportDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                _logger.LogInformation($"Get customer charges for filter values: {request.CustomerChargesFilter.CustomerID}  " +
                    $"customerName: {request.CustomerChargesFilter.CustomerName} chargeTypeID: {request.CustomerChargesFilter.ChargeTypeId} " +
                    $"user: {request.CustomerChargesFilter.User} actionId: {request.CustomerChargesFilter.ActionId}  " +
                    $"dateStart: {request.CustomerChargesFilter.DateStart}  dateEnd: {request.CustomerChargesFilter.DateEnd} " +
                    $"sort field: {request.CustomerChargesFilter.SortField} sort direction: {request.CustomerChargesFilter.SortOrder} statusId: {request.CustomerChargesFilter.StatusId}!");

                if (request.CustomerChargesFilter.DateStart != null && request.CustomerChargesFilter.DateEnd != null &&
                    request.CustomerChargesFilter.DateStart > request.CustomerChargesFilter.DateEnd)
                {
                    _logger.LogError($"Start date cannot be greater than end date!");
                    throw new RestException(HttpStatusCode.BadRequest, $"Start date cannot be greater than end date!");
                }

                IQueryable<ChargeReportDTO> customerChargesReportData = CustomerChargesList(_context, request.CustomerChargesFilter);
                if (!string.IsNullOrEmpty(request.CustomerChargesFilter.SortField) && !string.IsNullOrEmpty(request.CustomerChargesFilter.SortOrder))
                {
                    customerChargesReportData = customerChargesReportData.OrderByPropertyName(request.CustomerChargesFilter.SortField, request.CustomerChargesFilter.SortOrder).AsQueryable();
                }
                else
                {
                    customerChargesReportData.OrderByDescending(ch => ch.ChargeTypeCode).ThenByDescending(c => c.LastModifiedDate).ThenByDescending(ch => ch.AtlasId);
                }

                PagedList<ChargeReportDTO> paginatedCustChgRepList = await PagedList<ChargeReportDTO>.CreateAsync(customerChargesReportData, request.CustomerChargesFilter.PageNumber, request.CustomerChargesFilter.PageSize);
                if (paginatedCustChgRepList == null || paginatedCustChgRepList.Items.Count() == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "Customer charges history for the values from filters does not exist in the database!");
                }

                return paginatedCustChgRepList;
            }
        }

    }
}
