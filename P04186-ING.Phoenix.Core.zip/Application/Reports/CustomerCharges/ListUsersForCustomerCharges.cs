﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;

namespace Application.Reports.CustomerCharges
{
    public class ListUsersForCustomerCharges
    {
        public class Query : IRequest<List<string>> { }

        public class Handler : IRequestHandler<Query, List<string>>
        {
            private readonly PhoenixContext _context;
            private readonly ILogger<Handler> _logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                _context = context;
                _logger = logger;
            }

            public async Task<List<string>> Handle(Query request, CancellationToken cancellationToken)
            {
                _logger.LogInformation($"Get users for charge type history report!");
                var customerChargesUser = await _context.ChargesHistory.Select(cch => cch.LastModifiedBy.ToUpper()).Distinct().OrderBy(cch => cch).ToListAsync();

                var deletedCustomerChargesUser = await _context.DeletedChargesHistory.Select(dcch => dcch.LastModifiedBy.ToUpper()).Distinct().OrderBy(dcch => dcch).ToListAsync();

                var customerChargesUsers = customerChargesUser.Union(deletedCustomerChargesUser).Distinct().OrderBy(cchu => cchu).ToList();
                return customerChargesUsers;
            }

        }
    }
}
