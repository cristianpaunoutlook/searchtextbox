﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using Domain;

namespace Application.Reports.CustomerCharges
{
    [ExcludeFromCodeCoverage]
    public class CustomerChargesActionDTO
    {
        public int ActionId { get; set; }
        public string ActionName { get; set; }
    }
}
