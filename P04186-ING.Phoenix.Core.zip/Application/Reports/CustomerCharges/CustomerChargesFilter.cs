﻿using System;
using System.Diagnostics.CodeAnalysis;
using Application.Helpers;

namespace Application.Reports.CustomerCharges
{
    [ExcludeFromCodeCoverage]
    public class CustomerChargesFilter : PaginationParams
    {
        public string SortField { get; set; }
        public string SortOrder { get; set; }
        public string CustomerID { get; set; }
        public string CustomerName { get; set; }
        public int ChargeTypeId { get; set; }
        public string User { get; set; }
        public int ActionId { get; set; }
        public DateTime? DateStart { get; set; }
        public DateTime? DateEnd { get; set; }
        public int StatusId { get; set; }
    }
}
