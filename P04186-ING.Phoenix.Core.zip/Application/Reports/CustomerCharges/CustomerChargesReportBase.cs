﻿using Application.Commons.Enums;
using Application.Helpers;
using Persistence;
using System.Collections.Generic;
using System.Linq;

namespace Application.Reports.CustomerCharges
{
    public class CustomerChargesReportBase
    {
        public IQueryable<ChargeReportDTO> CustomerChargesList(PhoenixContext _context, CustomerChargesFilter filter)
        {
            IQueryable<ChargeReportDTO> charges = from ch in _context.ChargesHistory
                                                  join acc in _context.Accounts on ch.DebitAccount equals acc.IBAN

                                                  select new ChargeReportDTO
                                                  {
                                                      ActionId = ch.ActionId,
                                                      ActionName = ch.ObjectAction.Name,
                                                      AtlasId = ch.AtlasId,
                                                      CustomerId = ch.AtlasId,
                                                      ChargeValue = ch.SpecialAmount == null ? ChargeValues.Standard.ToString() : ChargeValues.Negotiated.ToString(),
                                                      ChargeTypeId = ch.ChargeTypeId,
                                                      ChargeTypeCode = ch.ChargeType.ChargeTypeCode,
                                                      StatusId = ch.StatusId,
                                                      StatusName = ch.Status.ObjectStatusName,
                                                      CustomerChargeTypeDescription = ch.CustomerChargeType.Description,
                                                      DebitAccount = ch.DebitAccount,
                                                      CreditAccountShort = ch.CreditAccountShort,
                                                      ChargedItems = ch.ChargedItems,
                                                      RejectReason = ch.RejectReason,
                                                      LastModifiedBy = ch.LastModifiedBy,
                                                      LastModifiedDate = ch.LastModifiedDate,
                                                      AmountToDisplay = ch.SpecialAmount != null ? ch.SpecialAmount.Value : ch.CustomerChargeTypeId == (int)CustomerChargeType.PerProduct ? ch.ChargeType.AmountProduct.Value : ch.ChargeType.DefaultAmount,
                                                      CurrencyToDisplay = ch.SpecialAmount != null ? ch.Currency.CurrencyCode : ch.ChargeType.Curr.CurrencyCode,
                                                      CustomerName = acc.CustomerName
                                                  };

            IQueryable<ChargeReportDTO> deletedCharges = from ch in _context.DeletedChargesHistory
                                                         join ct in _context.ChargeTypes on ch.ChargeTypeId equals ct.ChargeTypeId
                                                         join os in _context.ObjectStatus on ch.StatusId equals os.ObjectStatusId
                                                         join oa in _context.ObjectActions on ch.ActionId equals oa.ActionId
                                                         join acc in _context.Accounts on ch.DebitAccount equals acc.IBAN
                                                         join cct in _context.CustomerChargeTypes on ch.CustomerChargeTypeId equals cct.Id
                                                         from curr in _context.Currencies.Where(c => c.CurrencyId == ch.CurrencyId).DefaultIfEmpty()

                                                         select new ChargeReportDTO
                                                         {
                                                             ActionId = ch.ActionId,
                                                             ActionName = oa.Name,
                                                             AtlasId = ch.AtlasId,
                                                             CustomerId = ch.AtlasId,
                                                             ChargeValue = ch.SpecialAmount == null ? ChargeValues.Standard.ToString() : ChargeValues.Negotiated.ToString(),
                                                             ChargeTypeId = ch.ChargeTypeId,
                                                             ChargeTypeCode = ct.ChargeTypeCode,
                                                             StatusId = ch.StatusId,
                                                             StatusName = os.ObjectStatusName,
                                                             CustomerChargeTypeDescription = cct.Description,
                                                             DebitAccount = ch.DebitAccount,
                                                             CreditAccountShort = ch.CreditAccountShort,
                                                             ChargedItems = ch.ChargedItems,
                                                             RejectReason = ch.RejectReason,
                                                             LastModifiedBy = ch.LastModifiedBy,
                                                             LastModifiedDate = ch.LastModifiedDate,
                                                             AmountToDisplay = ch.SpecialAmount != null ? ch.SpecialAmount.Value : ch.CustomerChargeTypeId == (int)CustomerChargeType.PerProduct ? ct.AmountProduct.Value : ct.DefaultAmount,
                                                             CurrencyToDisplay = ch.SpecialAmount != null ? curr.CurrencyCode : ct.Curr.CurrencyCode,
                                                             CustomerName = acc.CustomerName,
                                                         };

            IQueryable<ChargeReportDTO> customerChargesHistory = charges.Union(deletedCharges);

            if (!string.IsNullOrEmpty(filter.CustomerID))
            {
                customerChargesHistory = customerChargesHistory.Where(cch => cch.AtlasId.Contains(filter.CustomerID));
            }

            if (!string.IsNullOrEmpty(filter.CustomerName))
            {
                customerChargesHistory = customerChargesHistory.Where(cch => cch.CustomerName.Contains(filter.CustomerName));
            }

            if (filter.ChargeTypeId != -1)
            {
                customerChargesHistory = customerChargesHistory.Where(cch => cch.ChargeTypeId == filter.ChargeTypeId);
            }

            if (filter.User != "All")
            {
                customerChargesHistory = customerChargesHistory.Where(cch => cch.LastModifiedBy.Contains(filter.User));
            }

            if (filter.ActionId != -1)
            {
                customerChargesHistory = customerChargesHistory.Where(cch => cch.ActionId == filter.ActionId);
            }

            if (filter.DateStart != null && filter.DateEnd == null)
            {
                filter.DateEnd = filter.DateStart.Value.AddDays(1);
                customerChargesHistory = customerChargesHistory.Where(cch => cch.LastModifiedDate >= filter.DateStart.Value.Date && cch.LastModifiedDate <= filter.DateEnd.Value.Date);
            }

            if (filter.DateStart == null && filter.DateEnd != null)
            {
                filter.DateStart = filter.DateEnd.Value.AddDays(-1);
                customerChargesHistory = customerChargesHistory.Where(cch => cch.LastModifiedDate >= filter.DateStart.Value.Date && cch.LastModifiedDate <= filter.DateEnd.Value.Date);
            }

            if (filter.DateStart != null && filter.DateEnd != null && filter.DateEnd >= filter.DateStart)
            {
                filter.DateEnd = filter.DateEnd.Value.AddDays(1);
                customerChargesHistory = customerChargesHistory.Where(cch => cch.LastModifiedDate >= filter.DateStart.Value.Date && cch.LastModifiedDate <= filter.DateEnd.Value.Date);
            }

            if (filter.StatusId != -1)
            {
                customerChargesHistory = customerChargesHistory.Where(cch => cch.StatusId == filter.StatusId);
            }
            return customerChargesHistory;
        }
    }
}
