﻿using System;
using System.Collections.Generic;
using System.Linq;
using Application.Commons.Constants;
using Persistence;

namespace Application.Reports.VatCharges
{
    public class VatChargesReportBase
    {
        public IQueryable<VatChargeReportDTO> VatChargesList(PhoenixContext _context, VatChargesFilter filter)
        {
            var vatParam = _context.Parameters.Where(p => p.ParamName == Constants.VAT_PARAMETER_NAME).FirstOrDefault();
            var vatValue = vatParam.ParamValue.Substring(2);
            var vatCharges = from p in _context.Payments
                             join acc in _context.Accounts on p.IBANDebitAccount equals acc.IBAN
                             where p.ChargeType.HasVAT == true && p.ChargeType.ChargeTypeCode != Constants.CIP_GBS && p.ChargeType.ChargeTypeCode != Constants.CIP_PRF &&
                             p.ApplicationLog.ObjectTypeId == (int)Commons.Enums.ObjectType.SessionExport
                             select new VatChargeReportDTO
                             {
                                 GridId = acc.GridID,
                                 CustomerAtlasId = p.CustomerAtlasId,
                                 CustomerName = p.CustomerName,
                                 ChargeTypeCode = p.ChargeType.ChargeTypeCode,
                                 Address = p.CustomerDetails.Address,
                                 RegistrationNumber = p.CustomerDetails.RegistrationNumber,
                                 CUI = acc.CUI,
                                 Currency = p.Currency.CurrencyCode,
                                 AmountDebited = p.AmountDebited,
                                 VATValue = vatValue,
                                 DueDate = Constants.DUE_DAY_TVA,
                                 ChargeTypeId = p.ChargeTypeId,
                                 RecordStamp = p.ApplicationLog.RecordStamp,
                                 StatusId = p.Processed
                             };

            if (!string.IsNullOrEmpty(filter.CustomerId))
            {
                vatCharges = vatCharges.Where(vc => vc.CustomerAtlasId.Contains(filter.CustomerId));
            }
            if (!string.IsNullOrEmpty(filter.GridId))
            {
                vatCharges = vatCharges.Where(vc => vc.GridId.Contains(filter.GridId));
            }
            if (!string.IsNullOrEmpty(filter.CUI))
            {
                vatCharges = vatCharges.Where(vc => vc.CUI.Contains(filter.CUI));
            }
            if (filter.ChargeTypeId != -1)
            {
                vatCharges = vatCharges.Where(vc => vc.ChargeTypeId == filter.ChargeTypeId);
            }
            if (filter.StatusId != -1)
            {
                vatCharges = vatCharges.Where(vc => vc.StatusId == filter.StatusId);
            }
            if (filter.StartDate != null)
            {
                vatCharges = vatCharges.Where(vc => vc.RecordStamp.Date >= filter.StartDate.Value.Date);
            }
            if (filter.EndDate != null)
            {
                vatCharges = vatCharges.Where(vc => vc.RecordStamp.Date <= filter.EndDate.Value.Date);
            }

            return vatCharges.OrderByDescending(vc => vc.CustomerName);
        }
    }
}
