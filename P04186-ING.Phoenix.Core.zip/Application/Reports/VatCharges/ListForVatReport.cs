﻿using Application.Errors;
using Application.Helpers;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Reports.VatCharges
{
    public class ListForVatReport
    {
        public class Query : IRequest<PagedList<VatChargeReportDTO>>
        {
            public VatChargesFilter VatChargesFilter { get; set; }
        }

        public class Handler : VatChargesReportBase, IRequestHandler<Query, PagedList<VatChargeReportDTO>>
        {
            private readonly PhoenixContext _context;
            private readonly ILogger<Handler> _logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                _context = context;
                _logger = logger;
            }

            public async Task<PagedList<VatChargeReportDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                _logger.LogInformation($"Get VAT charges for filter values: curomerid {request.VatChargesFilter.CustomerId} " +
                    $" GridId: {request.VatChargesFilter.GridId} CUI:{request.VatChargesFilter.CUI} ChargeTypeId:{request.VatChargesFilter.ChargeTypeId} " +
                    $"StatusId: {request.VatChargesFilter.StatusId} StartDate: {request.VatChargesFilter.StartDate} EndDate: {request.VatChargesFilter.EndDate}");

                var vatChargesReportData = VatChargesList(_context, request.VatChargesFilter);

                var paginatedVatChargesRepList = await PagedList<VatChargeReportDTO>.CreateAsync(vatChargesReportData, request.VatChargesFilter.PageNumber, request.VatChargesFilter.PageSize);

                if (paginatedVatChargesRepList == null || paginatedVatChargesRepList.Items.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "Vat charges for the values from filters does not exist in the database!");
                }

                return paginatedVatChargesRepList;
            }
        }
    }
}
