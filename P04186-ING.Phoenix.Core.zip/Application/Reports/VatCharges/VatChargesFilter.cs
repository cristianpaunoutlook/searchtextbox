﻿using Application.Helpers;
using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.Reports.VatCharges
{
    [ExcludeFromCodeCoverage]
    public class VatChargesFilter : PaginationParams
    {
        public string CustomerId { get; set; }
        public string GridId { get; set; }
        public string CUI { get; set; }
        public int ChargeTypeId { get; set; }
        public int StatusId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
