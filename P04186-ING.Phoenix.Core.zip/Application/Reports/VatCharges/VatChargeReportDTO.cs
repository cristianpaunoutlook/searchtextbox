﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.Reports.VatCharges
{
    [ExcludeFromCodeCoverage]
    public class VatChargeReportDTO
    {
        public string GridId { get; set; }
        public string CustomerAtlasId { get; set; }
        public string CustomerName { get; set; }
        public string ChargeTypeCode { get; set; }
        public string Address { get; set; }
        public string RegistrationNumber { get; set; }
        public string CUI { get; set; }
        public string Currency { get; set; }
        public decimal AmountDebited { get; set; }
        public string VATValue { get; set; }
        public int DueDate { get; set; }
        public int ChargeTypeId { get; set; }
        public DateTime RecordStamp { get; set; }
        public int StatusId { get; set; }
    }
}
