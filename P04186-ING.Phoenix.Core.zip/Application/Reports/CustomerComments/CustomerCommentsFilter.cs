﻿using Application.Helpers;
using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.Reports.CustomerComments
{
    [ExcludeFromCodeCoverage]
    public class CustomerCommentsFilter : PaginationParams
    {
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public string LastModifiedBy { get; set; }

    }
}
