﻿using Application.DTO;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Reports.CustomerComments
{
    public class ListUsersForCustomerComments
    {
        public class Query : IRequest<List<string>> { }

        public class Handler : IRequestHandler<Query, List<string>>
        {
            private readonly PhoenixContext _context;
            private readonly ILogger<Handler> _logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                _context = context;
                _logger = logger;
            }

            public async Task<List<string>> Handle(Query request, CancellationToken cancellationToken)
            {
                _logger.LogInformation($"Get users for customer comments report!");
                var customerCommentsUsers = from c in _context.Customers
                                            join acc in _context.Accounts on c.AtlasID equals acc.CustomerId
                                            where c.StatusId == (int)Commons.Enums.ObjectStatusId.Active && c.Comments != null
                                            orderby c.DateLastUpdate descending
                                            select c.UserID;

                return await customerCommentsUsers.Distinct().ToListAsync();
            }
        }
    }
}
