﻿using Application.DTO;
using Persistence;
using System.Linq;

namespace Application.Reports.CustomerComments
{
    public class CustomerCommentsReportBase
    {
        public IQueryable<CustomerCommentsDTO> CustomerCommentsList(PhoenixContext _context, CustomerCommentsFilter filter)
        {
            var customerComments = from c in _context.Customers
                                   join acc in _context.Accounts on c.AtlasID equals acc.CustomerId
                                   where c.StatusId == (int)Commons.Enums.ObjectStatusId.Active && !string.IsNullOrEmpty(c.Comments)
                                   select new CustomerCommentsDTO
                                   {
                                       CustomerId = c.AtlasID,
                                       CustomerName = acc.CustomerName,
                                       Comments = c.Comments,
                                       LastModifiedBy = c.UserID,
                                       LastModifiedDate = c.DateLastUpdate
                                   };

            customerComments = customerComments.Distinct().OrderByDescending(cc => cc.LastModifiedDate);
            if (!string.IsNullOrEmpty(filter.CustomerId))
            {
                customerComments = customerComments.Where(cc => cc.CustomerId.Contains(filter.CustomerId));
            }
            if (!string.IsNullOrEmpty(filter.CustomerName))
            {
                customerComments = customerComments.Where(cc => cc.CustomerName.Contains(filter.CustomerName));
            }
            if (filter.LastModifiedBy != "All" && filter.LastModifiedBy != null)
            {
                customerComments = customerComments.Where(cc => cc.LastModifiedBy.Contains(filter.LastModifiedBy));
            }
            if (filter.LastModifiedDate != null)
            {
                customerComments = customerComments.Where(cc => cc.LastModifiedDate >= filter.LastModifiedDate);
            }

            return customerComments;
        }
    }
}
