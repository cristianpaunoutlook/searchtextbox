﻿using Application.DTO;
using Application.Errors;
using Application.Helpers;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Reports.CustomerComments
{
    public class ListForCustomerCommentsReport
    {
        public class Query : IRequest<PagedList<CustomerCommentsDTO>>
        {
            public CustomerCommentsFilter CustomerCommentsFilter { get; set; }
        }
        public class Handler : CustomerCommentsReportBase, IRequestHandler<Query, PagedList<CustomerCommentsDTO>>
        {
            private readonly PhoenixContext _context;
            private readonly ILogger<Handler> _logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                _context = context;
                _logger = logger;
            }

            public async Task<PagedList<CustomerCommentsDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                _logger.LogInformation($"Get customer comments for filter values: CustomerId {request.CustomerCommentsFilter.CustomerId} " +
                    $" CustomerName: {request.CustomerCommentsFilter.CustomerName} LastModifiedBy:{request.CustomerCommentsFilter.LastModifiedBy} LastModifiedDate:{request.CustomerCommentsFilter.LastModifiedDate}!");
                IQueryable<CustomerCommentsDTO> customerCommentsReportData = CustomerCommentsList(_context, request.CustomerCommentsFilter);
                PagedList<CustomerCommentsDTO> paginatedCustomerCommentsRepList = await PagedList<CustomerCommentsDTO>.CreateAsync(customerCommentsReportData, request.CustomerCommentsFilter.PageNumber, request.CustomerCommentsFilter.PageSize);
                if (paginatedCustomerCommentsRepList == null || paginatedCustomerCommentsRepList.Items.Count() == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "Customer comments for the values from filters does not exist in the database!");
                }
                return paginatedCustomerCommentsRepList;
            }
        }
    }
}
