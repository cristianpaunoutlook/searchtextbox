﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboAccount
{
    public class ListIbanForChargeCreate
    {
        public class Query : IRequest<IEnumerable<string>>
        {
            public string CustomerId { get; set; }
        }

        public class Handler : IRequestHandler<Query, IEnumerable<string>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }
            public async Task<IEnumerable<string>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get IBAN list for customer: {request.CustomerId}");

                var accounts = context.Accounts.Where(a => a.IBAN != null && a.IBAN.Substring(8, 3) != "TVA" && a.CustomerId == request.CustomerId);

                var result = (from acc in accounts
                              from gbs in context.GBSDebitAccountTypes.Where(gbs => acc.Type == gbs.Code)
                              select acc.IBAN).Union(
                    from acc in accounts
                    from prf in context.PRFDebitAccountTypes.Where(prf => acc.Type == prf.Code && acc.TypeId == prf.CifTypeId)
                    select acc.IBAN);

                return await result.ToListAsync();
            }
        }
    }
}
