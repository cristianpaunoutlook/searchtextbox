﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboAccount
{
    public class ListForAccountShortValidation
    {
        public class Query : IRequest<IEnumerable<string>>
        {
            public string CoreBanking { get; set; }
        }

        public class Handler : IRequestHandler<Query, IEnumerable<string>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<IEnumerable<string>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get account short list for corebanking: {request.CoreBanking}");

                var accounts = context.Accounts.AsQueryable();
                if(request.CoreBanking == CoreBanking.GBS.ToString() || request.CoreBanking == CoreBanking.PRF.ToString())
                    accounts = accounts.Where(a => a.CoreBanking == request.CoreBanking);

                var result = (from acc in accounts
                              from gbs in context.GBSCreditAccountTypes.Where(gbs => acc.Type == gbs.Code)
                              select acc.AccountShort.ToString()).Union(
                    from acc in accounts
                    from prf in context.PRFCreditAccountTypes.Where(prf => acc.TypeId == prf.CifTypeId)
                    select acc.AccountShort.ToString()
                    );

                return await result.ToListAsync();

            }
        }
    }
}
