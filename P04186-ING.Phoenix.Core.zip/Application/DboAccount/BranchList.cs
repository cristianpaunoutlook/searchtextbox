﻿using Application.Commons.Enums;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboAccount
{
    [ExcludeFromCodeCoverage]
    public class BranchList
    {
        public class Query : IRequest<IReadOnlyList<string>> { }

        public class Handler : IRequestHandler<Query, IReadOnlyList<string>>
        {
            private readonly PhoenixContext context;

            public Handler(PhoenixContext context)
            {
                this.context = context;
            }

            public async Task<IReadOnlyList<string>> Handle(Query request, CancellationToken cancellationToken) =>
                await context.Accounts
                        .OrderBy(a => a.BranchCode)
                        .Select(a => a.BranchCode)
                        .Distinct()
                        .ToListAsync();
        }
    }
}
