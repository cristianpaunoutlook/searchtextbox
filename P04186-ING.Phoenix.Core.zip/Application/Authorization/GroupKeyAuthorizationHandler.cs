﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;
using MediatR;
using Application.Security;
using System.Linq;
using Application.Errors;
using System.Net;
using System.Diagnostics.CodeAnalysis;

namespace Application.Authorization
{
    [ExcludeFromCodeCoverage]
    public class GroupKeyAuthorizationHandler : AuthorizationHandler<GroupKeyRequirement>
    {
        private readonly ILogger<GroupKeyAuthorizationHandler> _logger;
        private readonly IMediator _mediator;
        
        public GroupKeyAuthorizationHandler(ILogger<GroupKeyAuthorizationHandler> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, GroupKeyRequirement requirement)
        {
            _logger.LogWarning($"Evaluating authorization requirement for group key {requirement.GroupKey}");
            var groups = _mediator.Send(new UserGroups.Query() { User = context.User.Identity }).Result;
            if (groups == null)
                UserWithoutRights(requirement, HttpStatusCode.Unauthorized);
            var groupRightsList = groups.Select(r => r.Value);
            var found = false;
            foreach(var groupRight in groupRightsList)
            {
                if(CheckGroupRight(requirement.GroupKey, groupRight))
                {
                    _logger.LogInformation($"Group key {requirement.GroupKey} satisfied");
                    found = true;
                    context.Succeed(requirement);
                    break;
                }
            }

            if(!found)
            {
                UserWithoutRights(requirement, HttpStatusCode.Forbidden);
            }

            return Task.CompletedTask;
        }

        private bool CheckGroupRight(string requestedGroupRight, string groupRight)
        {
            var requestedPage = requestedGroupRight.Substring(0, requestedGroupRight.IndexOf("_"));
            var requestedRight = requestedGroupRight.Substring(requestedGroupRight.IndexOf("_") + 1);

            var page = groupRight.Substring(0, groupRight.IndexOf("_"));
            var right = groupRight.Substring(groupRight.IndexOf("_") + 1);

            return requestedPage == page && int.Parse(requestedRight) <= int.Parse(right);
        }

        private Task UserWithoutRights(GroupKeyRequirement requirement, HttpStatusCode statusCode)
        {
            _logger.LogInformation($"User does not have the group key {requirement.GroupKey} satisfied");
            throw new RestException(statusCode, $"User does not have the group key {requirement.GroupKey} satisfied");
        }
    }
}
