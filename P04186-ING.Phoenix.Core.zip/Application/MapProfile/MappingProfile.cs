﻿using Application.DboCharge;
using Application.DTO;
using Application.Export.ChargeTypeHistoryReport;
using Application.Export.ChargeTypes;
using Application.Export.CIPReport;
using Application.Export.CustomerChargesReport;
using Application.Export.Groups;
using Application.Export.ImportedPayments;
using Application.Export.ImportedPaymentsReport;
using Application.Export.PaymentStatusReport;
using Application.Export.VatChargesReport;
using Application.Helpers;
using Application.Import;
using Application.Reports.CustomerCharges;
using Application.Reports.VatCharges;
using AutoMapper;
using Domain;
using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.MapProfile
{
    [ExcludeFromCodeCoverage]
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<ObjectType, ObjectTypeDTO>();
            CreateMap<PhxParameter, ParameterDTO>();
            CreateMap<Session, SessionDTO>().ForMember(d => d.Stare, o => o.MapFrom(s => s.Status));
            CreateMap<ChargeType, ChargeTypeReportData>()
                .ForMember(d => d.Currency, o => o.MapFrom(s => s.Curr.CurrencyCode))
                .ForMember(d => d.Frequency, o => o.MapFrom(s => s.Frequency.ProcessingFrequencyName))
                .ForMember(d => d.Status, o => o.MapFrom(s => s.Status.ObjectStatusName));
            CreateMap<DboChargeType.Create.Command, ChargeType>()
                .ForMember(d => d.DefaultAmount, o => o.MapFrom(s => s.Amount_Unit))
                .ForMember(d => d.AmountProduct, o => o.MapFrom(s => s.Amount_Product))
                .ForMember(d => d.LastModifiedDate, o => o.MapFrom(s => DateTime.Now))
                .ForMember(d => d.PaymentDetail, o => o.MapFrom(s => s.PaymentDetails));
            CreateMap<DboChargeType.Create.Command, ChargeTypeHistory>()
                .ForMember(d => d.DefaultAmount, o => o.MapFrom(s => s.Amount_Unit))
                .ForMember(d => d.AmountProduct, o => o.MapFrom(s => s.Amount_Product))
                .ForMember(d => d.LastModifiedDate, o => o.MapFrom(s => DateTime.Now))
                .ForMember(d => d.PaymentDetail, o => o.MapFrom(s => s.PaymentDetails));
            CreateMap<DboChargeType.Edit.Command, ChargeType>()
                .ForMember(d => d.DefaultAmount, o => o.MapFrom(s => s.Amount_Unit))
                .ForMember(d => d.AmountProduct, o => o.MapFrom(s => s.Amount_Product))
                .ForMember(d => d.LastModifiedDate, o => o.MapFrom(s => DateTime.Now))
                .ForMember(d => d.PaymentDetail, o => o.MapFrom(s => s.PaymentDetails));
            CreateMap<DboChargeType.Edit.Command, ChargeTypeHistory>()
                .ForMember(d => d.DefaultAmount, o => o.MapFrom(s => s.Amount_Unit))
                .ForMember(d => d.AmountProduct, o => o.MapFrom(s => s.Amount_Product))
                .ForMember(d => d.LastModifiedDate, o => o.MapFrom(s => DateTime.Now))
                .ForMember(d => d.PaymentDetail, o => o.MapFrom(s => s.PaymentDetails));
            CreateMap<ChargeType, ChargeTypeHistory>();
            CreateMap<Currency, CurrencyDTO>();
            CreateMap<ProcessingFrequency, ProcessingFrequencyDTO>();
            CreateMap<ObjectStatus, ObjectStatusDTO>();
            CreateMap<ChargeType, ChargeTypeDTO>();
            CreateMap<ChargeTypeHistory, ChargeTypeHistoryDTO>();
            CreateMap<ChargeTypeListDTO, ChargeTypeReportData>()
                .ForMember(d => d.Status, o => o.MapFrom(s => s.HistoryStatusCode))
                .ForMember(d => d.Currency, o => o.MapFrom(s => s.CurrCode))
                .ForMember(d => d.Frequency, o => o.MapFrom(s => s.FrequencyName))
                .ForMember(d => d.ChargeTypeCode, o => o.MapFrom(s => s.ChargeTypeCode.ToUpper()));
            CreateMap<ChargeTypeParams, ChargeTypesFilter>();
            CreateMap<ChargeType, ChargeTypeDropDownDTO>();
            CreateMap<Charge, ChargeHistory>();
            CreateMap<DboCharge.Create.Command, Charge>();
            CreateMap<DboCharge.Edit.Command, Charge>();
            CreateMap<DboCharge.Edit.Command, ChargeHistory>();
            CreateMap<ImportCharges, ImportedPayments>()
                .ForMember(d => d.AtlasId, o => o.MapFrom(s => s.CustomerID))
                .ForMember(d => d.CustomerChargeType, o => o.MapFrom(s => s.Type))
                .ForMember(d => d.PaymentDetails, o => o.MapFrom(s =>
                        !string.IsNullOrEmpty(s.PaymentDetails) && s.PaymentDetails.Length > 35 ?
                            "ERROR: " + s.PaymentDetails.Substring(0, 27) : s.PaymentDetails));
            CreateMap<ImportedPayments, ImportedPaymentsDTO>()
                .ForMember(d => d.CustomerId, o => o.MapFrom(s => s.AtlasId))
                .ForMember(d => d.Code, o => o.MapFrom(s => s.ChargeCode))
                .ForMember(d => d.Type, o => o.MapFrom(s => s.CustomerChargeType))
                .ForMember(d => d.Currency, o => o.MapFrom(s => s.CurrencyCode))
                .ForMember(d => d.Imported, o => o.MapFrom(s => s.IsImported.Value))
                .ForMember(d => d.Amount, o => o.MapFrom(s => s.SpecialAmount));
            CreateMap<ImportedPaymentsParams, ImportedPaymentsFilter>();
            CreateMap<ImportedPaymentsDTO, ImportedPaymentsReportData>();
            CreateMap<ManualProcessSpResult, ChargeTypeForManualProcessingDto>();
            CreateMap<ManualProcessSpResult, ManualProcessingChargeTypesReportData>();
            CreateMap<GroupPageRightListDTO, GroupPageRightReportData>();
            CreateMap<ChargeReportDTO, CustomerChargesHistoryReportData>();
            CreateMap<VatChargeReportDTO, VatChargesReportData>();
            CreateMap<PaymentsStatusReport, PaymentsStatusReportData>();
            CreateMap<ChargeTypeHistoryReportParams, ChargeTypeHistoryReportFilter>();
            CreateMap<ChargeTypeHistoryReportListDTO, ChargeTypeHistoryReportData>();
            CreateMap<CipReportDTO, CIPReportData>();
            CreateMap<ImportedPaymentsReportParams, ImportedPaymentsReportFilter>();
            CreateMap<ImportedPaymentsReportDTO, ImportedPaymentReportData>();
            CreateMap<CustomerCommentsDTO, CustomerCommentsReportData>();
            CreateMap<Create.Command, ChargeValidationObjectDTO>();
            CreateMap<Edit.Command, ChargeValidationObjectDTO>();
        }
    }
}
