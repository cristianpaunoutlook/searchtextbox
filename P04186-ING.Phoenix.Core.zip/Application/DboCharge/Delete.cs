﻿using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.Commons.Enums;
using Application.Errors;
using Application.StateManagement;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;

namespace Application.DboCharge
{
    public class Delete
    {
        public class Command : IRequest
        {
            public int ChargeId { get; set; }
            public string LastModifiedBy { get; set; }
        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Delete charge with id {request.ChargeId}");
                var charge = await context.Charges.FindAsync(request.ChargeId);
                if (charge == null)
                {
                    throw new Exception($"Charge {request.ChargeId} does not exist in the database!");
                }

                var chargeHistory = await context.ChargesHistory
                        .Where(ct => ct.ChargeId == charge.ChargeId)
                        .OrderByDescending(ct => ct.ChargeHistoryId)
                        .FirstOrDefaultAsync();

                if (chargeHistory == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge history for {charge.ChargeId} does not exist in the database!");
                }

                var statusManger = new StatusStateManagement(charge.Status.ObjectStatusName, chargeHistory.Status.ObjectStatusName, true);
                statusManger.SetNextState(StateTrigger.Delete);

                var objStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.State.ToString()).FirstOrDefaultAsync();
                var objStatusHistory = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.HistoryState.ToString()).FirstOrDefaultAsync();

                charge.StatusId = objStatus.ObjectStatusId;
                charge.LastModifiedBy = request.LastModifiedBy;
                charge.LastModifiedDate = DateTime.Now;
                charge.RejectReason = null;

                var newChargeHistory = mapper.Map<Charge, ChargeHistory>(charge);
                newChargeHistory.Status = objStatusHistory;
                newChargeHistory.StatusId = objStatusHistory.ObjectStatusId;
                newChargeHistory.ActionId = (int)ObjectAction.DELETE;
                context.ChargesHistory.Add(newChargeHistory);

                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception($"Charge type {charge.ChargeId} was not deleted!");
            }
        }
    }
}
