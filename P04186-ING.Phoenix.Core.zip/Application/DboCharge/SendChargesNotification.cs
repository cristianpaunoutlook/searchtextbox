﻿using Application.Interfaces;
using Application.Notifications.ChargesReportNotifications;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCharge
{
    public class SendChargesNotification
    {
        public class Command : IRequest
        {
            public byte[] ReportFile { get; set; }
        }

        public class Handler : ChargesReportNotificationBase, IRequestHandler<Command>
        {
            private readonly ILogger<Handler> logger;

            public Handler(ILogger<Handler> logger, IConfiguration configuration, IEmailSender sender) : base(configuration, sender)
            {
                this.logger = logger;
            }
            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation("Creating Charges email notification");

                if (request.ReportFile != null)
                    await SendChargesReportEmailAsync("Customer Charges Report.xlsx", request.ReportFile);

                return Unit.Value;
            }
        }
    }
}
