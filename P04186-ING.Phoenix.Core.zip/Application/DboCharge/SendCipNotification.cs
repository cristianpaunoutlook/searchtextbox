﻿using Application.Interfaces;
using Application.Notifications.CipReportNotifications;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCharge
{
    public class SendCipNotification
    {
        public class Command : IRequest
        {
            public byte[] ReportFile { get; set; }
        }

        public class Handler : CipReportNotificationBase, IRequestHandler<Command>
        {
            private readonly ILogger<Handler> logger;

            public Handler(ILogger<Handler> logger, IConfiguration configuration, IEmailSender sender) : base(configuration, sender)
            {
                this.logger = logger;
            }
            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation("Creating CIP email notification");

                await SendCipReportEmailAsync("CIP Report.xlsx", request.ReportFile);

                return Unit.Value;
            }
        }
    }
}
