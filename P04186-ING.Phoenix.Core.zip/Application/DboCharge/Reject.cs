﻿using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.Commons.Enums;
using Application.Errors;
using Application.StateManagement;
using AutoMapper;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;

namespace Application.DboCharge
{
    public class Reject
    {
        public class Command : IRequest
        {
            public int ChargeId { get; set; }
            public string UserKey { get; set; }
            public string RejectReason { get; set; }
        }


        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(cht => cht.ChargeId).NotNull().NotEmpty();
                RuleFor(cht => cht.RejectReason).NotNull().NotEmpty().MaximumLength(500);
            }
        }

        public class Handler : ChargeBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Reject customer charge with id {request.ChargeId}");
                var customerCharge = await context.Charges.Where(c => c.ChargeId == request.ChargeId).FirstOrDefaultAsync();
                if (customerCharge == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Customer charge with id {request.ChargeId} does not exist in the database!");
                }

                var customerChargeHistory = await context.ChargesHistory
                    .Where(ch => ch.ChargeId == customerCharge.ChargeId)
                    .OrderByDescending(ch => ch.ChargeHistoryId)
                    .FirstOrDefaultAsync();

                if (customerChargeHistory == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Customer charge history with id {request.ChargeId} does not exist in the database!");
                }

                if (request.UserKey == customerChargeHistory.LastModifiedBy)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"You have changed the customer charge with id {request.ChargeId} so you can not reject the changes!");
                }

                logger.LogInformation($"Current state, charge type: {customerCharge.Status.ObjectStatusName} charge type history: {customerChargeHistory.Status.ObjectStatusName}");
                var statusManger = new StatusStateManagement(customerCharge.Status.ObjectStatusName, customerChargeHistory.Status.ObjectStatusName);
                statusManger.SetNextState(StateTrigger.Reject);
                logger.LogInformation($"Future state after reject, customer charge state: {statusManger.State} customer charge history state: {statusManger.HistoryState}");
                var objStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.State.ToString()).FirstOrDefaultAsync();
                var objStatusForHistory = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.HistoryState.ToString()).FirstOrDefaultAsync();

                customerCharge.StatusId = objStatus.ObjectStatusId;
                customerCharge.LastModifiedBy = request.UserKey;
                customerCharge.LastModifiedDate = DateTime.Now;
                customerCharge.RejectReason = request.RejectReason;
                var newCustomerChargeHistory = mapper.Map<ChargeHistory>(customerCharge);
                newCustomerChargeHistory.Status = objStatusForHistory;
                newCustomerChargeHistory.StatusId = objStatusForHistory.ObjectStatusId;
                newCustomerChargeHistory.ActionId = (int)ObjectAction.REJECT;
                context.ChargesHistory.Add(newCustomerChargeHistory);

                if (objStatus.ObjectStatusName == Commons.Enums.ObjectStatus.RejectAdd)
                {
                    await UpdateCustomerToNotSet(context, logger, customerCharge.AtlasId, customerCharge.ChargeId);
                }

                var success = await context.SaveChangesAsync() > 0;


                return success ? Unit.Value : throw new Exception("Error on reject customer charge!");
            }
        }
    }
}
