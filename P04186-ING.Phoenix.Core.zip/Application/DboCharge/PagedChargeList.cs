﻿using Application.DTO;
using Application.Helpers;

namespace Application.DboCharge
{
    public class PagedChargeList
    {
        public PagedList<ChargeValidationDTO> Charges { get; set; }
        public int CountValidToApprove { get; set; }
    }
}
