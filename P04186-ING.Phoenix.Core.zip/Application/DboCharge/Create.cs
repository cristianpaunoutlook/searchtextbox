﻿using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using AutoMapper;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCharge
{
    public class Create
    {
        public class Command : IRequest
        {
            public string AtlasId { get; set; }
            public int ValueId { get; set; }
            public int ChargeTypeId { get; set; }
            public int CustomerChargeTypeId { get; set; }
            public decimal? SpecialAmount { get; set; }
            public int? CurrencyId { get; set; }
            public int? ChargedItems { get; set; }
            public string DebitAccount { get; set; }
            public long CreditAccountShort { get; set; }
            public string LastModifiedBy { get; set; }
            public DateTime LastModifiedDate { get; set; }
            public string PaymentDetails { get; set; }
        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(ch => ch.ChargeTypeId).NotNull();
                RuleFor(ch => ch.CustomerChargeTypeId).NotNull();
                RuleFor(ch => ch.DebitAccount).NotNull();
                RuleFor(ch => ch.CreditAccountShort).NotNull().Must(x => x > 999 && x < 1000000000000);
                RuleFor(ch => ch.ChargedItems).NotEqual(0);
                RuleFor(ch => ch.PaymentDetails).MaximumLength(35);
            }
        }

        public class Handler : ChargeBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                var coreBankingForClient = await GetCoreBankingForAccount(context, request.AtlasId);

                var validChargeTypes = await GetChargeTypeListForChargeCreate(context, coreBankingForClient);

                var chargeType = validChargeTypes.Where(ct => ct.ChargeTypeId == request.ChargeTypeId).FirstOrDefault();

                if (chargeType == null)
                {
                    logger.LogInformation($"Charge type is not valid for creating a new charge!");
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type does not exists in the DB!");
                }

                var chargeValidation = mapper.Map<Command, ChargeValidationObjectDTO>(request);

                var chargeTypeCode = chargeType.ChargeTypeCode;
                ValidateChargeValueAndType(chargeValidation, logger);
                ValidatePaymentDetails(request.PaymentDetails, chargeType, logger);

                CheckFCOMRules(request.ValueId, request.CustomerChargeTypeId, chargeType, logger);

                await ValidateCharge(context, logger, chargeValidation, chargeTypeCode, request.PaymentDetails, chargeType.ChargeTypeGroupCd);

                logger.LogInformation($"Create charge for atlas id: {request.AtlasId} and charge type code: {chargeTypeCode}");

                var objStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationAdd).FirstOrDefaultAsync();
                var charge = mapper.Map<Command, Charge>(request);
                charge.StatusId = objStatus.ObjectStatusId;
                charge.LastModifiedBy = request.LastModifiedBy;
                charge.LastModifiedDate = DateTime.Now;
                charge.RejectReason = null;
                charge.PaymentDetails = chargeType.FrequencyId == (int)Commons.Enums.ProcessingFrequency.Once
                    && string.IsNullOrEmpty(request.PaymentDetails) ? chargeType.PaymentDetails : request.PaymentDetails;

                var chargeHistory = mapper.Map<Charge, ChargeHistory>(charge);
                chargeHistory.Charge = charge;
                chargeHistory.ActionId = (int)ObjectAction.ADD;
                context.Add(charge);
                context.Add(chargeHistory);

                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Charge type was not created!");
            }
        }
    }
}
