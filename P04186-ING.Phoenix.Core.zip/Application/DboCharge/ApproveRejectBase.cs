﻿using Application.Helpers;
using Persistence;
using System.Data;
using System.Linq;

namespace Application.DboCharge
{
    public class ApproveRejectBase : VerificationBase
    {
        public int[] GetIdsForApproveReject(bool toBeExcluded, int[] chargeIds, ValidationParams filter, PhoenixContext context, string userKey)
        {
            if (toBeExcluded == false)
            {
                return chargeIds;
            }
            else
            {
                var chargeIdsFromList = ChargeVerificationList(context, filter, userKey).Select(c => c.ChargeId).ToList();

                return chargeIdsFromList.Except(chargeIds).ToArray();
            }
        }
    }
}
