﻿using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Application.Helpers;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCharge
{
    public class Verification
    {
        public class Query : IRequest<PagedList<ChargeValidationDTO>>
        {
            public ValidationParams ValidationParams { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : VerificationBase, IRequestHandler<Query, PagedList<ChargeValidationDTO>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }
            public async Task<PagedList<ChargeValidationDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Getting charges for validation using filters {request.ValidationParams.ChargeTypeId} {request.ValidationParams.CustomerId} " +
                    $"{request.ValidationParams.CustomerName} {request.ValidationParams.ImportDate} {request.ValidationParams.SessionId} {request.ValidationParams.StatusId}");

                var chargesToVerify = ChargeVerificationList(context, request.ValidationParams, request.UserKey);

                var paginatedChargeList = await PagedList<ChargeValidationDTO>.CreateAsync(chargesToVerify, request.ValidationParams.PageNumber,
                    request.ValidationParams.PageSize);

                if (paginatedChargeList.Items.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "There are no records corresponding to your search!");
                }

                var nrCrt = 1;
                paginatedChargeList.Items = paginatedChargeList.Items.Select(
                    c =>
                    {
                        c.Number = request.ValidationParams.PageSize * (request.ValidationParams.PageNumber - 1) + nrCrt;
                        nrCrt++;
                        return c;
                    }).ToList();

                return paginatedChargeList;
            }
        }
    }
}
