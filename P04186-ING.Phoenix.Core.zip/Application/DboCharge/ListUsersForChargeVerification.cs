﻿using Application.Commons.Enums;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCharge
{
    public class ListUsersForChargeVerification
    {
        public class Query : IRequest<IEnumerable<string>>
        {
            public string UserKey { get; set; }
        }

        public class Handler : IRequestHandler<Query, IEnumerable<string>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<IEnumerable<string>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get users for charges in status waiting for approval for ddl in charges verification");

                var users = from c in context.Charges.Where(c => c.Status.ObjectStatusName == ObjectStatus.Active ||
                                    c.Status.ObjectStatusName == ObjectStatus.VerificationAdd)
                            from ch in context.ChargesHistory.Where(ch => ch.ChargeId == c.ChargeId)
                                                          .OrderByDescending(ch => ch.ChargeHistoryId)
                                                           .Take(1)
                            where ch.LastModifiedBy != "System" && ch.LastModifiedBy != request.UserKey &&
                            (ch.Status.ObjectStatusName == ObjectStatus.VerificationAdd
                              || ch.Status.ObjectStatusName == ObjectStatus.VerificationModify
                              || ch.Status.ObjectStatusName == ObjectStatus.VerificationDelete)
                            select ch.LastModifiedBy;

                return await users.Distinct().OrderBy(u => u).ToListAsync();

            }
        }
    }
}
