﻿using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCharge
{
    public class List
    {
        public class Query : IRequest<CustomerChargesDTO> { public string CustomerId { get; set; } }

        public class Handler : IRequestHandler<Query, CustomerChargesDTO>
        {
            private readonly PhoenixContext _context;
            private readonly ILogger<Handler> _logger;


            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                _context = context;
                _logger = logger;
            }


            public async Task<CustomerChargesDTO> Handle(Query request, CancellationToken cancellationToken)
            {
                _logger.LogInformation($"Getting charges for customer with atlasId {request.CustomerId}");
                var customer = await _context.Customers.Where(c => c.AtlasID == request.CustomerId).FirstOrDefaultAsync();

                var charges = from c in _context.Charges.Where(c => (c.Status.ObjectStatusName == Commons.Enums.ObjectStatus.Active ||
                              c.Status.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationAdd) && c.AtlasId == request.CustomerId)
                              from ch in _context.ChargesHistory.Where(o => c.ChargeId == o.ChargeId)
                                                                 .OrderByDescending(h => h.ChargeHistoryId)
                                                                 .Take(1)
                                                                 .DefaultIfEmpty()

                              select new ChargeDTO
                              {
                                  ChargeId = c.ChargeId,
                                  ChargeValue = c.SpecialAmount == null ? ChargeValues.Standard.ToString() : ChargeValues.Negotiated.ToString(),
                                  ChargeTypeId = c.ChargeTypeId,
                                  ChargeTypeCode = c.ChargeType.ChargeTypeCode,
                                  ChargeTypeDescription = c.ChargeType.ChargeTypeDescription,
                                  StatusId = c.StatusId,
                                  StatusName = c.Status.ObjectStatusName,
                                  CustomerChargeTypeId = c.CustomerChargeTypeId,
                                  CustomerChargeTypeDescription = c.CustomerChargeType.Description,
                                  SpecialAmount = c.SpecialAmount,
                                  CurrencyId = c.CurrencyId,
                                  CurrencyCode = c.Currency.CurrencyCode,
                                  DebitAccount = c.DebitAccount,
                                  CreditAccountShort = c.CreditAccountShort.ToString(),
                                  ChargedItems = c.ChargedItems,
                                  RejectReason = c.RejectReason,
                                  REF_ID_CCM = c.REF_ID_CCM,
                                  ChargeTypeDefaultAmount = c.ChargeType.DefaultAmount,
                                  ChargeTypeAmountProduct = c.ChargeType.AmountProduct,
                                  ChargeTypeCurrencyId = c.ChargeType.CurrId,
                                  LastModifiedBy = c.LastModifiedBy,
                                  LastModifiedDate = c.LastModifiedDate,
                                  ChargeHistoryId = ch.ChargeHistoryId,
                                  ChargeTypeHistoryCode = ch.ChargeType.ChargeTypeCode,
                                  HistoryLastModifiedBy = ch.LastModifiedBy,
                                  HistoryDebitAccount = ch.DebitAccount,
                                  HistoryCreditAccount = ch.CreditAccountShort.ToString(),
                                  HistoryCurrencyCode = ch.Currency.CurrencyCode,
                                  HistoryChargedItems = ch.ChargedItems,
                                  HistoryStatusCode = ch.Status.ObjectStatusName,
                                  HistoryCustomerChargeTypeDescription = ch.CustomerChargeType.Description,
                                  HistorySpecialAmount = ch.SpecialAmount,
                                  HistoryChargeValue = ch.SpecialAmount == null ? ChargeValues.Standard.ToString() : ChargeValues.Negotiated.ToString(),
                                  AmountToDisplay = c.SpecialAmount != null ? c.SpecialAmount.Value : c.CustomerChargeTypeId == (int)CustomerChargeType.PerProduct ? c.ChargeType.AmountProduct.Value : c.ChargeType.DefaultAmount,
                                  CurrencyToDisplay = c.SpecialAmount != null ? c.Currency.CurrencyCode : c.ChargeType.Curr.CurrencyCode,
                                  HistoryAmountToDisplay = ch.SpecialAmount != null ? ch.SpecialAmount.Value : ch.CustomerChargeTypeId == (int)CustomerChargeType.PerProduct ? ch.ChargeType.AmountProduct.Value : ch.ChargeType.DefaultAmount,
                                  HistoryCurrencyToDisplay = ch.SpecialAmount != null ? ch.Currency.CurrencyCode : ch.ChargeType.Curr.CurrencyCode,
                                  AccountState = c.ChargeAccountState.Code,
                                  ChargeTypeGroupCd = c.ChargeType.ChargeTypeGroup.Code,
                                  PaymentDetails = c.PaymentDetails,
                                  HistoryPaymentDetails = ch.PaymentDetails
                              };

                var customerCharges = await charges.OrderByDescending(ch => ch.HistoryStatusCode).ThenBy(c => c.ChargeTypeCode).ToListAsync();

                return new CustomerChargesDTO
                {
                    CustomerId = request.CustomerId,
                    Comments = customer != null ? customer.Comments : "",
                    Charges = customerCharges
                };
            }
        }

    }
}
