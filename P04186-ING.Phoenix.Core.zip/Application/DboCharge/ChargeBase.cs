﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Application.Helpers;
using Castle.Core.Internal;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CustomerChargeType = Application.Commons.Enums.CustomerChargeType;

namespace Application.DboCharge
{
    public class ChargeBase
    {
        public async Task<List<ChargeTypeForChargeCreateDTO>> GetChargeTypeListForChargeCreate(PhoenixContext context, string coreBanking)
        {
            IQueryable<ChargeTypeForChargeCreateDTO> chargeTypes = from ct in context.ChargeTypes.Where(ct => ct.Status.ObjectStatusName == Commons.Enums.ObjectStatus.Active
                                 && ct.Action.Name == Department.PCM.ToString())
                                                                   from ac in context.Accounts.Where(ac => ac.CoreBanking == coreBanking && ct.CreditAccountShort == ac.AccountShort)
                                                                   from cth in context.ChargeTypeHistories.Where(cth => ct.ChargeTypeId == cth.ChargeTypeId)
                                                                                                 .OrderByDescending(cth => cth.ChargeTypeHistoryId)
                                                                                                  .Take(1)
                                                                   select new ChargeTypeForChargeCreateDTO
                                                                   {
                                                                       ChargeTypeId = ct.ChargeTypeId,
                                                                       ChargeTypeCode = ct.ChargeTypeCode,
                                                                       ChargeTypeDescription = ct.ChargeTypeDescription,
                                                                       CreditAccountShort = ct.CreditAccountShort != null ? ct.CreditAccountShort.ToString() : string.Empty,
                                                                       CurrencyId = ct.CurrId,
                                                                       DefaultAmount = ct.DefaultAmount,
                                                                       AmountProduct = ct.AmountProduct,
                                                                       ChargeTypeGroupCd = ct.ChargeTypeGroup.Code,
                                                                       PaymentDetails = ct.PaymentDetail,
                                                                       FrequencyId = ct.FrequencyId
                                                                   };

            return await chargeTypes.Distinct().OrderBy(c => c.ChargeTypeCode).ToListAsync();
        }

        public IQueryable<CipReportDTO> CipReportList(PhoenixContext context, CipReportParams filter, string VATValue)
        {
            IQueryable<CipReportDTO> cipList = (from c in context.Charges.Where(c => c.ChargedItems != null &&
                                                                (c.ChargeType.ChargeTypeCode == Constants.CIP_GBS ||
                                                                c.ChargeType.ChargeTypeCode == Constants.CIP_PRF))
                                                join acct in context.Accounts on c.DebitAccount equals acct.IBAN
                                                select new CipReportDTO
                                                {
                                                    GridId = acct.GridID,
                                                    CustomerId = c.AtlasId,
                                                    CustomerName = acct.CustomerName,
                                                    Branch = acct.BranchCode,
                                                    Address = acct.CustomerDetails.Address,
                                                    JCode = acct.CustomerDetails.RegistrationNumber,
                                                    CUI = acct.CUI.Replace("R", "").Replace("O", ""),
                                                    Quantity = c.ChargedItems.Value,
                                                    Amount = c.SpecialAmount != null ? c.SpecialAmount.Value : c.CustomerChargeTypeId == (int)CustomerChargeType.PerProduct ?
                                                                                                                      c.ChargeType.AmountProduct.Value : c.ChargeType.DefaultAmount,
                                                    VAT = decimal.Parse(VATValue) * 100,
                                                    DueDate = Constants.DUE_DAY_TVA
                                                })
                          .Where(c => c.Amount != 0);
            if (filter != null)
            {
                if (!string.IsNullOrEmpty(filter.CustomerId))
                {
                    cipList = cipList.Where(c => c.CustomerId.Contains(filter.CustomerId));
                }

                if (!string.IsNullOrEmpty(filter.CUI))
                {
                    cipList = cipList.Where(c => c.CUI.Contains(filter.CUI));
                }

                if (!string.IsNullOrEmpty(filter.GridId))
                {
                    cipList = cipList.Where(c => c.GridId.Contains(filter.GridId));
                }

                if (!string.IsNullOrEmpty(filter.Branch))
                {
                    cipList = cipList.Where(c => c.Branch == filter.Branch);
                }

            }

            return cipList;
        }

        public async Task<string> GetCoreBankingForAccount(PhoenixContext context, string customerId)
        {
            return await context.Accounts
                                        .Where(acc => acc.CustomerId == customerId)
                                        .Select(acc => acc.CoreBanking)
                                        .FirstOrDefaultAsync();
        }

        //protected async Task CheckCreditAccountShort(PhoenixContext context, ILogger logger, string debitAccount, long creditAccountShort)
        //{
        //    var creditAccount = await context.Accounts.FindAsync(creditAccountShort);
        //    if (creditAccount == null)
        //    {
        //        ErrorMesage($"Credit account short: {creditAccountShort} is invalid", logger);
        //    }

        //    var debitAcc = await context.Accounts.Where(a => a.IBAN == debitAccount).FirstOrDefaultAsync();
        //    if (debitAcc == null)
        //    {
        //        ErrorMesage($"Debit account: {debitAccount} is invalid", logger);
        //    }

        //    if (creditAccount.CoreBanking != debitAcc.CoreBanking)
        //    {
        //        ErrorMesage($"Debit account: {debitAccount} and credit account {creditAccountShort} should have the same CoreBanking!", logger);
        //    }

        //    if (creditAccount.CoreBanking == CoreBanking.GBS.ToString())
        //    {
        //        var validAccountType = (
        //                            from acc in context.Accounts
        //                            join gbsTypes in context.GBSCreditAccountTypes on acc.Type equals gbsTypes.Code
        //                            select
        //                                acc
        //                        ).Where(acc => acc.AccountShort == creditAccount.AccountShort).FirstOrDefault();

        //        if (validAccountType == null)
        //        {
        //            ErrorMesage($"Credit account short: {creditAccountShort} is invalid or has incorrect Core Banking!", logger);
        //        }
        //    }

        //    if (creditAccount.CoreBanking == CoreBanking.PRF.ToString())
        //    {
        //        var validAccountType = (
        //                            from acc in context.Accounts
        //                            join prfTypes in context.PRFCreditAccountTypes on acc.TypeId.Value equals prfTypes.CifTypeId
        //                            select
        //                                acc
        //                        ).Where(acc => acc.AccountShort == creditAccount.AccountShort).FirstOrDefault();

        //        if (validAccountType == null)
        //        {
        //            ErrorMesage($"Credit account short: {creditAccountShort} is invalid or has incorrect Core Banking!", logger);
        //        }
        //    }
        //}


        protected async Task CheckCreditAccountShort(PhoenixContext context, ILogger logger, int chargeTypeId, long creditAccountShort)
        {
            long? creditAccountShortCt = await context.ChargeTypes.Where(c => c.ChargeTypeId == chargeTypeId)
                                                              .Select(c => c.CreditAccountShort)
                                                              .FirstOrDefaultAsync();
            if (creditAccountShortCt != creditAccountShort)
            {
                ErrorMesage($"Credit account short: {creditAccountShort} is invalid", logger);
            }
        }

        private void ErrorMesage(string errMessage, ILogger logger)
        {
            logger.LogInformation(errMessage);
            throw new RestException(HttpStatusCode.BadRequest, errMessage);
        }

        protected async Task HasCustomerChargeType(PhoenixContext context, ILogger logger, string atlasId, int chargeTypeId,
            string chargeTypeCode, int customerChargeType, int currentCustomerChargeType, int chargeId)
        {
            bool hasCustomerChargeType = await context.Charges.Where(c => c.AtlasId == atlasId && c.ChargeTypeId == chargeTypeId
                                          && c.Status.ObjectStatusName == Commons.Enums.ObjectStatus.Active
                                          && c.CustomerChargeTypeId == customerChargeType
                                          && c.ChargeId != chargeId).AnyAsync();

            logger.LogInformation($"Charge for atlas id {atlasId} and charge type code {chargeTypeCode} " +
                $"has {(customerChargeType == (int)CustomerChargeType.PerProduct ? "per product" : "per transaction")} : {hasCustomerChargeType}");


            if (hasCustomerChargeType)
            {
                if (customerChargeType == (int)CustomerChargeType.PerProduct
                    && currentCustomerChargeType == (int)CustomerChargeType.PerTransaction)
                {
                    logger.LogInformation($"A per product is already set for charge type code: {chargeTypeCode}!");
                    throw new RestException(HttpStatusCode.BadRequest, $"A per product is already set for charge type code: {chargeTypeCode}!");
                }

                if (customerChargeType == (int)CustomerChargeType.PerTransaction
                && currentCustomerChargeType == (int)CustomerChargeType.PerProduct)
                {
                    logger.LogInformation($"A per transaction is already set for charge type code: {chargeTypeCode}!");
                    throw new RestException(HttpStatusCode.BadRequest, $"A per transaction is already set for charge type code: {chargeTypeCode}!");
                }
            }
        }

        protected void CheckCurrentCustomer(PhoenixContext context, string atlasId)
        {
            Customer currentCustomer = context.Customers.Where(c => c.AtlasID == atlasId).FirstOrDefault();

            if (currentCustomer == null)
            {
                Customer customer = new Customer
                {
                    AtlasID = atlasId,
                    StatusId = (byte)ObjectStatusId.Active
                };

                context.Add(customer);
            }
            else
            {
                if (currentCustomer.StatusId != (byte)ObjectStatusId.Active)
                {
                    currentCustomer.StatusId = (byte)ObjectStatusId.Active;
                }
            }
        }

        protected void CheckFCOMRules(int valueId, int customerChargeTypeId, ChargeTypeForChargeCreateDTO chargeType, ILogger logger)
        {
            if (chargeType.ChargeTypeGroupCd == Commons.Enums.ChargeTypeGroup.FCOM.ToString()
                                && valueId != (int)ChargeValues.Negotiated)
            {
                logger.LogInformation($"Charge Items of type FCOM should have Negociated value!");
                throw new RestException(HttpStatusCode.BadRequest, $"Charge Items of type FCOM should have Negociated value!");
            }

            if (chargeType.ChargeTypeGroupCd == Commons.Enums.ChargeTypeGroup.FCOM.ToString()
                                && customerChargeTypeId != (int)CustomerChargeType.PerProduct)
            {
                logger.LogInformation($"Charge Items of type FCOM should have Negociated value!");
                throw new RestException(HttpStatusCode.BadRequest, $"Charge Items of type FCOM should have Negociated value!");
            }
        }


        public async Task ValidateCharge(PhoenixContext context, ILogger logger, ChargeValidationObjectDTO charge, string chargeTypeCode, string paymentDetails, string chargeTypeGroup, int chargeId = 0)
        {
            await CheckCreditAccountShort(context, logger, charge.ChargeTypeId, charge.CreditAccountShort);

            await HasCustomerChargeType(context, logger, charge.AtlasId, charge.ChargeTypeId, chargeTypeCode,
                (int)CustomerChargeType.PerProduct, charge.CustomerChargeTypeId, chargeId);

            await HasCustomerChargeType(context, logger, charge.AtlasId, charge.ChargeTypeId, chargeTypeCode,
                (int)CustomerChargeType.PerTransaction, charge.CustomerChargeTypeId, chargeId);
            if(chargeTypeGroup == Commons.Enums.ChargeTypeGroup.RECO.ToString())
                await CheckUnicityChargeTypeDebitAccForRECO(context, logger, charge.AtlasId, charge.ChargeTypeId, charge.DebitAccount, paymentDetails, chargeId);
            else
                await CheckUnicityChargeTypeDebitAccNonRECO(context, logger, charge.AtlasId, charge.ChargeTypeId, charge.DebitAccount, chargeId);

            CheckCurrentCustomer(context, charge.AtlasId);
        }

        private async Task CheckUnicityChargeTypeDebitAccNonRECO(PhoenixContext context, ILogger logger, string atlasiId, int chargeTypeId, string debitAccount, int chargeId)
        {
            Charge chargeOnSameDebitAccount = await context
                                                    .Charges
                                                    .Where(c => c.ChargeTypeId == chargeTypeId &&
                                                            c.AtlasId == atlasiId &&
                                                            c.DebitAccount == debitAccount &&
                                                            (c.StatusId != (int)ObjectStatusId.Deleted && c.StatusId != (int)ObjectStatusId.RejectAdd) &&
                                                            c.ChargeId != chargeId
                                                            )
                                                    .FirstOrDefaultAsync();
            if (chargeOnSameDebitAccount != null)
            {
                logger.LogInformation($"Charge code {chargeOnSameDebitAccount.ChargeType.ChargeTypeCode} already exits on same debit account");
                throw new RestException(HttpStatusCode.BadRequest, $"Charge code {chargeOnSameDebitAccount.ChargeType.ChargeTypeCode} already exits on same debit account!");
            }
        }
        private async Task CheckUnicityChargeTypeDebitAccForRECO(PhoenixContext context, ILogger logger, string atlasiId, int chargeTypeId, string debitAccount, string paymentDetails, int chargeId)
        {
            string pattern = @"[re|pa|RE|PA]{2}\d{13}";
            var paymentDetail = Regex.Match(paymentDetails, pattern).ToString();

            if(!string.IsNullOrEmpty(paymentDetail))
            { 
                Charge chargeOnSameDebitAccount = await context
                                                        .Charges
                                                        .Where(c => c.ChargeTypeId == chargeTypeId &&
                                                                c.AtlasId == atlasiId &&
                                                                c.DebitAccount == debitAccount &&
                                                                (c.StatusId != (int)ObjectStatusId.Deleted && c.StatusId != (int)ObjectStatusId.RejectAdd)
                                                                &&
                                                                c.ChargeId != chargeId &&
                                                                c.PaymentDetails.Contains(paymentDetail)
                                                                )
                                                        .FirstOrDefaultAsync();
                if (chargeOnSameDebitAccount != null)
                {
                    logger.LogInformation($"Charge code {chargeOnSameDebitAccount.ChargeType.ChargeTypeCode} already exits on same debit account!");
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge code {chargeOnSameDebitAccount.ChargeType.ChargeTypeCode} already exits on same debit account!");
                };
            }
        }

        protected async Task UpdateCustomerToNotSet(PhoenixContext context, ILogger logger, string chargeAtlasId, int chargeId)
        {
            Customer currentCustomer = await context.Customers.Where(c => c.AtlasID == chargeAtlasId).FirstOrDefaultAsync();
            if (currentCustomer == null)
            {
                logger.LogInformation($"Customer for atlasId {chargeAtlasId} does not exist in the database.");
                throw new RestException(HttpStatusCode.BadRequest, $"Customer for atlasId {chargeAtlasId} does not exist in the database. Please contact administrator!");
            }

            bool hasChargesInOtherStatus = await context.Charges
                            .Where(c => c.AtlasId == chargeAtlasId && c.ChargeId != chargeId &&
                                c.Status.ObjectStatusName != Commons.Enums.ObjectStatus.Deleted &&
                                c.Status.ObjectStatusName != Commons.Enums.ObjectStatus.RejectAdd)
                            .AnyAsync();

            if (!hasChargesInOtherStatus && currentCustomer.StatusId != (byte)ObjectStatusId.NotSet)
            {
                currentCustomer.StatusId = (byte)ObjectStatusId.NotSet;
            }
        }

        protected void ValidateChargeValueAndType(ChargeValidationObjectDTO charge, ILogger logger)
        {
            if (charge.ValueId == (int)ChargeValues.Standard && (charge.CurrencyId != null || charge.SpecialAmount != null))
            {
                logger.LogInformation($"Currency and/or amount should not be null if value is STANDARD!");
                throw new RestException(HttpStatusCode.BadRequest, $"Currency and/or amount should not be null if value is STANDARD!");
            }

            if (charge.CustomerChargeTypeId == (int)Commons.Enums.CustomerChargeType.PerProduct && charge.ChargedItems > 1)
            {
                logger.LogInformation($"Charged Items can have just value NULL or 1 for customer charge type Per Product!");
                throw new RestException(HttpStatusCode.BadRequest, $"Charged Items can have just value NULL or 1 for customer charge type Per Product!");
            }
        }

        protected void ValidatePaymentDetails(string chargePaymentDetails, ChargeTypeForChargeCreateDTO chargeType, ILogger logger)
        {
            if (chargeType.FrequencyId != (int)Commons.Enums.ProcessingFrequency.Once && chargeType.PaymentDetails != chargePaymentDetails)
            {
                logger.LogInformation($"For charge other than once payment details for customer charge must be the same with payment details for charge!");
                throw new RestException(HttpStatusCode.BadRequest, $"For charge other than once payment details for customer charge must be the same with payment details " +
                    $"for charge");
            }
        }
    }
}