﻿using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Application.StateManagement;
using AutoMapper;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCharge
{
    public class Edit
    {
        public class Command : IRequest
        {

            public int ChargeId { get; set; }
            public string AtlasId { get; set; }
            public int ValueId { get; set; }
            public int ChargeTypeId { get; set; }
            public int CustomerChargeTypeId { get; set; }
            public decimal? SpecialAmount { get; set; }
            public int? CurrencyId { get; set; }
            public int? ChargedItems { get; set; }
            public string DebitAccount { get; set; }
            public long CreditAccountShort { get; set; }
            public string LastModifiedBy { get; set; }
            public DateTime LastModifiedDate { get; set; }
            public string PaymentDetails { get; set; }

        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(ch => ch.ChargeTypeId).NotNull();
                RuleFor(ch => ch.CustomerChargeTypeId).NotNull();
                RuleFor(ch => ch.DebitAccount).NotNull();
                RuleFor(ch => ch.CreditAccountShort).NotNull().Must(x => x > 999 && x < 1000000000000);
                RuleFor(ch => ch.ChargedItems).NotEqual(0);
                RuleFor(ch => ch.PaymentDetails).MaximumLength(35);
            }
        }

        public class Handler : ChargeBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Edit charge {request.ChargeId}");
                var charge = await context.Charges.FindAsync(request.ChargeId);

                if (charge == null)
                {
                    logger.LogInformation($"Charge id {request.ChargeId} does not exist in the database!");
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge id {request.ChargeId} does not exist in the database!");
                }

                if (charge.Status.ObjectStatusName != Commons.Enums.ObjectStatus.Active)
                {
                    logger.LogInformation($"Cannot edit charge that is not active!");
                    throw new RestException(HttpStatusCode.BadRequest, $"Cannot edit charge that is not active!");
                }

                var coreBankingForClient = await GetCoreBankingForAccount(context, request.AtlasId);

                var validChargeTypes = await GetChargeTypeListForChargeCreate(context, coreBankingForClient);

                var chargeType = validChargeTypes.Where(ct => ct.ChargeTypeId == request.ChargeTypeId).FirstOrDefault();

                if (chargeType == null)
                {
                    logger.LogInformation($"Charge type is not valid for editing a charge!");
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type is not valid for editing a charge!");
                }

                var chargeValidation = mapper.Map<Command, ChargeValidationObjectDTO>(request);

                var chargeTypeCode = chargeType.ChargeTypeCode;

                ValidateChargeValueAndType(chargeValidation, logger);
                ValidatePaymentDetails(request.PaymentDetails, chargeType, logger);

                CheckFCOMRules(request.ValueId, request.CustomerChargeTypeId, chargeType, logger);

                await ValidateCharge(context, logger, chargeValidation, chargeTypeCode, request.PaymentDetails, chargeType.ChargeTypeGroupCd, request.ChargeId);

                var chargeHistory = await context.ChargesHistory
                    .Where(ch => ch.ChargeId == charge.ChargeId)
                    .OrderByDescending(ch => ch.ChargeHistoryId)
                    .FirstOrDefaultAsync();

                if (chargeHistory == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge history for {request.ChargeId} does not exist in the database!");
                }

                var statusManger = new StatusStateManagement(charge.Status.ObjectStatusName, chargeHistory.Status.ObjectStatusName);
                statusManger.SetNextState(StateTrigger.Modify);
                logger.LogInformation($"Future state after modify state, charge: {statusManger.State} charge history: {statusManger.HistoryState}");
                var objStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.State.ToString()).FirstOrDefaultAsync();
                var objStatusForHistory = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.HistoryState.ToString()).FirstOrDefaultAsync();

                if (charge.Status.ObjectStatusName != Commons.Enums.ObjectStatus.Deleted && !IsChargeDirty(charge, request))
                {
                    return Unit.Value;
                }

                charge.StatusId = objStatus.ObjectStatusId;
                charge.LastModifiedBy = request.LastModifiedBy;
                charge.LastModifiedDate = DateTime.Now;
                charge.RejectReason = null;

                var chargeHistoryEdit = mapper.Map<Command, ChargeHistory>(request);
                chargeHistoryEdit.StatusId = objStatusForHistory.ObjectStatusId;
                chargeHistoryEdit.LastModifiedDate = DateTime.Now;
                chargeHistoryEdit.Charge = charge;
                chargeHistoryEdit.ActionId = (int)ObjectAction.EDIT;
                chargeHistoryEdit.PaymentDetails = chargeType.FrequencyId == (int)Commons.Enums.ProcessingFrequency.Once
                    && string.IsNullOrEmpty(request.PaymentDetails) ? chargeType.PaymentDetails : request.PaymentDetails;
                context.ChargesHistory.Add(chargeHistoryEdit);

                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Charge was not updated!");
            }

            private bool IsChargeDirty(Charge charge, Command request)
            {
                return charge.CustomerChargeTypeId != request.CustomerChargeTypeId ||
                        charge.SpecialAmount != request.SpecialAmount ||
                        charge.CreditAccountShort != request.CreditAccountShort ||
                        charge.CurrencyId != request.CurrencyId ||
                        charge.ChargedItems != request.ChargedItems ||
                        charge.DebitAccount != request.DebitAccount ||
                        charge.CreditAccountShort != request.CreditAccountShort ||
                        charge.PaymentDetails != request.PaymentDetails;
            }
        }
    }
}
