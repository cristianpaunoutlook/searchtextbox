﻿using Application.Commons.Enums;
using Application.DTO;
using Application.Helpers;
using Persistence;
using System.Linq;

namespace Application.DboCharge
{
    public class VerificationBase
    {
        public IQueryable<ChargeValidationDTO> ChargeVerificationList(PhoenixContext context, ValidationParams filter, string userKey)
        {
            var chargesToVerify = from c in context.Charges
                                  join ct in context.ChargeTypes on c.ChargeTypeId equals ct.ChargeTypeId
                                  join curr in context.Currencies on ct.CurrId equals curr.CurrencyId into chgCurr
                                  from curr in chgCurr.DefaultIfEmpty()
                                  join a in context.Accounts on c.DebitAccount equals a.IBAN
                                  from ch in context.ChargesHistory.Where(o => c.ChargeId == o.ChargeId)
                                                             .OrderByDescending(h => h.ChargeHistoryId)
                                                             .Take(1)
                                  select new ChargeValidationDTO()
                                  {
                                      ChargeId = c.ChargeId,
                                      ChargeTypeId = c.ChargeTypeId,
                                      ChargeTypeCode = ct.ChargeTypeCode,
                                      Amount = c.SpecialAmount != null ?
                                                c.SpecialAmount.Value : c.CustomerChargeTypeId == (int)CustomerChargeType.PerProduct ?
                                                                            ct.AmountProduct.Value : ct.DefaultAmount,
                                      DebitAccount = c.DebitAccount,
                                      CreditAccount = c.CreditAccountShort,
                                      CustomerId = c.AtlasId,
                                      CustomerName = a.CustomerName,
                                      PaymentDetails = c.PaymentDetails ?? ct.PaymentDetail,
                                      Type = c.CustomerChargeType.Description,
                                      SessionId = c.SessionId,
                                      UserId = ch.LastModifiedBy,
                                      StatusId = ch.StatusId,
                                      Status = ch.Status.ObjectStatusName,
                                      ImportDate = ch.LastModifiedDate,
                                      Currency = c.SpecialAmount != null ? c.Currency.CurrencyCode : curr.CurrencyCode,
                                  };

            chargesToVerify = chargesToVerify.Where(c => c.UserId != userKey);

            if (filter.ChargeTypeId != -1)
            {
                chargesToVerify = chargesToVerify.Where(c => c.ChargeTypeId == filter.ChargeTypeId);
            }

            if (!string.IsNullOrEmpty(filter.CustomerId))
            {
                chargesToVerify = chargesToVerify.Where(c => c.CustomerId.Contains(filter.CustomerId));
            }

            if (!string.IsNullOrEmpty(filter.CustomerName))
            {
                chargesToVerify = chargesToVerify.Where(c => c.CustomerName.Contains(filter.CustomerName));
            }

            if (filter.SessionId != -1)
            {
                chargesToVerify = chargesToVerify.Where(c => c.SessionId == filter.SessionId);
            }

            if (!string.IsNullOrEmpty(filter.UserId))
            {
                chargesToVerify = chargesToVerify.Where(c => c.UserId.Contains(filter.UserId));
            }

            if (filter.StatusId != -1)
            {
                chargesToVerify = chargesToVerify.Where(c => c.StatusId == filter.StatusId);
            }
            else
            {
                chargesToVerify = chargesToVerify.Where(c => c.StatusId == (int)ObjectStatusId.VerificationAdd ||
                                                                c.StatusId == (int)ObjectStatusId.VerificationModify ||
                                                                c.StatusId == (int)ObjectStatusId.VerificationDelete);
            }

            if (filter.ImportDate != null)
            {
                chargesToVerify = chargesToVerify.Where(c => c.ImportDate.Value >= filter.ImportDate
                                                                && c.ImportDate.Value < filter.ImportDate.Value.AddDays(1));
            }

            return chargesToVerify.OrderBy(c => c.ChargeTypeCode).ThenBy(c => c.CustomerName);
        }
    }
}
