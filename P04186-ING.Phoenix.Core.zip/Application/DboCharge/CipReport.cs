﻿using Application.Commons.Constants;
using Application.DTO;
using Application.Errors;
using Application.Helpers;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCharge
{
    public class CipReport
    {
        public class Query : IRequest<PagedList<CipReportDTO>>
        {
            public CipReportParams CipReportParams { get; set; }
        }

        public class Handler : ChargeBase, IRequestHandler<Query, PagedList<CipReportDTO>>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<PagedList<CipReportDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get cip report with filters code: " +
                    $"CustomerId: {request.CipReportParams.CustomerId} GridId: {request.CipReportParams.GridId} " +
                    $"CUI: {request.CipReportParams.CUI} branch: {request.CipReportParams.Branch} ");

                var VATParam = await context.Parameters.FirstOrDefaultAsync(p => p.ParamName == Constants.VAT_PARAMETER_NAME);
                if (VATParam == null)
                    throw new Exception("No Parameter defined for VAT value");

                var cipReport = CipReportList(context, request.CipReportParams, VATParam.ParamValue);
                var cipList = await PagedList<CipReportDTO>.CreateAsync(cipReport, request.CipReportParams.PageNumber, request.CipReportParams.PageSize);
                if (cipList == null || cipList.Items.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched cip charges does not exist in the database!");
                }
                return cipList;
            }
        }
    }
}
