﻿using Application.Errors;
using Application.Helpers;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCharge
{
    [ExcludeFromCodeCoverage]
    public class BulkReject
    {
        public class Query : IRequest<int>
        {
            public int[] ChargeIds { get; set; }
            public ValidationParams Filter { get; set; }
            public bool ListToExclude { get; set; }
            public string RejectReason { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : ApproveRejectBase, IRequestHandler<Query, int>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }
            public async Task<int> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Bulk reject charges from charge verification");

                if (string.IsNullOrEmpty(request.RejectReason))
                    throw new RestException(HttpStatusCode.BadRequest, "Reject Reason must not be empty!");

                int[] chargeIdsForApprove = GetIdsForApproveReject(request.ListToExclude, request.ChargeIds, request.Filter, context, request.UserKey);

                return await context.BulkRejectCharges(chargeIdsForApprove, request.UserKey, request.RejectReason);

            }
        }
    }
}
