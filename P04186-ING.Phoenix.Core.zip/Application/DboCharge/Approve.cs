﻿using Application.Commons.Enums;
using Application.Errors;
using Application.StateManagement;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCharge
{
    public class Approve
    {
        public class Command : IRequest
        {
            public int ChargeId { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : ChargeBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Approve action for customer charge with id {request.ChargeId}");
                var customerCharge = await context.Charges.Where(c => c.ChargeId == request.ChargeId).FirstOrDefaultAsync();
                if (customerCharge == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Customer charge with id {request.ChargeId} does not exist in the database!");
                }

                var chargeTypeCode = customerCharge.ChargeType.ChargeTypeCode;

                await HasCustomerChargeType(context, logger, customerCharge.AtlasId, customerCharge.ChargeTypeId, chargeTypeCode,
               (int)Commons.Enums.CustomerChargeType.PerProduct, customerCharge.CustomerChargeTypeId.Value, request.ChargeId);

                await HasCustomerChargeType(context, logger, customerCharge.AtlasId, customerCharge.ChargeTypeId, chargeTypeCode,
                    (int)Commons.Enums.CustomerChargeType.PerTransaction, customerCharge.CustomerChargeTypeId.Value, request.ChargeId);

                var customerChargeHistory = await context.ChargesHistory
                    .Where(ch => ch.ChargeId == customerCharge.ChargeId)
                    .OrderByDescending(ch => ch.ChargeHistoryId)
                    .FirstOrDefaultAsync();

                if (customerChargeHistory == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Customer charge history with id {request.ChargeId} does not exist in the database!");
                }

                if (request.UserKey == customerChargeHistory.LastModifiedBy)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"You have changed the customer charge with id {request.ChargeId} so you can not approve the changes!");
                }

                logger.LogInformation($"Current state, customer charge: {customerCharge.Status.ObjectStatusName} customer charge history: {customerChargeHistory.Status.ObjectStatusName}");
                var statusManger = new StatusStateManagement(customerCharge.Status.ObjectStatusName, customerChargeHistory.Status.ObjectStatusName);
                statusManger.SetNextState(StateTrigger.Approve);

                logger.LogInformation($"Future state after approve, customer charge state: {statusManger.State} customer charge history state: {statusManger.HistoryState}");
                var objStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.State.ToString()).FirstOrDefaultAsync();
                var objStatusForHistory = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.HistoryState.ToString()).FirstOrDefaultAsync();
                customerCharge.StatusId = objStatus.ObjectStatusId;
                customerCharge.LastModifiedBy = request.UserKey;
                customerCharge.RejectReason = null;
                customerCharge.GetFromHistory(customerChargeHistory);
                var newChargeHistory = mapper.Map<ChargeHistory>(customerCharge);
                newChargeHistory.Status = objStatusForHistory;
                newChargeHistory.StatusId = objStatusForHistory.ObjectStatusId;
                newChargeHistory.ActionId = (int)ObjectAction.APPROVE;

                context.ChargesHistory.Add(newChargeHistory);
                if (objStatus.ObjectStatusName == Commons.Enums.ObjectStatus.Deleted)
                {
                    await UpdateCustomerToNotSet(context, logger, customerCharge.AtlasId, customerCharge.ChargeId);
                }

                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Error on approve customer charge!");
            }
        }
    }
}
