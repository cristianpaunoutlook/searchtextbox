﻿using Application.Helpers;

namespace Application.DboCharge
{
    public class ChargesVerification
    {
        public int[] ChargeIds { get; set; }
        public ValidationParams Filter { get; set; }
        public bool ListToExclude { get; set; }
        public string RejectReason { get; set; }
    }
}
