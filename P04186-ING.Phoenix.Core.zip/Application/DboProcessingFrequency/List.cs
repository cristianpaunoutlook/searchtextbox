﻿using Domain;
using Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using Enums = Application.Commons.Enums;

namespace Application.DboProcessingFrequency
{
    public class List
    {
        public class Query : IRequest<List<ProcessingFrequency>> { }

        public class Handler : IRequestHandler<Query, List<ProcessingFrequency>>
        {
            private readonly PhoenixContext _context;
            public Handler(PhoenixContext context)
            {
                _context = context;
            }
            public async Task<List<ProcessingFrequency>> Handle(Query request, CancellationToken cancellationToken) =>
                await _context.ProcessingFrequencies
                            .Where(pf => pf.ProcessingFrequencyName == Enums.ProcessingFrequency.Once.ToString() ||
                                    pf.ProcessingFrequencyName == Enums.ProcessingFrequency.Monthly.ToString() ||
                                    pf.ProcessingFrequencyName == Enums.ProcessingFrequency.Quarterly.ToString())
                            .ToListAsync();
        }
    }
}
