﻿using System;
using System.Net;
using Application.Commons.Enums;
using Application.Errors;
using Stateless;

namespace Application.StateManagement
{
    public class StatusStateManagement
    {
        private State _statusState;
        private HistoryState _statusHistoryState;
        private readonly StateMachine<State, StateTrigger> _machine;
        private readonly StateMachine<HistoryState, StateTrigger> _machineHistory;
        private readonly bool _isChargeType;

        public StatusStateManagement(string statusState, string statusHistoryState, bool isChargeType = false)
        {
            if (!Enum.TryParse(statusState, true, out _statusState))
            {
                throw new RestException(HttpStatusCode.BadRequest,
                   isChargeType ? $"{statusState} is not a valid state for Charge Types!" : $"{statusState} is not a valid state for Customer Charges!"
                    );
            }
            if (!Enum.TryParse(statusHistoryState, true, out _statusHistoryState))
            {
                throw new RestException(HttpStatusCode.BadRequest,
                   isChargeType ? $"{statusHistoryState} is not a valid state for Charge Types!" : $"{statusHistoryState} is not a valid state for Customer Charges!"
                    );
            }
            _machine = new StateMachine<State, StateTrigger>(() => _statusState, s => _statusState = s);
            _machineHistory = new StateMachine<HistoryState, StateTrigger>(() => _statusHistoryState, s => _statusHistoryState = s);
            _isChargeType = isChargeType;
            InitHistoryStates();
            InitStates();
        }

        private void InitStates()
        {
            _machine.Configure(State.VerificationAdd).Permit(StateTrigger.Approve, State.Active);
            _machine.Configure(State.VerificationAdd).Permit(StateTrigger.Reject, State.RejectAdd);

            _machine.Configure(State.Active).PermitReentry(StateTrigger.Modify);
            _machine.Configure(State.Active).PermitReentry(StateTrigger.Delete);

            if (_isChargeType)
            {
                _machine.Configure(State.Deleted)
                    .PermitIf(StateTrigger.Modify,
                    State.VerificationAdd,
                    () => _machineHistory.State == HistoryState.Deleted);
            }

            if (_isChargeType)
            {
                _machine.Configure(State.RejectAdd)
                    .PermitIf(StateTrigger.Modify,
                    State.VerificationAdd,
                    () => _machineHistory.State == HistoryState.RejectAdd);
            }

            _machine.Configure(State.Active)
                .PermitIf(StateTrigger.Approve,
                    State.Deleted,
                    () => _machineHistory.State == HistoryState.VerificationDelete);

            _machine.Configure(State.Active)
                            .PermitReentryIf(StateTrigger.Approve,
                                () => _machineHistory.State == HistoryState.VerificationModify);

            _machine.Configure(State.Active)
                .PermitReentryIf(StateTrigger.Reject,
                    () => _machineHistory.State == HistoryState.VerificationDelete ||
                            _machineHistory.State == HistoryState.VerificationModify);

            _machine.OnUnhandledTrigger((state, trigger) =>
            {
                throw new RestException(HttpStatusCode.BadRequest,
                    _isChargeType ? $"We can't {trigger} a charge type in state {_statusState}" : $"We can't {trigger} a customer charge in state {_statusState}"
                    );
            });
        }

        private void InitHistoryStates()
        {
            _machineHistory.Configure(HistoryState.VerificationAdd).Permit(StateTrigger.Approve, HistoryState.Active);
            _machineHistory.Configure(HistoryState.VerificationAdd).Permit(StateTrigger.Reject, HistoryState.RejectAdd);

            _machineHistory.Configure(HistoryState.Active).Permit(StateTrigger.Modify, HistoryState.VerificationModify);
            _machineHistory.Configure(HistoryState.Active).Permit(StateTrigger.Delete, HistoryState.VerificationDelete);

            _machineHistory.Configure(HistoryState.VerificationModify).Permit(StateTrigger.Approve, HistoryState.Active);
            _machineHistory.Configure(HistoryState.VerificationModify).Permit(StateTrigger.Reject, HistoryState.Active);

            _machineHistory.Configure(HistoryState.VerificationDelete).Permit(StateTrigger.Approve, HistoryState.Deleted);
            _machineHistory.Configure(HistoryState.VerificationDelete).Permit(StateTrigger.Reject, HistoryState.Active);

            _machineHistory.Configure(HistoryState.Deleted).Permit(StateTrigger.Modify, HistoryState.VerificationAdd);
            _machineHistory.Configure(HistoryState.RejectAdd).Permit(StateTrigger.Modify, HistoryState.VerificationAdd);

            _machineHistory.OnUnhandledTrigger((state, trigger) =>
            {
                throw new RestException(HttpStatusCode.BadRequest,
                    _isChargeType ? $"We can't {trigger} a charge type in state {_statusHistoryState}" : $"We can't {trigger} a customer charge in state {_statusHistoryState}"
                    );
            });
        }

        public HistoryState HistoryState { get => _machineHistory.State; }
        public State State { get => _machine.State; }

        public void SetNextState(StateTrigger trigger)
        {
            _machine.Fire(trigger);
            _machineHistory.Fire(trigger);
        }
    }
}

