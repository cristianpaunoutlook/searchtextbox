﻿using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.Commons.Constants;
using Application.DTO;
using Application.Errors;
using Application.Export.ImportedPayments;
using Application.Helpers;
using AutoMapper;
using Castle.Core.Internal;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;

namespace Application.DboImportedPayments
{
    public class List
    {
        public class Query : IRequest<ImportedPaymentsListDTO>
        {
            public ImportedPaymentsParams ImportedPaymentsParams { get; set; }
            public string UserId { get; set; }
        }

        public class Handler : ImportedPaymentsListBase, IRequestHandler<Query, ImportedPaymentsListDTO>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;


            public Handler(PhoenixContext context, IMapper mapper)
            {
                this.context = context;
                this.mapper = mapper;
            }

            public async Task<ImportedPaymentsListDTO> Handle(Query request, CancellationToken cancellationToken)
            {
                var sessionId = request.ImportedPaymentsParams.SessionId;
                var userId = request.UserId;
                if (sessionId == 0)
                {
                    var paramImportSession = await context.Parameters.Where(p => p.ParamName == Constants.FILE_IMPORT_SESSION_ID).FirstOrDefaultAsync();
                    if (paramImportSession == null)
                        throw new RestException(HttpStatusCode.BadRequest, $"The parameter {Constants.FILE_IMPORT_SESSION_ID} is missing from Parameter table.");
                    sessionId = int.Parse(paramImportSession.ParamValue);
                    var paramImportUser = await context.Parameters.Where(p => p.ParamName == Constants.FILE_IMPORT_USER_ID).FirstOrDefaultAsync();
                    if (paramImportUser == null)
                        throw new RestException(HttpStatusCode.BadRequest, $"The parameter {Constants.FILE_IMPORT_USER_ID} is missing from Parameter table.");
                    userId = paramImportUser.ParamValue;
                    if (paramImportSession.ParamValue.IsNullOrEmpty() && paramImportUser.ParamValue.IsNullOrEmpty())
                        throw new RestException(HttpStatusCode.BadRequest, "There is no import session in working progress");
                    paramImportUser.ParamValue = "";
                    paramImportSession.ParamValue = "";
                    await context.SaveChangesAsync();
                }

                var filter = mapper.Map<ImportedPaymentsFilter>(request.ImportedPaymentsParams);
                if (filter.SessionId == 0)
                {
                    filter.SessionId = sessionId;
                }
                var importedPayments = ImportedPaymentsList(context, filter, userId);

                var importedPaymentsPaginatedDTO = await PagedList<ImportedPaymentsDTO>.CreateAsync(importedPayments, request.ImportedPaymentsParams.PageNumber,
                    request.ImportedPaymentsParams.PageSize);

                var idx = 1;
                importedPaymentsPaginatedDTO.Items = importedPaymentsPaginatedDTO.Items.Select(ip =>
                    {
                        ip.No = (request.ImportedPaymentsParams.PageNumber - 1) * request.ImportedPaymentsParams.PageSize + idx;
                        idx++;
                        return ip;
                    }).ToList();

                return new ImportedPaymentsListDTO() { SessionId = sessionId, ImportedPayments = importedPaymentsPaginatedDTO };
            }
        }
    }
}
