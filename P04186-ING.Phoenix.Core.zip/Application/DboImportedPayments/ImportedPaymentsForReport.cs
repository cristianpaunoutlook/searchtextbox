﻿using Application.DTO;
using Application.Errors;
using Application.Export.ImportedPaymentsReport;
using Application.Helpers;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboImportedPayments
{
    public class ImportedPaymentsForReport
    {
        public class Query : IRequest<PagedList<ImportedPaymentsReportDTO>>
        {
            public ImportedPaymentsReportParams ImportedPaymentsReportParams { get; set; }
        }

        public class Handler : ImportedPaymentsListBase, IRequestHandler<Query, PagedList<ImportedPaymentsReportDTO>>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<PagedList<ImportedPaymentsReportDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get imported payments list with filters session id: {request.ImportedPaymentsReportParams.SessionId}  " +
                    $"customerId: {request.ImportedPaymentsReportParams.CustomerId} chargeCode: {request.ImportedPaymentsReportParams.ChargeCode} " +
                    $"userId: {request.ImportedPaymentsReportParams.UserId} startDate: {request.ImportedPaymentsReportParams.StartDate} " +
                    $"endDate: {request.ImportedPaymentsReportParams.EndDate} isImported: {request.ImportedPaymentsReportParams.IsImported}");

                if (request.ImportedPaymentsReportParams.StartDate != null && request.ImportedPaymentsReportParams.EndDate != null &&
                    request.ImportedPaymentsReportParams.StartDate > request.ImportedPaymentsReportParams.EndDate)
                {
                    logger.LogInformation($"Start date cannot be greater than end date!");
                    throw new RestException(HttpStatusCode.BadRequest, $"Start date cannot be greater than end date!");
                }

                var filter = mapper.Map<ImportedPaymentsReportFilter>(request.ImportedPaymentsReportParams);
                var importedPayments = ImportedPaymentsReportList(context, filter);

                importedPayments = importedPayments.OrderByDescending(ip => ip.SessionId).ThenByDescending(ip => ip.LineNumber);

                var importedPaymentsResult = await PagedList<ImportedPaymentsReportDTO>.CreateAsync(importedPayments, request.ImportedPaymentsReportParams.PageNumber,
                    request.ImportedPaymentsReportParams.PageSize);

                if (importedPaymentsResult == null || importedPaymentsResult.Items.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched imported payments does not exist in the database!");
                }

                return importedPaymentsResult;
            }
        }
    }
}
