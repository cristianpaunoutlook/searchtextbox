﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.Errors;
using Application.Helpers;
using Application.Import;
using Application.Interfaces;
using Application.Interfaces.Import;
using Application.Notifications.FileImportNotifications;
using AutoMapper;
using Domain;
using EFCore.BulkExtensions;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboImportedPayments
{
    [ExcludeFromCodeCoverage]
    public class ImportFile
    {
        public class Command : IRequest
        {
            public IFormFile FileToImport { get; set; }
            public string UserId { get; set; }
            public int MailId { get; set; }

        }
        public class Handler : FileImportNotificationBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;
            private readonly IImportFromExcel<ImportCharges> importFile;
            private readonly IMapper mapper;

            public Handler(PhoenixContext context, ILogger<Handler> logger, IImportFromExcel<ImportCharges> importFile, IMapper mapper,
                IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.logger = logger;
                this.importFile = importFile;
                this.mapper = mapper;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                var savedFileFullPath = await SaveFile(request);
                int sessionId;
                int importedPaymntsOK;

                var mailTo = await context.MailList.Where(m => m.Id == request.MailId).FirstOrDefaultAsync();

                if (mailTo == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest,"Please select an address email!");
                } 

                using (var transaction = context.Database.BeginTransaction())
                {
                    var newSession = await CreateSessionAndParameters(request.FileToImport.FileName, request.UserId);
                    sessionId = newSession.SessionId;
                    await AddApplicationLog(sessionId, request.UserId);
                    AddChargesToImportedPayments(savedFileFullPath, newSession);
                    await ValidateImportedPayments(sessionId);
                    await AddCharges(sessionId, request.UserId);
                    importedPaymntsOK = IsImportOk(sessionId);
                    transaction.Commit();
                }

                await ActivateClient(sessionId, request.UserId);

                logger.LogInformation($"Delete saved file {savedFileFullPath} from import folder!");
                File.Delete(savedFileFullPath);

                if (importedPaymntsOK > 0)
                {
                    await SendFileImportEmailAsync(sessionId, request.UserId, mailTo.Email);
                }

                return Unit.Value;
            }

            private int IsImportOk(int sessionId)
            {
                logger.LogInformation($"Start spValidateImportedPaymentsForFileImport");
                int result = context.ImportedPayments.Where(ip => ip.SessionId == sessionId && ip.IsImported == true).Count();
                return result;
            }

            private async Task AddApplicationLog(int sessionId, string userId)
            {
                var applicationLog = new ApplicationLog
                {
                    UserId = userId,
                    ActionId = (int)ObjectAction.IMPORT_FILE,
                    ObjectTypeId = (int)Commons.Enums.ObjectType.SessionImport,
                    RecordId = sessionId.ToString(),
                    ErrorNumberId = 0,
                    RecordStamp = DateTime.Now,
                    SessionId = sessionId,
                    Details = "Import OK."
                };
                context.ApplicationLogs.Add(applicationLog);
                await context.SaveChangesAsync();
            }

            private void AddChargesToImportedPayments(string savedFileFullPath, Session newSession)
            {
                List<ImportCharges> listToImport = new List<ImportCharges>();
                try
                {
                    listToImport = importFile.GetListFromFile(savedFileFullPath);
                }
                catch (Exception ex)
                {
                    if (ex.Message.StartsWith("BAD INPUT: "))
                        throw new RestException(HttpStatusCode.BadRequest, ex.Message);
                    throw ex;
                }
                var importedPayments = mapper.Map<List<ImportCharges>, List<ImportedPayments>>(listToImport);
                importedPayments = importedPayments.Select(c =>
                {
                    c.SessionId = newSession.SessionId;
                    c.Session = newSession;
                    c.AtlasId = c.AtlasId.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.ChargeCode = c.ChargeCode.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.ChargedItems = c.ChargedItems.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.CreditAccount = c.CreditAccount.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.CurrencyCode = c.CurrencyCode.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.CustomerChargeType = c.CustomerChargeType.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.DebitAccount = c.DebitAccount.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.Message = c.Message.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.PaymentDetails = c.PaymentDetails.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.SpecialAmount = c.SpecialAmount.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.VATCreditAccount = c.VATCreditAccount.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    c.VATDebitAccount = c.VATDebitAccount.ReplaceAllIgnoreCase(Constants.INVALID_STRINGS, "");
                    return c;
                }).ToList();
                context.BulkInsert(importedPayments);
            }

            private async Task<Session> CreateSessionAndParameters(string fileName, string userId)
            {
                var newSession = new Session()
                {
                    ObjectTypeId = (int)Commons.Enums.ObjectType.SessionImport,
                    GeneratedFileName = fileName,
                    RecordStamp = DateTime.Now,
                    Status = (int)ObjectStatusId.Active
                };

                context.Sessions.Add(newSession);
                await context.SaveChangesAsync();

                var importedSessionIdParam = await context.Parameters.FindAsync(Constants.FILE_IMPORT_SESSION_ID);
                var importedUserIdParam = await context.Parameters.FindAsync(Constants.FILE_IMPORT_USER_ID);

                if (importedSessionIdParam != null && importedUserIdParam != null)
                {
                    if (!string.IsNullOrEmpty(importedSessionIdParam.ParamValue) || !string.IsNullOrEmpty(importedUserIdParam.ParamValue))
                    {
                        throw new RestException(HttpStatusCode.BadRequest, "A file import is already in progress!");
                    }
                    else
                    {
                        importedSessionIdParam.ParamValue = newSession.SessionId.ToString();
                        importedUserIdParam.ParamValue = userId;
                        await context.SaveChangesAsync();
                    }
                }
                else
                {
                    throw new RestException(HttpStatusCode.BadRequest, "Missing import records from Parameter table! Please check Parameters table for 'Import_SessionId', 'Import_UserId'!");
                }

                return newSession;
            }

            private async Task ValidateImportedPayments(int sessionId)
            {
                logger.LogInformation($"Start spValidateImportedPaymentsForFileImport");
                await context.Database.ExecuteSqlRawAsync($"exec spValidateImportedPaymentsForFileImport {sessionId}");
            }

            private async Task ActivateClient(int sessionId, string userId)
            {
                logger.LogInformation($"Start spAddOrActivateCustomers");
                await context.Database.ExecuteSqlRawAsync($"exec spAddOrActivateCustomers {sessionId}, '{userId}'");
            }

            private async Task AddCharges(int sessionId, string userId)
            {
                logger.LogInformation($"Start spAddCharges");
                await context.Database.ExecuteSqlRawAsync($"exec spAddCharges {sessionId}, '{userId}' ");
            }

            private async Task<string> SaveFile(Command request)
            {
                logger.LogInformation($"Start uploading file {request.FileToImport.FileName} to the server!");
                var file = request.FileToImport;
                if (file.Length <= 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"File is empty!");
                }

                if (Path.GetExtension(file.FileName) != ".txt" && Path.GetExtension(file.FileName) != ".xlsx")
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"The file must have .txt or .xlsx extension!");
                }

                var folderName = await context.Parameters.Where(p => p.ParamName == Constants.FILE_IMPORT_PATH).FirstOrDefaultAsync();
                string savedFileFullPath = "";
                if (folderName == null || !Directory.Exists(folderName.ParamValue))
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Path to save file is invalid, please contact administrator!");
                }

                try
                {
                    var savedFileName = Path.GetFileNameWithoutExtension(file.FileName) + DateTime.Now.ToString("yyyyMMddHHmmss") + Path.GetExtension(file.FileName);
                    savedFileFullPath = Path.Combine(folderName.ParamValue, savedFileName);
                    using (var stream = new FileStream(savedFileFullPath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    var backupPath = await context.Parameters.Where(p => p.ParamName == Constants.FILE_IMPORT_BACKUP_PATH).FirstOrDefaultAsync();
                    if (backupPath == null || !Directory.Exists(backupPath.ParamValue))
                    {
                        throw new RestException(HttpStatusCode.BadRequest, $"Path to create archive file is invalid, please contact administrator!");
                    }
                    var archiveName = Path.GetFileNameWithoutExtension(file.FileName) + DateTime.Now.ToString("yyyyMMddHHmmss") + ".zip";
                    var backupFullPath = Path.Combine(backupPath.ParamValue, archiveName);
                    using (var zipToCreate = new FileStream(backupFullPath, FileMode.Create))
                    {
                        using (var archive = new ZipArchive(zipToCreate, ZipArchiveMode.Update))
                        {
                            logger.LogInformation($"Add file {savedFileName} to archive!");
                            archive.CreateEntryFromFile(savedFileFullPath, savedFileName);
                        }
                    }
                }
                catch (Exception)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"File import error please contact administrator!");
                }

                return savedFileFullPath;
            }
        }
    }
}