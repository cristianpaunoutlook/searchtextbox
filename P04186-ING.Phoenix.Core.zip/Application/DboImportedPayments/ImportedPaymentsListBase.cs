﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Application.Export.ImportedPayments;
using Application.Export.ImportedPaymentsReport;
using Domain;
using Persistence;
using System.Linq;
using System.Net;

namespace Application.DboImportedPayments
{
    public class ImportedPaymentsListBase
    {
        public IQueryable<ImportedPaymentsDTO> ImportedPaymentsList(PhoenixContext context, ImportedPaymentsFilter filter, string userId)
        {
            var importedPayments = context.ImportedPayments.Where(s => s.SessionId == filter.SessionId);

            if (filter.Imported != -1)
            {
                var imported = filter.Imported != 0;
                importedPayments = importedPayments.Where(ip => ip.IsImported == imported);
            }

            var result = importedPayments.Select(ip =>
                 new ImportedPaymentsDTO
                 {
                     SessionId = ip.SessionId,
                     No = ip.LineNumber,
                     Code = ip.ChargeCode,
                     PaymentDetails = ip.PaymentDetails,
                     CustomerId = ip.AtlasId,
                     DebitAccount = ip.DebitAccount,
                     CreditAccount = ip.CreditAccount,
                     Type = ip.CustomerChargeType,
                     Amount = ip.SpecialAmount,
                     Currency = ip.CurrencyCode,
                     Imported = ip.IsImported ?? false,
                     Message = ip.Message,
                     ImportedBy = userId,
                     DebitAccountStatus = ip.DebitAccountStatus

                 });

            return result;
        }

        public IQueryable<ImportedPaymentsReportDTO> ImportedPaymentsReportList(PhoenixContext context, ImportedPaymentsReportFilter filter)
        {
            var importedPayments = from ip in context.ImportedPayments
                                   join ap in context.ApplicationLogs.Where(ap => ap.ObjectTypeId == (int)Commons.Enums.ObjectType.SessionImport)
                                    on ip.SessionId equals ap.SessionId into aps
                                   from ap in aps.DefaultIfEmpty()
                                   join ct in context.ChargeTypes on ip.ChargeCode equals ct.ChargeTypeCode into cts from ct in cts.DefaultIfEmpty()
                                   join cr in context.Currencies on ct.CurrId equals cr.CurrencyId into cus from cr in cus.DefaultIfEmpty()
                                   select new ImportedPaymentsReportDTO
                                   {
                                       SessionId = ip.SessionId,
                                       LineNumber = ip.LineNumber,
                                       AtlasId = ip.AtlasId,
                                       ChargeCode = ip.ChargeCode,
                                       ChargedItems = ip.ChargedItems,
                                       SpecialAmount = GetAmount(ip, ct),
                                       CurrencyCode = GetCurrency(ip, cr),
                                       CustomerChargeType = ip.CustomerChargeType,
                                       DebitAccount = ip.DebitAccount,
                                       CreditAccount = ip.CreditAccount,
                                       IsImported = ip.IsImported.Value == true ? Constants.IS_IMPORTED : Constants.IS_NOT_IMPORTED,
                                       PaymentDetails = ip.PaymentDetails,
                                       Message = ip.Message,
                                       REF_ID_CCM = ip.REF_ID_CCM,
                                       LastModifiedDate = ap.RecordStamp,
                                       LastModifyBy = ap.UserId.ToUpper(),
                                       DebitAccountStatus = ip.DebitAccountStatus
                                   };



            if (!string.IsNullOrEmpty(filter.SessionId) && int.TryParse(filter.SessionId, out int sessionId))
            {
                importedPayments = importedPayments.Where(ip => ip.SessionId == sessionId);
            }

            if (!string.IsNullOrEmpty(filter.CustomerId))
            {
                importedPayments = importedPayments.Where(ip => ip.AtlasId.Contains(filter.CustomerId));
            }

            if (!string.IsNullOrEmpty(filter.ChargeCode))
            {
                importedPayments = importedPayments.Where(ip => ip.ChargeCode.Trim() == filter.ChargeCode);
            }

            if (!string.IsNullOrEmpty(filter.UserId))
            {
                importedPayments = importedPayments.Where(ip => ip.LastModifyBy == filter.UserId);
            }

            if (filter.StartDate != null)
            {
                importedPayments = importedPayments.Where(ip => ip.LastModifiedDate.Value.Date >= filter.StartDate.Value.Date);
            }

            if (filter.EndDate != null)
            {
                importedPayments = importedPayments.Where(ip => ip.LastModifiedDate.Value.Date <= filter.EndDate.Value.Date);
            }

            if (filter.IsImported == 1)
            {
                importedPayments = importedPayments.Where(ip => ip.IsImported == Constants.IS_IMPORTED);
            }
            else if (filter.IsImported == 0)
            {
                importedPayments = importedPayments.Where(ip => ip.IsImported == Constants.IS_NOT_IMPORTED);
            }

            return importedPayments;
        }

        private static string GetAmount(ImportedPayments ip, ChargeType chargeType) 
        {
            if (!Constants.IMPORT_PAYM_REPORTS_CTS_AMOUNTS.Contains(ip.ChargeCode))
                return ip.SpecialAmount;

            if (chargeType == null)
                return string.Empty;

            return ip.CustomerChargeType.ToLower() == Constants.PER_TRANSACTION ? chargeType.DefaultAmount.ToString() :
                                        ip.CustomerChargeType.ToLower() == Constants.PER_PRODUCT ? chargeType.AmountProduct.ToString() : ip.SpecialAmount;
        }   

        private static string GetCurrency(ImportedPayments ip, Currency currency)
        {
            if (!Constants.IMPORT_PAYM_REPORTS_CTS_AMOUNTS.Contains(ip.ChargeCode))
                return ip.CurrencyCode;

            return currency == null ? string.Empty : currency.CurrencyCode;
        }
    }
}
