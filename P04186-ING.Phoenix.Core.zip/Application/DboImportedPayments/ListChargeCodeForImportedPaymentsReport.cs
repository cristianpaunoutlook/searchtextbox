﻿using Application.Commons.Constants;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboImportedPayments
{
    public class ListChargeCodeForImportedPaymentsReport
    {
        public class Query : IRequest<IEnumerable<string>> { }

        public class Handler : IRequestHandler<Query, IEnumerable<string>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<IEnumerable<string>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get charge codes for imported payments report from ChargeType table!");

                return await context.ChargeTypes
                    .Select(ct => ct.ChargeTypeCode.Trim().ToUpper())
                    .OrderBy(ct => ct)
                    .ToListAsync();
            }

        }
    }
}
