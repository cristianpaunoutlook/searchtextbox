﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Import
{
    [ExcludeFromCodeCoverage]
    public class ImportCharges
    {
        public string ChargeCode { get; set; }
        public string CustomerID { get; set; }
        public string DebitAccount { get; set; }
        public string CreditAccount { get; set; }
        public string SpecialAmount { get; set; }
        public string Type { get; set; }
        public string PaymentDetails { get; set; }
    }
}
