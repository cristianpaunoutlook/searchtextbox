﻿using Application.Commons.Constants;
using Application.Errors;
using Application.Export.PaymentStatusReport;
using Application.Helpers;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.PaymentsStatus
{
    [ExcludeFromCodeCoverage]
    public class PaymentsStatusForReport
    {
        public class Query : IRequest<PagedList<PaymentsStatusReport>>
        {
            public PaymentsStatusReportParams PaymentsStatusReportParams { get; set; }
        }

        public class CommandValidator : AbstractValidator<Query>
        {
            public CommandValidator()
            {
                RuleFor(x => x.PaymentsStatusReportParams.ExportStartDate)
                    .NotNull()
                    .WithMessage("Please provide a value for export start date!");
                RuleFor(x => x.PaymentsStatusReportParams.ExportEndDate)
                    .NotNull()
                    .WithMessage("Please provide a value for export end date!"); ;
                RuleFor(x => x.PaymentsStatusReportParams.ExportStartDate)
                    .LessThanOrEqualTo(DateTime.Now)
                    .WithMessage("Export start date is less then or equal with today!");
                RuleFor(x => x.PaymentsStatusReportParams.ExportEndDate)
                    .LessThanOrEqualTo(DateTime.Now)
                    .WithMessage("Export start end is less then or equal with today!");
                RuleFor(x => x.PaymentsStatusReportParams.ExportStartDate)
                    .LessThanOrEqualTo(x => x.PaymentsStatusReportParams.ExportEndDate)
                    .WithMessage("Export start date should be less then end date!");
            }
        }

        public class Handler : PaymentsStatusReportBase, IRequestHandler<Query, PagedList<PaymentsStatusReport>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }
            public async Task<PagedList<PaymentsStatusReport>> Handle(Query request, CancellationToken cancellationToken)
            {
                if (request.PaymentsStatusReportParams.ExportStartDate.AddMonths(Constants.PAYMENTS_REPORT_TIME_INTERVAL) < request.PaymentsStatusReportParams.ExportEndDate)
                    throw new RestException(HttpStatusCode.BadRequest, $"The maximum time interval for paymets status report is {Constants.PAYMENTS_REPORT_TIME_INTERVAL} months");
                logger.LogInformation("Get list payments status report");
                List<PaymentsStatusReport> paymentsStatus = await GetPaymentsStatusList(context, request.PaymentsStatusReportParams);
                var totalItems = paymentsStatus.Select(p => p.TotalCount).FirstOrDefault();
                return new PagedList<PaymentsStatusReport>(paymentsStatus, totalItems, request.PaymentsStatusReportParams.PageNumber, request.PaymentsStatusReportParams.PageSize);
            }
            
        }
    }
}
