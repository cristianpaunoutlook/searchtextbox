﻿using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.Errors;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;

namespace Application.Parameter
{
    public class GetParameter
    {
        public class Query : IRequest<PhxParameter>
        {
            public string ParamName { get; set; }
        }

        public class Handler : IRequestHandler<Query, PhxParameter>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<PhxParameter> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get parameter {request.ParamName} value.");
                var parameterValue = await context.Parameters.Where(p => p.ParamName == request.ParamName).FirstOrDefaultAsync();
                if (parameterValue == null)
                {
                    throw new RestException(HttpStatusCode.NotFound, $"Parameter with name {request.ParamName} does not exist!");
                }

                return parameterValue;
            }
        }
    }
}
