﻿using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Parameter
{
    [ExcludeFromCodeCoverage]
    public class List
    {
        public class Query : IRequest<List<PhxParameter>> { }

        public class Handler : IRequestHandler<Query, List<PhxParameter>>
        {
            private readonly PhoenixContext _context;

            public Handler(PhoenixContext context)
            {
                _context = context;
            }

            public async Task<List<PhxParameter>> Handle(Query request, CancellationToken cancellationToken) => await _context.Parameters.ToListAsync();
        }
    }
}
