﻿using Application.Commons.Enums;
using Application.Errors;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboGroup
{
    public class Reject
    {
        public class Command : IRequest
        {
            public int GroupId { get; set; }
            public string UserKey { get; set; }
            public string SessionId { get; set; }
        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }
            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                var secSession = await context.SecSessions.Where(s => s.Session == request.SessionId).FirstOrDefaultAsync();
                if (secSession == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The session is not registred!");
                }

                var groupToReject = await ValidateGroup(request);
                var nextStatus = await context.ObjectStatus.Where(s => s.ObjectStatusId == groupToReject.NextStatusId).FirstOrDefaultAsync();
                switch (groupToReject.NextStatusId)
                {
                    case (byte)ObjectStatusId.VerificationAdd:
                        var removeGroupPages = await context.GroupsPagesRights.Where(gpr => gpr.GroupId == request.GroupId).ToListAsync();
                        removeGroupPages.ForEach(r => context.GroupsPagesRights.Remove(r));
                        context.Groups.Remove(groupToReject);
                        break;
                    case (byte)ObjectStatusId.VerificationModify:
                        await UpdateGroupInfo(groupToReject, request.UserKey);
                        var rightsToRemove = await context.GroupsPagesRights.Where(gpr => gpr.GroupId == groupToReject.Id && gpr.Right.Code == RightsCode.NORIGHT.ToString()).ToListAsync();
                        rightsToRemove.ForEach(r => context.GroupsPagesRights.Remove(r));
                        break;
                    case (byte)ObjectStatusId.VerificationDelete:
                        await UpdateGroupInfo(groupToReject, request.UserKey);
                        break;
                    default:
                        throw new RestException(HttpStatusCode.BadRequest, $"To update a group the state should be Verification Add, Verification Modify or Verification Delete!");
                }

                var logActionInfo = new SecUserLog()
                {
                    UserId = request.UserKey,
                    ActionId = (int)UserAction.Reject,
                    ObjectId = (int)UserObject.UserGroup,
                    RecordId = groupToReject.Id.ToString(),
                    ErrorNumberId = 0,
                    RecordStamp = groupToReject.LastModifiedDate,
                    SessionId = secSession.SessionId,
                    Details = $"GroupName={groupToReject.Name},ADName={groupToReject.ADName}",
                    OldDetails = null
                };
                context.UserLogs.Add(logActionInfo);

                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Error when updating data for rights!");
            }

            private async Task UpdateGroupInfo(Group groupToReject, string userKey)
            {
                groupToReject.NextStatusId = groupToReject.StatusId;
                groupToReject.NextStatus = groupToReject.Status;
                groupToReject.LastModifiedBy = userKey;
                groupToReject.LastModifiedDate = DateTime.Now;
                var groupPages = await context.GroupsPagesRights.Where(gpr => gpr.GroupId == groupToReject.Id && gpr.NextRightId != gpr.RightId).ToListAsync();
                groupPages.ForEach(gp => {
                    gp.NextRightId = gp.RightId;
                    gp.LastModifiedBy = userKey;
                    gp.LastModifiedDate = DateTime.Now;
                });
            }

            private async Task<Group> ValidateGroup(Command request)
            {
                var groupToReject = await context.Groups.Where(g => g.Id == request.GroupId).FirstOrDefaultAsync();
                if (groupToReject == null)
                {
                    logger.LogError($"The group with id {request.GroupId} does not exist in the database!");
                    throw new RestException(HttpStatusCode.BadRequest, $"The group with id {request.GroupId} does not exist in the database!");
                }

                if (groupToReject.LastModifiedBy == request.UserKey)
                {
                    logger.LogError($"User that updated the group can not reject the change!");
                    throw new RestException(HttpStatusCode.BadRequest, $"User that updated the group can not reject the change!");
                }

                return groupToReject;
            }
        }        
    }
}
