﻿using Application.Commons.Enums;
using Application.Errors;
using Castle.DynamicProxy.Contributors;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Org.BouncyCastle.Asn1.Ocsp;
using Org.BouncyCastle.Ocsp;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboGroup
{
    public class Delete
    {
        public class Command : IRequest
        {
            public int GroupId { get; set; }
            public string LastModifiedBy { get; set; }
            public string SessionId { get; set; }
        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                var secSession = await context.SecSessions.Where(s => s.Session == request.SessionId).FirstOrDefaultAsync();
                if (secSession == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The session is not registred!");
                }

                var groupToDelete = await context.Groups.Where(g => g.Id == request.GroupId).FirstOrDefaultAsync();

                if (groupToDelete == null)
                {
                    throw new RestException(HttpStatusCode.NotFound, $"The group {request.GroupId} does not exist in the database!");
                }

                if(groupToDelete.Status.ObjectStatusName != Commons.Enums.ObjectStatus.Active || 
                    groupToDelete.NextStatus.ObjectStatusName != Commons.Enums.ObjectStatus.Active)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"You cannot delete a group that is not active!");
                }

                groupToDelete.NextStatusId = (int)ObjectStatusId.VerificationDelete;
                groupToDelete.LastModifiedBy = request.LastModifiedBy;
                groupToDelete.LastModifiedDate = DateTime.Now;
                var groupPages = await context.GroupsPagesRights.Where(gpr => gpr.GroupId == groupToDelete.Id).ToListAsync();
                var noRight = await context.Rights.Where(r => r.Value == (int)RightsCode.NORIGHT).FirstOrDefaultAsync();
                groupPages.ForEach(gp =>
                {
                    gp.NextRightId = noRight.Id;
                    gp.LastModifiedBy = request.LastModifiedBy;
                    gp.LastModifiedDate = DateTime.Now;
                });

                var logActionInfo = new SecUserLog()
                {
                    UserId = groupToDelete.LastModifiedBy,
                    ActionId = (int)UserAction.Delete,
                    ObjectId = (int)UserObject.UserGroup,
                    RecordId = groupToDelete.Id.ToString(),
                    ErrorNumberId = 0,
                    RecordStamp = groupToDelete.LastModifiedDate,
                    SessionId = secSession.SessionId,
                    Details = $"GroupName={groupToDelete.Name},ADName={groupToDelete.ADName}",
                    OldDetails = null
                };
                context.UserLogs.Add(logActionInfo);

                var success = await context.SaveChangesAsync() > 0;
                
                return success ? Unit.Value : throw new Exception($"Group was not deleted!");
            }
        }
    }
}
