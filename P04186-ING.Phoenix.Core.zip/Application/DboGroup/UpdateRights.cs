﻿using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.Commons.Constants;

namespace Application.DboGroup
{
    public class UpdateRights
    {
        public class Command : IRequest
        {
            public string UserKey { get; set; }
            public GroupPagesRightsDTO[] RightsToUpdate { get; set; }
            public string SessionId { get; set; }

        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(gr => gr.RightsToUpdate.Length).GreaterThan(0).WithMessage("You have to update at least one right!");
            }
        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }
            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                var secSession = await context.SecSessions.Where(s => s.Session == request.SessionId).FirstOrDefaultAsync();
                if (secSession == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The session is not registred!");
                }

                var groupToUpdate = await ValidateGroup(request);
                var currentDate = DateTime.Now;
                groupToUpdate.LastModifiedDate = currentDate;
                groupToUpdate.LastModifiedBy = request.UserKey;
                groupToUpdate.NextStatusId = (int)ObjectStatusId.VerificationModify;
                var changedRights = request.RightsToUpdate.Where(r => r.RightValue != r.NextRightValue);
                var noRight = await context.Rights.Where(r => r.Value == (int)RightsCode.NORIGHT).FirstOrDefaultAsync();
                foreach (var groupRight in changedRights)
                {
                    var rightToUpdate = await context
                                                .GroupsPagesRights
                                                .Where(ugr => ugr.GroupId == groupToUpdate.Id && ugr.PageId == groupRight.PageId)
                                                .FirstOrDefaultAsync();

                    
                    var nextRight = await context.Rights.Where(r => r.Value == groupRight.NextRightValue).FirstOrDefaultAsync();
                    if (rightToUpdate == null)
                    {
                        var page = await context.Pages.Where(p => p.Id == groupRight.PageId).FirstOrDefaultAsync();
                        var groupRightToAdd = new GroupPageRight() { 
                            GroupId = groupToUpdate.Id,
                            Group = groupToUpdate,
                            LastModifiedBy = request.UserKey,
                            LastModifiedDate = currentDate,
                            RightId = noRight.Id,
                            Right = noRight,
                            NextRightId = nextRight.Id,
                            NextRight = nextRight,
                            PageId = groupRight.PageId,
                            Page = page
                        };
                        context.GroupsPagesRights.Add(groupRightToAdd);
                    }
                    else
                    {
                        rightToUpdate.LastModifiedBy = request.UserKey;
                        rightToUpdate.LastModifiedDate = currentDate;                            
                        rightToUpdate.NextRightId = nextRight.Id;
                     }
                }

                var logActionInfo = new SecUserLog()
                {
                    UserId = groupToUpdate.LastModifiedBy,
                    ActionId = (int)UserAction.ModifyEdit,
                    ObjectId = (int)UserObject.UserGroup,
                    RecordId = groupToUpdate.Id.ToString(),
                    ErrorNumberId = 0,
                    RecordStamp = groupToUpdate.LastModifiedDate,
                    SessionId = secSession.SessionId,
                    Details = $"GroupName={groupToUpdate.Name},ADName={groupToUpdate.ADName}",
                    OldDetails = null
                };
                context.UserLogs.Add(logActionInfo);

                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Error when updating data for rights!");
            }

            private async Task<Group> ValidateGroup(Command request)
            {
                var groupId = request.RightsToUpdate[0].GroupId;
                var groupToUpdate = await context.Groups.Where(g => g.Id == groupId).FirstOrDefaultAsync();
                if (groupToUpdate == null)
                {
                    logger.LogError($"The group with id {groupId} does not exist in the database!");
                    throw new RestException(HttpStatusCode.BadRequest, $"The group with id {groupId} does not exist in the database!");
                }

                if (groupToUpdate.NextStatusId != (int)ObjectStatusId.Active || groupToUpdate.StatusId != (int)ObjectStatusId.Active)
                {
                    logger.LogError($"The group {groupToUpdate.Name} is not active");
                    throw new RestException(HttpStatusCode.BadRequest, $"The group {groupToUpdate.Name} is not active");
                }


                if (request.RightsToUpdate.Any(r => r.PageCode != Constants.SECURITY_PAGE && r.NextRightValue != (int)RightsCode.NORIGHT) &&
                    request.RightsToUpdate.Any(r => r.PageCode == Constants.SECURITY_PAGE && r.NextRightValue != (int)RightsCode.NORIGHT))
                {
                    logger.LogError($"The group {groupToUpdate.Name} can not have rights in security module and in a functional module in the same time!");
                    throw new RestException(HttpStatusCode.BadRequest, $"The group {groupToUpdate.Name} can not have rights in security module and in a functional module in the same time!");
                }

                foreach (var groupRight in request.RightsToUpdate)
                {
                    if (groupRight.RightValue != groupRight.NextRightValue)
                        return groupToUpdate;
                }

                throw new RestException(HttpStatusCode.BadRequest, $"The rights for {groupToUpdate.Name} are not changed!");
            }
        }
    }
}
