﻿using Application.Commons.Enums;
using Application.DTO;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboGroup
{
    public class RightsList
    {
        public class Query : IRequest<IEnumerable<GroupPagesRightsDTO>> {
            public int GroupId { get; set; }
        }

        public class Handler : IRequestHandler<Query, IEnumerable<GroupPagesRightsDTO>>
        {
            private readonly PhoenixContext context;

            public Handler(PhoenixContext context)
            {
                this.context = context;
            }

            public async Task<IEnumerable<GroupPagesRightsDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                var query = from p in context.Pages
                            join ugr in context.GroupsPagesRights on new { p.Id, request.GroupId } equals new { Id = ugr.PageId, ugr.GroupId } into groupRights
                            from ugr in groupRights.DefaultIfEmpty()
                            select new GroupPagesRightsDTO()
                            {
                                GroupId = request.GroupId,
                                GroupName = ugr == null ? null : ugr.Group.ADName,
                                PageId = p.Id,
                                PageName = p.Name,
                                PageCode = p.Code,
                                RightValue = ugr == null ? (int)RightsCode.NORIGHT : ugr.Right.Value,
                                NextRightValue = ugr == null ? (int)RightsCode.NORIGHT : ugr.NextRight.Value,
                                LastModifiedBy = ugr == null ? string.Empty : ugr.LastModifiedBy,
                                OrderNo = p.OrderNo
                            };

                return await query.OrderBy(p => p.OrderNo).ToListAsync();

            }                
        }
    }

}
