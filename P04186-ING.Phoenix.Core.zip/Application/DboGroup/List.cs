﻿using Application.DTO;
using Application.Errors;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboGroup
{
    public class List
    {
        public class Query : IRequest<GroupsDTO> { }

        public class Handler : IRequestHandler<Query, GroupsDTO>
        {
            private readonly PhoenixContext _context;
            private readonly ILogger _logger;
            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                _context = context;
                _logger = logger;
            }

            public async Task<GroupsDTO> Handle(Query request, CancellationToken cancellationToken)
            {
                _logger.LogInformation($"Getting groups list!");
                var groups = await _context.Groups.ToListAsync();

               return new GroupsDTO
                {
                    Groups = groups,
                };
            }
        }
    }
}
