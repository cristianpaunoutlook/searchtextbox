﻿using Application.Commons.Constants;
using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboGroup
{
    public class Create
    {
        public class Command : IRequest<Group>
        {
            public string Name { get; set; }
            public string AdName { get; set; }
            public GroupPageRightDTO[] PageRight { get; set; }
            public string LastModifiedBy { get; set; }
            public DateTime LastModifiedDate { get; set; }
            public string SessionId { get; set; }

        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(g => g.PageRight.Length).GreaterThan(0).WithMessage("You have to update at least one right!");
                RuleFor(g => g.Name).NotNull();
                RuleFor(g => g.AdName).NotNull();
            }
        }

        public class Handler : IRequestHandler<Command, Group>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;
            private readonly IConfiguration configuration;

            public Handler(PhoenixContext context, ILogger<Handler> logger, IConfiguration configuration)
            {
                this.context = context;
                this.logger = logger;
                this.configuration = configuration;
            }

            public async Task<Group> Handle(Command request, CancellationToken cancellationToken)
            {
                var secSession = await context.SecSessions.Where(s => s.Session == request.SessionId).FirstOrDefaultAsync();
                if (secSession == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The session is not registred!");
                }

                var appDefaultPattern = configuration.GetSection("UserGroupsNamePattern").Value;
                
                if (!request.AdName.Contains(appDefaultPattern))
                {
                    logger.LogInformation($"AD name {request.AdName} should contain the application code {appDefaultPattern}!");
                    throw new RestException(HttpStatusCode.BadRequest, $"AD name {request.AdName} should contain the application code {appDefaultPattern}!");
                }

                var checkGroup = await context.Groups.Where(g => g.Name == request.Name.Trim()).FirstOrDefaultAsync();

                if (checkGroup != null)
                {
                    logger.LogInformation($"Group with AD name {request.Name} already exists in database with status {checkGroup.Status.ObjectStatusName}!");
                    throw new RestException(HttpStatusCode.BadRequest, $"Group Name already exists! Please modify existing group or insert a new Group Name!");
                }

                var secPage = await context.Pages.Where(p => p.Code == Constants.SECURITY_PAGE).FirstOrDefaultAsync();

                if (request.PageRight.Any(r => r.PageId != secPage.Id && r.NextRightValue != (int)RightsCode.NORIGHT) &&
                    request.PageRight.Any(r => r.PageId == secPage.Id && r.NextRightValue != (int)RightsCode.NORIGHT))
                {
                    logger.LogError($"The group {request.Name} can not have rights in security module and in a functional module in the same time!");
                    throw new RestException(HttpStatusCode.BadRequest, $"The group {request.Name} can not have rights in security module and in a functional module in the same time!");
                }

                logger.LogInformation($"Create group with name {request.Name} and AD name {request.AdName} for application: {Constants.NON_TRANSACTIONAL_FEES}");
                var objNextStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationAdd).FirstOrDefaultAsync();

                var newGroup = new Group
                {
                    Name = request.Name.Trim(),
                    ADName = request.AdName.Trim(),
                    StatusId = objNextStatus.ObjectStatusId,
                    NextStatusId = objNextStatus.ObjectStatusId,
                    LastModifiedBy = request.LastModifiedBy,
                    LastModifiedDate = DateTime.Now,
                };

                context.Add(newGroup);

                var logActionInfo = new SecUserLog()
                {
                    UserId = newGroup.LastModifiedBy,
                    ActionId = (int)UserAction.Add,
                    ObjectId = (int)UserObject.UserGroup,
                    RecordId = newGroup.Id.ToString(),
                    ErrorNumberId = 0,
                    RecordStamp = newGroup.LastModifiedDate,
                    SessionId = secSession.SessionId,
                    Details = $"GroupName={newGroup.Name},ADName={newGroup.ADName}",
                    OldDetails = null
                };
                context.UserLogs.Add(logActionInfo);

                var noRight = await context.Rights.Where(r => r.Value == (int)RightsCode.NORIGHT).FirstOrDefaultAsync();

                foreach (var pr in request.PageRight)
                {
                    var nextRight = await context.Rights.Where(r => r.Value == pr.NextRightValue).FirstOrDefaultAsync();

                    var groupPageRight = new GroupPageRight
                    {
                        GroupId = newGroup.Id,
                        Group = newGroup,
                        PageId = pr.PageId,
                        RightId = noRight.Id,
                        Right = noRight,
                        NextRightId = nextRight.Id,
                        NextRight = nextRight,
                        LastModifiedBy = newGroup.LastModifiedBy,
                        LastModifiedDate = newGroup.LastModifiedDate
                    };

                    context.Add(groupPageRight);
                }


                var success = await context.SaveChangesAsync() > 0;

                return success ? newGroup : throw new Exception("Group was not created!");
            }
        }
    }
}
