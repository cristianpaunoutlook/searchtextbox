﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;

namespace Application.PosFlow
{
    [ExcludeFromCodeCoverage]
    public class PosFlow
    {
        public class Command : IRequest
        {
            public string UserId { get; set; }
        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Start POS flow");

                var newSession = await CreateNewSession();
                logger.LogInformation($"Session created with id {newSession.SessionId}");

                context.Database.BeginTransaction();
                await CalculatePosCharges(newSession.SessionId);
                await ValidateChargeCode(newSession.SessionId);
                await ValidateCustomerId(newSession.SessionId);
                await ValidateDebitAccount(newSession.SessionId);
                await ValidateCreditAccount(newSession.SessionId);
                await ValidateChargedItems(newSession.SessionId);
                await ValidateSpecialAmount(newSession.SessionId);
                await ValidateDuplicateCharges(newSession.SessionId);
                await ValidateCustomerChargeType(newSession.SessionId);
                await ValidateCurrency(newSession.SessionId);
                await UpdateImportedPayments(newSession.SessionId);
                await ActivateClients(newSession.SessionId, request.UserId);
                await MergeCharges(newSession.SessionId, request.UserId);
                context.Database.CommitTransaction();
                return Unit.Value;
            }

            private async Task<Session> CreateNewSession()
            {
                var newSession = new Session
                {
                    RecordStamp = DateTime.Now,
                    GeneratedFileName = string.Empty,
                    ObjectTypeId = (int)Commons.Enums.ObjectType.SessionImport,
                    Status = (int)Commons.Enums.SessionStatus.Finished

                };
                context.Add(newSession);

                var success = await context.SaveChangesAsync() > 0;

                return success ? newSession : throw new Exception("Session was not created!");
            }

            private async Task CalculatePosCharges(int sessionId)
            {
                logger.LogInformation($"Start spCalculatePosChargesPhx");
                await context.Database.ExecuteSqlRawAsync($"exec spCalculatePosChargesPhx {sessionId}");
            }

            private async Task ValidateChargeCode(int sessionId)
            {
                logger.LogInformation($"Start spImportedPaymentsValidateChargeCode");
                await context.Database.ExecuteSqlRawAsync($"exec spImportedPaymentsValidateChargeCode {sessionId}");
            }

            private async Task ValidateCustomerId(int sessionId)
            {
                logger.LogInformation($"Start spImportedPaymentsValidateCustomerId");
                await context.Database.ExecuteSqlRawAsync($"exec spImportedPaymentsValidateCustomerId {sessionId}");
            }

            private async Task ValidateDebitAccount(int sessionId)
            {
                logger.LogInformation($"Start spImportedPaymentsValidateDebitAccount");
                await context.Database.ExecuteSqlRawAsync($"exec spImportedPaymentsValidateDebitAccount {sessionId}");
            }

            private async Task ValidateCreditAccount(int sessionId)
            {
                logger.LogInformation($"Start spImportedPaymentsValidateCreditAccount");
                await context.Database.ExecuteSqlRawAsync($"exec spImportedPaymentsValidateCreditAccount {sessionId}");
            }

            private async Task ValidateChargedItems(int sessionId)
            {
                logger.LogInformation($"Start spImportedPaymentsValidateChargedItems");
                await context.Database.ExecuteSqlRawAsync($"exec spImportedPaymentsValidateChargedItems {sessionId}");
            }

            private async Task ValidateSpecialAmount(int sessionId)
            {
                logger.LogInformation($"Start spImportedPaymentsValidateSpecialAmount");
                await context.Database.ExecuteSqlRawAsync($"exec spImportedPaymentsValidateSpecialAmount {sessionId}");
            }

            private async Task ValidateDuplicateCharges(int sessionId)
            {
                logger.LogInformation($"Start spImportedPaymentsValidateDuplicateCharges");
                await context.Database.ExecuteSqlRawAsync($"exec spImportedPaymentsValidateDuplicateCharges {sessionId}");
            }

            private async Task ValidateCustomerChargeType(int sessionId)
            {
                logger.LogInformation($"Start spImportedPaymentsValidateCustomerChargeType");
                await context.Database.ExecuteSqlRawAsync($"exec spImportedPaymentsValidateCustomerChargeType {sessionId}");
            }

            private async Task ValidateCurrency(int sessionId)
            {
                logger.LogInformation($"Start spImportedPaymentsValidateCurrency");
                await context.Database.ExecuteSqlRawAsync($"exec spImportedPaymentsValidateCurrency {sessionId}");
            }

            private async Task UpdateImportedPayments(int sessionId)
            {
                logger.LogInformation($"Start spUpdateImportedPayments");
                await context.Database.ExecuteSqlRawAsync($"exec spUpdateImportedPayments {sessionId}");
            }

            private async Task ActivateClients(int sessionId, string userId)
            {
                logger.LogInformation($"Start spAddOrActivateCustomers");
                await context.Database.ExecuteSqlRawAsync($"exec spAddOrActivateCustomers {sessionId}, {userId}");
            }

            private async Task MergeCharges(int sessionId, string userId)
            {
                logger.LogInformation($"Start spMergeCharges");
                await context.Database.ExecuteSqlRawAsync($"exec spMergeCharges {sessionId}, {userId}");
            }
        }
    }
}
