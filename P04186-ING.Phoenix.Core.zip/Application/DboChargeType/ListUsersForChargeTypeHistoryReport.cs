﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    [ExcludeFromCodeCoverage]
    public class ListUsersForChargeTypeHistoryReport
    {
        public class Query : IRequest<IEnumerable<string>> { }

        public class Handler : IRequestHandler<Query, IEnumerable<string>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<IEnumerable<string>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get users for charge type history report!");

                return await context.ChargeTypeHistories.Select(cth => cth.LastModifiedBy.ToUpper()).Distinct().OrderBy(cth => cth).ToListAsync();
            }
        }
    }
}
