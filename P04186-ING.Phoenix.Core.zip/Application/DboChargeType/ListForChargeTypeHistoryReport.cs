﻿using Application.DTO;
using Application.Errors;
using Application.Export.ChargeTypeHistoryReport;
using Application.Helpers;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    public class ListForChargeTypeHistoryReport
    {
        public class Query : IRequest<PagedList<ChargeTypeHistoryReportListDTO>>
        {
            public ChargeTypeHistoryReportParams ChargeTypeHistoryReportParams { get; set; }
        }

        public class Handler : ChargeTypeListBase, IRequestHandler<Query, PagedList<ChargeTypeHistoryReportListDTO>>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<PagedList<ChargeTypeHistoryReportListDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get charge type list with filters code: {request.ChargeTypeHistoryReportParams.ChargeTypeId}  " +
                    $"statusId: {request.ChargeTypeHistoryReportParams.StatusId} userId: {request.ChargeTypeHistoryReportParams.UserId} " +
                    $"actionId: {request.ChargeTypeHistoryReportParams.ActionId} startDate: {request.ChargeTypeHistoryReportParams.StartDate} " +
                    $"endDate: {request.ChargeTypeHistoryReportParams.EndDate} sort field: {request.ChargeTypeHistoryReportParams.SortField} " +
                    $"sort direction {request.ChargeTypeHistoryReportParams.SortOrder}");

                if(request.ChargeTypeHistoryReportParams.StartDate != null && request.ChargeTypeHistoryReportParams.EndDate != null &&
                    request.ChargeTypeHistoryReportParams.StartDate > request.ChargeTypeHistoryReportParams.EndDate)
                {
                    logger.LogInformation($"Start date cannot be greater than end date!");
                    throw new RestException(HttpStatusCode.BadRequest, $"Start date cannot be greater than end date!");
                }

                var filter = mapper.Map<ChargeTypeHistoryReportFilter>(request.ChargeTypeHistoryReportParams);
                var chargeTypes = ChargeTypeHistoryReportList(context, filter);

                if (!String.IsNullOrEmpty(request.ChargeTypeHistoryReportParams.SortField) && !String.IsNullOrEmpty(request.ChargeTypeHistoryReportParams.SortOrder))
                {
                    chargeTypes = chargeTypes.OrderByPropertyName(request.ChargeTypeHistoryReportParams.SortField, request.ChargeTypeHistoryReportParams.SortOrder).AsQueryable();
                }
                else
                {
                    chargeTypes = chargeTypes.OrderByDescending(ct => ct.LastModifiedDate).ThenBy(ct => ct.ChargeTypeCode);
                }

                var chargeTypeResult = await PagedList<ChargeTypeHistoryReportListDTO>.CreateAsync(chargeTypes, request.ChargeTypeHistoryReportParams.PageNumber,
                    request.ChargeTypeHistoryReportParams.PageSize);

                if (chargeTypeResult == null || chargeTypeResult.Items.Count == 0)
                    throw new RestException(HttpStatusCode.BadRequest, "The searched charge type history does not exist in the database!");

                return chargeTypeResult;
            }
        }
    }
}
