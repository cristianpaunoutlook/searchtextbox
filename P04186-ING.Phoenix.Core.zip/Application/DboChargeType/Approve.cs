﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.ChargeTypeNotifications;
using Application.StateManagement;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;

namespace Application.DboChargeType
{
    public class Approve
    {
        public class Command : IRequest
        {
            public string ChargeTypeCode { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : ChargeTypeNotificationBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger, IConfiguration configuration,
                IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Approve charge type {request.ChargeTypeCode}");
                var chargeType = await context.ChargeTypes.Where(cht => cht.ChargeTypeCode.Trim() == request.ChargeTypeCode.Trim()).FirstOrDefaultAsync();
                if (chargeType == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type with code {request.ChargeTypeCode} does not exist in the database!");
                }

                var chargeHistory = await context.ChargeTypeHistories
                    .Where(cth => cth.ChargeTypeId == chargeType.ChargeTypeId)
                    .OrderByDescending(cth => cth.ChargeTypeHistoryId)
                    .FirstOrDefaultAsync();

                if (chargeHistory == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type history for {request.ChargeTypeCode} does not exist in the database!");
                }

                if (request.UserKey == chargeHistory.LastModifiedBy)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"You have changed the charge type so you can not approve the charge type {request.ChargeTypeCode} changes!");
                }

                logger.LogInformation($"Current state, charge type: {chargeType.Status.ObjectStatusName} charge type history: {chargeHistory.Status.ObjectStatusName}");

                var statusManger = new StatusStateManagement(chargeType.Status.ObjectStatusName, chargeHistory.Status.ObjectStatusName, true);
                statusManger.SetNextState(StateTrigger.Approve);
                logger.LogInformation($"Future state after approve state, charge type: {statusManger.State} charge type history: {statusManger.HistoryState}");
                var objStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.State.ToString()).FirstOrDefaultAsync();
                var objStatusForHistory = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.HistoryState.ToString()).FirstOrDefaultAsync();
                chargeType.StatusId = objStatus.ObjectStatusId;
                chargeType.LastModifiedBy = request.UserKey;
                chargeType.RejectReason = null;
                chargeType.GetFromHistory(chargeHistory);
                var newChargeTypeHistory = mapper.Map<ChargeTypeHistory>(chargeType);
                newChargeTypeHistory.Status = objStatusForHistory;
                newChargeTypeHistory.StatusId = objStatusForHistory.ObjectStatusId;
                newChargeTypeHistory.ActionId = (int) ObjectAction.APPROVE;
                context.ChargeTypeHistories.Add(newChargeTypeHistory);

                if (objStatus.ObjectStatusName == Commons.Enums.ObjectStatus.Deleted)
                {
                    await DeleteAllChargesOfTheSameType(chargeType, objStatus);
                }
                
                var success = await context.SaveChangesAsync() > 0;

                if (success)
                {
                    await SendChargeTypeEmailAsync(chargeType, chargeHistory.Status.ObjectStatusName, nameof(NotificationType.Approved));
                }

                return success ? Unit.Value : throw new Exception("Error on approve charge type!");

            }

            private async Task DeleteAllChargesOfTheSameType(ChargeType chargeType, Domain.ObjectStatus objStatus)
            {
                logger.LogInformation($"Delete charges of type {chargeType.ChargeTypeCode} and then add history record");
                var charges = await context.Charges
                                            .Where(c => c.ChargeTypeId == chargeType.ChargeTypeId && 
                                                    c.Status.ObjectStatusName != Commons.Enums.ObjectStatus.Deleted).ToListAsync();
                var actionDelete = await context.ObjectActions.Where(oa => oa.ActionId == (int)ObjectAction.DELETE).FirstOrDefaultAsync();
                charges.ForEach(c =>
                {
                    c.StatusId = objStatus.ObjectStatusId;
                    c.Status = objStatus;
                    c.LastModifiedBy = chargeType.LastModifiedBy;
                    c.LastModifiedDate = chargeType.LastModifiedDate;
                    c.RejectReason = null;
                });
                var chargesHistory = mapper.Map<List<Charge>, List<ChargeHistory>>(charges);
                chargesHistory.ForEach(ch => {
                    ch.ActionId = actionDelete.ActionId;
                    ch.ObjectAction = actionDelete;
                });
                context.AddRange(chargesHistory);
            }
        }
    }
}
