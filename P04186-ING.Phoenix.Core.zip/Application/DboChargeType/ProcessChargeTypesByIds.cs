﻿using Application.DTO;
using Application.Interfaces.ProcessPayment;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    public class ProcessChargeTypesByIds
    {
        public class Query : IRequest<ProcessResponseDTO> {
            public string ChargeTypeIds { get; set; }
        }

        public class Handler : IRequestHandler<Query, ProcessResponseDTO>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;
            private readonly IProcessPayment processPayment;

            public Handler(PhoenixContext context, ILogger<Handler> logger, IProcessPayment processPayment)
            {
                this.context = context;
                this.logger = logger;
                this.processPayment = processPayment;
            }

            public async Task<ProcessResponseDTO> Handle(Query request, CancellationToken cancellationToken)
            {
                if (string.IsNullOrEmpty(request.ChargeTypeIds))
                {
                    return null;
                }
                var intIds = Array.ConvertAll(request.ChargeTypeIds.Split(','), int.Parse);
                var sessionInfo = await processPayment.RegularExport(intIds);
                logger.LogInformation($"session info ID: {sessionInfo.SessionId} Response {sessionInfo.Response}");
                await context.SetNextRunDay(intIds);
                if (sessionInfo.SessionId == 0)
                {
                    logger.LogInformation($"There are no payments to process for {request.ChargeTypeIds}");
                }
                return sessionInfo.SessionId == 0 ? null : sessionInfo;
            }
        }
    }
}
