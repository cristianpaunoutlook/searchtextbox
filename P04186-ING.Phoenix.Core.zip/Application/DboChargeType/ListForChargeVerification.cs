﻿using Application.Commons.Enums;
using Application.DTO;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    public class ListForChargeVerification
    {
        public class Query : IRequest<IEnumerable<ChargeTypeWithDescriptionDdlDTO>> { }

        public class Handler : IRequestHandler<Query, IEnumerable<ChargeTypeWithDescriptionDdlDTO>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }
            public async Task<IEnumerable<ChargeTypeWithDescriptionDdlDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get charge types for charges verification page ddl");

                var chargeTypes = from c in context.Charges.Where(c => c.Status.ObjectStatusName == ObjectStatus.Active ||
                                    c.Status.ObjectStatusName == ObjectStatus.VerificationAdd)
                                  from ct in context.ChargeTypes.Where(ct => c.ChargeTypeId == ct.ChargeTypeId &&
                                    ct.Action.Name == Department.PCM.ToString())
                                  from ch in context.ChargesHistory.Where(ch => ch.ChargeId == c.ChargeId)
                                                                .OrderByDescending(ch => ch.ChargeHistoryId)
                                                                 .Take(1)
                                  where ch.Status.ObjectStatusName == ObjectStatus.VerificationAdd
                                    || ch.Status.ObjectStatusName == ObjectStatus.VerificationModify
                                    || ch.Status.ObjectStatusName == ObjectStatus.VerificationDelete
                                  select new ChargeTypeWithDescriptionDdlDTO
                                  {
                                      ChargeTypeId = ct.ChargeTypeId,
                                      ChargeTypeCode = ct.ChargeTypeCode,
                                      ChargeTypeDescription = ct.ChargeTypeDescription
                                  };

                return await chargeTypes.Distinct().OrderBy(c => c.ChargeTypeCode).ToListAsync();
            }
        }
    }
}
