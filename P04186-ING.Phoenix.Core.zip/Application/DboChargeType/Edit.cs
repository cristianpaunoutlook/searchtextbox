﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.StateManagement;
using AutoMapper;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Enums = Application.Commons.Enums;

namespace Application.DboChargeType
{
    public class Edit
    {
        public class Command : IRequest
        {
            public int ChargeTypeId { get; set; }
            public string ChargeTypeCode { get; set; }
            public string ChargeTypeDescription { get; set; }
            public string PaymentDetails { get; set; }
            public long? CreditAccountShort { get; set; }
            public int CurrId { get; set; }
            public decimal Amount_Unit { get; set; }
            public decimal? Amount_Product { get; set; }
            public int FrequencyId { get; set; }
            public byte? RunDay { get; set; }
            public string LastModifiedBy { get; set; }
            public DateTime LastModifiedDate { get; set; }
            public DateTime CurrentDate { get; set; } = DateTime.Now;
        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(cht => cht.ChargeTypeDescription).NotNull().MinimumLength(2).MaximumLength(50);
                RuleFor(cht => cht.PaymentDetails).NotNull().MinimumLength(2).MaximumLength(50);
                RuleFor(cht => cht.CreditAccountShort).NotNull().Must(x => x > 999 && x < 1000000000000);
                RuleFor(cht => cht.CurrId).NotNull();
                RuleFor(cht => cht.Amount_Unit).GreaterThanOrEqualTo(0);
                RuleFor(cht => cht.Amount_Product).GreaterThanOrEqualTo(0);
                RuleFor(cht => cht.FrequencyId).NotNull();
                RuleFor(cht => cht.RunDay)
                   .InclusiveBetween((byte)0, (byte)15)
                   .When(cht => cht.RunDay.HasValue);

            }
        }

        public class Handler : ChargeTypeBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger, IConfiguration configuration,
                IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Edit charge type {request.ChargeTypeCode}");
                var charge = await context.ChargeTypes.Where(cht => cht.ChargeTypeCode == request.ChargeTypeCode).FirstOrDefaultAsync();
                if (charge == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type {request.ChargeTypeCode} does not exist in the database!");
                }

                if (charge.Action.Name.ToLower() == Department.Lending.ToString().ToLower())
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type {request.ChargeTypeCode} of type {Department.Lending} cannot be changed!");
                }

                var chargeHistory = await context.ChargeTypeHistories
                    .Where(cth => cth.ChargeTypeId == charge.ChargeTypeId)
                    .OrderByDescending(cth => cth.ChargeTypeHistoryId)
                    .FirstOrDefaultAsync();

                if (chargeHistory == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type history for {request.ChargeTypeCode} does not exist in the database!");
                }

                await CheckCreditAccountShort(context, logger, request.CreditAccountShort.Value);

                bool frequencyHasChanged = request.FrequencyId != charge.FrequencyId;

                switch (request.FrequencyId)
                {
                    case (int)Enums.ProcessingFrequency.Quarterly:
                        request.RunDay = 1;
                        break;
                    case (int)Enums.ProcessingFrequency.Monthly:
                        if (request.RunDay == null)
                            throw new RestException(HttpStatusCode.BadRequest, "You should provide run day for this charge type!");
                        break;
                    case (int)Enums.ProcessingFrequency.Once:
                        request.RunDay = null;
                        break;
                }

                DateTime? nextRunDay = null;

                if (frequencyHasChanged)
                {
                    nextRunDay = GetNextRunDay(context, request.FrequencyId, request.RunDay, request.CurrentDate);
                }

                var statusManger = new StatusStateManagement(charge.Status.ObjectStatusName, chargeHistory.Status.ObjectStatusName, true);
                statusManger.SetNextState(StateTrigger.Modify);
                logger.LogInformation($"Future state after approve state, charge type: {statusManger.State} charge type history: {statusManger.HistoryState}");
                var objStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.State.ToString()).FirstOrDefaultAsync();
                var objStatusForHistory = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.HistoryState.ToString()).FirstOrDefaultAsync();

                if (charge.Status.ObjectStatusName != Enums.ObjectStatus.Deleted && !IsChargeTypeDirty(charge, request))
                {
                    return Unit.Value;
                }

                charge.LastModifiedBy = request.LastModifiedBy;
                charge.StatusId = objStatus.ObjectStatusId;
                charge.LastModifiedDate = DateTime.Now;
                charge.RejectReason = null;
                var chargeTypeHistory = mapper.Map<Command, ChargeTypeHistory>(request);
                chargeTypeHistory.GroupId = charge.GroupId;
                chargeTypeHistory.ChargeTypeId = charge.ChargeTypeId;
                chargeTypeHistory.StatusId = objStatusForHistory.ObjectStatusId;
                chargeTypeHistory.ForDepartment = charge.ForDepartment;
                chargeTypeHistory.LastRunDate = charge.LastRunDate;
                chargeTypeHistory.NextRunDay = frequencyHasChanged ? nextRunDay : charge.NextRunDay;
                chargeTypeHistory.ActionId = (int)ObjectAction.EDIT;
                context.ChargeTypeHistories.Add(chargeTypeHistory);
                var success = await context.SaveChangesAsync() > 0;

                if (success)
                {
                    await SendChargeTypeEmailAsync(charge, nameof(NotificationAction.Edit), nameof(NotificationType.SendToApprove));
                }

                return success ? Unit.Value : throw new Exception("Charge type was not updated!");
            }

            private bool IsChargeTypeDirty(ChargeType charge, Command request)
            {
                return charge.ChargeTypeDescription != request.ChargeTypeDescription ||
                        charge.PaymentDetail != request.PaymentDetails ||
                        charge.CreditAccountShort != request.CreditAccountShort ||
                        charge.CurrId != request.CurrId ||
                        charge.DefaultAmount != request.Amount_Unit ||
                        charge.AmountProduct != request.Amount_Product ||
                        charge.FrequencyId != request.FrequencyId;
            }
        }
    }
}
