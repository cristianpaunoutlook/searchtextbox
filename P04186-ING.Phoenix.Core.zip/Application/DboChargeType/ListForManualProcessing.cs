﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.DTO;
using Application.Errors;
using Application.Helpers;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;

namespace Application.DboChargeType
{
    [ExcludeFromCodeCoverage]
    public class ListForManualProcessing
    {
        public class Query : IRequest<PagedChargeTypeForManualProcessing>
        {
            public ManualProcessParams ManualProcessParams { get; set; }
        }

        public class Handler : IRequestHandler<Query, PagedChargeTypeForManualProcessing>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;
            private readonly IMapper mapper;


            public Handler(PhoenixContext context, ILogger<Handler> logger, IMapper mapper)
            {
                this.context = context;
                this.logger = logger;
                this.mapper = mapper;
            }
            public async Task<PagedChargeTypeForManualProcessing> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation("Get list for manual processing");

                var chargeTypeList = await context.ListForManualProcess(request.ManualProcessParams.PageNumber,
                    request.ManualProcessParams.PageSize, request.ManualProcessParams.ChargeTypeId, request.ManualProcessParams.NextRunDay,
                    request.ManualProcessParams.ChargeDescription);

                if (chargeTypeList.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "There are no records corresponding to your search!");
                }

                var totalItems = chargeTypeList.Select(c => c.TotalItems).FirstOrDefault();
                var totalValidItems = chargeTypeList.Select(c => c.TotalValidItems).FirstOrDefault();

                var listOfChargeTypes = mapper.Map<List<ChargeTypeForManualProcessingDto>>(chargeTypeList);

                var chargeTypePagination = new PagedList<ChargeTypeForManualProcessingDto>(listOfChargeTypes, totalItems,
                    request.ManualProcessParams.PageNumber, request.ManualProcessParams.PageSize);

                var listToReturn = new PagedChargeTypeForManualProcessing
                {
                    ChargeTypes = chargeTypePagination,
                    CountValidToProcess = totalValidItems
                };

                return listToReturn;
            }
        }
    }
}
