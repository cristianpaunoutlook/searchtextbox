﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Helpers;
using Application.Interfaces;
using Application.Notifications.ChargeTypeNotifications;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    public class ChargeTypeBase : ChargeTypeNotificationBase
    {
        public ChargeTypeBase(IConfiguration configuration, IEmailSender emailSender) : base(configuration, emailSender) { }

        protected async Task CheckCreditAccountShort(PhoenixContext context, ILogger logger, long creditAccountShort)
        {
            var creditAccount = await context.Accounts.FindAsync(creditAccountShort);

            if (creditAccount == null)
            {
                ErrorMesage($"Credit account short: {creditAccountShort} is invalid or has incorrect Core Banking!", logger);
            }

            if (creditAccount.CoreBanking == CoreBanking.GBS.ToString())
            {
                var validAccountType = (
                                    from acc in context.Accounts
                                    join gbsTypes in context.GBSCreditAccountTypes on acc.Type equals gbsTypes.Code
                                    select
                                        acc
                                ).Where(acc => acc.AccountShort == creditAccount.AccountShort).FirstOrDefault();

                if (validAccountType == null)
                {
                    ErrorMesage($"Credit account short: {creditAccountShort} is invalid or has incorrect Core Banking!", logger);
                }
            }

            if (creditAccount.CoreBanking == CoreBanking.PRF.ToString())
            {
                var validAccountType = (
                                    from acc in context.Accounts
                                    join prfTypes in context.PRFCreditAccountTypes on acc.TypeId.Value equals prfTypes.CifTypeId
                                    select
                                        acc
                                ).Where(acc => acc.AccountShort == creditAccount.AccountShort).FirstOrDefault();

                if (validAccountType == null)
                {
                    ErrorMesage($"Credit account short: {creditAccountShort} is invalid or has incorrect Core Banking!", logger);
                }
            }
        }

        private void ErrorMesage(string errMessage, ILogger logger)
        {
            logger.LogInformation(errMessage);
            throw new RestException(HttpStatusCode.BadRequest, errMessage);
        }

        protected DateTime? GetNextRunDay(PhoenixContext context, int frequencyId, byte? runDay, DateTime dt)
        {
            if (frequencyId == (int)ProcessingFrequency.Once)
                return null;

            if (frequencyId == (int)ProcessingFrequency.Monthly)
                return GetNextRunDayForMonthly(context, runDay, dt);


            if (frequencyId == (int)ProcessingFrequency.Quarterly)
                return GetNextRunDayForQuarterly(context, dt);

            return null;
        }

        private bool IsWorkingDay(PhoenixContext context, DateTime dateToCheck)
        {
            return dateToCheck.DayOfWeek != DayOfWeek.Saturday && dateToCheck.DayOfWeek != DayOfWeek.Sunday && !IsNonWorkingDay(context, dateToCheck);
        }

        private bool IsNonWorkingDay(PhoenixContext context, DateTime dateToCheck)
        {
            return context.NonWorkingDays.Where(d => d.Date == dateToCheck.Date).Any();
        }

        private DateTime? CalculateNextRunDayForQuarterly(PhoenixContext context, DateTime dateToCheck)
        {
            if (IsWorkingDay(context, dateToCheck))
            {
                return dateToCheck.Date;
            }
            else
            {
                for (int i = 2; i <= dateToCheck.LastDayOfMonth().Day; i++)
                {
                    var nextDate = new DateTime(dateToCheck.Year, dateToCheck.Month, i);
                    if (IsWorkingDay(context, nextDate))
                    {
                        return nextDate.Date;
                    }
                }
            }
            return null;
        }

        private DateTime? GetNextRunDayForMonthly(PhoenixContext context, byte? runDay, DateTime dt)
        {
            var lastDayOfNextMonth = dt.AddMonths(1).LastDayOfMonth();

            if (runDay == 0)
            {
                if (IsWorkingDay(context, lastDayOfNextMonth))
                {
                    return lastDayOfNextMonth.Date;
                }

                for (int i = lastDayOfNextMonth.Day - 1; i > 0; i--)
                {
                    var dateToCheck = new DateTime(lastDayOfNextMonth.Year, lastDayOfNextMonth.Month, i);
                    if (IsWorkingDay(context, dateToCheck))
                    {
                        return dateToCheck.Date;
                    }
                }
            }
            else
            {
                var counterWorkingDays = 0;
                for (int i = 1; i <= lastDayOfNextMonth.Day; i++)
                {
                    var dateToCheck = new DateTime(lastDayOfNextMonth.Year, lastDayOfNextMonth.Month, i);
                    if (IsWorkingDay(context, dateToCheck))
                    {
                        counterWorkingDays += 1;
                        if (counterWorkingDays == runDay)
                        {
                            return dateToCheck.Date;
                        }
                    }
                }
            }
            return null;
        }

        private DateTime? GetNextRunDayForQuarterly(PhoenixContext context, DateTime dt)
        {
            if (dt.Month == (int)Month.January || dt.Month == (int)Month.February || dt.Month == (int)Month.March)
            {
                var dateToCheck = new DateTime(dt.Year, (int)Month.April, 1);
                return CalculateNextRunDayForQuarterly(context, dateToCheck);
            }
            else if (dt.Month == (int)Month.April || dt.Month == (int)Month.May || dt.Month == (int)Month.June || dt.Month == (int)Month.July)
            {
                var dateToCheck = new DateTime(dt.Year, (int)Month.August, 1);
                return CalculateNextRunDayForQuarterly(context, dateToCheck);
            }
            else if (dt.Month == (int)Month.August || dt.Month == (int)Month.September || dt.Month == (int)Month.October || dt.Month == (int)Month.November)
            {
                var dateToCheck = new DateTime(dt.Year, (int)Month.December, 1);
                return CalculateNextRunDayForQuarterly(context, dateToCheck);
            }
            else
            {
                var dateToCheck = new DateTime(dt.Year + 1, (int)Month.April, 1);
                return CalculateNextRunDayForQuarterly(context, dateToCheck);
            }
        }

    }
}
