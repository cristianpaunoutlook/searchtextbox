﻿using Application.DTO;
using Application.Helpers;
using Application.Interfaces.ProcessPayment;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    [ExcludeFromCodeCoverage]
    public class ProcessChargeTypes
    {
        public class Query : IRequest<ProcessResponseDTO>
        {
            public int[] ChargeTypeIds { get; set; }
            public ManualProcessParams Filter { get; set; }
        }

        public class Handler : IRequestHandler<Query, ProcessResponseDTO>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;
            private readonly IProcessPayment processPayment;

            public Handler(PhoenixContext context, ILogger<Handler> logger, IProcessPayment processPayment)
            {
                this.context = context;
                this.logger = logger;
                this.processPayment = processPayment;
            }
            public async Task<ProcessResponseDTO> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Process charge types: {string.Join(",", request.ChargeTypeIds)}.");
                var chargeTypesToProcess = request.ChargeTypeIds;

                var result = await processPayment.RegularExport(chargeTypesToProcess);
                await context.SetNextRunDay(chargeTypesToProcess);
                return result;
            }
        }
    }
}
