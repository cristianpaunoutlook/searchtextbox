﻿using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using AutoMapper;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Enums = Application.Commons.Enums;

namespace Application.DboChargeType
{
    public class Create
    {
        public class Command : IRequest
        {
            public string ChargeTypeCode { get; set; }
            public string ChargeTypeDescription { get; set; }
            public string PaymentDetails { get; set; }
            public long? CreditAccountShort { get; set; }
            public int CurrId { get; set; }
            public decimal Amount_Unit { get; set; }
            public decimal? Amount_Product { get; set; }
            public int FrequencyId { get; set; }
            public byte? RunDay { get; set; }
            public string LastModifiedBy { get; set; }
            public DateTime LastModifiedDate { get; set; }
            public DateTime CurrentDate { get; set; } = DateTime.Now;
        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(cht => cht.ChargeTypeCode).NotNull().MinimumLength(2).MaximumLength(10);
                RuleFor(cht => cht.ChargeTypeDescription).NotNull().MinimumLength(2).MaximumLength(50);
                RuleFor(cht => cht.PaymentDetails).NotNull().MinimumLength(2).MaximumLength(35);
                RuleFor(cht => cht.CreditAccountShort).NotNull().Must(x => x > 999 && x < 1000000000000);
                RuleFor(cht => cht.CurrId).NotNull();
                RuleFor(cht => cht.Amount_Unit).GreaterThanOrEqualTo(0);
                RuleFor(cht => cht.Amount_Product).GreaterThanOrEqualTo(0);
                RuleFor(cht => cht.FrequencyId).NotNull();
                RuleFor(cht => cht.RunDay)
                   .InclusiveBetween((byte)0, (byte)15)
                   .When(cht => cht.RunDay.HasValue);
            }
        }

        public class Handler : ChargeTypeBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger, IConfiguration configuration,
                IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                var checkChargeType = await context.ChargeTypes.Where(cht => cht.ChargeTypeCode.Trim() == request.ChargeTypeCode.Trim()).FirstOrDefaultAsync();
                if (checkChargeType != null)
                {
                    var statusCode = checkChargeType.Status.ObjectStatusName == Enums.ObjectStatus.Deleted || 
                        checkChargeType.Status.ObjectStatusName == Enums.ObjectStatus.RejectAdd ? HttpStatusCode.Conflict : HttpStatusCode.BadRequest;
                    logger.LogInformation($"Charge type with code {request.ChargeTypeCode} already exists in database with status {checkChargeType.Status.ObjectStatusName}!");
                    throw new RestException(statusCode, $"Charge type with code {request.ChargeTypeCode} already exists in database with status {checkChargeType.Status.ObjectStatusName}!");
                }

                await CheckCreditAccountShort(context, logger, request.CreditAccountShort.Value);

                logger.LogInformation($"Create charge type {request.ChargeTypeCode}");
                var objStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == Enums.ObjectStatus.VerificationAdd).FirstOrDefaultAsync();
                var forDepartment = await context.ObjectActions
                                            .Where(fd => fd.Name == Department.PCM.ToString())
                                            .FirstOrDefaultAsync();

                switch (request.FrequencyId)
                {
                    case (int)Enums.ProcessingFrequency.Quarterly:
                        request.RunDay = 1;
                        break;
                    case (int)Enums.ProcessingFrequency.Monthly:
                        if (request.RunDay == null)
                            throw new RestException(HttpStatusCode.BadRequest, "You should provide run day for this charge type!");
                        break;
                    case (int)Enums.ProcessingFrequency.Once:
                        request.RunDay = null;
                        break;
                }

                var nextRunDay = GetNextRunDay(context, request.FrequencyId, request.RunDay, request.CurrentDate);

                logger.LogInformation($"RunDay {request.RunDay}");
                logger.LogInformation($"Next Run Day {nextRunDay}");
                var chargeType = mapper.Map<Command, ChargeType>(request);
                chargeType.StatusId = objStatus.ObjectStatusId;
                chargeType.ForDepartment = forDepartment.ActionId;
                chargeType.NextRunDay = nextRunDay;
                var defaultChargeTypeGroup = await context.ChargeTypeGroups
                                                .FirstOrDefaultAsync(ctg => ctg.Code == Enums.ChargeTypeGroup.DEFAULT.ToString());
                if(defaultChargeTypeGroup == null)
                {
                    logger.LogInformation($"No default charge type group exists in database!");
                    throw new RestException(HttpStatusCode.BadRequest, $"No default charge type group exists in database!");
                }

                chargeType.GroupId = defaultChargeTypeGroup.Id;
                chargeType.RejectReason = null;

                var chargeTypeHistory = mapper.Map<ChargeType, ChargeTypeHistory>(chargeType);
                chargeTypeHistory.ChargeType = chargeType;
                chargeTypeHistory.ActionId = (int)ObjectAction.ADD;
                context.Add(chargeType);
                context.Add(chargeTypeHistory);

                var success = await context.SaveChangesAsync() > 0;

                if (success)
                {
                    await SendChargeTypeEmailAsync(chargeType, nameof(NotificationAction.Add), nameof(NotificationType.SendToApprove));
                }

                return success ? Unit.Value : throw new Exception("Charge type was not created!");
            }
        }
    }
}