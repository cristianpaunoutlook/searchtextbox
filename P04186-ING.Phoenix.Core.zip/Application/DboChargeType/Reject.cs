﻿using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.ChargeTypeNotifications;
using Application.StateManagement;
using AutoMapper;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;

namespace Application.DboChargeType
{
    public class Reject
    {
        public class Command : IRequest
        {
            public string ChargeTypeCode { get; set; }
            public string UserKey { get; set; }
            public string RejectReason { get; set; }
        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(cht => cht.ChargeTypeCode).NotNull().NotEmpty().MaximumLength(10);
                RuleFor(cht => cht.RejectReason).NotNull().NotEmpty().MaximumLength(500);
            }
        }

        public class Handler : ChargeTypeNotificationBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger, IConfiguration configuration,
                IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Reject charge type {request.ChargeTypeCode}");
                var chargeType = await context.ChargeTypes.Where(cht => cht.ChargeTypeCode.Trim() == request.ChargeTypeCode.Trim()).FirstOrDefaultAsync();
                if (chargeType == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type with code {request.ChargeTypeCode} does not exist in the database!");
                }

                var chargeHistory = await context.ChargeTypeHistories
                    .Where(cth => cth.ChargeTypeId == chargeType.ChargeTypeId)
                    .OrderByDescending(cth => cth.ChargeTypeHistoryId)
                    .FirstOrDefaultAsync();

                if (chargeHistory == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type history for {request.ChargeTypeCode} does not exist in the database!");
                }

                if (request.UserKey == chargeHistory.LastModifiedBy)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"You have changed the charge type so you can not approve the change!");
                }

                logger.LogInformation($"Current state, charge type: {chargeType.Status.ObjectStatusName} charge type history: {chargeHistory.Status.ObjectStatusName}");

                var statusManger = new StatusStateManagement(chargeType.Status.ObjectStatusName, chargeHistory.Status.ObjectStatusName, true);
                statusManger.SetNextState(StateTrigger.Reject);

                logger.LogInformation($"Future state after approve state, charge type: {statusManger.State} charge type history: {statusManger.HistoryState}");

                var objStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.State.ToString()).FirstOrDefaultAsync();
                var objStatusForHistory = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.HistoryState.ToString()).FirstOrDefaultAsync();
                chargeType.StatusId = objStatus.ObjectStatusId;
                chargeType.LastModifiedBy = request.UserKey;
                chargeType.LastModifiedDate = DateTime.Now;
                chargeType.RejectReason = request.RejectReason;
                var newChargeTypeHistory = mapper.Map<ChargeTypeHistory>(chargeType);
                newChargeTypeHistory.Status = objStatusForHistory;
                newChargeTypeHistory.StatusId = objStatusForHistory.ObjectStatusId;
                newChargeTypeHistory.ActionId = (int)ObjectAction.REJECT;
                context.ChargeTypeHistories.Add(newChargeTypeHistory);
                var success = await context.SaveChangesAsync() > 0;

                if (success)
                {
                    await SendChargeTypeEmailAsync(chargeType, chargeHistory.Status.ObjectStatusName, nameof(NotificationType.Rejected));
                }

                return success ? Unit.Value : throw new Exception("Error on reject charge type!");

            }
        }
    }
}
