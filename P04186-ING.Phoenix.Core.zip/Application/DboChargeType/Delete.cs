﻿using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.Commons.Enums;
using Application.Errors;
using Application.Interfaces;
using Application.Notifications.ChargeTypeNotifications;
using Application.StateManagement;
using AutoMapper;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;

namespace Application.DboChargeType
{
    public class Delete
    {
        public class Command : IRequest
        {
            public int ChargeTypeId { get; set; }
            public string LastModifiedBy { get; set; }
        }

        public class Handler : ChargeTypeNotificationBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger, IConfiguration configuration,
                IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Create charge type with id {request.ChargeTypeId}");
                var charge = await context.ChargeTypes.FindAsync(request.ChargeTypeId);
                if (charge == null)
                {
                    throw new Exception($"Charge type does not exist in the database!");
                }

                if (charge.Action.Name.ToLower() == Department.Lending.ToString().ToLower())
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type {charge.ChargeTypeCode} of type {Department.Lending} cannot be deleted!");
                }

                if (charge.IsJobBased)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type {charge.ChargeTypeCode} is job based and cannot be deleted!");
                }

                var chargeHistory = await context.ChargeTypeHistories
                        .Where(cth => cth.ChargeTypeId == charge.ChargeTypeId)
                        .OrderByDescending(cth => cth.ChargeTypeHistoryId)
                        .FirstOrDefaultAsync();

                if (chargeHistory == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Charge type history for {charge.ChargeTypeCode} does not exist in the database!");
                }

                var statusManger = new StatusStateManagement(charge.Status.ObjectStatusName, chargeHistory.Status.ObjectStatusName, true);
                statusManger.SetNextState(StateTrigger.Delete);

                var objStatus = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.State.ToString()).FirstOrDefaultAsync();
                var objStatusHistory = await context.ObjectStatus.Where(os => os.ObjectStatusName == statusManger.HistoryState.ToString()).FirstOrDefaultAsync();

                charge.StatusId = objStatus.ObjectStatusId;
                charge.LastModifiedBy = request.LastModifiedBy;
                charge.LastModifiedDate = DateTime.Now;
                charge.RejectReason = null;

                var chargeTypeHistory = mapper.Map<ChargeType, ChargeTypeHistory>(charge);
                chargeTypeHistory.Status = objStatusHistory;
                chargeTypeHistory.StatusId = objStatusHistory.ObjectStatusId;
                chargeTypeHistory.ActionId = (int)ObjectAction.DELETE;

                context.ChargeTypeHistories.Add(chargeTypeHistory);

                var success = await context.SaveChangesAsync() > 0;

                if (success)
                {
                    await SendChargeTypeEmailAsync(charge, nameof(NotificationAction.Delete), nameof(NotificationType.SendToApprove));
                }

                return success ? Unit.Value : throw new Exception($"Charge type {charge.ChargeTypeCode} was not deleted!");
            }
        }
    }
}
