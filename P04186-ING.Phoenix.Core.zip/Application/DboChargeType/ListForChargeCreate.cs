﻿using Application.Commons.Enums;
using Application.DboCharge;
using Application.DTO;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    public class ListForChargeCreate
    {
        public class Query : IRequest<IEnumerable<ChargeTypeForChargeCreateDTO>>
        {
            public string CoreBanking { get; set; }
        }

        public class Handler : ChargeBase, IRequestHandler<Query, IEnumerable<ChargeTypeForChargeCreateDTO>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }
            public async Task<IEnumerable<ChargeTypeForChargeCreateDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get charge types and their corresponding values for corebanking: {request.CoreBanking}");

                return await GetChargeTypeListForChargeCreate(context, request.CoreBanking);
            }
        }
    }
}
