﻿using Application.Commons.Enums;
using Application.DTO;
using Application.Interfaces;
using Application.Notifications.ManualProcessingNotifications;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    public class ManualProcessNotification
    {
        public class Command : IRequest
        {
            public int SessionId { get; set; }
            public IEnumerable<SessionInfoDTO> SessionInfo { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : ManualProcessingNotificationBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;

            public Handler(PhoenixContext context, IEmailSender emailSender, IConfiguration configuration) :
                base(configuration, emailSender)
            {
                this.context = context;
            }
            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                var chargeTypeIds = request.SessionInfo.Where(s => s.SessionId == request.SessionId)
                                                       .Select(s => s.ChargeTypeIds)
                                                       .FirstOrDefault();

                var isChargeTypeValidForNotification = await context.ChargeTypes
                    .Where(c => chargeTypeIds.Select(c => c.Key).Contains(c.ChargeTypeId) && 
                                            (c.FrequencyId == (int)ProcessingFrequency.Monthly ||
                                             c.FrequencyId == (int)ProcessingFrequency.Quarterly   
                                            ))
                    .AnyAsync();

                if (isChargeTypeValidForNotification)
                {
                    var currentSession = request.SessionInfo.Where(s => s.SessionId == request.SessionId).FirstOrDefault();

                    await SendManualProcessingEmailAsync(request.SessionId, request.UserKey, string.Join(", ", chargeTypeIds.Select(c => c.Value)),
                            currentSession.StartDate.ToString("dd.MM.yyyy HH:mm:ss"), currentSession.TotalCommissons);
                }

                return Unit.Value;
            }
        }
    }
}
