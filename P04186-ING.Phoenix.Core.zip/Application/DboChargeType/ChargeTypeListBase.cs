﻿using Application.DTO;
using Application.Export.ChargeTypeHistoryReport;
using Application.Export.ChargeTypes;
using Persistence;
using System.Linq;

namespace Application.DboChargeType
{
    public class ChargeTypeListBase
    {
        public IQueryable<ChargeTypeListDTO> ChargeTypeList(PhoenixContext context, ChargeTypesFilter filter)
        {
            var chargeTypes = from ct in context.ChargeTypes.Where(ct => ct.Status.ObjectStatusName == Commons.Enums.ObjectStatus.Active ||
                                        ct.Status.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationAdd)
                              from cth in context.ChargeTypeHistories.Where(o => ct.ChargeTypeId == o.ChargeTypeId)
                                                            .OrderByDescending(h => h.ChargeTypeHistoryId)
                                                             .Take(1)
                                                             .DefaultIfEmpty()

                              select new ChargeTypeListDTO
                              {
                                  ChargeTypeId = ct.ChargeTypeId,
                                  ChargeTypeCode = ct.ChargeTypeCode,
                                  ChargeTypeDescription = ct.ChargeTypeDescription,
                                  CurrId = ct.CurrId,
                                  CurrCode = ct.Curr.CurrencyCode,
                                  DefaultAmount = ct.DefaultAmount,
                                  FrequencyId = ct.FrequencyId,
                                  FrequencyName = ct.Frequency.ProcessingFrequencyName,
                                  PaymentDetail = ct.PaymentDetail,
                                  StatusId = ct.StatusId,
                                  StatusName = ct.Status.ObjectStatusName,
                                  LastRunDate = ct.LastRunDate,
                                  ForDepartment = ct.ForDepartment,
                                  ForDepartmentName = ct.Action.Name,
                                  CreditAccountId = ct.CreditAccountId,
                                  RejectReason = ct.RejectReason,
                                  AmountProduct = ct.AmountProduct,
                                  CreditAccountShort = ct.CreditAccountShort,
                                  LastModifiedBy = ct.LastModifiedBy,
                                  IsJobBased = ct.IsJobBased,
                                  ChargeTypeHistoryId = cth.ChargeTypeHistoryId,
                                  HistoryStatusId = cth.StatusId,
                                  HistoryStatusCode = cth.Status.ObjectStatusName,
                                  HistoryLastModifiedBy = cth.LastModifiedBy,
                                  RunDay = ct.RunDay,
                                  NextRunDay = ct.NextRunDay,
                                  LastModifiedDate = ct.LastModifiedDate,
                                  HistoryChargeTypeDescription = cth.ChargeTypeDescription,
                                  HistoryPaymentDetail = cth.PaymentDetail,
                                  HistoryCreditAccount = cth.CreditAccountShort,
                                  HistoryCurrency = cth.Curr.CurrencyCode,
                                  HistoryAmountProduct = cth.AmountProduct,
                                  HistoryAmountUnit = cth.DefaultAmount,
                                  HistoryFrequency = cth.Frequency.ProcessingFrequencyName,
                                  HistoryRunDay = cth.RunDay
                              };

            if (filter.ChargeTypeId != null)
            {
                return chargeTypes.Where(c => c.ChargeTypeId == filter.ChargeTypeId);
            }

            if (filter.FrequencyId != -1)
            {
                chargeTypes = chargeTypes.Where(c => c.FrequencyId == filter.FrequencyId);
            }

            if (filter.StatusId != -1)
            {
                chargeTypes = chargeTypes.Where(c => c.HistoryStatusId == filter.StatusId);
            }

            if (!string.IsNullOrEmpty(filter.ChargeTypeCode))
            {
                chargeTypes = chargeTypes.Where(c => c.ChargeTypeCode.Contains(filter.ChargeTypeCode));
            }

            if (!string.IsNullOrEmpty(filter.ChargeTypeDescription))
            {
                chargeTypes = chargeTypes.Where(c => c.ChargeTypeDescription.Contains(filter.ChargeTypeDescription));
            }

            return chargeTypes;
        }

        public IQueryable<ChargeTypeHistoryReportListDTO> ChargeTypeHistoryReportList(PhoenixContext context, ChargeTypeHistoryReportFilter filter)
        {
            var chargeTypes = from cth in context.ChargeTypeHistories

                              select new ChargeTypeHistoryReportListDTO
                              {
                                  ChargeTypeId = cth.ChargeTypeId,
                                  ChargeTypeCode = cth.ChargeType.ChargeTypeCode,
                                  ChargeTypeDescription = cth.ChargeTypeDescription,
                                  PaymentDetail = cth.PaymentDetail,
                                  CreditAccountShort = cth.CreditAccountShort,
                                  CurrCode = cth.Curr.CurrencyCode,
                                  DefaultAmount = cth.DefaultAmount,
                                  AmountProduct = cth.AmountProduct,
                                  FrequencyName = cth.Frequency.ProcessingFrequencyName,
                                  RunDay = cth.RunDay,
                                  StatusId = cth.StatusId,
                                  StatusName = cth.Status.ObjectStatusName,
                                  LastModifiedBy = cth.LastModifiedBy,
                                  ActionId = cth.ActionId,
                                  ActionName = cth.ObjectAction.Name,
                                  RejectReason = cth.RejectReason,
                                  LastModifiedDate = cth.LastModifiedDate
                              };

            if (filter.ChargeTypeId != -1)
            {
                chargeTypes = chargeTypes.Where(c => c.ChargeTypeId == filter.ChargeTypeId);
            }

            if (filter.StatusId != -1)
            {
                chargeTypes = chargeTypes.Where(c => c.StatusId == filter.StatusId);
            }

            if (!string.IsNullOrEmpty(filter.UserId))
            {
                chargeTypes = chargeTypes.Where(c => c.LastModifiedBy.Contains(filter.UserId));
            }

            if (filter.ActionId != -1)
            {
                chargeTypes = chargeTypes.Where(c => c.ActionId == filter.ActionId);
            }

            if (filter.StartDate != null)
            {
                chargeTypes = chargeTypes.Where(c => c.LastModifiedDate.Value.Date >= filter.StartDate.Value.Date);
            }

            if (filter.EndDate != null)
            {
                chargeTypes = chargeTypes.Where(c => c.LastModifiedDate.Value.Date <= filter.EndDate.Value.Date);
            }

            return chargeTypes;
        }
    }
}
