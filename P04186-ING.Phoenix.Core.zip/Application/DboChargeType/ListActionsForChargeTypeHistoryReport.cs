﻿using Application.DTO;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    [ExcludeFromCodeCoverage]
    public class ListActionsForChargeTypeHistoryReport
    {
        public class Query : IRequest<IEnumerable<ActionDropDownDTO>> { }

        public class Handler : IRequestHandler<Query, IEnumerable<ActionDropDownDTO>>
        {
            private readonly PhoenixContext context;

            public Handler(PhoenixContext context)
            {
                this.context = context;
            }

            public async Task<IEnumerable<ActionDropDownDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                var actions = from cth in context.ChargeTypeHistories
                              select new ActionDropDownDTO
                              {
                                  ActionId = cth.ObjectAction.ActionId,
                                  Name = cth.ObjectAction.Name
                              };
                return await actions.Distinct().OrderBy(a => a.Name).ToListAsync();
            }
        }
    }
}
