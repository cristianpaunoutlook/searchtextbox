﻿using Application.Commons.Enums;
using Application.DTO;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    public class ListForPaymentsReport
    {
        public class Query : IRequest<IEnumerable<ChargeTypeDropDownDTO>> { }

        public class Handler : IRequestHandler<Query, IEnumerable<ChargeTypeDropDownDTO>>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;

            public Handler(PhoenixContext context, IMapper mapper)
            {
                this.context = context;
                this.mapper = mapper;
            }

            public async Task<IEnumerable<ChargeTypeDropDownDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                var chargeTypes = await context.ChargeTypes
                                            .Where(ct => ct.Status.ObjectStatusName != ObjectStatus.RejectAdd && 
                                                            ct.Status.ObjectStatusName != ObjectStatus.VerificationAdd)
                                            .ToListAsync();

                return mapper.Map<IEnumerable<ChargeTypeDropDownDTO>>(chargeTypes);
            }
        }
    }
}
