﻿using Application.DTO;
using Application.Helpers;
using System.Diagnostics.CodeAnalysis;

namespace Application.DboChargeType
{
    [ExcludeFromCodeCoverage]
    public class PagedChargeTypeForManualProcessing
    {
        public PagedList<ChargeTypeForManualProcessingDto> ChargeTypes { get; set; }
        public int CountValidToProcess { get; set; }
    }
}
