﻿using Application.DTO;
using Application.Errors;
using Application.Export.ChargeTypes;
using Application.Helpers;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboChargeType
{
    public class List
    {
        public class Query : IRequest<PagedList<ChargeTypeListDTO>> { public ChargeTypeParams ChargeTypeParams { get; set; } }

        public class Handler : ChargeTypeListBase, IRequestHandler<Query, PagedList<ChargeTypeListDTO>>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<PagedList<ChargeTypeListDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get charge type list with filters code: {request.ChargeTypeParams.ChargeTypeCode}  " +
                    $"description {request.ChargeTypeParams.ChargeTypeDescription} frequency {request.ChargeTypeParams.FrequencyId} " +
                    $"statusId {request.ChargeTypeParams.StatusId} sort field {request.ChargeTypeParams.SortField} sort direction {request.ChargeTypeParams.SortOrder}");

                var filter = mapper.Map<ChargeTypesFilter>(request.ChargeTypeParams);
                var chargeTypes = ChargeTypeList(context, filter);

                if (!String.IsNullOrEmpty(request.ChargeTypeParams.SortField) && !String.IsNullOrEmpty(request.ChargeTypeParams.SortOrder))
                {
                    chargeTypes = chargeTypes.OrderByPropertyName(request.ChargeTypeParams.SortField, request.ChargeTypeParams.SortOrder).AsQueryable();
                }
                else
                {
                    chargeTypes = chargeTypes.OrderByDescending(ct => ct.HistoryStatusId).ThenBy(ct => ct.ChargeTypeCode);
                }

                var paginatedResult = await PagedList<ChargeTypeListDTO>.CreateAsync(chargeTypes, request.ChargeTypeParams.PageNumber,
                    request.ChargeTypeParams.PageSize);

                if (paginatedResult.Items.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "There are no records corresponding to your search!");
                }

                return paginatedResult;
            }
        }
    }
}
