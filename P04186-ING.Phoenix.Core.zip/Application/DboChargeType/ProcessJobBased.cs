﻿using Application.Commons.Enums;
using Application.DTO;
using Application.Interfaces.ProcessPayment;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Application.Commons.Constants;

namespace Application.DboChargeType
{
    public class ProcessJobBased
    {
        public class Query : IRequest<ProcessResponseDTO> { }

        public class Handler : IRequestHandler<Query, ProcessResponseDTO>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;
            private readonly IProcessPayment processPayment;

            public Handler(PhoenixContext context, ILogger<Handler> logger, IProcessPayment processPayment)
            {
                this.context = context;
                this.logger = logger;
                this.processPayment = processPayment;
            }

            public async Task<ProcessResponseDTO> Handle(Query request, CancellationToken cancellationToken)
            {
                var chargeTypesList = await context
                    .ChargeTypes
                    .Where(ct => ct.IsJobBased == true &&
                        ct.ForDepartment != (int)Department.Lending &&
                        ct.NextRunDay.Value.Date == DateTime.Now.Date &&
                        !Constants.CHARES_TYPES_JOBS_BASED_SPECIAL.Contains(ct.ChargeTypeCode))
                    .ToListAsync();

                if (chargeTypesList.Count == 0)
                {
                    return null;
                }
                var chargeTypeIds = chargeTypesList.Select(ct => ct.ChargeTypeId).ToArray();
                var sessionInfo = await processPayment.RegularExport(chargeTypeIds);
                logger.LogInformation($"session info ID: {sessionInfo.SessionId} Response {sessionInfo.Response}");
                await context.SetNextRunDay(chargeTypeIds);
                if (sessionInfo.SessionId == 0)
                {
                    logger.LogInformation($"There ar no payments to process for {string.Join(",", chargeTypeIds)}");
                }
                return sessionInfo.SessionId == 0 ? null : sessionInfo;
            }
        }
    }
}
