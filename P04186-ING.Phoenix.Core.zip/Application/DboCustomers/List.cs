﻿using Application.Commons.Enums;
using Application.DTO;
using Application.Errors;
using Application.Helpers;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCustomers
{
    public class List
    {
        public class Query : IRequest<PagedList<CustomerListDTO>> { public CustomerParams CustomerParams { get; set; } }

        public class Handler : IRequestHandler<Query, PagedList<CustomerListDTO>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<PagedList<CustomerListDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get customers list with filters customer: {request.CustomerParams.CustomerId}  " +
                    $"cui {request.CustomerParams.CUI} customer name {request.CustomerParams.Name} charge type {request.CustomerParams.ChargeTypeId}" +
                    $"statusId {request.CustomerParams.StatusId} sort field {request.CustomerParams.SortField} sort direction {request.CustomerParams.SortOrder}");

                var accounts = context.Accounts.Where(a => a.IBAN != null && a.IBAN.Substring(8, 3) != "TVA");

                var customers = (from acc in accounts
                                 from gbs in context.GBSDebitAccountTypes.Where(gbs => acc.Type == gbs.Code)
                                 select new CustomerListDTO
                                 {
                                     CustomerId = acc.CustomerId,
                                     CUI = acc.CUI,
                                     Name = acc.CustomerName,
                                     CoreBanking = acc.CoreBanking
                                 }).Union(
                    from acc in accounts
                    from prf in context.PRFDebitAccountTypes.Where(prf => acc.Type == prf.Code && acc.TypeId == prf.CifTypeId)
                    select new CustomerListDTO
                    {
                        CustomerId = acc.CustomerId,
                        CUI = acc.CUI,
                        Name = acc.CustomerName,
                        CoreBanking = acc.CoreBanking
                    });

                if (request.CustomerParams.ChargeTypeId != -1 || request.CustomerParams.StatusId != -1)
                {
                    if (request.CustomerParams.StatusId == -1)
                    {
                        customers = from cst in customers
                                    join ch in context.Charges on cst.CustomerId equals ch.AtlasId
                                    where ch.Status.ObjectStatusName == ObjectStatus.Active || ch.Status.ObjectStatusName == ObjectStatus.VerificationAdd
                                    select new CustomerListDTO
                                    {
                                        CustomerId = cst.CustomerId,
                                        CUI = cst.CUI,
                                        Name = cst.Name,
                                        ChargeTypeId = ch.ChargeTypeId,
                                        CoreBanking = cst.CoreBanking
                                    };
                        customers = customers.Where(c => c.ChargeTypeId == request.CustomerParams.ChargeTypeId);
                    }

                    else
                    {

                        customers = from cst in customers
                                    join ch in context.Charges.Where(c => request.CustomerParams.ChargeTypeId == -1 || c.ChargeTypeId == request.CustomerParams.ChargeTypeId)
                                        on cst.CustomerId equals ch.AtlasId
                                    from cth in context.ChargesHistory.Where(h => ch.ChargeId == h.ChargeId)
                                                            .OrderByDescending(h => h.ChargeHistoryId)
                                                             .Take(1)
                                    where ch.Status.ObjectStatusName == ObjectStatus.Active || ch.Status.ObjectStatusName == ObjectStatus.VerificationAdd
                                    select new CustomerListDTO
                                    {
                                        CustomerId = cst.CustomerId,
                                        CUI = cst.CUI,
                                        Name = cst.Name,
                                        StatusId = cth.StatusId,
                                        CoreBanking = cst.CoreBanking
                                    };

                        customers = customers.Where(c => c.StatusId == request.CustomerParams.StatusId);
                    }

                }

                if (!string.IsNullOrEmpty(request.CustomerParams.CustomerId))
                {
                    customers = customers.Where(c => c.CustomerId.Contains(request.CustomerParams.CustomerId.Trim()));
                }

                if (!string.IsNullOrEmpty(request.CustomerParams.CUI))
                {
                    customers = customers.Where(c => c.CUI.Contains(request.CustomerParams.CUI.Trim()));
                }

                if (!string.IsNullOrEmpty(request.CustomerParams.Name))
                {
                    customers = customers.Where(c => c.Name.Contains(request.CustomerParams.Name.Trim()));
                }

                customers = customers.Distinct().OrderBy(ct => ct.Name);

                var paginatedCustomers = await PagedList<CustomerListDTO>.CreateAsync(customers, request.CustomerParams.PageNumber, request.CustomerParams.PageSize);

                if (paginatedCustomers.Items.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "There are no records corresponding to your search!");
                }

                return paginatedCustomers;
            }
        }
    }
}
