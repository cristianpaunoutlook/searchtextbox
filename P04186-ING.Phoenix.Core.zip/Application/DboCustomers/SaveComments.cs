﻿using Application.Commons.Enums;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboCustomers
{
    public class SaveComments
    {
        public class Command : IRequest
        {
            public string CustomerId { get; set; }

            public string Comments { get; set; }

            public string LastModifiedBy { get; set; }
        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"edit customer {request.CustomerId} comments {request.Comments}");

                var customer = await context.Customers.Where(c => c.AtlasID == request.CustomerId).FirstOrDefaultAsync();
                if (customer == null)
                {
                    var newCustomer = new Customer
                    {
                        AtlasID = request.CustomerId,
                        Comments = request.Comments,
                        DateLastUpdate = DateTime.Now,
                        UserID = request.LastModifiedBy,
                        StatusId = (byte)ObjectStatusId.NotSet
                    };

                    context.Add(newCustomer);
                }
                else
                {
                    customer.Comments = request.Comments;
                    customer.DateLastUpdate = DateTime.Now;
                    customer.UserID = request.LastModifiedBy;
                }

                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Customer was not updated!");
            }
        }
    }
}
