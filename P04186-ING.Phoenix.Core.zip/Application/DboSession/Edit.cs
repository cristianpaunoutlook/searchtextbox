using System;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using MediatR;
using Persistence;
using Application.Errors;
using System.Net;
using Microsoft.Extensions.Logging;

namespace Application.DboSession
{
    public class Edit
    {
        public class Command : IRequest
        {
            public int SessionId { get; set; }

            public DateTime? RecordStamp { get; set; }

            public string GeneratedFileName { get; set; }

            public int? ObjectTypeId { get; set; }

            public int? Status { get; set; }

        }

        public class CommandValidator : AbstractValidator<Command>
        {
            public CommandValidator()
            {
                RuleFor(x => x.GeneratedFileName).NotEmpty();
            }
        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"edit sesssion {request.SessionId}");

                var session = await context.Sessions.FindAsync(request.SessionId);
                if (session == null)
                    throw new RestException(HttpStatusCode.BadRequest, $"Session {request.SessionId} does not exist in the database!");

                session.GeneratedFileName = request.GeneratedFileName ?? session.GeneratedFileName;
                session.ObjectTypeId = request.ObjectTypeId ?? session.ObjectTypeId;
                session.Status = request.Status ?? session.Status;
                session.RecordStamp = request.RecordStamp ?? session.RecordStamp;

                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Session was not updated!");
            }
        }
    }
}