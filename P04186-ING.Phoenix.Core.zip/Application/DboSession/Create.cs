using System;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Domain;
using Persistence;
using Microsoft.Extensions.Logging;

namespace Application.DboSession
{
    public class Create
    {
        public class Command : IRequest
        {
            public string GeneratedFileName { get; set; }

            public int ObjectTypeId { get; set; }

            public int Status { get; set; }

        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Create sesssion status {request.Status} object type {request.ObjectTypeId}");
                var session = new Session(){
                    RecordStamp = DateTime.Now,
                    GeneratedFileName = request.GeneratedFileName,
                    Status = request.Status,
                    ObjectTypeId = request.ObjectTypeId
                };

                this.context.Add(session);
                var success = await this.context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Session was not created!");
            }
        }
    }
}