﻿using Application.DTO;
using Application.Interfaces.ProcessPayment;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboSession
{
    public class SessionInfo
    {
        public class Query : IRequest<IEnumerable<SessionInfoDTO>>
        {
        }

        public class Handler : IRequestHandler<Query, IEnumerable<SessionInfoDTO>>
        {
            private readonly ILogger<Handler> logger;
            private readonly IProcessPayment processPayment;

            public Handler(ILogger<Handler> logger, IProcessPayment processPayment)
            {
                this.logger = logger;
                this.processPayment = processPayment;
            }
            public async Task<IEnumerable<SessionInfoDTO>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Get current sessions");
               
                return await processPayment.GetSessions();
            }
        }
    }
}
