using System.Net;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using MediatR;
using Application.DTO;
using Application.Errors;
using Domain;
using Persistence;
using Microsoft.Extensions.Logging;

namespace Application.DboSession
{
    public class Details
    {
        public class Query : IRequest<SessionDTO> { public int Id { get; set; } }

        public class Handler : IRequestHandler<Query, SessionDTO>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, IMapper mapper, ILogger<Handler> logger)
            {
                this.context = context;
                this.mapper = mapper;
                this.logger = logger;
            }

            public async Task<SessionDTO> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"sesssion details for {request.Id}");

                var session = await context.Sessions.FindAsync(request.Id);

                if (session == null)
                    throw new RestException(HttpStatusCode.NotFound, $"The session {request.Id} does not exist!");

                return mapper.Map<Session, SessionDTO>(session);
            }
        }
    }
}