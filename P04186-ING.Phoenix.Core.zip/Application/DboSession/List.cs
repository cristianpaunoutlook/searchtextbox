using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Domain;
using Persistence;
using Application.Helpers;
using System;
using Microsoft.Extensions.Logging;

namespace Application.DboSession
{
    public class List
    {
        public class Query : IRequest<PagedList<Session>> { public SessionParams SessionParams { get; set; } }

        public class Handler : IRequestHandler<Query, PagedList<Session>>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<PagedList<Session>> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"get sessions list");

                var sessions = context.Sessions.AsQueryable();

                if (request.SessionParams.SessionId != 0)
                {
                    sessions = sessions.Where(s => s.SessionId == request.SessionParams.SessionId);
                }

                if (!string.IsNullOrEmpty(request.SessionParams.GeneratedFileName))
                {
                    sessions = sessions.Where(s => s.GeneratedFileName == request.SessionParams.GeneratedFileName);
                }

                return await PagedList<Session>.CreateAsync(sessions, request.SessionParams.PageNumber,
                    request.SessionParams.PageSize);
            }
        }
    }
}