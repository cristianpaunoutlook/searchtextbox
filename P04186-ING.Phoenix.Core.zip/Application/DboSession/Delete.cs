using System;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Persistence;
using Microsoft.Extensions.Logging;

namespace Application.DboSession
{
    public class Delete
    {
        public class Command : IRequest
        {
            public int SessionId { get; set; }
        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Delete sesssion {request.SessionId}");

                var session = await context.Sessions.FindAsync(request.SessionId);
                if (session == null)
                    throw new Exception($"Session {request.SessionId} does not exist in the database!");

                context.Remove(session);

                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Session was not updated!");
            }
        }
    }
}