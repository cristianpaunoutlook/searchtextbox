﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeWithDescriptionDdlDTO
    {
        public int ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
    }
}
