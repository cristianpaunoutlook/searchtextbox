﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{

    [ExcludeFromCodeCoverage]
    public class CurrencyDTO
    {
        public int CurrencyId { get; set; }

        public string CurrencyCode { get; set; }

        public bool ActiveYN { get; set; }
    }
}
