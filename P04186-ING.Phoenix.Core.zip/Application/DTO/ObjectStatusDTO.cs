﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ObjectStatusDTO
    {
        public byte ObjectStatusId { get; set; }

        public string ObjectStatusName { get; set; }

        public bool Visible { get; set; }
    }
}
