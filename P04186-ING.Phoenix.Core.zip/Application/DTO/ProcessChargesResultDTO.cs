﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ProcessChargesResultDTO
    {
        public IEnumerable<SessionInfoDTO> SessionInfo { get; set; }
        public ProcessResponseDTO ProcessResponse { get; set; }
    }
}
