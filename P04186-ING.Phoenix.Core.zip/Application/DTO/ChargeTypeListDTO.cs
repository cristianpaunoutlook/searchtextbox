﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeListDTO
    {
        public int ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
        public int CurrId { get; set; }
        public string CurrCode { get; set; }
        public decimal DefaultAmount { get; set; }
        public int FrequencyId { get; set; }
        public string FrequencyName { get; set; }
        public string PaymentDetail { get; set; }
        public byte StatusId { get; set; }
        public string StatusName { get; set; }
        public DateTime? LastRunDate { get; set; }
        public int? ForDepartment { get; set; }
        public string ForDepartmentName { get; set; }
        public int? CreditAccountId { get; set; }
        public string RejectReason { get; set; }
        public decimal? AmountProduct { get; set; }
        public long? CreditAccountShort { get; set; }
        public string LastModifiedBy { get; set; }
        public byte? RunDay { get; set; }
        public DateTime? NextRunDay { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public bool IsJobBased { get; set; }
        public int ChargeTypeHistoryId { get; set; }
        public byte HistoryStatusId { get; set; }
        public string HistoryStatusCode { get; set; }
        public string HistoryLastModifiedBy { get; set; }
        public string HistoryChargeTypeDescription { get; set; }
        public string HistoryPaymentDetail { get; set; }
        public long? HistoryCreditAccount { get; set; }
        public string HistoryCurrency { get; set; }
        public decimal? HistoryAmountProduct { get; set; }
        public decimal HistoryAmountUnit { get; set; }
        public string HistoryFrequency { get; set; }
        public byte? HistoryRunDay { get; set; }
    }
}
