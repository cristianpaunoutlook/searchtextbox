﻿using Application.Helpers;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ProcessChargeTypeDTO
    {
        public int[] ChargeTypeIds { get; set; }
        public ManualProcessParams Filter { get; set; }
    }
}
