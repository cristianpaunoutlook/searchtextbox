﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeDropDownDTO
    {
        public int ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
    }
}
