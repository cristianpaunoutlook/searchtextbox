﻿using Domain;
using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ChargeDTO
    {
        public int ChargeId { get; set; }
        public string ChargeValue { get; set; }
        public int ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
        public ChargeTypeDTO ChargeType { get; set; }
        public byte StatusId { get; set; }
        public string StatusName { get; set; }

        public ObjectStatusDTO ObjectStatus { get; set; }
        public int? CustomerChargeTypeId { get; set; }
        public string CustomerChargeTypeDescription { get; set; }

        public CustomerChargeType CustomerChargeType { get; set; }
        public decimal? SpecialAmount { get; set; }
        public int? CurrencyId { get; set; }
        public string CurrencyCode { get; set; }
        public CurrencyDTO Currency { get; set; }
        public string DebitAccount { get; set; }
        public string CreditAccountShort { get; set; }
        public int? ChargedItems { get; set; }
        public string RejectReason { get; set; }
        public int? REF_ID_CCM { get; set; }
        public decimal ChargeTypeDefaultAmount { get; set; }
        public decimal? ChargeTypeAmountProduct { get; set; }
        public int ChargeTypeCurrencyId { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }

        public int ChargeHistoryId { get; set; }
        public string ChargeTypeHistoryCode { get; set; }
        public string HistoryStatusCode { get; set; }
        public string HistoryDebitAccount { get; set; }
        public string HistoryCreditAccount { get; set; }
        public string HistoryLastModifiedBy { get; set; }
        public string HistoryCurrencyCode { get; set; }
        public decimal? HistoryChargedItems { get; set; }
        public string HistoryCustomerChargeTypeDescription { get; set; }
        public decimal? HistorySpecialAmount { get; set; }
        public string HistoryChargeValue { get; set; }

        public decimal AmountToDisplay { get; set; }
        public string CurrencyToDisplay { get; set; }
        public decimal HistoryAmountToDisplay { get; set; }
        public string HistoryCurrencyToDisplay { get; set; }
        public string AccountState { get; set; }
        public string ChargeTypeGroupCd { get; set; }
        public string PaymentDetails { get; set; }
        public string HistoryPaymentDetails { get; set; }
    }
}
