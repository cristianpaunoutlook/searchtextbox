﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ParameterDTO
    {
        public string ParamName { get; set; }
        public string ParamValue { get; set; }
        public string Description { get; set; }
    }
}
