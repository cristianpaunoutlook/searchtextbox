﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class CustomerCommentsDTO
    {
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Comments { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
    }
}
