﻿using Application.Helpers;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ImportedPaymentsListDTO
    {
        public int SessionId { get; set; }
        public PagedList<ImportedPaymentsDTO> ImportedPayments { get; set; }
    }
}
