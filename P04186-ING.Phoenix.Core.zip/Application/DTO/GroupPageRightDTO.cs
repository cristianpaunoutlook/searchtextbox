﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class GroupPageRightDTO
    {
        public int PageId { get; set; }
        public int NextRightValue { get; set; }
    }
}
