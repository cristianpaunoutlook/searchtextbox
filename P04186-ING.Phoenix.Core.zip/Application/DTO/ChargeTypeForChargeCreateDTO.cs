﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeForChargeCreateDTO
    {
        public int ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
        public string CreditAccountShort { get; set; }
        public int CurrencyId { get; set; }
        public decimal DefaultAmount { get; set; }
        public decimal? AmountProduct { get; set; }
        public string ChargeTypeGroupCd { get; set; }
        public string PaymentDetails { get; set; }
        public int? FrequencyId { get; set; }

    }
}
