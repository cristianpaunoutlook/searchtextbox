﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class SessionInfoDTO
    {
        public int SessionId { get; set; }
        public Dictionary<int, string> ChargeTypeIds { get; set; }
        public int TotalCommissons { get; set; }
        public int PendingCommissons { get; set; }
        public int InProgressCommissons { get; set; }
        public int ProcessedCommissons { get; set; }
        public int UnprocessedCommissons { get; set; }
        public string UserId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
