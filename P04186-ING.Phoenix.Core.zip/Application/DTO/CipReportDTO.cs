﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class CipReportDTO
    {
        public int No { get; set; }
        public string GridId { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Branch { get; set; }
        public string Address { get; set; }
        public string JCode { get; set; }
        public string CUI { get; set; }
        public int Quantity { get; set; }
        public decimal Amount { get; set; }
        public decimal VAT { get; set; }
        public int DueDate { get; set; }
    }
}
