﻿using Domain;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ChargeHistoryDTO
    {
        public int ChargeId { get; set; }
        public int ChargeTypeId { get; set; }
        public virtual ChargeType ChargeType { get; set; }
        public byte StatusId { get; set; }
        public virtual ObjectStatus Status { get; set; }
        public int? CustomerChargeTypeId { get; set; }
        public virtual CustomerChargeType CustomerChargeType { get; set; }
        public decimal? SpecialAmount { get; set; }
        public int? CurrencyId { get; set; }
        public virtual Currency Currency { get; set; }
        public string DebitAccount { get; set; }
        public long CreditAccountShort { get; set; }
        public int? ChargedItems { get; set; }
        public string RejectReason { get; set; }
        public int? REF_ID_CCM { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
    }
}
