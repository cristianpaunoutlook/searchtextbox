﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeDTO
    {
        public int ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
        public int CurrId { get; set; }
        public CurrencyDTO Curr { get; set; }
        public decimal DefaultAmount { get; set; }
        public int FrequencyId { get; set; }
        public ProcessingFrequencyDTO Frequency { get; set; }
        public string PaymentDetail { get; set; }
        public byte StatusId { get; set; }
        public ObjectStatusDTO ObjectStatus { get; set; }
        public DateTime? LastRunDate { get; set; }
        public short? ForDepartment { get; set; }
        public int? CreditAccountId { get; set; }
        public string RejectReason { get; set; }
        public decimal? AmountProduct { get; set; }
        public long? CreditAccountShort { get; set; }
    }
}
