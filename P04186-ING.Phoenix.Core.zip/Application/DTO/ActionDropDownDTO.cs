﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ActionDropDownDTO
    {
        public int ActionId { get; set; }
        public string Name { get; set; }
    }
}
