﻿using Application.DTO;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ImportedPaymentsDTO
    {
        public ImportedPaymentsDTO()
        {

        }
        public int SessionId { get; set; }

        public int No { get; set; }

        public string Code { get; set; }

        public string PaymentDetails { get; set; }

        public string CustomerId { get; set; }

        public string DebitAccount { get; set; }

        public string CreditAccount { get; set; }
        public string Type { get; set; }

        public string Amount { get; set; }

        public string Currency { get; set; }

        public bool Imported { get; set; }

        public string Message { get; set; }

        public string ImportedBy { get; set; }

        public string DebitAccountStatus { get; set; }
    }
}
