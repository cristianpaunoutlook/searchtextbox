using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ObjectTypeDTO
    {
        public int ObjectTypeId { get; set; }

        public string ObjectTypeName { get; set; }

        public string ObjectTypeDescription { get; set; }

    }
}