﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ImportedPaymentsReportDTO
    {
        public int SessionId { get; set; }
        public int LineNumber { get; set; }
        public string AtlasId { get; set; }
        public string ChargeCode { get; set; }
        public string ChargedItems { get; set; }
        public string SpecialAmount { get; set; }
        public string CurrencyCode { get; set; }
        public string CustomerChargeType { get; set; }
        public string DebitAccount { get; set; }
        public string CreditAccount { get; set; }
        public string IsImported { get; set; }
        public string PaymentDetails { get; set; }
        public string Message { get; set; }
        public int? REF_ID_CCM { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public string LastModifyBy { get; set; }
        public string DebitAccountStatus { get; set; }

    }
}
