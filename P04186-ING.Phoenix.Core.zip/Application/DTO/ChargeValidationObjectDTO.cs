﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ChargeValidationObjectDTO
    {
        public string DebitAccount { get; set; }
        public long CreditAccountShort { get; set; }
        public string AtlasId { get; set; }
        public int ChargeTypeId { get; set; }
        public int CustomerChargeTypeId { get; set; }
        public int ValueId { get; set; }
        public int? CurrencyId { get; set; }
        public decimal? SpecialAmount { get; set; }
        public int? ChargedItems { get; set; }
    }
}
