﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class GroupsDTO
    {
        public IReadOnlyList<Domain.Group> Groups { get; set; }
    }
}
