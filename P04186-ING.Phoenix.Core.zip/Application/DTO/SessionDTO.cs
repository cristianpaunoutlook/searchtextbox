using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class SessionDTO
    {
        public int SessionId { get; set; }

        public DateTime RecordStamp { get; set; }

        public string GeneratedFileName { get; set; }

        public int ObjectTypeId { get; set; }

        public ObjectTypeDTO ObjectType { get; set; }

        public int Stare { get; set; }
    }
}