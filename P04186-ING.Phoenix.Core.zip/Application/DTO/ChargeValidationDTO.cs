﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ChargeValidationDTO
    {
        public int ChargeId { get; set; }
        public int Number { get; set; }
        public string ChargeTypeCode { get; set; }
        public int ChargeTypeId { get; set; }
        public string PaymentDetails { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string DebitAccount { get; set; }
        public long CreditAccount { get; set; }
        public string Type { get; set; }
        public decimal Amount { get; set; }
        public int? SessionId { get; set; }
        public string UserId { get; set; }
        public string Status { get; set; }
        public int StatusId { get; set; }
        public DateTime? ImportDate { get; set; }
        public string Currency { get; set; }
    }
}
