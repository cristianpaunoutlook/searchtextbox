﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class CustomerDTO
    {
        public int CustomerId { get; set; }

        public string AtlasID { get; set; }

        public string Comments { get; set; }

        public string UserID { get; set; }

        public DateTime? DateLastUpdate { get; set; }

        public byte StatusId { get; set; }
    }
}
