﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class CustomerChargesDTO
    {
        public string CustomerId { get; set; }

        public string Comments { get; set; }

        public IReadOnlyList<ChargeDTO> Charges { get; set; }
    }
}
