﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class CustomerListDTO : IEqualityComparer<CustomerListDTO>
    {
        public string CustomerId { get; set; }
        public string CUI { get; set; }
        public string Name { get; set; }
        public string CoreBanking { get; set; }
        public int StatusId { get; set; }
        public int ChargeTypeId { get; set; }

        public bool Equals([AllowNull] CustomerListDTO first, [AllowNull] CustomerListDTO second)
        {
            if (first is null || second is null)
                return false;

            return first.CustomerId == second.CustomerId && first.CUI == second.CUI && first.Name == second.Name;
        }

        public int GetHashCode([DisallowNull] CustomerListDTO cust)
        {
            if (cust is null) return 0;

            var custInfo = $"{cust.CustomerId}_{cust.CUI}_{cust.Name}";
            return custInfo.GetHashCode();
        }
    }
}
