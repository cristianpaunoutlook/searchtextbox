﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ProcessingFrequencyDTO
    {
        public int ProcessingFrequencyId { get; set; }
        public string ProcessingFrequencyName { get; set; }
    }
}
