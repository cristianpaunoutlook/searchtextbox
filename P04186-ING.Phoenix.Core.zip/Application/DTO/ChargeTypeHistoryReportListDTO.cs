﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeHistoryReportListDTO
    {
        public int ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
        public string PaymentDetail { get; set; }
        public long? CreditAccountShort { get; set; }
        public string CurrCode { get; set; }
        public decimal DefaultAmount { get; set; }
        public decimal? AmountProduct { get; set; }
        public string FrequencyName { get; set; }
        public byte? RunDay { get; set; }
        public byte StatusId { get; set; }
        public string StatusName { get; set; }
        public string LastModifiedBy { get; set; }
        public int ActionId { get; set; }
        public string ActionName { get; set; }
        public string RejectReason { get; set; }
        public DateTime? LastModifiedDate { get; set; }
    }
}
