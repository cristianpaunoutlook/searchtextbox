﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class GroupPagesRightsDTO
    {
        public int GroupId { get; set; }
        public int PageId { get; set; }
        public string PageCode { get; set; }
        public int RightValue { get; set; }
        public int NextRightValue { get; set; }
        public string PageName { get; set; }
        public string GroupName { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public int OrderNo { get; set; }
    }
}
