﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class ProcessResponseDTO
    {
        public int SessionId { get; set; }
        public string Response { get; set; }
    }
}
