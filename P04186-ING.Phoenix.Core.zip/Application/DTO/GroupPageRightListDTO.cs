﻿using System.Diagnostics.CodeAnalysis;

namespace Application.DTO
{
    [ExcludeFromCodeCoverage]
    public class GroupPageRightListDTO
    {
        public string GroupName { get; set; }
        public string AdName { get; set; }
        public string Page { get; set; }
        public string ViewExport { get; set; }
        public string AddEditDelete { get; set; }
        public string ApproveReject { get; set; }
    }
}
