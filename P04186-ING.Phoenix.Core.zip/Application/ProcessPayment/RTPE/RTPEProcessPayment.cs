﻿using Application.Commons.Constants;
using Application.DTO;
using Application.Interfaces;
using Application.Interfaces.ProcessPayment;
using Application.Notifications.ManualProcessingNotifications;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Threading.Tasks;

namespace Application.ProcessPayment.RTPE
{
    [ExcludeFromCodeCoverage]
    public class RTPEProcessPayment : IProcessPayment
    {
        private readonly HttpClient httpClient;

        public RTPEProcessPayment(HttpClient httpClient)
        {
            this.httpClient = httpClient;
        }
        public async Task<IEnumerable<SessionInfoDTO>> GetSessions()
        {
            var response = await httpClient.GetAsync(Constants.RTPE_SESSIONINFO);
            var res = await response.Content.ReadAsStringAsync();
            var sessions = JsonConvert.DeserializeObject<IEnumerable<SessionInfoDTO>>(res);
            return sessions;
        }

        public async Task<ProcessResponseDTO> RegularExport(int[] chargeIds)
        {
            var chargeList = $"{Constants.RTPE_PROCESS_PAYMENT}?chargetypes={string.Join(",", chargeIds)}";
            var response = await httpClient.GetAsync(chargeList);
            var res = await response.Content.ReadAsStringAsync();
            var session = JsonConvert.DeserializeObject<ProcessResponseDTO>(res);
            return session;
        }
    }
}
