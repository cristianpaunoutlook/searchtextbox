﻿using Domain;
using Persistence;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Application.SECSession
{
    public class Create
    {
        public class Command : IRequest
        {
            public string Session { get; set; }

            public DateTime SessionDate { get; set; } = DateTime.Now;

            public string UserId { get; set; }

            public string IP { get; set; }

            public string Workstation { get; set; }

            public int CountFailedLogin { get; set; } = 0;

        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"create sec.sesssion");

                var session = new SecSession()
                {
                    Session = request.Session,
                    UserId = request.UserId,
                    IP = request.IP,
                    Workstation = request.Workstation,
                    CountFailedLogin = request.CountFailedLogin,
                    SessionDate = request.SessionDate
                };

                context.SecSessions.Add(session);
                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Session was not created!");
            }
        }
    }
}
