﻿using Domain;
using Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.SECSession
{
    public class LastSession
    {
        public class Query : IRequest<SecSession>
        {
            public string CorporateKey { get; set; }
        }

        public class Handler : IRequestHandler<Query, SecSession>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<SecSession> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"get last sec.sesssion");
                return await context.SecSessions
                            .OrderByDescending(s => s.SessionDate)
                            .Where(s => s.UserId == request.CorporateKey)
                            .FirstOrDefaultAsync();
            }

        }
    }
}
