﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.Helpers
{
    [ExcludeFromCodeCoverage]
    public class PaymentsStatusReportParams : PaginationParams
    {
        public string SortColumn { get; set; }
        public string SortOrder { get; set; }
        public int SessionId { get; set; }
        public string CustomerId { get; set; }
        public string TRID { get; set; }
        public int ChargeTypeId { get; set; }
        public int Processed { get; set; }
        public string UserId { get; set; }
        public DateTime ExportStartDate { get; set; }
        public DateTime ExportEndDate { get; set; }
    }
}
