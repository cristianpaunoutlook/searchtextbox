﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Helpers
{
    [ExcludeFromCodeCoverage]
    public class SessionParams : PaginationParams
    {
        public int SessionId { get; set; }
        public string GeneratedFileName { get; set; }
    }
}
