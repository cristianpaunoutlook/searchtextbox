﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.Helpers
{
    [ExcludeFromCodeCoverage]
    public class ValidationParams : PaginationParams
    {
        public int ChargeTypeId { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public DateTime? ImportDate { get; set; }
        public int SessionId { get; set; }
        public int StatusId { get; set; }
        public string UserId { get; set; }
    }
}
