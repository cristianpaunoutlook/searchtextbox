﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Helpers
{
    [ExcludeFromCodeCoverage]
    public class CipReportParams : PaginationParams
    {
        public string CustomerId { get; set; }
        public string GridId { get; set; }
        public string CUI { get; set; }
        public string Branch { get; set; }
    }
}
