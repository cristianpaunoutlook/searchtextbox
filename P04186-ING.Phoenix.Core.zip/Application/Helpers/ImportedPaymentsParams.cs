﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.Helpers
{

    [ExcludeFromCodeCoverage]
    public class ImportedPaymentsParams : PaginationParams
    {
        public int SessionId { get; set; }
        public int Imported { get; set; }
    }
}
