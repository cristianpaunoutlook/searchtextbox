﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.Helpers
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeHistoryReportParams : PaginationParams
    {
        public string SortField { get; set; }
        public string SortOrder { get; set; }
        public int ChargeTypeId { get; set; }
        public int StatusId { get; set; }
        public string UserId { get; set; }
        public int ActionId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
