﻿using Application.Commons.Enums;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace Application.Helpers
{
    public static class Extensions
    {
        public static IQueryable<T> OrderByPropertyName<T>(this IQueryable<T> listToSort, string sortField, string sortOrder)
        {
            var param = Expression.Parameter(typeof(T), "p");
            var prop = Expression.Property(param, sortField);
            var exp = Expression.Lambda(prop, param);
            string method = sortOrder.ToLower() == "asc" ? nameof(SortOrder.OrderBy) : nameof(SortOrder.OrderByDescending);
            Type[] types = new Type[] { listToSort.ElementType, exp.Body.Type };
            var rs = Expression.Call(typeof(Queryable), method, types, listToSort.Expression, exp);
            return listToSort.Provider.CreateQuery<T>(rs);
        }

        public static DateTime LastDayOfMonth(this DateTime value)
        {
            var firstDayOfNextMonthMonth = new DateTime(value.Year, value.Month, 1);
            return firstDayOfNextMonthMonth.AddMonths(1).AddDays(-1);
        }

        public static string ReplaceAllIgnoreCase(this string seed, string[] chars, string replacementCharacter)
        {
            if (seed == null)
                return seed;
            return chars.Aggregate(seed, (str, cItem) => str.Replace(cItem, replacementCharacter, StringComparison.CurrentCultureIgnoreCase));
        }
    }
}
