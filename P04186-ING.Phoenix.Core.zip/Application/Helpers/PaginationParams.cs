﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Helpers
{
    public class PaginationParams
    {
        private const int MaxPageSize = 50;

        private int pageNumber = 1;

        public int PageNumber
        {
            get { return pageNumber; }
            set { pageNumber = (value <= 0) ? 1 : value; }
        }

        private int pageSize = 15;

        public int PageSize
        {
            get { return pageSize; }
            set { pageSize = (value > MaxPageSize) ? MaxPageSize : value; }
        }
    }
}
