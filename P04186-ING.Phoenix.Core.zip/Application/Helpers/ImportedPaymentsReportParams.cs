﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.Helpers
{
    [ExcludeFromCodeCoverage]
    public class ImportedPaymentsReportParams : PaginationParams
    {
        public string SessionId { get; set; }
        public string CustomerId { get; set; }
        public string ChargeCode { get; set; }
        public string UserId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public sbyte IsImported { get; set; }

    }
}
