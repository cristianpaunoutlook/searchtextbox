﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Helpers
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeParams : PaginationParams
    {
        public string SortField { get; set; }
        public string SortOrder { get; set; }
        public int? ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
        public int? FrequencyId { get; set; }
        public int? StatusId { get; set; }

    }
}
