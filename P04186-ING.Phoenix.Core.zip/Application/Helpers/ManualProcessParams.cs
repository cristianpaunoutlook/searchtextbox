﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.Helpers
{
    [ExcludeFromCodeCoverage]
    public class ManualProcessParams : PaginationParams
    {
        public int ChargeTypeId { get; set; }
        public DateTime? NextRunDay { get; set; }
        public string ChargeDescription { get; set; }
    }
}
