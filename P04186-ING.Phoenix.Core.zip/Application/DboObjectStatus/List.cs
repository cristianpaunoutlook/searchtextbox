﻿using Domain;
using Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using Application.Commons.Enums;

namespace Application.DboObjectStatus
{
    public class List
    {
        public class Query : IRequest<List<Domain.ObjectStatus>> { }

        public class Handler : IRequestHandler<Query, List<Domain.ObjectStatus>>
        {
            private readonly PhoenixContext _context;

            public Handler(PhoenixContext context)
            {
                _context = context;
            }
            public async Task<List<Domain.ObjectStatus>> Handle(Query request, CancellationToken cancellationToken) =>
                await _context.ObjectStatus.Where(o => o.ObjectStatusName == Commons.Enums.ObjectStatus.Active
                || o.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationAdd
                || o.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationModify
                || o.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationDelete).ToListAsync();
        }
    }
}
