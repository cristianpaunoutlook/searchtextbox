﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboObjectStatus
{
    public class WaitingApprovalList
    {
        public class Query : IRequest<List<Domain.ObjectStatus>> { }

        public class Handler : IRequestHandler<Query, List<Domain.ObjectStatus>>
        {
            private readonly PhoenixContext _context;

            public Handler(PhoenixContext context)
            {
                _context = context;
            }
            public async Task<List<Domain.ObjectStatus>> Handle(Query request, CancellationToken cancellationToken) =>
                await _context.ObjectStatus.Where(o => o.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationAdd
                || o.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationModify
                || o.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationDelete).ToListAsync();
        }
    }
}
