﻿using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboObjectStatus
{
    public class ListForChargeTypeHistoryReport
    {
        public class Query : IRequest<List<ObjectStatus>> { }

        public class Handler : IRequestHandler<Query, List<ObjectStatus>>
        {
            private readonly PhoenixContext context;

            public Handler(PhoenixContext context)
            {
                this.context = context;
            }
            public async Task<List<ObjectStatus>> Handle(Query request, CancellationToken cancellationToken) =>
                await context.ObjectStatus.Where(o => o.ObjectStatusName == Commons.Enums.ObjectStatus.Active
                || o.ObjectStatusName == Commons.Enums.ObjectStatus.Deleted
                || o.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationAdd
                || o.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationModify
                || o.ObjectStatusName == Commons.Enums.ObjectStatus.VerificationDelete
                || o.ObjectStatusName == Commons.Enums.ObjectStatus.RejectAdd).ToListAsync();
        }
    }
}
