﻿using Application.Interfaces;
using Application.Notifications.FileImportJobsNotifications;
using ImportFileInDb.Interfaces;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace Application.ImportFile
{
    public class ImportAnafFile
    {
        public class Command : IRequest { }

        public class Handler : FileImportJobsNotificationBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;
            private readonly IFileImport fileImport;
            private readonly IConfiguration configuration;

            public Handler(PhoenixContext context, ILogger<Handler> logger, IFileImport fileImport, IConfiguration configuration,
                IEmailSender emailSender) : base(configuration, emailSender)
            {
                this.context = context;
                this.logger = logger;
                this.fileImport = fileImport;
                this.configuration = configuration;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation("Start import ANAF file");

                var anafFolder = configuration.GetSection("AnafFileLocation").Value;
                DirectoryInfo directory = new DirectoryInfo(anafFolder);
                FileInfo file = null;

                try
                {
                    file = directory.GetFiles().Length > 0 ? directory.GetFiles()[0] : throw new Exception("There are no files to import at location");
                    var backupFolder = configuration.GetSection("AnafFileLocationBackup").Value;
                    if (!string.IsNullOrEmpty(backupFolder))
                        File.Copy(file.FullName, backupFolder + GetNewFileName(file.Name));

                    await context.StartImportAnafFile(file.Name);

                    fileImport.ImportFile(file.FullName, "dbo.IOL_ANAF_REP", hasHeader: true, mapping: GetMapping(), 
                        delimitatorForCsv: "|", filterData: FilterData, currentCulture: "ro-RO");

                    await context.StopImportAnafFile(file.Name, false);
                }
                catch (Exception ex)
                {
                    await SendAnafErrorEmailAsync(file.Name);
                    await context.StopImportAnafFile(file.Name, true);
                    throw new Exception(ex.Message);
                }
                finally
                {
                    File.Delete(anafFolder + file.Name);
                }

                return Unit.Value;
            }

            private string GetNewFileName(string fileName)
            {
                string name = Path.GetFileNameWithoutExtension(fileName);
                string extension = Path.GetExtension(fileName);
                return $"{name}__{DateTime.Now:yyyyMMdd_HHmmss_ffff}{extension}";
            }

            private Dictionary<string, string> GetMapping()
            {
                return new Dictionary<string, string>()
                {
                    {"Customer Status", "CustomerStatus" },
                    {"Customer Name", "CustomerName" },
                    {"User FirstName", "UserFirstName" },
                    {"User LastName", "UserLastName" },
                    {"UserToCustomer Status", "UserToCustomerStatus" },
                    {"User Status", "UserStatus" },
                    {"User Registration Date", "UserRegistrationDate" },
                    {"User Last Login Date", "UserLastLoginDate" },
                    {"IBAN Account for GBS accounts", "IBANAccount" },
                    {"Username from IBP", "UsernameFromIBP" },
                    {"Account Origin", "AccountOrigin" }
                };
            }

            private DataTable FilterData(DataTable dataTable)
            {
                DataTable tblFiltered = dataTable.AsEnumerable()
                    .Where(row => row.Field<String>("Account Origin").ToUpper() == "ATL"
                        && row.Field<String>("Customer Status").ToUpper() == "ACTIVE"
                        && row.Field<String>("UserToCustomer Status").ToUpper() == "ACTIVE"
                        && row.Field<String>("User Status").ToUpper() == "ACTIVE"
                        && !string.IsNullOrEmpty(row.Field<String>("IBAN Account for GBS accounts")))
                    .CopyToDataTable();

                return tblFiltered;
            }
        }
    }
}
