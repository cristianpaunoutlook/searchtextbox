﻿using System.Collections.Generic;

namespace Application.Interfaces.Export
{
    public interface IExportAsExcel<T>
    {
        byte[] Export(string title, IList<T> listToExport);
    }
}