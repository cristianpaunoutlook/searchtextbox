﻿using Application.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application.Interfaces.ProcessPayment
{
    public interface IProcessPayment
    {
        Task<IEnumerable<SessionInfoDTO>> GetSessions();
        Task<ProcessResponseDTO> RegularExport(int[] chargeIds);
    }
}
