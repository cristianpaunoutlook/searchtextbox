﻿namespace Application.Interfaces
{
    public interface IUserFromJwt
    {
        string GetUserName();
    }
}
