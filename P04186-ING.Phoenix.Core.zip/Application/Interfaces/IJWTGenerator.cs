﻿using Application.Security;
using System;
using System.Collections.Generic;

namespace Application.Interfaces
{
    public interface IJWTGenerator
    {
        string CreateToken(List<KeyValue> claims, string jwtEncryptKey, int sessionExpiration);
        string RefreshToken(string jwtEncryptKey, int sessionExpiration, string jwtHeaderKey, List<KeyValue> rights);
        DateTime GetExpirationDate(string jwtEncryptKey, string jwtHeaderKey);
        string GetSessionId(string jwtEncryptKey, string jwtHeaderKey);
    }
}
