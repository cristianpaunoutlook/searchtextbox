﻿using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboMailList
{
    public class List
    {
        public class Query : IRequest<List<MailList>> { }

        public class Handler : IRequestHandler<Query, List<MailList>>
        {
            private readonly PhoenixContext context;

            public Handler(PhoenixContext context)
            {
                this.context = context;
            }

            public async Task<List<MailList>> Handle(Query request, CancellationToken cancellationToken)
            {
                return await context.MailList                 
                    .OrderBy(c => c.DisplayName)                  
                    .ToListAsync();
            }
        }
    }
}
