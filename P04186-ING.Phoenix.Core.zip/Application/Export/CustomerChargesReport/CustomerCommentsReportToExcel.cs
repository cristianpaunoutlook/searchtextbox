﻿using Application.Errors;
using Application.Interfaces.Export;
using Application.Reports.CustomerComments;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.CustomerChargesReport
{
    [ExcludeFromCodeCoverage]
    public class CustomerCommentsReportToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public CustomerCommentsFilter Filter { get; set; }
        }

        public class Handler : ExportCustomerCommentsBase, IRequestHandler<Query, byte[]>
        {
            private readonly IExportAsExcel<CustomerCommentsReportData> export;
            private readonly ILogger<Handler> logger;
            public Handler(PhoenixContext context, ILogger<Handler> logger, IMapper mapper, IExportAsExcel<CustomerCommentsReportData> export) : base(context, mapper, logger)
            {
                this.export = export;
                this.logger = logger;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                if (request.Filter.CustomerId == null && request.Filter.CustomerName == null && request.Filter.LastModifiedBy == "All" && request.Filter.LastModifiedDate == null)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "At least one filter value should be provided for export!");
                }
                logger.LogInformation("Export customer comments list as excel file!");
                var customerComments = await GetDataToExport(request.Filter);
                if (customerComments == null || customerComments.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched customer comments does not exist in the database!");
                }

                return export.Export(request.Title, customerComments);
            }
        }
    }
}

