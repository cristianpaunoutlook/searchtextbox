﻿using Application.DTO;
using Application.Reports.CustomerComments;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace Application.Export.CustomerChargesReport
{
    [ExcludeFromCodeCoverage]
    public class ExportCustomerCommentsBase : CustomerCommentsReportBase
    {
        private readonly PhoenixContext _context;
        private readonly IMapper _mapper;
        private readonly ILogger _logger;
        public ExportCustomerCommentsBase(PhoenixContext context, IMapper mapper, ILogger logger)
        {
            _context = context;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<List<CustomerCommentsReportData>> GetDataToExport(CustomerCommentsFilter filter)
        {
            _logger.LogInformation("Getting customer comments report data for export!");
            IQueryable<CustomerCommentsDTO> customerComments = CustomerCommentsList(_context, filter);
            var customerCommentsToExport = await customerComments.ToListAsync();
            return _mapper.Map<List<CustomerCommentsDTO>, List<CustomerCommentsReportData>>(customerCommentsToExport);
        }
    }
}
