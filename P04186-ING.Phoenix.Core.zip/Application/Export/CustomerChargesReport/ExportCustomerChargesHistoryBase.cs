﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;
using Application.DTO;
using Application.Reports.CustomerCharges;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Persistence;

namespace Application.Export.CustomerChargesReport
{
    [ExcludeFromCodeCoverage]
    public class ExportCustomerChargesHistoryBase : CustomerChargesReportBase
    {
        private readonly PhoenixContext _context;
        private readonly IMapper _mapper;

        public ExportCustomerChargesHistoryBase(PhoenixContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<CustomerChargesHistoryReportData>> GetDataToExport(CustomerChargesFilter filter)
        {
            var customerChargesHistory = await CustomerChargesList(_context, filter).ToListAsync();
            return _mapper.Map<List<ChargeReportDTO>, List<CustomerChargesHistoryReportData>>(customerChargesHistory);
        }
    }
}
