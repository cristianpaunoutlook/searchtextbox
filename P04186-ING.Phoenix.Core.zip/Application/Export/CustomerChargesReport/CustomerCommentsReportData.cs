﻿using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace Application.Export.CustomerChargesReport
{
    [ExcludeFromCodeCoverage]
    public class CustomerCommentsReportData
    {
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Comments { get; set; }
        [Description("Last modification by")]
        public string LastModifiedBy { get; set; }
        [Description("Last modification date")]
        public DateTime? LastModifiedDate { get; set; }
    }
}
