﻿using Application.Errors;
using Application.Interfaces.Export;
using Application.Reports.CustomerCharges;
using AutoMapper;
using MediatR;
using Persistence;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.CustomerChargesReport
{
    [ExcludeFromCodeCoverage]
    public class CustomerChargesHistoryToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public CustomerChargesFilter Filter { get; set; }
        }

        public class Handler : ExportCustomerChargesHistoryBase, IRequestHandler<Query, byte[]>
        {
            private readonly IExportAsExcel<CustomerChargesHistoryReportData> export;
            public Handler(PhoenixContext context, IMapper mapper, IExportAsExcel<CustomerChargesHistoryReportData> export) : base(context, mapper)
            {
                this.export = export;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var customerChargesHistory = await GetDataToExport(request.Filter);
                if (customerChargesHistory == null || customerChargesHistory.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Customer Charges History is not available for applied filter!");
                }

                return export.Export(request.Title, customerChargesHistory);
            }
        }
    }
}
