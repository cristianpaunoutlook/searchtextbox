﻿using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace Application.Export.CustomerChargesReport
{
    [ExcludeFromCodeCoverage]
    public class CustomerChargesHistoryReportData
    {
        [Description("CustomerId")]
        public string CustomerId { get; set; }
        [Description("Customer Name")]
        public string CustomerName { get; set; }
        [Description("Charge Code")]
        public string ChargeTypeCode { get; set; }
        [Description("Value")]
        public string ChargeValue { get; set; }
        [Description("Type")]
        public string CustomerChargeTypeDescription { get; set; }
        [Description("Amount")]
        public decimal AmountToDisplay { get; set; }
        [Description("Currency")]
        public string CurrencyToDisplay { get; set; }
        [Description("Debit Account")]
        public string DebitAccount { get; set; }
        [Description("Credit Account")]
        public long CreditAccountShort { get; set; }
        [Description("ChargedItems")]
        public int? ChargedItems { get; set; }
        [Description("Status")]
        public string StatusName { get; set; }
        [Description("User")]
        public string LastModifiedBy { get; set; }
        [Description("Action")]
        public string ActionName { get; set; }
        [Description("Reject Reason")]
        public string RejectReason { get; set; }
        [Description("Date")]
        public DateTime? LastModifiedDate { get; set; }
    }
}
