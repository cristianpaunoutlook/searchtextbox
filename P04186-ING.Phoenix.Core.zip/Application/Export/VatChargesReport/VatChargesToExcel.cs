﻿using Application.Errors;
using Application.Interfaces.Export;
using Application.Reports.VatCharges;
using AutoMapper;
using MediatR;
using Persistence;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.VatChargesReport
{
    [ExcludeFromCodeCoverage]
    public class VatChargesToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public VatChargesFilter Filter { get; set; }
        }

        public class Handler : ExportVatChargesBase, IRequestHandler<Query, byte[]>
        {
            private readonly IExportAsExcel<VatChargesReportData> export;
            public Handler(PhoenixContext context, IMapper mapper, IExportAsExcel<VatChargesReportData> export) : base(context, mapper)
            {
                this.export = export;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var vatCharges = await GetDataToExport(request.Filter);
                if (vatCharges == null || vatCharges.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Vat charges are not available for applied filter!");
                }

                return export.Export(request.Title, vatCharges);
            }
        }
    }
}
