﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;
using Application.Reports.VatCharges;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Persistence;

namespace Application.Export.VatChargesReport
{
    [ExcludeFromCodeCoverage]
    public class ExportVatChargesBase : VatChargesReportBase
    {
        private readonly PhoenixContext _context;
        private readonly IMapper _mapper;

        public ExportVatChargesBase(PhoenixContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<VatChargesReportData>> GetDataToExport(VatChargesFilter filter)
        {
            var vatCharges = await VatChargesList(_context, filter).ToListAsync();
            return _mapper.Map<List<VatChargeReportDTO>, List<VatChargesReportData>>(vatCharges);
        }
    }
}
