﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.Export.VatChargesReport
{
    [ExcludeFromCodeCoverage]
    public class VatChargesReportData
    {
        [Description("GridID")]
        public string GridId { get; set; }
        [Description("CustomerID")]
        public string CustomerAtlasId { get; set; }
        [Description("Customer Name")]
        public string CustomerName { get; set; }
        [Description("Charge")]
        public string ChargeTypeCode { get; set; }
        [Description("Address")]
        public string Address { get; set; }
        [Description("Registration Number")]
        public string RegistrationNumber { get; set; }
        [Description("Fiscal Number")]
        public string CUI { get; set; }
        [Description("Amount with VAT")]
        public decimal AmountDebited { get; set; }
        [Description("VAT percentage")]
        public string VATValue { get; set; }
        [Description("Due Date")]
        public int DueDate { get; set; }
    }
}
