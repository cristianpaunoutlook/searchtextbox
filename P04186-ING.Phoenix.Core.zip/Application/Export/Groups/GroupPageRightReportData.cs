﻿using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace Application.Export.Groups
{
    [ExcludeFromCodeCoverage]
    public class GroupPageRightReportData
    {
        [Description("Group Name")]
        public string GroupName { get; set; }
        [Description("AD Name")]
        public string AdName { get; set; }
        [Description("Page")]
        public string Page { get; set; }
        [Description("View/Export")]
        public string ViewExport { get; set; }
        [Description("Add/Edit/Delete")]
        public string AddEditDelete { get; set; }
        [Description("Approve/Reject")]
        public string ApproveReject { get; set; }
    }
}
