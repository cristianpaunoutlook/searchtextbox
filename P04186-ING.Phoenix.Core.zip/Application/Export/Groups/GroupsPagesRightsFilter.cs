﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Export.Groups
{
    [ExcludeFromCodeCoverage]
    public class GroupsPagesRightsFilter
    {
        public string Pattern { get; set; }
    }
}
