﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Application.DTO;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Persistence;

namespace Application.Export.Groups
{
    [ExcludeFromCodeCoverage]
    public class ExportGroupsPagesRightsBase : GroupPageRightListBase
    {
        private readonly PhoenixContext _context;
        private readonly IMapper _mapper;

        public ExportGroupsPagesRightsBase(PhoenixContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<GroupPageRightReportData>> GetDataToExport()
        {
            var groupsPagesRights = GroupPageRightList(_context);
            var groupsPagesRightsToExport = await groupsPagesRights.ToListAsync();
            return _mapper.Map<List<GroupPageRightListDTO>, List<GroupPageRightReportData>>(groupsPagesRightsToExport);
        }
    }
}
