﻿using Application.Commons.Enums;
using Application.DTO;
using Persistence;
using System.Linq;

namespace Application.Export.Groups
{
    public class GroupPageRightListBase
    {
        public IQueryable<GroupPageRightListDTO> GroupPageRightList(PhoenixContext context)
        {
            var groupsRightsPages = from gpr in context.GroupsPagesRights
                                    .Where (p => p.Right.Code != (GroupRight.NoRight).ToString())
                                    select new GroupPageRightListDTO
                                    {
                                        GroupName = gpr.Group.Name,
                                        AdName = gpr.Group.ADName,
                                        Page = gpr.Page.Name,
                                        ViewExport = gpr.Right.Value >= (int)GroupRight.ViewExport ? "X" : "",
                                        AddEditDelete = gpr.Right.Value >= (int)GroupRight.AddEditDelete ? "X" : "",
                                        ApproveReject = gpr.Right.Value >= (int)GroupRight.ApproveReject ? "X" : "",
                                    };
            return groupsRightsPages;
        }
    }
}
