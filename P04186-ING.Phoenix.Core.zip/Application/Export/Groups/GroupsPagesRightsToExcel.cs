﻿using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.Errors;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Configuration;
using Persistence;

namespace Application.Export.Groups
{
    [ExcludeFromCodeCoverage]
    public class GroupsPagesRightsToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
        }
        public class Handler : ExportGroupsPagesRightsBase, IRequestHandler<Query, byte[]>
        {
            private readonly IExportAsExcel<GroupPageRightReportData> export;

            public Handler(PhoenixContext context, IMapper mapper, IExportAsExcel<GroupPageRightReportData> export) : base(context, mapper)
            {
                this.export = export;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var groupsPagesRights = await GetDataToExport();
                if (groupsPagesRights == null || groupsPagesRights.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, $"Groups, pages and rights are not available!");
                }

                return export.Export(request.Title, groupsPagesRights);
            }
        }
    }
}
