﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.Export.CIPReport
{
    [ExcludeFromCodeCoverage]
    public class CIPReportData
    {
        [Description("GRID ID")]
        public string GridId { get; set; }
        public string CustomerId { get; set; }
        [Description("Customer Name")]
        public string CustomerName { get; set; }
        public string Address { get; set; }
        [Description("Registration Number")]
        public string JCode { get; set; }
        [Description("Fiscal Number")]
        public string CUI { get; set; }
        public string Branch { get; set; }
        public int Quantity { get; set; }
        [Description("Amount / Unit no VAT")]
        public decimal Amount { get; set; }
        [Description("VAT Percentage ")]
        public decimal VAT { get; set; }
        [Description("Due Date")]
        public int DueDate { get; set; }
    }
}
