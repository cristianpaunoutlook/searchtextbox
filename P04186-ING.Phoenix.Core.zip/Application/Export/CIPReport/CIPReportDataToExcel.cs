﻿using Application.Commons.Constants;
using Application.DboCharge;
using Application.DTO;
using Application.Helpers;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.CIPReport
{
    [ExcludeFromCodeCoverage]
    public class CIPReportDataToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public CipReportParams Filter { get; set; }
        }
        public class Handler : ChargeBase, IRequestHandler<Query, byte[]>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly IExportAsExcel<CIPReportData> export;

            public Handler(PhoenixContext context, IMapper mapper, IExportAsExcel<CIPReportData> export)
            {
                this.context = context;
                this.mapper = mapper;
                this.export = export;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var VATParam = await context.Parameters.FirstOrDefaultAsync(p => p.ParamName == Constants.VAT_PARAMETER_NAME);
                if (VATParam == null)
                    throw new Exception("No Parameter defined for VAT value");
                var listToExport = await CipReportList(context, request.Filter, VATParam.ParamValue).ToListAsync();
                var cipDataReport = mapper.Map<List<CipReportDTO>, List<CIPReportData>>(listToExport);
                return export.Export(request.Title, cipDataReport);
            }
        }
    }
}
