﻿using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace Application.Export.PaymentStatusReport
{
    [ExcludeFromCodeCoverage]
    public class PaymentsStatusReportData
    {
        public int No { get; set; }
        
        [Description("Session")]
        public int SessionId { get; set; }

        [Description("SDREF")]
        public string PaymentId { get; set; }

        [Description("TRID")]
        public string Trid { get; set; }
        public string Status { get; set; }
        public string CustomerId { get; set; }

        [Description("ChargeCode")]
        public string ChargeTypeCode { get; set; }
        public decimal Amount { get; set; }
        [Description("Currency")]
        public string CurrencyCode { get; set; }
        [Description("DebitAccount")]
        public string IBANDebitAccount { get; set; }
        public string CreditAccount { get; set; }
        [Description("PaymentDetails")]
        public string PaymentDetails { get; set; }
        [Description("User")]
        public string UserId { get; set; }
        [Description("Date")]
        public DateTime RecordStamp { get; set; }
        [Description("RefID_CCM")]
        public int? REF_ID_CCM { get; set; }
        public string RejectReason { get; set; }
        [Description("NRReprocesari")]
        public int? RepNo { get; set; }
    }
}
