﻿using Application.Errors;
using Application.Helpers;
using AutoMapper;
using Domain;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Application.Export.PaymentStatusReport
{
    [ExcludeFromCodeCoverage]
    public class PaymentsStatusReportBase
    {
        protected async Task<List<PaymentsStatusReport>> GetPaymentsStatusList(PhoenixContext context, PaymentsStatusReportParams filterParams)
        {
            var paymentsStatus = await context.PaymentsStatusReport(filterParams.PageNumber, filterParams.PageSize, filterParams.SortColumn,
                                filterParams.SortOrder, filterParams.SessionId, filterParams.CustomerId, filterParams.TRID, filterParams.ChargeTypeId,
                                filterParams.Processed, filterParams.UserId, filterParams.ExportStartDate, filterParams.ExportEndDate);

            if (paymentsStatus.Count == 0)
            {
                throw new RestException(HttpStatusCode.BadRequest, "There are no records corresponding to your search!");
            }

            return paymentsStatus;
        }

        protected async Task<List<PaymentsStatusReportData>> ListForExport(PhoenixContext context, PaymentsStatusReportParams filterParams, IMapper mapper)
        {
            var paymentsList = await GetPaymentsStatusList(context, filterParams);
            var listToExport = mapper.Map<List<PaymentsStatusReport>, List<PaymentsStatusReportData>>(paymentsList);
            return listToExport.Select((payment, index) => { payment.No = index + 1; return payment; }).ToList();
        }
    }
}
