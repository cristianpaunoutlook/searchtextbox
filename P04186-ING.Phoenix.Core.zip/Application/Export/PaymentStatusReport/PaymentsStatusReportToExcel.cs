﻿using Application.Helpers;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Persistence;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.PaymentStatusReport
{
    [ExcludeFromCodeCoverage]
    public class PaymentsStatusReportToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public PaymentsStatusReportParams Filter { get; set; }
        }
        public class Handler : PaymentsStatusReportBase, IRequestHandler<Query, byte[]>
        {
            private readonly PhoenixContext context;
            private readonly IMapper mapper;
            private readonly IExportAsExcel<PaymentsStatusReportData> export;

            public Handler(PhoenixContext context, IMapper mapper, IExportAsExcel<PaymentsStatusReportData> export)
            {
                this.context = context;
                this.mapper = mapper;
                this.export = export;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var listToExport = await ListForExport(context, request.Filter, mapper);
                return export.Export(request.Title, listToExport);
            }
        }
    }
}
