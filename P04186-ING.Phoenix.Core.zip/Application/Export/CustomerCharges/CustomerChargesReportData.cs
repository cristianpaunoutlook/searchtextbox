﻿using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace Application.Export.CustomerCharges
{
    [ExcludeFromCodeCoverage]
    public class CustomerChargesReportData
    {

        public int ChargeId { get; set; }
        public string CUI { get; set; }
        public string Name { get; set; }
        [Description("CustomerId")]
        public string AtlasId { get; set; }
        public int ChargeTypeId { get; set; }
        [Description("ChargeCode")]
        public string ChargeTypeCode { get; set; }
        [Description("Amount")]
        public decimal Amount { get; set; }
        public string DebitAccount { get; set; }
        public int? ChargedItems { get; set; }
        [Description("Status")]
        public string Status { get; set; }
        [Description("CustomerChargeType")]
        public string CustomerChargeType { get; set; }
        [Description("Currency")]
        public string Currency { get; set; }
        public string CreditAccountShort { get; set; }
        public string HasVAT { get; set; }
    }
}
