﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Export.CustomerCharges
{
    [ExcludeFromCodeCoverage]
    public class CustomerChargesFilter
    {
        public string CustomerID { get; set; }
        public string CUI { get; set; }
        public string Name { get; set; }
        public int ChargeTypeId { get; set; }
        public int StatusId { get; set; }
        public string ChargeTypeCode { get; set; }
        public bool IsForChargeNotification { get; set; } = false;
    }
}
