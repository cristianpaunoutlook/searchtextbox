﻿using Application.Errors;
using Application.Interfaces.Export;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.CustomerCharges
{
    [ExcludeFromCodeCoverage]
    public class CustomerChargesToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public CustomerChargesFilter Filter { get; set; }
        }
        public class Handler : ExportCustomerChargesBase, IRequestHandler<Query, byte[]>
        {
            private readonly IExportAsExcel<CustomerChargesReportData> export;
            private readonly ILogger<Handler> logger;
            public Handler(PhoenixContext context, ILogger<Handler> logger, IExportAsExcel<CustomerChargesReportData> export) : base(context, logger)
            {
                this.export = export;
                this.logger = logger;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation("Export customer charges list as excel file!");
                var customerCharges = await GetDataToExport(request.Filter);
                var isListEmpty = customerCharges == null || customerCharges.Count == 0;
                if (isListEmpty && request.Filter.IsForChargeNotification == false)
                    throw new RestException(HttpStatusCode.BadRequest, "The searched customer charges does not exist in the database!");
                return  isListEmpty ? null : export.Export(request.Title, customerCharges);
            }
        }
    }
}
