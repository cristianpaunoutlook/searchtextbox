﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Commons.Enums;
using Castle.Core.Internal;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;

namespace Application.Export.CustomerCharges
{
    public class ExportCustomerChargesBase
    {
        private readonly PhoenixContext context;
        private readonly ILogger logger;

        public ExportCustomerChargesBase(PhoenixContext context, ILogger logger)
        {
            this.context = context;
            this.logger = logger;
        }

        public async Task<List<CustomerChargesReportData>> GetDataToExport(CustomerChargesFilter filter)
        {
            logger.LogInformation($"Export Filter values:{"CustomerId (GBSID/CIF)=" + filter.CustomerID + " " + "CUI=" + filter.CUI + " " + "Name=" + filter.Name + " " + "Charge Code=" + filter.ChargeTypeCode + " " + "Charge StatusId =" + filter.StatusId  }");
            var customerCharges = from c in context.Charges.Where(c => c.Status.ObjectStatusName == ObjectStatus.Active ||
                          c.Status.ObjectStatusName == ObjectStatus.VerificationAdd)
                                  from ch in context.ChargesHistory.Where(o => c.ChargeId == o.ChargeId)
                                                                     .OrderByDescending(h => h.ChargeHistoryId)
                                                                     .Take(1)
                                                                     .DefaultIfEmpty()
                                  from acc in context.Accounts.Where(acc => acc.CustomerId == c.AtlasId)
                                  select new CustomerChargesReportData
                                  {
                                      ChargeId = c.ChargeId,
                                      AtlasId = c.AtlasId,
                                      ChargeTypeId = c.ChargeTypeId,
                                      ChargeTypeCode = c.ChargeType.ChargeTypeCode,
                                      Amount = c.SpecialAmount != null ? c.SpecialAmount.Value : c.CustomerChargeTypeId == (int)CustomerChargeType.PerProduct ?
                                                                         c.ChargeType.AmountProduct.Value : c.ChargeType.DefaultAmount,
                                      DebitAccount = c.ChargeAccountState.Status == (int)ChargeAccountStatus.AccountActive ||
                                                    c.ChargeAccountState.Status == (int)ChargeAccountStatus.CreditAccountInactive ? c.DebitAccount : "",
                                      ChargedItems = c.ChargedItems,
                                      Status = ch.Status.ObjectStatusName,
                                      CustomerChargeType = c.CustomerChargeType.Description,
                                      Currency = c.SpecialAmount != null ? c.Currency.CurrencyCode : c.ChargeType.Curr.CurrencyCode,
                                      CreditAccountShort = c.CreditAccountShort.ToString(),
                                      CUI = acc.CUI,
                                      Name = acc.CustomerName,
                                      HasVAT = c.ChargeType.HasVAT ? "Yes" : "No"
                                  };
            if (!filter.CustomerID.IsNullOrEmpty())
            {
                customerCharges = customerCharges.Where(c => c.AtlasId.Contains(filter.CustomerID));
            }

            if (!filter.CUI.IsNullOrEmpty())
            {
                customerCharges = customerCharges.Where(c => c.CUI.Contains(filter.CUI));
            }

            if (!filter.Name.IsNullOrEmpty())
            {
                customerCharges = customerCharges.Where(c => c.Name.Contains(filter.Name));
            }

            if (filter.ChargeTypeId != -1)
            {
                customerCharges = customerCharges.Where(c => c.ChargeTypeId == filter.ChargeTypeId);
            }

            if (filter.StatusId != -1)
            {
                var chargeHistoryStatus = await context.ObjectStatus.FindAsync(Convert.ToByte(filter.StatusId));
                customerCharges = customerCharges.Where(c => c.Status == chargeHistoryStatus.ObjectStatusName);
            }

            if (filter.IsForChargeNotification)
            {
                customerCharges = customerCharges.Where(c => c.Status == ObjectStatus.VerificationAdd ||
                    c.Status == ObjectStatus.VerificationModify || c.Status == ObjectStatus.VerificationDelete);
            }

            return await customerCharges.Distinct().OrderBy(c => c.AtlasId).ToListAsync();
        }
    }
}
