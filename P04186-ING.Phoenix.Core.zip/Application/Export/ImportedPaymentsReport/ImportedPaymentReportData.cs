﻿using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace Application.Export.ImportedPaymentsReport
{
    [ExcludeFromCodeCoverage]
    public class ImportedPaymentReportData
    {
        [Description("SessionID")]
        public int SessionId { get; set; }

        [Description("Line No")]
        public int LineNumber { get; set; }

        [Description("CustomerId")]
        public string AtlasId { get; set; }

        [Description("Charge Code")]
        public string ChargeCode { get; set; }

        [Description("ChargedItems")]
        public string ChargedItems { get; set; }

        [Description("Amount")]
        public string SpecialAmount { get; set; }

        [Description("Currency")]
        public string CurrencyCode { get; set; }

        [Description("Type")]
        public string CustomerChargeType { get; set; }

        [Description("Debit Account")]
        public string DebitAccount { get; set; }

        [Description("Credit Account")]
        public string CreditAccount { get; set; }

        [Description("IsImported")]
        public string IsImported { get; set; }

        [Description("DbtAcc Status")]
        public string DebitAccountStatus { get; set; }

        [Description("PaymentDetails")]
        public string PaymentDetails { get; set; }

        [Description("Message")]
        public string Message { get; set; }

        [Description("REF_ID_CCM")]
        public int? REF_ID_CCM { get; set; }

        [Description("User")]
        public string LastModifyBy { get; set; }

        [Description("Date")]
        public DateTime? LastModifiedDate { get; set; }
    }
}
