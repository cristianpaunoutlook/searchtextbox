﻿using Application.DboImportedPayments;
using Application.DTO;
using Application.Errors;
using Application.Helpers;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.ImportedPaymentsReport
{
    [ExcludeFromCodeCoverage]
    public class ImportedPaymentsReportToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public ImportedPaymentsReportParams Filter { get; set; }
        }
        public class Handler : ImportedPaymentsListBase, IRequestHandler<Query, byte[]>
        {
            private readonly PhoenixContext context;
            private readonly IExportAsExcel<ImportedPaymentReportData> export;
            private readonly IMapper mapper;

            public Handler(PhoenixContext context, IMapper mapper, IExportAsExcel<ImportedPaymentReportData> export)
            {
                this.context = context;
                this.export = export;
                this.mapper = mapper;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var filter = mapper.Map<ImportedPaymentsReportFilter>(request.Filter);
                var importedPayments = ImportedPaymentsReportList(context, filter);
                var importedPaymentsToExport = await importedPayments.ToListAsync();
                var result = mapper.Map<List<ImportedPaymentsReportDTO>, List<ImportedPaymentReportData>>(importedPaymentsToExport);
                if (result == null || result.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched imported payments does not exist in the database!");
                }

                return export.Export(request.Title, result);
            }
        }
    }
}
