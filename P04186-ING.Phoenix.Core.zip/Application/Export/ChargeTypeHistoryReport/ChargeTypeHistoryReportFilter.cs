﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Application.Export.ChargeTypeHistoryReport
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeHistoryReportFilter
    {
        public int ChargeTypeId { get; set; }
        public int StatusId { get; set; }
        public string UserId { get; set; }
        public int ActionId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
