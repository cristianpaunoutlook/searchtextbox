﻿using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace Application.Export.ChargeTypeHistoryReport
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeHistoryReportData
    {
        [Description("ChargeCode")]
        public string ChargeTypeCode { get; set; }

        [Description("Description")]
        public string ChargeTypeDescription { get; set; }

        [Description("PaymentDetails")]
        public string PaymentDetail { get; set; }

        [Description("Credit Account")]
        public long? CreditAccountShort { get; set; }

        [Description("Currency")]
        public string CurrCode { get; set; }

        [Description("Amount/ Transaction")]
        public decimal DefaultAmount { get; set; }

        [Description("Amount/ Product")]
        public decimal? AmountProduct { get; set; }

        [Description("Frequency")]
        public string FrequencyName { get; set; }

        [Description("Run Day")]
        public byte? RunDay { get; set; }

        [Description("Status")]
        public string StatusName { get; set; }

        [Description("User")]
        public string LastModifiedBy { get; set; }

        [Description("Action")]
        public string ActionName { get; set; }

        [Description("RejectReason")]
        public string RejectReason { get; set; }

        [Description("Date")]
        public DateTime? LastModifiedDate { get; set; }
    }
}
