﻿using Application.Errors;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Persistence;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.ChargeTypeHistoryReport
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeHistoryReportToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public ChargeTypeHistoryReportFilter Filter { get; set; }
        }
        public class Handler : ExportChargeTypeHistoryReportBase, IRequestHandler<Query, byte[]>
        {
            private readonly IExportAsExcel<ChargeTypeHistoryReportData> export;

            public Handler(PhoenixContext context, IMapper mapper, IExportAsExcel<ChargeTypeHistoryReportData> export) : base(context, mapper)
            {
                this.export = export;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var chargeTypeHistories = await GetDataToExport(request.Filter);
                if (chargeTypeHistories == null || chargeTypeHistories.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched charge type history does not exist in the database!");
                }

                return export.Export(request.Title, chargeTypeHistories);
            }
        }
    }
}
