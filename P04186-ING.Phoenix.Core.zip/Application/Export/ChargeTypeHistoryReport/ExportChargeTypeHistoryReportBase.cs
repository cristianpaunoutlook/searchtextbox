﻿using Application.DboChargeType;
using Application.DTO;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Application.Export.ChargeTypeHistoryReport
{
    [ExcludeFromCodeCoverage]
    public class ExportChargeTypeHistoryReportBase : ChargeTypeListBase
    {
        private readonly PhoenixContext context;
        private readonly IMapper mapper;

        public ExportChargeTypeHistoryReportBase(PhoenixContext context, IMapper mapper)
        {
            this.context = context;
            this.mapper = mapper;
        }

        public async Task<List<ChargeTypeHistoryReportData>> GetDataToExport(ChargeTypeHistoryReportFilter filter)
        {
            var chargeTypeHistories = ChargeTypeHistoryReportList(context, filter);
            var chargeTypeHistoriesToExport = await chargeTypeHistories.ToListAsync();
            return mapper.Map<List<ChargeTypeHistoryReportListDTO>, List<ChargeTypeHistoryReportData>>(chargeTypeHistoriesToExport);
        }
    }
}
