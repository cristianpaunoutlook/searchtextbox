﻿using Application.Errors;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Persistence;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.ImportedPayments
{
    [ExcludeFromCodeCoverage]
    public class ImportedPaymentsToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public ImportedPaymentsFilter Filter { get; set; }
            public string UserId { get; set; }
        }
        public class Handler : ExportImportedPaymentsBase, IRequestHandler<Query, byte[]>
        {
            private readonly IExportAsExcel<ImportedPaymentsReportData> export;

            public Handler(PhoenixContext context, IMapper mapper, IExportAsExcel<ImportedPaymentsReportData> export) : base(context, mapper)
            {
                this.export = export;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var importedPayments = await GetDataToExport(request.Filter, request.UserId);
                if (importedPayments == null || importedPayments.Count == 0)
                    throw new RestException(HttpStatusCode.BadRequest, "The searched imported payments does not exist in the database!");
                return export.Export(request.Title, importedPayments);
            }
        }
    }
}
