﻿using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace Application.Export.ImportedPayments
{
    [ExcludeFromCodeCoverage]
    public class ImportedPaymentsReportData
    {
        public int SessionId { get; set; }

        [Description("ChargeCode")]
        public string Code { get; set; }

        public string PaymentDetails { get; set; }

        public string CustomerId { get; set; }

        public string DebitAccount { get; set; }

        public string CreditAccount { get; set; }
        
        public string Type { get; set; }

        [Description("SpecialAmount")]
        public string Amount { get; set; }

        public string Currency { get; set; }

        public bool Imported { get; set; }

        public string Message { get; set; }

        public string ImportedBy { get; set; }
    }
}
