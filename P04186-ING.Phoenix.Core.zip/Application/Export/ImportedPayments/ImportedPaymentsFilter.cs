﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Export.ImportedPayments
{
    [ExcludeFromCodeCoverage]
    public class ImportedPaymentsFilter
    {
        public int SessionId { get; set; }
        public int Imported { get; set; }
    }
}
