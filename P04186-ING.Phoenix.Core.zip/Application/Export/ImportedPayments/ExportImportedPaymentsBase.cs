﻿using Application.DboImportedPayments;
using Application.DTO;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Application.Export.ImportedPayments
{
    [ExcludeFromCodeCoverage]
    public class ExportImportedPaymentsBase : ImportedPaymentsListBase
    {
        private readonly PhoenixContext context;
        private readonly IMapper mapper;

        public ExportImportedPaymentsBase(PhoenixContext context, IMapper mapper)
        {
            this.context = context;
            this.mapper = mapper;
        }

        public async Task<List<ImportedPaymentsReportData>> GetDataToExport(ImportedPaymentsFilter filter, string userId)
        {
            var importedPayments = ImportedPaymentsList(context, filter, userId);
            var importedPaymentsToExport = await importedPayments.ToListAsync();
            return mapper.Map<List<ImportedPaymentsDTO>, List<ImportedPaymentsReportData>>(importedPaymentsToExport);
        }
    }
}
