﻿using Application.DboChargeType;
using Application.DTO;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Application.Export.ChargeTypes
{
    [ExcludeFromCodeCoverage]
    public class ExportChargeTypeBase : ChargeTypeListBase
    {
        private readonly PhoenixContext context;
        private readonly IMapper mapper;

        public ExportChargeTypeBase(PhoenixContext context, IMapper mapper)
        {
            this.context = context;
            this.mapper = mapper;
        }

        public async Task<List<ChargeTypeReportData>> GetDataToExport(ChargeTypesFilter filter)
        {
            var chargeTypes = ChargeTypeList(context, filter);
            var chargeTypesToExport = await chargeTypes.ToListAsync();
            return mapper.Map<List<ChargeTypeListDTO>, List<ChargeTypeReportData>>(chargeTypesToExport);
        }
    }
}
