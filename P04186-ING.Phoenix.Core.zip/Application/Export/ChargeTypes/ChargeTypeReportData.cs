﻿using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace Application.Export.ChargeTypes
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeReportData
    {
        public string Status { get; set; }

        [Description("Code")]
        public string ChargeTypeCode { get; set; }

        [Description("Description")]
        public string ChargeTypeDescription { get; set; }

        [Description("Credit Account")]
        public long? CreditAccountShort { get; set; }

        public string Currency { get; set; }

        [Description("Amount / Transaction")]
        public decimal DefaultAmount { get; set; }

        [Description("Amount / Product")]
        public decimal? AmountProduct { get; set; }

        public string Frequency { get; set; }

        [Description("Run day")]
        public byte? RunDay { get; set; }

        [Description("Last modification date")]
        public DateTime? LastModifiedDate { get; set; }
    }
}
