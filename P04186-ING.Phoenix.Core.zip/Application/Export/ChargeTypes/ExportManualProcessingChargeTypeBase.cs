﻿using Application.Helpers;
using AutoMapper;
using Domain;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Application.Export.ChargeTypes
{
    [ExcludeFromCodeCoverage]
    public class ExportManualProcessingChargeTypeBase
    {
        private readonly PhoenixContext context;
        private readonly ILogger logger;
        private readonly IMapper mapper;

        public ExportManualProcessingChargeTypeBase(PhoenixContext context, ILogger logger, IMapper mapper)
        {
            this.context = context;
            this.logger = logger;
            this.mapper = mapper;
        }

        public async Task<List<ManualProcessingChargeTypesReportData>> GetDataToExport(ManualProcessParams filter)
        {
            logger.LogInformation($"Export Filter values:{"ChargeTypeId =" + filter.ChargeTypeId + " " + "NextRunDay =" + filter.NextRunDay + " " + "Charge description = " + filter.ChargeDescription }");
            var chargeTypeList = await context.ListForManualProcess(filter.PageNumber,
                    filter.PageSize, filter.ChargeTypeId, filter.NextRunDay, filter.ChargeDescription);

            var listOfChargeTypes = mapper.Map<List<ManualProcessSpResult>, List<ManualProcessingChargeTypesReportData>>(chargeTypeList);

            return listOfChargeTypes;
        }
    }

}
