﻿using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Application.Errors;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Persistence;

namespace Application.Export.ChargeTypes
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypesToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public ChargeTypesFilter Filter { get; set; }
        }
        public class Handler : ExportChargeTypeBase, IRequestHandler<Query, byte[]>
        {
            private readonly IExportAsExcel<ChargeTypeReportData> export;

            public Handler(PhoenixContext context, IMapper mapper, IExportAsExcel<ChargeTypeReportData> export) : base(context, mapper)
            {
                this.export = export;
            }
            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                var charges = await GetDataToExport(request.Filter);
                if (charges == null || charges.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched charge types does not exist in the database!");
                }

                return export.Export(request.Title, charges);
            }
        }
    }
}
