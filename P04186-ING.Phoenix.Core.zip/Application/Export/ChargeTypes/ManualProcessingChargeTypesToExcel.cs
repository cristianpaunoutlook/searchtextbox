﻿using Application.Errors;
using Application.Helpers;
using Application.Interfaces.Export;
using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Export.ChargeTypes
{
    [ExcludeFromCodeCoverage]
    public class ManualProcessingChargeTypesToExcel
    {
        public class Query : IRequest<byte[]>
        {
            public string Title { get; set; }
            public ManualProcessParams Filter { get; set; }
        }
        public class Handler : ExportManualProcessingChargeTypeBase, IRequestHandler<Query, byte[]>
        {
            private readonly IExportAsExcel<ManualProcessingChargeTypesReportData> export;
            private readonly ILogger logger;
            private readonly IMapper mapper;

            public Handler(PhoenixContext context, ILogger<Handler> logger, IMapper mapper, IExportAsExcel<ManualProcessingChargeTypesReportData> export) : base(context, logger, mapper)
            {
                this.export = export;
                this.logger = logger;
                this.mapper = mapper;
            }

            public async Task<byte[]> Handle(Query request, CancellationToken cancellationToken)
            {
                logger.LogInformation("Export manual processing charge types list as excel file!");
                var manualProcessingChargeTypes = await GetDataToExport(request.Filter);
                if (manualProcessingChargeTypes == null || manualProcessingChargeTypes.Count == 0)
                {
                    throw new RestException(HttpStatusCode.BadRequest, "The searched charge types for manual processing does not exist in the database!");
                }

                return export.Export(request.Title, manualProcessingChargeTypes);
            }
        }
    }
}
