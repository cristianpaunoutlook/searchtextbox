﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.Export.ChargeTypes
{
    [ExcludeFromCodeCoverage]
    public class ManualProcessingChargeTypesReportData
    {
        [Description("Charge Code")]
        public string ChargeTypeCode { get; set; }
        public string Currency { get; set; }
        public string Description { get; set; }
        [Description("Payments Last Run")]
        public int PaymentsLastRun { get; set; }
        public int Payments { get; set; }
        [Description("Total RON Last Run")]
        public decimal TotalRONLastRun { get; set; }
        [Description("Total RON")]
        public decimal TotalRON { get; set; }
        public DateTime? LastRunDay { get; set; }
        public DateTime? NextRunDay { get; set; }
    }
}
