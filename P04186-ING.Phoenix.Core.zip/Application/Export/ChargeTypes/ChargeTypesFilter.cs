﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.Export.ChargeTypes
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypesFilter
    {
        public int? ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
        public int FrequencyId { get; set; }
        public int StatusId { get; set; }
    }
}
