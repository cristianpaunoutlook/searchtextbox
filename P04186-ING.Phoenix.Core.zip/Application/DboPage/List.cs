﻿using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboPage
{
    [ExcludeFromCodeCoverage]
    public class List
    {
        public class Query : IRequest<List<Page>> {  }

        public class Handler : IRequestHandler<Query, List<Page>>
        {
            private readonly PhoenixContext context;

            public Handler(PhoenixContext context)
            {
                this.context = context;
            }

            public async Task<List<Page>> Handle(Query request, CancellationToken cancellationToken) =>
                await context.Pages.OrderBy(p => p.OrderNo).ToListAsync();
        }
    }
}
