﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;

namespace Application.DboCurrency
{
    public class List
    {
        public class Query : IRequest<List<Currency>> { }

        public class Handler : IRequestHandler<Query, List<Currency>>
        {
            private readonly PhoenixContext context;

            public Handler(PhoenixContext context)
            {
                this.context = context;
            }

            public async Task<List<Currency>> Handle(Query request, CancellationToken cancellationToken)
            {
                return await context.Currencies
                    .Where(curr => curr.ActiveYN != false)
                    .OrderBy(c => c.DisplayOrder)
                    .ThenBy(c => c.CurrencyCode)
                    .ToListAsync();
            }
        }
    }
}
