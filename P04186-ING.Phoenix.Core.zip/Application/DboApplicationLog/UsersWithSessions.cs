﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboApplicationLog
{
    public class UsersWithSessions
    {
        public class Query : IRequest<List<string>>
        {
            public int SessionType { get; set; }
        }

        public class Handler : IRequestHandler<Query, List<string>>
        {
            private readonly PhoenixContext context;

            public Handler(PhoenixContext context)
            {
                this.context = context;
            }

            public async Task<List<string>> Handle(Query request, CancellationToken cancellationToken) =>
                await context.ApplicationLogs
                        .Where(l => l.ObjectTypeId == request.SessionType)
                        .OrderBy(l => l.UserId)
                        .Select(l => l.UserId.ToUpper())
                        .Distinct()
                        .ToListAsync();
        }
    }
}
