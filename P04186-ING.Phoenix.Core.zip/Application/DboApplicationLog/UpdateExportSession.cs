﻿using Application.Commons.Enums;
using Application.Errors;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Application.DboApplicationLog
{
    public class UpdateExportSession
    {
        public class Command : IRequest
        {
            public int SessionId { get; set; }
            public string UserKey { get; set; }
        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }
            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"Change user on session {request.SessionId}. User key: {request.UserKey}");
                var applicationLog = await context.ApplicationLogs
                                                .Where(al => al.SessionId == request.SessionId && 
                                                                al.ObjectTypeId == (int)ObjectType.SessionExport)
                                                .FirstOrDefaultAsync();
                if (applicationLog == null)
                {
                    logger.LogError($"No line in Application Log with export session id {request.SessionId}");
                    throw new RestException(HttpStatusCode.BadRequest, $"No line in Application Log with export session id {request.SessionId}");
                }

                if (applicationLog.UserId == request.UserKey)
                    return Unit.Value;

                applicationLog.UserId = request.UserKey;
                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("Application Log was not updated!");
            }
        }
    }
}
