﻿using Application.Commons.Enums;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System.Threading;
using System.Threading.Tasks;

namespace Application.SECUserLog
{
    public class LogIn
    {
        public class Command : UserLogCommandBase, IRequest
        {
            public string SessionId { get; set; }
        }

        public class Handler : UserLogHandlerBase, IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"log user login");
                return await AddUserLog(context, request.SessionId, (int)UserAction.Login, (int)UserObject.Session, request.UserId, request.IP, request.Workstation);
            }

        }
    }
}
