﻿using Application.Commons.Enums;
using Domain;
using MediatR;
using Microsoft.Extensions.Logging;
using Persistence;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.SECUserLog
{
    public class InvalidLogin
    {
        public class Command : UserLogCommandBase, IRequest
        {            
        }

        public class Handler : IRequestHandler<Command>
        {
            private readonly PhoenixContext context;
            private readonly ILogger<Handler> logger;

            public Handler(PhoenixContext context, ILogger<Handler> logger)
            {
                this.context = context;
                this.logger = logger;
            }

            public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
            {
                logger.LogInformation($"login failed");
                var loginFailed = new SecUserLog()
                {
                    ActionId = (int)UserAction.FailedLogin,
                    ObjectId = (int)UserObject.Session,
                    RecordStamp = DateTime.Now,
                    UserId = request.UserId,
                    ErrorNumberId = 0,
                    SessionId = -1,
                    RecordId = "-1",
                    Details = $"Session=NoSession;UserId={request.UserId};IP={request.IP};Workstation={request.Workstation}"
                };

                context.UserLogs.Add(loginFailed);
                var success = await context.SaveChangesAsync() > 0;

                return success ? Unit.Value : throw new Exception("UserLog record was not created!");
            }

        }
    }
}
