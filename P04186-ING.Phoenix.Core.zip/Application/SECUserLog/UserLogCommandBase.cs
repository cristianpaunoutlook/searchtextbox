﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.SECUserLog
{
    public class UserLogCommandBase
    {
        public string UserId { get; set; }

        public string IP { get; set; }

        public string Workstation { get; set; }
    }
}
