﻿using Application.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace Application.Notifications.ChargesReportNotifications
{
    [ExcludeFromCodeCoverage]
    public class ChargesReportNotificationBase : NotificationBase
    {
        private readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        public ChargesReportNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("ChargeManagementNotification").Value.Split(";");
        }

        private string CreateEmailSubject()
        {
            var date = DateTime.Now;
            return $"Customer Charges - Approval Request - <{date:MMMM} {date.Year}>";
        }

        public async Task SendChargesReportEmailAsync(string fileName, byte[] fileAttached)
        {
            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\ChargesReportNotifications\\EmailTemplates\\ChargesReport.html";

            var emailBody = ReadTextFromMailTemplate(pathToFile);

            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                CreateEmailSubject(),
                emailBody.Replace("[Url]", configuration.GetSection("PhoenixChargesVerificationUrl").Value), fileName: fileName, fileAttached: fileAttached);
        }
    }
}
