﻿using Application.Interfaces;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace Application.Notifications.ManualProcessingNotifications
{
    [ExcludeFromCodeCoverage]
    public class ManualProcessingNotificationBase : NotificationBase
    {
        private readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        public ManualProcessingNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("ChargeManagementNotification").Value.Split(";");
        }

        private string CreateEmailSubject(int sessionId)
        {
            string emailSubject = $"Process charges - Session ID {sessionId}";

            return emailSubject;
        }

        private ManualProcessingNotificationParams CreateNotificationParam(int sessionId, string keyUser, string chargeTypeCode,
            string startDate, int totalCommissions)
        {
            var notificationParams = new ManualProcessingNotificationParams()
            {
                SessionId = sessionId,
                KeyUser = keyUser,
                ChargeTypeCode = chargeTypeCode,
                StartDate = startDate,
                TotalCommissions = totalCommissions
            };

            return notificationParams;
        }

        public async Task SendManualProcessingEmailAsync(int sessionId, string keyUser, string chargeTypeCode,
            string startDate, int totalCommissions)
        {
            var notificationParams = CreateNotificationParam(sessionId, keyUser, chargeTypeCode, startDate, totalCommissions);

            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\ManualProcessingNotifications\\EmailTemplates\\ProcessCharges.html";

            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                CreateEmailSubject(sessionId),
                CreateEmailBody(notificationParams, pathToFile));
        }
    }
}
