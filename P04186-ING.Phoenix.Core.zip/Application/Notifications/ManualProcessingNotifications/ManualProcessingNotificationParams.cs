﻿using System.Diagnostics.CodeAnalysis;

namespace Application.Notifications.ManualProcessingNotifications
{
    [ExcludeFromCodeCoverage]
    public class ManualProcessingNotificationParams
    {
        public int SessionId { get; set; }
        public string KeyUser { get; set; }
        public string ChargeTypeCode { get; set; }
        public string StartDate { get; set; }
        public int TotalCommissions { get; set; }
    }
}
