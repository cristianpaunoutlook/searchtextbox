﻿using Application.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace Application.Notifications.FileImportJobsNotifications
{
    [ExcludeFromCodeCoverage]
    public class FileImportJobsNotificationBase : NotificationBase
    {
        private readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        public FileImportJobsNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("AnafNotification").Value.Split(";");
        }

        private string CreateEmailSubject(string fileName)
        {
            return $"Import WBIF File: {fileName} NOK - {DateTime.Now:yyyyMMdd} ";
        }

        public async Task SendAnafErrorEmailAsync(string fileName)
        {
            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\FileImportJobsNotifications\\EmailTemplates\\AnafJob.html";

            var emailBody = ReadTextFromMailTemplate(pathToFile);

            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                CreateEmailSubject(fileName),
                emailBody.Replace("[ErrorTime]", DateTime.Now.ToString("yyyyMMdd HH:mm")));
        }
    }
}
