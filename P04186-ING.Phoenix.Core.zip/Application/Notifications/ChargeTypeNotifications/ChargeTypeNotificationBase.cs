﻿using Application.Commons.Enums;
using Application.Interfaces;
using Domain;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace Application.Notifications.ChargeTypeNotifications
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeNotificationBase : NotificationBase
    {
        private readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        private readonly Dictionary<string, string> actions = new Dictionary<string, string>()
            {
                { nameof(NotificationAction.Add), NotificationAction.Add },
                { nameof(NotificationAction.Edit), NotificationAction.Edit },
                { nameof(NotificationAction.Delete), NotificationAction.Delete },
                { Commons.Enums.ObjectStatus.VerificationAdd, NotificationAction.ApproveRejectAdd },
                { Commons.Enums.ObjectStatus.VerificationModify, NotificationAction.ApproveRejectModify },
                { Commons.Enums.ObjectStatus.VerificationDelete, NotificationAction.ApproveRejectDelete }
            };


        public ChargeTypeNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }

        private string CreateEmailSubject(string chargeTypeCode, string notificationType)
        {
            string emailSubject = $"Charge {chargeTypeCode} ";

            if (notificationType == nameof(NotificationType.SendToApprove))
            {
                emailSubject += $"- Approval Request";
            }
            else if (notificationType == nameof(NotificationType.Approved))
            {
                emailSubject += $"has been approved";
            }
            else
            {
                emailSubject += $"has been rejected";
            }

            return emailSubject;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("ChargeManagementNotification").Value.Split(";");
        }

        public async Task SendChargeTypeEmailAsync(ChargeType chargeType, string actionKey, string notificationType)
        {
            var notificationParams = CreateNotificationParam(chargeType, actions[actionKey], notificationType);

            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\ChargeTypeNotifications\\EmailTemplates\\ChargeType{notificationParams.NotificationType}.html";

            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                CreateEmailSubject(notificationParams.ChargeTypeCode, notificationParams.NotificationType),
                CreateEmailBody(notificationParams, pathToFile));
        }

        private ChargeTypeNotificationParams CreateNotificationParam(ChargeType chargeType, string action, string notificationType)
        {
            var notificationParams = new ChargeTypeNotificationParams(configuration)
            {
                ChargeTypeId = chargeType.ChargeTypeId,
                KeyUser = chargeType.LastModifiedBy,
                ChargeTypeCode = chargeType.ChargeTypeCode,
                ChargeTypeDescription = chargeType.ChargeTypeDescription,
                RejectReason = chargeType.RejectReason,
                Action = action,
                NotificationType = notificationType
            };

            return notificationParams;
        }
    }
}
