﻿
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace Application.Notifications.ChargeTypeNotifications
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeNotificationParams
    {
        private readonly IConfiguration configuration;

        public ChargeTypeNotificationParams(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public int ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
        public string KeyUser { get; set; }
        public string RejectReason { get; set; }
        public string Action { get; set; }
        public string NotificationType { get; set; }
        public string Url { get { return $"{configuration.GetSection("PhoenixChargeTypeUrl").Value}{ChargeTypeId}"; } }
    }
}
