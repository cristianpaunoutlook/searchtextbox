﻿using Application.Interfaces;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace Application.Notifications.FileImportNotifications
{
    [ExcludeFromCodeCoverage]
    public class FileImportNotificationBase: NotificationBase
    {
        private readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        public FileImportNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("ToEmailAddress").Value.Split(";");
        }

        private string CreateEmailSubject(int sessionId)
        {
            string emailSubject = $"File was imported - Session ID {sessionId}";

            return emailSubject;
        }

        private FileImportNotificationParams CreateNotificationParam(int sessionId, string keyUser)
        {
            var notificationParams = new FileImportNotificationParams(configuration)
            {
                SessionId = sessionId,
                KeyUser = keyUser
            };

            return notificationParams;
        }

        public async Task SendFileImportEmailAsync(int sessionId, string keyUser, string mailTo)
        {
            var notificationParams = CreateNotificationParam(sessionId, keyUser);
            string[] arrMail = new string[] { mailTo};
            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\FileImportNotifications\\EmailTemplates\\FileImportApprove.html";

            await emailSender.SendEmailAsync(arrMail,
                CreateEmailSubject(sessionId),
                CreateEmailBody(notificationParams, pathToFile));
            
        }
    }
}