﻿using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace Application.Notifications.FileImportNotifications
{
    [ExcludeFromCodeCoverage]
    public class FileImportNotificationParams
    {
        private readonly IConfiguration configuration;

        public FileImportNotificationParams(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public int SessionId { get; set; }
        public string KeyUser { get; set; }
        public string Url { get { return $"{configuration.GetSection("PhoenixChargesVerificationUrl").Value}{SessionId}"; } }
    }
}
