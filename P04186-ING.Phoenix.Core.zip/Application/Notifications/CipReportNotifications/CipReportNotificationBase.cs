﻿using Application.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace Application.Notifications.CipReportNotifications
{
    [ExcludeFromCodeCoverage]
    public class CipReportNotificationBase : NotificationBase
    {
        private readonly IConfiguration configuration;
        private readonly IEmailSender emailSender;

        public CipReportNotificationBase(IConfiguration configuration, IEmailSender emailSender)
        {
            this.configuration = configuration;
            this.emailSender = emailSender;
        }

        private string[] CreateToEmailAddress()
        {
            return configuration.GetSection("CipNotification").Value.Split(";");
        }

        private string CreateEmailSubject()
        {
            var previousMonth = DateTime.Now.AddMonths(-1).ToString("MMMM");
            var year = DateTime.Now.AddMonths(-1).Year;
            string emailSubject = $"CIP Report {previousMonth} {year}";

            return emailSubject;
        }

        public async Task SendCipReportEmailAsync(string fileName, byte[] fileAttached)
        {
            var pathToFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) +
                $"\\Notifications\\CipReportNotifications\\EmailTemplates\\CipReport.html";

            await emailSender.SendEmailAsync(CreateToEmailAddress(),
                CreateEmailSubject(),
                ReadTextFromMailTemplate(pathToFile), fileName: fileName, fileAttached: fileAttached);
        }
    }
}
