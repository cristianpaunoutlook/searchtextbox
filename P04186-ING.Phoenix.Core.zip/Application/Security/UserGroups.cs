using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Persistence;
using System;
using Microsoft.Extensions.Configuration;
using Application.Interfaces;
using System.Net;
using Application.Errors;
using Domain;
using Application.Commons.Enums;
using System.Diagnostics.CodeAnalysis;

namespace Application.Security
{
    [ExcludeFromCodeCoverage]
    public class UserGroups
    {
        public class Query : IRequest<List<KeyValue>>
        { 
            public IIdentity User { get; set; }
            public string JWTEncryptKey { get; set; }
        }

        public class Handler : IRequestHandler<Query, List<KeyValue>>
        {
            private readonly PhoenixContext _context;
            private readonly IConfiguration _configuration;
            private readonly IADUserGroups _adUserGroups;

            public Handler(PhoenixContext context, 
                IConfiguration configuration,
                IADUserGroups adUserGroups
                )
            {
                _context = context;
                _configuration = configuration;
                _adUserGroups = adUserGroups;
            }

            public async Task<List<KeyValue>> Handle(Query request, CancellationToken cancellationToken)
            {
                var userGroupsNamePattern = _configuration.GetSection("UserGroupsNamePattern").Value;
                var adGroups = _adUserGroups.GetUserGroupsFromAD(userGroupsNamePattern);
                var databaseRights = await GetAppGroupsFromDb(String.Join("|", adGroups.ToArray()));
                var userRights = ClaimsFromRights(databaseRights);

                return userRights.Count > 0 ? userRights : throw new RestException(HttpStatusCode.Unauthorized, "Insuficient rights, contact administrator!");
            }
            
            private async Task<List<GroupPageRight>> GetAppGroupsFromDb(string adGroups) =>
                await _context.GroupsPagesRights
                        .Where(gpr => adGroups
                                        .Contains(gpr.Group.ADName) && 
                                        gpr.Group.StatusId == (int)ObjectStatusId.Active)
                        .ToListAsync();

            private List<KeyValue> ClaimsFromRights(List<GroupPageRight> userGroupRights) {
                var query = from ugr in userGroupRights group ugr by ugr.Page.Code into userRights
                            select new KeyValue
                            {
                                Key = $"r_{userRights.Key}",
                                Value = $"{userRights.Key}_{userRights.Max(r => r.Right.Value)}"
                            };
                return query.Distinct().ToList();
            }
        }
    }
}


