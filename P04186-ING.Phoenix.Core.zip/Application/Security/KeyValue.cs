﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Application.Security
{
    [ExcludeFromCodeCoverage]
    public class KeyValue 
    {
        public string Key { get; set; }

        public string Value { get; set; }

        public override bool Equals(Object obj)
        {
            if(obj is KeyValue)
            {
                KeyValue objToCompare = (KeyValue)obj;
                return Key == objToCompare.Key && Value == objToCompare.Value;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Key, Value);
        }
    }
}
