﻿using Application.Interfaces.Import;
using ExcelDataReader;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace Infrastructure.Import
{
    public class ImportFromExcel<T> : IImportFromExcel<T> where T : new()
    {
        private readonly ILogger logger;

        public ImportFromExcel(ILogger<ImportFromExcel<T>> logger)
        {
            this.logger = logger;
        }

        public List<T> GetListFromFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                logger.LogError($"The file {filePath} does not exists!");
                throw new Exception($"BAD INPUT: The file {filePath} does not exists!");
            }

            var result = new List<T>();
            FileStream stream = File.Open(filePath, FileMode.Open, FileAccess.Read);
            IExcelDataReader excelReader;
            try
            {
                excelReader = GetReader(filePath, stream);
            }
            catch (Exception ex)
            {
                logger.LogError($"Error when loading file!  ${ex.Message}");
                throw new Exception("BAD INPUT: The file is invalid! Please verify the separator for csv file type.");
            }

            Dictionary<string, int> columns = new Dictionary<string, int>();
            var header = true;
            T row = new T();
            var properties = row.GetType().GetProperties();
            var lineNumber = 1;

            while (excelReader.Read())
            {
                if (header)
                {
                    columns = ValidateHeader(excelReader, row);
                    header = false;
                }
                else
                {
                    var rowToAdd = GetNewRow(properties, lineNumber, columns, excelReader);
                    result.Add(rowToAdd);
                }
                lineNumber++;
            }
            stream.Close();
            stream.Dispose();
            return result;
        }

        private T GetNewRow(PropertyInfo[] properties, int lineNumber, Dictionary<string, int> columns, IExcelDataReader excelReader)
        {
            var rowToAdd = new T();
            var column = 0;
            try
            {
                foreach (var property in properties)
                {
                    column = columns[property.Name.ToLower()];
                    property.SetValue(rowToAdd, GetValue(property, excelReader, column));
                }
            }
            catch (Exception ex)
            {
                logger.LogError($"Invalid data in file at line {lineNumber} and column {column + 1}.\n{ex.Message}");
                throw new Exception($"BAD INPUT: Invalid data in file at line {lineNumber} and column {column + 1}.");
            }

            return rowToAdd;
        }

        private Dictionary<string, int> ValidateHeader(IExcelDataReader excelReader, T row)
        {
            var properties = row.GetType().GetProperties();
            var columnsName = new Dictionary<string, int>();

            if (excelReader.FieldCount != properties.Length)
            {
                logger.LogError($"The number of columns in file is {excelReader.FieldCount}. The expected number of columns is {properties.Length}");
                throw new Exception($"BAD INPUT: The file does not contain the required structure. Please download the template and import file again");
            }

            for (var i = 0; i < excelReader.FieldCount; i++)
            {
                var newKey = excelReader.GetValue(i).ToString().ToLower();
                if (columnsName.ContainsKey(newKey))
                {
                    logger.LogError($"The column {excelReader.GetValue(i)} is added twice in the import file!");
                    throw new Exception($"BAD INPUT: The column { excelReader.GetValue(i)} is added twice in the import file!");
                }
                columnsName.Add(excelReader.GetValue(i).ToString().ToLower(), i);
            }

            for (var i = 0; i < properties.Length; i++)
            {
                if (!columnsName.ContainsKey(properties[i].Name.ToLower()))
                {
                    logger.LogError($"The header is invalid! Column name in file {excelReader.GetString(i)} is invalid!");
                    throw new Exception($"BAD INPUT: The header is invalid! Column name in file {excelReader.GetString(i)} is invalid!");
                }
            }

            return columnsName;
        }

        public dynamic GetValue(PropertyInfo property, IExcelDataReader reader, int columnNumber)
        {
            switch (Type.GetTypeCode(property.PropertyType))
            {
                case TypeCode.Int32:
                    return Int32.Parse(reader.GetValue(columnNumber).ToString().Trim());
                case TypeCode.Decimal:
                    return decimal.Parse(reader.GetValue(columnNumber).ToString().Trim());
                case TypeCode.DateTime:
                    return DateTime.Parse(reader.GetValue(columnNumber).ToString().Trim());
                case TypeCode.Boolean:
                    return bool.Parse(reader.GetValue(columnNumber).ToString().Trim());
                default:
                    return reader.GetValue(columnNumber) != null ? reader.GetValue(columnNumber).ToString().Trim() : string.Empty;
            }
        }

        public IExcelDataReader GetReader(string filePath, FileStream fileStream)
        {
            if (filePath.Substring(filePath.Length - 5).ToLower() == ".xlsx")
                return ExcelReaderFactory.CreateOpenXmlReader(fileStream);
            if (filePath.Substring(filePath.Length - 4).ToLower() == ".csv" || filePath.Substring(filePath.Length - 4).ToLower() == ".txt")
                return ExcelReaderFactory.CreateCsvReader(fileStream);

            logger.LogError($"The file {filePath} does not exists!");
            throw new Exception($"BAD INPUT: The file {filePath} does not exists!");
        }
    }
}
