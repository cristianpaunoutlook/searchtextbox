﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Infrastructure.Export
{
    public class ExportBase<T>
    {
        protected readonly string[] invalidChars = new string[] { "=", "+", "-", "@"};
        protected string GetColumnName(PropertyInfo property)
        {
            DescriptionAttribute[] attributes = (DescriptionAttribute[])property.GetCustomAttributes(typeof(DescriptionAttribute), false);
            if (attributes.Length > 0)
                return attributes[0].Description;
            else
                return property.Name.ToString();
        }

        protected string FormatColumn(T rowData, PropertyInfo property)
        {
            var value = property.GetValue(rowData);
            if (value == null) return "";
            if (property.PropertyType == typeof(DateTime) || property.PropertyType == typeof(DateTime?))
                return ((DateTime)value).ToString("dd MMM yyyy hh:mm:ss");
            return RemoveInvalidCaracters(value.ToString());
        }

        protected string RemoveInvalidCaracters(string valueToValidate)
        {
            if (String.IsNullOrEmpty(valueToValidate))
                return valueToValidate;
            return invalidChars.Aggregate(valueToValidate, (str, cItem) => {
                if (str.Length > 0 && str.Substring(0, 1) == cItem)
                    return str.Substring(1);
                return str; 
            });
        }
    }
}
