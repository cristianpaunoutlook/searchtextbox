﻿namespace Infrastructure.Export
{
    public static class HtmlTags
    {
        public static string HtmlHeadAndCss = @"<html>
                            <head>
                                <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
                                <title> Paginated HTML </title>
                                <style type='text/css'>
                                    body {
                                    font-family: ING Me;
                                    }
                                    h2 {
                                        font-family: ING Me;
                                        font-size:16px;
                                        color: #ff6200;
                                    }
                                    table {
                                        font-family: ING Me;
                                        font-size:14px;
                                        border-collapse: collapse;
                                        width: 100%;
                                    }
                                    table td, table th {
                                        border: 1px solid #ddd;
                                        padding: 2px;
                                    }
                                    table tr:nth-child(even){background-color: #f2f2f2;}
                                    table th {
                                        padding-top: 5px;
                                        padding-bottom: 5px;
                                        text-align: left;
                                        background-color: #ff6200;
                                        color: white;
                                    }
                                </style>
                            </head>
                            <body>";
        public static string CloseHtml = "</body></html>";
        public static string PageBreak = "<div style='page-break-after: always;'>&nbsp;</div>";
        public static string Table = "table";
        public static string TableRow = "tr";
        public static string TableHeading = "th";
        public static string TableColumn = "td";
        public static string H1 = "h1";
        public static string H2 = "h2";
        public static string H3 = "h3";
        public static string Font = "font";
        public static string Body = "body";
        public static string Html = "html";
        public static string NewLine = "<br/>";

        public static string AddTagWithValue(string TagName, string Value, string attributes = "")
        {
            return $"<{TagName} {attributes}>{Value}</{TagName}>";
        }

        public static string AddTag(string TagName, string attributes = "")
        {
            return $"<{TagName} {attributes}>";
        }

        public static string CloseTag(string TagName)
        {
            return $"</{TagName}>";
        }
    }
}