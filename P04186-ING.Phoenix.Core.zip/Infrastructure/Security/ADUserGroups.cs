﻿using Application.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;

namespace Infrastructure.Security
{
    public class ADUserGroups : IADUserGroups
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger _logger;

        public ADUserGroups(IHttpContextAccessor httpContextAccessor, ILogger<ADUserGroups> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
        }
        public List<string> GetUserGroupsFromAD(string userGroupsNamePattern)
        {   
            IIdentity identity = _httpContextAccessor.HttpContext.User.Identity;
            _logger.LogInformation($"get AD groups for user {identity.Name} using filter {userGroupsNamePattern}");
            var groups = ((WindowsIdentity)identity)
                        .Groups
                        .Select(TryTranslate)
                        .Select(EliminateDomain)
                        .Where(g => g.Contains(userGroupsNamePattern))
                        .ToList();
            _logger.LogInformation($"list of groups {String.Join("|", groups)}");
            return groups;
        }

        private string TryTranslate(IdentityReference identity)
        {
            try
            {
                return identity.Translate(typeof(NTAccount)).ToString();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Cannot translate {identity?.Value}");
                return "N/A";
            }
        }

        private string EliminateDomain(string group)
        {
            if (string.IsNullOrWhiteSpace(group))
                return group;

            var components = group.Split('\\');

            if (components.Length > 0)
            {
                return components[components.Length - 1];
            }

            return group;
        }
    }
}
