﻿using Application.Interfaces;
using Application.Security;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;

namespace Infrastructure.Security
{
    public class JWTGenerator : IJWTGenerator
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger<JWTGenerator> _logger;

        public JWTGenerator(IHttpContextAccessor httpContextAccessor, ILogger<JWTGenerator> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
        }

        public string CreateToken(List<KeyValue> claimsToAdd, string jwtEncryptKey, int sessionExpiration)
        {
            IIdentity identity = _httpContextAccessor.HttpContext.User.Identity;
            var claims = new List<Claim>
            {
                new Claim("UserName", identity.Name)
            };

            foreach (var claim in claimsToAdd)
            {
                claims.Add(new Claim(claim.Key, claim.Value));
            }

            return WriteTokenString(jwtEncryptKey, sessionExpiration, claims);
        }

        public string RefreshToken(string jwtEncryptKey, int sessionExpiration, string jwtHeaderKey, List<KeyValue> rights)
        {
            ClaimsPrincipal principal = GetTokenPrincipal(jwtEncryptKey, jwtHeaderKey);
            var claims = new List<Claim>
            {
                new Claim("UserName", principal.Claims.Where(c => c.Type == "UserName").FirstOrDefault().Value),
                new Claim("lastLoginDate", principal.Claims.Where(c => c.Type == "lastLoginDate").FirstOrDefault().Value),
                new Claim("lastLoginIP", principal.Claims.Where(c => c.Type == "lastLoginIP").FirstOrDefault().Value),
                new Claim("SessionId", principal.Claims.Where(c => c.Type == "SessionId").FirstOrDefault().Value)
            };

            foreach (var claim in rights)
            {
                claims.Add(new Claim(claim.Key, claim.Value));
            }

            return WriteTokenString(jwtEncryptKey, sessionExpiration, claims);
        }

        private ClaimsPrincipal GetTokenPrincipal(string jwtEncryptKey, string jwtHeaderKey)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var currentJwt = _httpContextAccessor.HttpContext.Request.Headers[jwtHeaderKey];

            var tokenValidationParamters = new TokenValidationParameters
            {
                ValidateAudience = false,
                ValidateIssuer = false,
                ValidateActor = false,
                ValidateLifetime = false,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(jwtEncryptKey))
            };

            SecurityToken securityToken;
            ClaimsPrincipal principal;

            try
            {
                principal = tokenHandler.ValidateToken(currentJwt, tokenValidationParamters, out securityToken);
            }
            catch (Exception)
            {

                throw new SecurityTokenException("Invalid token!");
            }
            return principal;
        }

        public DateTime GetExpirationDate(string jwtEncryptKey, string jwtHeaderKey)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var currentJwt = _httpContextAccessor.HttpContext.Request.Headers[jwtHeaderKey];

            var tokenValidationParamters = new TokenValidationParameters
            {
                ValidateAudience = false,
                ValidateIssuer = false,
                ValidateActor = false,
                ValidateLifetime = false,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(jwtEncryptKey))
            };

            SecurityToken securityToken;
            ClaimsPrincipal principal;

            try
            {
                principal = tokenHandler.ValidateToken(currentJwt, tokenValidationParamters, out securityToken);
            }
            catch (Exception)
            {

                throw new SecurityTokenException("Invalid token!");
            }
            var jwtSecurityToken = securityToken as JwtSecurityToken;
            if (jwtSecurityToken == null)
            {
                throw new SecurityTokenException("Invalid token!");
            }

            var userName = principal.FindFirst("UserName")?.Value;
            if (string.IsNullOrEmpty(userName) || userName.ToLower() != _httpContextAccessor.HttpContext.User.Identity.Name.ToLower())
            {
                throw new SecurityTokenException("Invalid user");
            }

            return jwtSecurityToken.ValidTo.ToLocalTime();
        }

        public string GetSessionId(string jwtEncryptKey, string jwtHeaderKey)
        {
            ClaimsPrincipal principal = GetTokenPrincipal(jwtEncryptKey, jwtHeaderKey);
            return principal.Claims.Where(c => c.Type == "SessionId").FirstOrDefault().Value;
        }

        private static string WriteTokenString(string jwtEncryptKey, int sessionExpiration, List<Claim> claims)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtEncryptKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var tokenDescryptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.ToLocalTime().AddMinutes(sessionExpiration),
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescryptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
