﻿using Application.Interfaces;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using System.Threading.Tasks;

namespace Infrastructure.Notifications
{
    public class EmailSender : IEmailSender
    {
        private readonly EmailConfiguration emailConfig;

        public EmailSender(EmailConfiguration emailConfig)
        {
            this.emailConfig = emailConfig;
        }

        public async Task SendEmailAsync(string[] to, string subject, string content, string fileName = null, byte[] fileAttached = null)
        {
            var message = new Message(to, subject, content);
            var emailMessage = CreateEmailMessage(message, fileName, fileAttached);
            await SendAsync(emailMessage);
        }

        private MimeMessage CreateEmailMessage(Message message, string fileName, byte[] fileAttached)
        {
            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress(emailConfig.From));
            emailMessage.To.AddRange(message.To);
            emailMessage.Subject = message.Subject;
            if (string.IsNullOrEmpty(fileName))
            {
                emailMessage.Body = new TextPart(MimeKit.Text.TextFormat.Html) { Text = message.Content };
            }
            else
            {
                var builder = new BodyBuilder
                {
                    HtmlBody = message.Content
                };
                builder.Attachments.Add(fileName, fileAttached, new ContentType("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
                emailMessage.Body = builder.ToMessageBody();
            }

            return emailMessage;
        }

        private async Task SendAsync(MimeMessage mailMessage)
        {
            using (var client = new SmtpClient())
            {
                await client.ConnectAsync(emailConfig.SmtpServer, emailConfig.Port, SecureSocketOptions.None);
                await client.SendAsync(mailMessage);
                await client.DisconnectAsync(true);
            }
        }
    }
}
