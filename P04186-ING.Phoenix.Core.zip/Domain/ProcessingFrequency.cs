﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ProcessingFrequency
    {
        public int ProcessingFrequencyId { get; set; }
        public string ProcessingFrequencyName { get; set; }
        public string ProcessingFrequencyDescription { get; set; }
        public bool Deleted { get; set; }
    }
}
