﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class DlfilesTblNonWorkingDays
    {
        public DateTime Date { get; set; }
        public string Comment { get; set; }
    }
}
