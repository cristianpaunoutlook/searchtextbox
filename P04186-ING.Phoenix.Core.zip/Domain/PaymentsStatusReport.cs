﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class PaymentsStatusReport
    {
        public int TotalCount { get; set; }
        public int SessionId { get; set; }
        public string PaymentId { get; set; }
        public string Trid { get; set; }
        public string Status { get; set; }
        public string CustomerId { get; set; }
        public string ChargeTypeCode { get; set; }
        public decimal Amount { get; set; }
        public string CurrencyCode { get; set; }
        public string IBANDebitAccount { get; set; }
        public string CreditAccount { get; set; }
        public string PaymentDetails { get; set; }
        public string UserId { get; set; }
        public DateTime RecordStamp { get; set; }
        public int? RepNo { get; set; }
        public DateTime? InsertDate { get; set; }
        public int? REF_ID_CCM { get; set; }
        public string RejectReason { get; set; }
    }
}
