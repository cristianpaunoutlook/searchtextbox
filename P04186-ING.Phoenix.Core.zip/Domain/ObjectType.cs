using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ObjectType
    {
        public int ObjectTypeId { get; set; }

        public string ObjectTypeName { get; set; }

        public string ObjectTypeDescription { get; set; }

        //public virtual IEnumerable<Session> Sessions { get; set; }
    }
}
