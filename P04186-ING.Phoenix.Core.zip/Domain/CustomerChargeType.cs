﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class CustomerChargeType
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
