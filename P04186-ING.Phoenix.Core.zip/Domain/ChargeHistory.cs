﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ChargeHistory
    {
        public int ChargeHistoryId { get; set; }
        public int ChargeId { get; set; }
        public virtual Charge Charge { get; set; }
        public string AtlasId { get; set; }
        public int ChargeTypeId { get; set; }
        public virtual ChargeType ChargeType { get; set; }
        public decimal? SpecialAmount { get; set; }
        public string DebitAccount { get; set; }
        public int? ChargedItems { get; set; }
        public byte StatusId { get; set; }
        public virtual ObjectStatus Status { get; set; }
        public int? CustomerChargeTypeId { get; set; }
        public virtual CustomerChargeType CustomerChargeType { get; set; }
        public string RejectReason { get; set; }
        public int? CurrencyId { get; set; }
        public virtual Currency Currency { get; set; }
        public int? REF_ID_CCM { get; set; }
        public long CreditAccountShort { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public int ActionId { get; set; }
        public virtual SecObjectAction ObjectAction { get; set; }
        public string PaymentDetails { get; set; }
    }
}
