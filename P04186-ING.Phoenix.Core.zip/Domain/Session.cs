﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Session
    {
        public int SessionId { get; set; }

        public DateTime RecordStamp { get; set; }

        public string GeneratedFileName { get; set; }

        public int ObjectTypeId { get; set; }

        public virtual ObjectType ObjectType { get; set; }

        public int Status { get; set; }
    }
}
