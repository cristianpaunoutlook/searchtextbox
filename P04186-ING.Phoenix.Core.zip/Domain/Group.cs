﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Group
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ADName { get; set; }
        public byte StatusId { get; set; }
        public virtual ObjectStatus Status { get; set; }
        public byte NextStatusId { get; set; }
        public virtual ObjectStatus NextStatus { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime LastModifiedDate { get; set; }
    }
}
