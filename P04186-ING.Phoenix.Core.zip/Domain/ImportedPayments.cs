﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ImportedPayments
    {
        public int SessionId { get; set; }

        public int LineNumber { get; set; }

        public virtual Session Session { get; set; }

        public string ChargeCode { get; set; }

        public string AtlasId { get; set; }

        public string DebitAccount { get; set; }

        public string CreditAccount { get; set; }

        public string ChargedItems { get; set; }

        public string SpecialAmount { get; set; }

        public bool? IsImported { get; set; }

        public string DebitAccountStatus { get; set; }

        public string Message { get; set; }

        public string CustomerChargeType { get; set; }

        public string CurrencyCode { get; set; }

        public int? REF_ID_CCM { get; set; }

        public string VATDebitAccount { get; set; }

        public string VATCreditAccount { get; set; }

        public string PaymentDetails { get; set; }
    }
}
