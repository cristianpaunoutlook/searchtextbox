﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Account
    {
        public string CustomerId { get; set; }
        public virtual CustomerDetails CustomerDetails { get; set; }

        public string CUI { get; set; }

        public string Type { get; set; }

        public string CurrencyCode { get; set; }

        public string Reference { get; set; }

        public string BranchCode { get; set; }

        public long AccountShort { get; set; }

        public string IBAN { get; set; }

        public int? Status { get; set; }

        public DateTime DateOpened { get; set; }

        public DateTime? DateClosed { get; set; }

        public string SubType { get; set; }

        public int BlockedDR { get; set; }

        public string Description { get; set; }

        public string CustomerName { get; set; }

        public string CustomerBranch { get; set; }

        public string RM { get; set; }

        public string CoreBanking { get; set; }

        public short? TypeId { get; set; }

        public string IsActive { get; set; }

        public string CustomerTypeHO { get; set; }
        public string GridID { get; set; }

    }
}
