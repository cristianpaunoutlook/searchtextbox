﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain

{
    [ExcludeFromCodeCoverage]
    public class Customer
    {
        public int CustomerId { get; set; }

        public string AtlasID { get; set; }

        public string Comments { get; set; }

        public string UserID { get; set; }

        public DateTime? DateLastUpdate { get; set; }

        public byte StatusId { get; set; }
    }
}
