﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeHistory
    {
        public int ChargeTypeHistoryId { get; set; }
        public int ChargeTypeId { get; set; }
        public virtual ChargeType ChargeType { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
        public int CurrId { get; set; }
        public virtual Currency Curr { get; set; }
        public decimal DefaultAmount { get; set; }
        public int FrequencyId { get; set; }
        public virtual ProcessingFrequency Frequency { get; set; }
        public string PaymentDetail { get; set; }
        public byte StatusId { get; set; }
        public virtual ObjectStatus Status { get; set; }
        public DateTime? LastRunDate { get; set; }
        public int? ForDepartment { get; set; }        
        public int? CreditAccountId { get; set; }
        public string RejectReason { get; set; }
        public decimal? AmountProduct { get; set; }
        public long? CreditAccountShort { get; set; }
        public byte? RunDay { get; set; }
        public DateTime? NextRunDay { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public int ActionId { get; set; }
        public int GroupId { get; set; }
        public virtual SecObjectAction ObjectAction { get; set; }
    }
}
