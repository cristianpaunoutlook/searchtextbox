﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class SecUserStatus
    {
        public int StatusId { get; set; }
        public string Status { get; set; }
    }
}
