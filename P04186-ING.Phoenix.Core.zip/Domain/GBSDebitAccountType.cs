﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class GBSDebitAccountType
    {
        public string Code { get; set; }

        public string Description { get; set; }
    }
}
