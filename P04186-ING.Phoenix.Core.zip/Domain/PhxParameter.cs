﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class PhxParameter
    {
        public string ParamName { get; set; }
        public string ParamValue { get; set; }
        public string Description { get; set; }
    }
}
