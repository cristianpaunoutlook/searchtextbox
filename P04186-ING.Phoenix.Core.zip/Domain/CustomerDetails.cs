using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class CustomerDetails
    {
        public string CustomerId { get; set; }
        public string Address { get; set; }
        public string RegistrationNumber { get; set; }
    }
}
