using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class UserGroup
    {
        public int GroupId { get; set; }

        public string GroupName { get; set; }

        public int StatusId { get; set; }

        public string ADName { get; set; }
    }
}