﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class SecSession
    {
        public int SessionId { get; set; }

        public string Session { get; set; }

        public DateTime SessionDate { get; set; }

        public string UserId { get; set; }

        public string IP { get; set; }

        public string Workstation { get; set; }

        public int CountFailedLogin { get; set; }
    }
}
