﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Right
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public int Value { get; set; }
        public string Description { get; set; }
    }
}
