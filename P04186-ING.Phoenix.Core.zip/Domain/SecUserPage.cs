﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class SecUserPage
    {
        public int PageId { get; set; }
        public string PageName { get; set; }
        public string Description { get; set; }
        public int FunctionId { get; set; }
        public bool IsDefault { get; set; }
        public string Folder { get; set; }
        public bool IsVisible { get; set; }
        public int MenuIndex { get; set; }
    }
}
