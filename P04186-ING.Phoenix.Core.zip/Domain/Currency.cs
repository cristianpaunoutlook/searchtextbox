﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Currency
    {
        public int CurrencyId { get; set; }

        public string CurrencyCode { get; set; }

        public bool ActiveYN { get; set; }

        public int DisplayOrder { get; set; }
    }
}
