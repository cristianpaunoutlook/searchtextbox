﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Charge
    {
        public int ChargeId { get; set; }
        public string AtlasId { get; set; }
        public int ChargeTypeId { get; set; }
        public virtual ChargeType ChargeType { get; set; }
        public decimal? SpecialAmount { get; set; }
        public string DebitAccount { get; set; }
        public int? ChargedItems { get; set; }
        public byte StatusId { get; set; }
        public virtual ObjectStatus Status { get; set; }
        public int? CustomerChargeTypeId { get; set; }
        public virtual CustomerChargeType CustomerChargeType { get; set; }
        public string RejectReason { get; set; }
        public int? CurrencyId { get; set; }
        public virtual Currency Currency { get; set; }
        public int? REF_ID_CCM { get; set; }
        public long CreditAccountShort { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public int AccountState { get; set; }
        public virtual ChargeAccountState ChargeAccountState { get; set; }
        public string PaymentDetails { get; set; }
        public int? SessionId { get; set; }
        public int? LineNumber { get; set; }
        public void GetFromHistory(ChargeHistory chargeHistory)
        {
            LastModifiedDate = DateTime.Now;
            ChargeTypeId = chargeHistory.ChargeTypeId;
            CustomerChargeTypeId = chargeHistory.CustomerChargeTypeId;
            SpecialAmount = chargeHistory.SpecialAmount;
            CurrencyId = chargeHistory.CurrencyId;
            DebitAccount = chargeHistory.DebitAccount;
            CreditAccountShort = chargeHistory.CreditAccountShort;
            ChargedItems = chargeHistory.ChargedItems;
            PaymentDetails = chargeHistory.PaymentDetails;
        }
    }
}
