﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ProcedureResult
    {
        public int CountModifiedCharges { get; set; }
    }
}
