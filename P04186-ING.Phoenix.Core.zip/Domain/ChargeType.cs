﻿using Domain;
using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ChargeType
    {
        public int ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string ChargeTypeDescription { get; set; }
        public int CurrId { get; set; }
        public virtual Currency Curr { get; set; }
        public decimal DefaultAmount { get; set; }
        public int FrequencyId { get; set; }
        public virtual ProcessingFrequency Frequency { get; set; }
        public string PaymentDetail { get; set; }
        public byte StatusId { get; set; }
        public virtual ObjectStatus Status { get; set; }
        public DateTime? LastRunDate { get; set; }
        public decimal TotalRONLastRun { get; set; }
        public int? ForDepartment { get; set; }
        public virtual SecObjectAction Action { get; set; }
        public int? CreditAccountId { get; set; }
        public string RejectReason { get; set; }
        public decimal? AmountProduct { get; set; }
        public long? CreditAccountShort { get; set; }
        public byte? RunDay { get; set; }
        public DateTime? NextRunDay { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public bool IsJobBased { get; set; }
        public bool HasVAT { get; set; }
        public int GroupId { get; set; }
        public virtual ChargeTypeGroup ChargeTypeGroup { get; set; }
        public void GetFromHistory(ChargeTypeHistory chargeHistory)
        {
            LastModifiedDate = DateTime.Now;
            AmountProduct = chargeHistory.AmountProduct;
            ChargeTypeDescription = chargeHistory.ChargeTypeDescription;
            CreditAccountId = chargeHistory.CreditAccountId;
            CreditAccountShort = chargeHistory.CreditAccountShort;
            CurrId = chargeHistory.CurrId;
            DefaultAmount = chargeHistory.DefaultAmount;
            FrequencyId = chargeHistory.FrequencyId;
            NextRunDay = chargeHistory.NextRunDay;
            PaymentDetail = chargeHistory.PaymentDetail;
            RunDay = chargeHistory.RunDay;
            GroupId = chargeHistory.GroupId;
        }
    }
}
