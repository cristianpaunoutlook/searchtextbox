﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ManualProcessSpResult
    {
        public int ChargeTypeId { get; set; }
        public string ChargeTypeCode { get; set; }
        public string Currency { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public int Payments { get; set; }
        public int PaymentsLastRun { get; set; }
        public decimal TotalRON { get; set; }
        public decimal TotalRONLastRun { get; set; }
        public DateTime? LastRunDay { get; set; }
        public DateTime? NextRunDay { get; set; }
        public int Enabled { get; set; }
        public int TotalItems { get; set; }
        public int TotalValidItems { get; set; }
    }
}
