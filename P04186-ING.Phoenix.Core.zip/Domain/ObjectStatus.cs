﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ObjectStatus
    {
        public byte ObjectStatusId { get; set; }

        public string ObjectStatusName { get; set; }

        public bool Visible { get; set; }
    }
}
