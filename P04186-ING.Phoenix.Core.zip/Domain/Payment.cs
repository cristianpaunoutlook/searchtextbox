﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class Payment
    {
        public int PaymentId { get; set; }
        public int ExportSessionId { get; set; }
        public virtual Session Session { get; set; }
        public virtual ApplicationLog ApplicationLog { get; set; }
        public int ChargeTypeId { get; set; }
        public virtual ChargeType ChargeType { get; set; }
        public int CurrencyId { get; set; }
        public virtual Currency Currency { get; set; }
        public decimal AmountDebited { get; set; }
        public string CustomerAtlasId { get; set; }
        public virtual CustomerDetails CustomerDetails { get; set; }
        public string CustomerName { get; set; }
        public string DebitAccount { get; set; }
        public string IBANDebitAccount { get; set; }
        public string DebitAccountDescription { get; set; }
        public string CreditAccount { get; set; }
        public string IBANCreditAccount { get; set; }
        public string CreditAccountDescription { get; set; }
        public string PaymentDetails { get; set; }
        public int Processed { get; set; }
        public string TRID { get; set; }
        public int? BaseCurrencyId { get; set; }
        public int? REF_ID_CCM { get; set; }
        public int? ChargeId { get; set; }
        public string RejectReason { get; set; }
    }
}
