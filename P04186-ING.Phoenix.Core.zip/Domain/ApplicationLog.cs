﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class ApplicationLog
    {
        public long ApplicationLogId { get; set; }
        public string UserId { get; set; }
        public int ActionId { get; set; }
        public int ObjectTypeId { get; set; }
        public string RecordId { get; set; }
        public int ErrorNumberId { get; set; }
        public DateTime RecordStamp { get; set; }
        public int SessionId { get; set; }
        public string Details { get; set; }
    }
}
