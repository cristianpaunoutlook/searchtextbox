﻿using System.Diagnostics.CodeAnalysis;

namespace Domain
{
    [ExcludeFromCodeCoverage]
    public class SecUserGroupRights
    {
        public int RightId { get; set; }
        public int GroupId { get; set; }
        public virtual UserGroup UserGroup { get; set; }
        public int PageId { get; set; }
        public virtual SecUserPage UserPage { get; set; }
        public int StatusId { get; set; }
        public virtual SecUserStatus Status { get; set; }
        public int? PageActionId { get; set; }
        public virtual SecObjectAction Page { get; set; }
    }
}
