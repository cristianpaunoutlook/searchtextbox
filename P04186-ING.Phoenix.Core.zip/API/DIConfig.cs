﻿using API.Helpers;
using Application.Authorization;
using Application.DboSession;
using Application.Interfaces;
using Application.Interfaces.Export;
using Application.Interfaces.Import;
using Application.Interfaces.ProcessPayment;
using Application.MapProfile;
using Application.ProcessPayment.RTPE;
using AutoMapper;
using Castle.Core.Internal;
using FluentValidation.AspNetCore;
using ImportFileInDb;
using ImportFileInDb.Interfaces;
using Infrastructure.Export;
using Infrastructure.Import;
using Infrastructure.Notifications;
using Infrastructure.Security;
using ING.Security;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Server.IISIntegration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Persistence;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Net;
using System.Net.Http;
using System.Text;

namespace API
{
    internal class DIConfig
    {
        public static void Setup(IServiceCollection services, IConfiguration configuration)
        {
            var decryptor = new SecurityService();

            services.AddHsts(options =>
           {
               options.Preload = true;
               options.IncludeSubDomains = true;
               options.MaxAge = TimeSpan.FromDays(730);
           });
            services.AddAuthentication(IISDefaults.AuthenticationScheme);
            services.AddDbContext<PhoenixContext>(opt =>
            {
                opt.UseSqlServer(decryptor.Decrypt(configuration.GetConnectionString("PhoenixCnn")),
                    sqlServerOptions => sqlServerOptions.CommandTimeout(int.Parse(configuration.GetSection("EFTimeout").Value)))
                    .UseLazyLoadingProxies();
            },
            ServiceLifetime.Transient
            );
            services.AddCors();
            services.AddScoped<IADUserGroups, ADUserGroups>();

            services.AddMediatR(assemblies: typeof(List.Handler).Assembly);

            services.AddAutoMapper(typeof(MappingProfile));

            services.AddSingleton<IAuthorizationPolicyProvider, GroupKeyPolicyProvider>();
            services.AddMemoryCache();
            services.AddSingleton<IAuthorizationHandler, GroupKeyAuthorizationHandler>();
            services.AddControllers()
                .AddNewtonsoftJson(x => x.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore)
                .AddFluentValidation(config => config.RegisterValidatorsFromAssemblyContaining<List>());

            var environmentStage = configuration.GetSection("EnvironmentStage").Value;
            if (!string.IsNullOrEmpty(environmentStage) && environmentStage == "ST")
            {
                    services.AddSwaggerGen(c =>
                {
                    // Existing configuration

                    // Tweak to the Schema generator
                    c.SchemaGeneratorOptions = new SchemaGeneratorOptions { SchemaIdSelector = type => type.FullName };
                });
            }
            services.AddScoped<IJWTGenerator, JWTGenerator>();
            services.AddScoped(typeof(IExportAsExcel<>), typeof(ExportAsExcel<>));

            var ignoreCertificateValidation = int.Parse(configuration["ignoreCertificateValidation"]);
            var userRTPE = decryptor.Decrypt(configuration.GetSection("RTPEUser").Value);
            var domain = configuration.GetSection("RTPEDomain").Value;
            var tokenRTPE = configuration.GetSection("RTPEToken").Value;


            if (ignoreCertificateValidation == 1)
            {
                services.AddHttpClient<IProcessPayment, RTPEProcessPayment>(client =>
                {
                    client.BaseAddress = new Uri(configuration["RTPEService"]);
                    client.DefaultRequestHeaders.Add("rtpe-token", tokenRTPE);
                }).ConfigurePrimaryHttpMessageHandler(() =>
                {
                    return new HttpClientHandler()
                    {
                        UseDefaultCredentials = true,
                        Credentials = new NetworkCredential(userRTPE, decryptor.Decrypt(configuration.GetSection("RTPEPassword").Value), domain),
                        ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true,
                    };
                });
            }
            else
            {
                services.AddHttpClient<IProcessPayment, RTPEProcessPayment>(client =>
                {
                    client.BaseAddress = new Uri(configuration["RTPEService"]);
                    client.DefaultRequestHeaders.Add("rtpe-token", tokenRTPE);
                }).ConfigurePrimaryHttpMessageHandler(() =>
                {
                    return new HttpClientHandler()
                    {
                        UseDefaultCredentials = true,
                        Credentials = new NetworkCredential(userRTPE, decryptor.Decrypt(configuration.GetSection("RTPEPassword").Value), domain)
                    };
                });
            }
            

            var emailConfig = configuration
                .GetSection("EmailConfiguration")
                .Get<EmailConfiguration>();
            services.AddSingleton(emailConfig);
            services.AddScoped<IEmailSender, EmailSender>();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            services.AddScoped(typeof(IImportFromExcel<>), typeof(ImportFromExcel<>));
            services.AddScoped<IFileImport>(conf =>
            {
                var log = conf.GetRequiredService<ILogger<FileImport>>();
                return new FileImport(log, decryptor.Decrypt(configuration.GetConnectionString("PhoenixCnn")));
            });
        }
    }
}
