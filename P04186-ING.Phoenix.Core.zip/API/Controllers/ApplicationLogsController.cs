﻿using Application.DboApplicationLog;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class ApplicationLogsController : PhoenixControllerBase
    {
        public ApplicationLogsController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger)
        {
        }

        [HttpGet]
        [Route("userswithsessions/{sessionType}")]
        public async Task<ActionResult<IReadOnlyList<string>>> Get(int sessionType)
            => await _mediator.Send(new UsersWithSessions.Query() { SessionType = sessionType });
    }
}