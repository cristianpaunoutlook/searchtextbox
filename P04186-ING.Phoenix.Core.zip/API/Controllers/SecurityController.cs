using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using Application.Security;
using Microsoft.Extensions.Logging;

namespace API.Controllers
{
    public class SecurityController : PhoenixControllerBase
    {
        public SecurityController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger){}

        [HttpGet]
        public async Task<ActionResult<IEnumerable<KeyValue>>> Get() => await _mediator.Send(new UserGroups.Query(){ User = User.Identity});

    }
}