﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Application.DboImportedPayments;
using Application.Parameter;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using List = Application.Parameter.List;

namespace API.Controllers
{
    public class ParametersController : PhoenixControllerBase
    {
        public ParametersController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger) { }

        [HttpGet("{paramName}")]
        public async Task<ActionResult<PhxParameter>> GetParameter(string paramName)
        {
            _logger.LogInformation($"Get parameter with name:{paramName}.");
            return await _mediator.Send(new GetParameter.Query() { ParamName = paramName });
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<PhxParameter>>> Get() => await _mediator.Send(new List.Query());
    }
}
