﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Application.DboCurrency;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace API.Controllers
{
    [ApiController]
    public class CurrenciesController : PhoenixControllerBase
    {
        public CurrenciesController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger) { }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Currency>>> Get() => await _mediator.Send(new List.Query());
    }
}
