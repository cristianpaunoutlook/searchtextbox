﻿using Application.Authorization;
using Application.DboCharge;
using Application.DboChargeType;
using Application.DboImportedPayments;
using Application.DTO;
using Application.Export.CIPReport;
using Application.Export.CustomerCharges;
using Application.Helpers;
using Application.PaymentsStatus;
using Application.Reports.CustomerCharges;
using Application.Reports.CustomerComments;
using Application.Reports.VatCharges;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class ReportsController : PhoenixControllerBase
    {
        public ReportsController(IMediator mediator, ILogger<ReportsController> logger) : base(mediator, logger) { }

        [HttpGet]
        [Route("customerchages")]
        [GroupKeyAuthorize("CCSR_1")]
        public async Task<ActionResult<PagedList<ChargeReportDTO>>> Get([FromQuery] Application.Reports.CustomerCharges.CustomerChargesFilter filter)
        {
            _logger.LogInformation($"Get customer charges report data for {filter.CustomerID}");
            return await _mediator.Send(new ListForReport.Query() { CustomerChargesFilter = filter });
        }

        [HttpGet]
        [Route("customerchages/actions")]
        [GroupKeyAuthorize("CCSR_1")]
        public async Task<ActionResult<IEnumerable<CustomerChargesActionDTO>>> GetActions()
        {
            return await _mediator.Send(new ListActionsForCustomerCharges.Query());
        }

        [HttpGet]
        [Route("customerchages/users")]
        [GroupKeyAuthorize("CCSR_1")]
        public async Task<ActionResult<IEnumerable<string>>> GetUsers()
        {
            return await _mediator.Send(new ListUsersForCustomerCharges.Query());
        }

        [HttpGet]
        [Route("vatcharges")]
        [GroupKeyAuthorize("VCR_1")]
        public async Task<ActionResult<PagedList<VatChargeReportDTO>>> Get([FromQuery] VatChargesFilter filter)
        {
            _logger.LogInformation($"Get VAT charges report data for {filter.CustomerId}");
            return await _mediator.Send(new ListForVatReport.Query() { VatChargesFilter = filter });
        }

        [HttpGet]
        [Route("listforchargetypehistoryreport")]
        [GroupKeyAuthorize("CTR_1")]
        public async Task<ActionResult<PagedList<ChargeTypeHistoryReportListDTO>>> ListForChargeTypeHistoryReport([FromQuery]ChargeTypeHistoryReportParams chargeTypeHistoryReportParams)
        {
            return await _mediator.Send(new ListForChargeTypeHistoryReport.Query() { ChargeTypeHistoryReportParams = chargeTypeHistoryReportParams });
        }

        [HttpGet]
        [Route("paymentsstatus")]
        [GroupKeyAuthorize("PSR_1")]
        public async Task<ActionResult<PagedList<PaymentsStatusReport>>> PaymentsStatus([FromQuery]PaymentsStatusReportParams PaymentsStatusReportParams)
        {
            return await _mediator.Send(new PaymentsStatusForReport.Query() { PaymentsStatusReportParams = PaymentsStatusReportParams });
        }

        [HttpGet]
        [Route("cip")]
        [GroupKeyAuthorize("CIP_1")]
        public async Task<ActionResult<PagedList<CipReportDTO>>> Cip([FromQuery]CipReportParams CipReportParams)
        {
            return await _mediator.Send(new CipReport.Query() { CipReportParams = CipReportParams });
        }

        [HttpGet]
        [Route("importedpaymentsreport")]
        [GroupKeyAuthorize("IPR_1")]
        public async Task<ActionResult<PagedList<ImportedPaymentsReportDTO>>> Get([FromQuery]ImportedPaymentsReportParams importedPaymentsReportParams)
        {
            return await _mediator.Send(new ImportedPaymentsForReport.Query() { ImportedPaymentsReportParams = importedPaymentsReportParams });
        }

        [HttpGet]
        [Route("customercomments")]
        [GroupKeyAuthorize("CCR_1")]
        public async Task<ActionResult<PagedList<CustomerCommentsDTO>>> Get([FromQuery] CustomerCommentsFilter filter)
        {
            _logger.LogInformation($"Get customer comments report data!");
            return await _mediator.Send(new ListForCustomerCommentsReport.Query() { CustomerCommentsFilter = filter });
        }

        [HttpGet]
        [Route("customercomments/users")]
        [GroupKeyAuthorize("CCR_1")]
        public async Task<ActionResult<IEnumerable<string>>> GetUsersForCustomerComments()
        {
            return await _mediator.Send(new ListUsersForCustomerComments.Query());
        }

        [HttpGet]
        [Route("SendCipNotification")]
        public async Task SendCipNotification()
        {
            var file = await _mediator.Send(new CIPReportDataToExcel.Query() { Title = "CIP Report", Filter = null });

            await _mediator.Send(new SendCipNotification.Command() { ReportFile = file });
        }

        [HttpGet]
        [Route("SendCustomerChargesNotification")]
        public async Task SendCustomerChargesNotification()
        {
            var file = await _mediator.Send(new CustomerChargesToExcel.Query()
            {
                Title = "Customer Charges Report",
                Filter = new Application.Export.CustomerCharges.CustomerChargesFilter
                {
                    ChargeTypeId = -1,
                    StatusId = -1,
                    IsForChargeNotification = true
                }
            });

            await _mediator.Send(new SendChargesNotification.Command() { ReportFile = file });
        }
    }
}
