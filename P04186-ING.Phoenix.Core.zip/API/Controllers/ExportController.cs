﻿using Application.Export.ChargeTypeHistoryReport;
using Application.Export.ChargeTypes;
using Application.Export.CIPReport;
using Application.Export.CustomerCharges;
using Application.Export.CustomerChargesReport;
using Application.Export.Groups;
using Application.Export.ImportedPayments;
using Application.Export.ImportedPaymentsReport;
using Application.Export.PaymentStatusReport;
using Application.Export.VatChargesReport;
using Application.Helpers;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace API.Controllers
{

    public class ExportController : PhoenixControllerBase
    {
        public ExportController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger) { }

        [HttpGet]
        [Route("chargetypes/excel")]
        public async Task<ActionResult> GetExcelAsync([FromQuery]ChargeTypesFilter filter)
        {
            var file = await _mediator.Send(new ChargeTypesToExcel.Query() { Title = "Charge Types Report", Filter = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("customercharges/excel")]
        public async Task<ActionResult> GetExcelAsync([FromQuery]CustomerChargesFilter filter)
        {
            var file = await _mediator.Send(new CustomerChargesToExcel.Query() { Title = "Customer Charges Report", Filter = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("importedPayments/excel")]
        public async Task<ActionResult> GetExcelAsync([FromQuery]ImportedPaymentsFilter filter)
        {
            var file = await _mediator.Send(new ImportedPaymentsToExcel.Query() { Title = "Imported Payments Report", Filter = filter, UserId = GetUserName() });
            return Ok(file);
        }

        [HttpGet]
        [Route("manualprocessingchargetypes/excel")]
        public async Task<ActionResult> GetExcel([FromQuery]ManualProcessParams filter)
        {
            var file = await _mediator.Send(new ManualProcessingChargeTypesToExcel.Query() { Title = "Manual Processing Charge Types Report", Filter = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("groups/excel")]
        public async Task<ActionResult> GetExcel()
        {
            var file = await _mediator.Send(new GroupsPagesRightsToExcel.Query() { Title = "Groups Pages Rights Report" });
            return Ok(file);
        }

        [HttpGet]
        [Route("reports/customerchages/excel")]
        public async Task<ActionResult> GetExcel([FromQuery] Application.Reports.CustomerCharges.CustomerChargesFilter filter)
        {
            var file = await _mediator.Send(new CustomerChargesHistoryToExcel.Query() { Title = "Customer Charges History Report", Filter = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("reports/vatcharges/excel")]
        public async Task<ActionResult> GetExcel([FromQuery] Application.Reports.VatCharges.VatChargesFilter filter)
        {
            var file = await _mediator.Send(new VatChargesToExcel.Query() { Title = "VAT Charges", Filter = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("chargetypehistoryreport/excel")]
        public async Task<ActionResult> GetExcel([FromQuery]ChargeTypeHistoryReportFilter filter)
        {
            var file = await _mediator.Send(new ChargeTypeHistoryReportToExcel.Query() { Title = "Charge Type History Report", Filter = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("paymentsstatus/excel")]
        public async Task<ActionResult> GetPaymentsStatusExcel([FromQuery]PaymentsStatusReportParams PaymentsStatusReportParams)
        {
            var file = await _mediator.Send(new PaymentsStatusReportToExcel.Query() { Title = "PaymentStatus", Filter = PaymentsStatusReportParams });
            return Ok(file);
        }

        [HttpGet]
        [Route("cip/excel")]
        public async Task<ActionResult> GetCipExcel([FromQuery]CipReportParams cipReportParams)
        {
            var file = await _mediator.Send(new CIPReportDataToExcel.Query() { Title = "CIP Report", Filter = cipReportParams });
            return Ok(file);
        }
        
        [HttpGet]
        [Route("importedpaymentsreport/excel")]
        public async Task<ActionResult> GetExcel([FromQuery]ImportedPaymentsReportParams filter)
        {
            var file = await _mediator.Send(new ImportedPaymentsReportToExcel.Query() { Title = "Imported Payments Report", Filter = filter });
            return Ok(file);
        }

        [HttpGet]
        [Route("reports/customercommentsreport/excel")]
        public async Task<ActionResult> GetExcel([FromQuery]Application.Reports.CustomerComments.CustomerCommentsFilter filter)
        {
            var file = await _mediator.Send(new CustomerCommentsReportToExcel.Query() { Title = "Customer Comments", Filter = filter });
            return Ok(file);
        }
    }

}
