﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain;
using Application.DboMailList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;


namespace API.Controllers
{
    [ApiController]
    public class MailListController : PhoenixControllerBase
    {

        public MailListController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger) { }

        [HttpGet]   
        public async Task<ActionResult<IEnumerable<MailList>>> GetMailList()
               => Ok(await _mediator.Send(new List.Query()));

    }
}
