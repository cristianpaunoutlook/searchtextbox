﻿using Application.DboObjectStatus;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class ObjectStatusController : PhoenixControllerBase
    {
        public ObjectStatusController(IMediator mediator, ILogger<ObjectStatusController> logger) : base(mediator, logger) { }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ObjectStatus>>> Get() => await _mediator.Send(new List.Query());

        [HttpGet]
        [Route("waitingforapproval")]
        public async Task<ActionResult<IEnumerable<ObjectStatus>>> GetWaitingApprovalStatus() => await _mediator.Send(new WaitingApprovalList.Query());

        [HttpGet]
        [Route("listforchargetypehistoryreport")]
        public async Task<ActionResult<IEnumerable<ObjectStatus>>> GetListForChargeTypeHistoryReport() => await _mediator.Send(new ListForChargeTypeHistoryReport.Query());

    }
}