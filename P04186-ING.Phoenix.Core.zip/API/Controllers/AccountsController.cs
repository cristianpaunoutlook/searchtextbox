﻿using Application.DboAccount;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class AccountsController : PhoenixControllerBase
    {
        public AccountsController(IMediator mediator, ILogger<AccountsController> logger) : base(mediator, logger) { }

        [HttpGet("{customerId}")]
        public async Task<ActionResult<IEnumerable<string>>> ListIbanForChargeCreate(string customerId)
          => Ok(await _mediator.Send(new ListIbanForChargeCreate.Query() { CustomerId = customerId }));

        [HttpGet]
        [Route("listforaccountshortvalidation/{coreBanking}")]
        public async Task<ActionResult<IEnumerable<string>>> ListForAccountShortValidation(string coreBanking)
          => Ok(await _mediator.Send(new ListForAccountShortValidation.Query() { CoreBanking = coreBanking }));

        [HttpGet]
        [Route("branches")]
        public async Task<ActionResult<IEnumerable<string>>> Brances() => Ok(await _mediator.Send(new BranchList.Query()));
    }
}