﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Application.DboImportedPayments;
using Application.DTO;
using Application.Helpers;
using Application.PosFlow;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace API.Controllers
{
    public class ImportedPaymentsController : PhoenixControllerBase
    {
        public ImportedPaymentsController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger) { }

        private async Task<ActionResult<Unit>> PosFlow()
        {
            _logger.LogInformation("Starting POS Flow");
            return await _mediator.Send(new PosFlow.Command() { UserId = "System" });
        }

        [HttpGet]
        [Route("importedfile")]
        public async Task<ActionResult<ImportedPaymentsListDTO>> List([FromQuery]ImportedPaymentsParams importedPaymentsParams) =>
            await _mediator.Send(new List.Query() { ImportedPaymentsParams = importedPaymentsParams, UserId = GetUserName() });

        [HttpPost]
        public async Task<ActionResult<ImportedPaymentsListDTO>> ImportFile()
        {
            _logger.LogInformation($"Upload file: {Request.Form.Files[0].FileName}");
            var mailId = int.Parse( Request.Form["mailId"]);
            await _mediator.Send(new ImportFile.Command() { FileToImport = Request.Form.Files[0], UserId = GetUserName(), MailId = mailId});
            return await _mediator.Send(new List.Query()
            {
                ImportedPaymentsParams = new ImportedPaymentsParams()
                {
                    SessionId = 0,
                    Imported = 0
                },
                UserId = GetUserName()
            });
        }

        [HttpGet]
        [Route("listchargecodeimportedpaymentsreport")]
        public async Task<ActionResult<IEnumerable<string>>> ListChargeCodeForImportedPaymentsReport()
         => Ok(await _mediator.Send(new ListChargeCodeForImportedPaymentsReport.Query()));
    }
}
