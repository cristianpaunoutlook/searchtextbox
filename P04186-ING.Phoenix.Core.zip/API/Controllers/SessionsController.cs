﻿using System.Threading.Tasks;
using Application.DboSession;
using Application.DTO;
using Application.Helpers;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace API.Controllers
{
    public class SessionsController : PhoenixControllerBase
    {
        public SessionsController(IMediator mediator, ILogger<SessionsController> logger) : base(mediator, logger) { }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<PagedList<Session>>> Get([FromQuery]SessionParams sessionParams)
            => await _mediator.Send(new List.Query() { SessionParams = sessionParams });

        [HttpGet("{id}")]
        public async Task<ActionResult<SessionDTO>> Details(int id)
        {
            _logger.LogInformation($"get session with id {id}");
            return await _mediator.Send(new Details.Query() { Id = id });
        }
        [HttpPut]
        public async Task<ActionResult<Unit>> Edit(Edit.Command command) => await _mediator.Send(command);

        [HttpPost]
        public async Task<ActionResult<Unit>> Create(Create.Command command) => await _mediator.Send(command);

        [HttpDelete("{id}")]
        public async Task<ActionResult<Unit>> Delete(int Id) => await _mediator.Send(new Delete.Command() { SessionId = Id });

    }
}
