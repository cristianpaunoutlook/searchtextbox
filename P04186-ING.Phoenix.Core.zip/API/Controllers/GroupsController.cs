﻿using System.Collections.Generic;
using Application.Authorization;
using System.Threading.Tasks;
using Application.DboGroup;
using Application.DTO;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Domain;

namespace API.Controllers
{
    public class GroupsController : PhoenixControllerBase
    {
        public GroupsController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger)
        {
        }

        [HttpGet]
        [Route("pagesrights/{groupId}")]
        [GroupKeyAuthorize("SEC_1")]
        public async Task<ActionResult<IEnumerable<GroupPagesRightsDTO>>> PagesRights(int groupId)
            => Ok(await _mediator.Send(new RightsList.Query(){ GroupId = groupId }));

        [HttpPut]
        [Route("update")]
        [GroupKeyAuthorize("SEC_2")]
        public async Task<ActionResult<Unit>> Edit(GroupPagesRightsDTO[] rightsToUpdate)
        {
            var command = new UpdateRights.Command() { UserKey = GetUserName(), RightsToUpdate = rightsToUpdate, SessionId = GetSession() };
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("approve")]
        [GroupKeyAuthorize("SEC_3")]
        public async Task<ActionResult<Unit>> Approve(Approve.Command command)
        {
            command.UserKey = GetUserName();
            command.SessionId = GetSession();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("reject")]
        [GroupKeyAuthorize("SEC_3")]
        public async Task<ActionResult<Unit>> Reject(Reject.Command command)
        {
            command.UserKey = GetUserName();
            command.SessionId = GetSession();
            return await _mediator.Send(command);
        }

        [HttpGet]
        [GroupKeyAuthorize("SEC_1")]
        public async Task<ActionResult<GroupsDTO>> Get() => await _mediator.Send(new List.Query() {  });

        [HttpPost]
        [GroupKeyAuthorize("SEC_2")]
        public async Task<ActionResult<Group>> Create([FromBody] Create.Command command)
        {
            command.LastModifiedBy = GetUserName();
            command.SessionId = GetSession();
            return await _mediator.Send(command);
        }
        
        [HttpDelete("{id}")]
        [GroupKeyAuthorize("SEC_2")]
        public async Task<ActionResult<Unit>> Delete(int Id) => await _mediator.Send(new Delete.Command() { GroupId = Id, LastModifiedBy = GetUserName(), SessionId = GetSession() });

    }
}
