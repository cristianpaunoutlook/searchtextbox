﻿using Application.ImportFile;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace API.Controllers
{

    public class ImportFileController : PhoenixControllerBase
    {
        public ImportFileController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger) { }

        [HttpGet]
        [Route("ImportAnafFile")]
        public async Task<ActionResult<Unit>> ImportAnafFile()
        {
            return await _mediator.Send(new ImportAnafFile.Command() { });
        }
    }
}