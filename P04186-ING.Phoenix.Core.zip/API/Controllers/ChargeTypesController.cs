﻿using Application.Authorization;
using Application.DboApplicationLog;
using Application.DboChargeType;
using Application.DboSession;
using Application.DTO;
using Application.Helpers;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class ChargeTypesController : PhoenixControllerBase
    {
        public ChargeTypesController(IMediator mediator, ILogger<ChargeTypesController> logger) : base(mediator, logger) { }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<PagedList<ChargeTypeListDTO>>> Get([FromQuery]ChargeTypeParams chargeTypeParams)
            => await _mediator.Send(new Application.DboChargeType.List.Query() { ChargeTypeParams = chargeTypeParams });

        [HttpGet]
        [Route("listforcharge")]
        public async Task<ActionResult<IEnumerable<ChargeTypeDropDownDTO>>> ListForCharge()
            => Ok(await _mediator.Send(new ListForCharge.Query()));

        [HttpGet]
        [Route("listforvatchargesReport")]
        public async Task<ActionResult<IEnumerable<ChargeTypeDropDownDTO>>> ListForVatCharge()
            => Ok(await _mediator.Send(new ListForVatCharge.Query()));

        [HttpGet]
        [Route("listforpaymentsReport")]
        public async Task<ActionResult<IEnumerable<ChargeTypeDropDownDTO>>> ListForPaymentsReport()
            => Ok(await _mediator.Send(new ListForPaymentsReport.Query()));

        [HttpGet]
        [Route("bydepartment/{department}")]
        public async Task<ActionResult<IEnumerable<ChargeTypeDropDownDTO>>> ListByDepartment(string department)
            => Ok(await _mediator.Send(new ListByDepartment.Query() { Department = department }));

        [HttpGet]
        [Route("listforchargeverification")]
        public async Task<ActionResult<IEnumerable<ChargeTypeWithDescriptionDdlDTO>>> ListForChargeVerification()
            => Ok(await _mediator.Send(new ListForChargeVerification.Query()));

        [HttpGet]
        [Route("corebanking/{coreBanking}")]
        public async Task<ActionResult<IEnumerable<ChargeTypeForChargeCreateDTO>>> ListForChargeCreate(string coreBanking)
          => Ok(await _mediator.Send(new ListForChargeCreate.Query() { CoreBanking = coreBanking }));

        [HttpPut]
        [GroupKeyAuthorize("CHT_2")]
        public async Task<ActionResult<Unit>> Edit(Application.DboChargeType.Edit.Command command)
        {
            command.LastModifiedBy = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPost]
        [GroupKeyAuthorize("CHT_2")]
        public async Task<ActionResult<Unit>> Create([FromBody] Application.DboChargeType.Create.Command command)
        {
            command.LastModifiedBy = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpDelete("{id}")]
        [GroupKeyAuthorize("CHT_2")]
        public async Task<ActionResult<Unit>> Delete(int Id) => await _mediator.Send(new Application.DboChargeType.Delete.Command() { ChargeTypeId = Id, LastModifiedBy = GetUserName() });

        [HttpPut]
        [Route("approve")]
        [GroupKeyAuthorize("CHT_3")]
        public async Task<ActionResult<Unit>> Approve(Approve.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("reject")]
        [GroupKeyAuthorize("CHT_3")]
        public async Task<ActionResult<Unit>> Reject(Reject.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpGet]
        [Route("listformanualprocessing")]
        public async Task<ActionResult<PagedChargeTypeForManualProcessing>> ListForManualProcessing([FromQuery]ManualProcessParams manualProcessParams)
            => Ok(await _mediator.Send(new ListForManualProcessing.Query() { ManualProcessParams = manualProcessParams }));

        [HttpPost]
        [Route("processchargetypes")]
        public async Task<ProcessChargesResultDTO> ProcessChargeTypes([FromBody] ProcessChargeTypeDTO chargeTypesToProcess)
        {
            var response = await _mediator.Send(new ProcessChargeTypes.Query()
            {
                ChargeTypeIds = chargeTypesToProcess.ChargeTypeIds,
                Filter = chargeTypesToProcess.Filter
            });

            var sessionInfo = await _mediator.Send(new SessionInfo.Query());
            await _mediator.Send(new UpdateExportSession.Command() { SessionId = response.SessionId, UserKey = GetUserName() });

            if (sessionInfo.Count() == 0)
            {
                _logger.LogInformation($"No payments to process!");
                return new ProcessChargesResultDTO()
                {
                    SessionInfo = null,
                    ProcessResponse = new ProcessResponseDTO { SessionId = 0, Response = "No payments to process!" }
                };
            }

            await _mediator.Send(new ManualProcessNotification.Command()
            {
                SessionId = response.SessionId,
                SessionInfo = sessionInfo,
                UserKey = GetUserName()
            });

            return new ProcessChargesResultDTO()
            {
                SessionInfo = sessionInfo,
                ProcessResponse = response
            };
        }

        [HttpGet]
        [Route("sessioninfo")]
        public async Task<IEnumerable<SessionInfoDTO>> ExportChargeTypeSessionInfo() => await _mediator.Send(new SessionInfo.Query());

        [HttpGet]
        [Route("listforchargetypehistoryreportfilter")]
        public async Task<ActionResult<IEnumerable<ChargeTypeDropDownDTO>>> ListForChargeTypeHistoryReportFilter()
            => Ok(await _mediator.Send(new ListForChargeTypeHistoryReportFilter.Query()));

        [HttpGet]
        [Route("listuserschargetypehistoryreport")]
        public async Task<ActionResult<IEnumerable<ChargeTypeDropDownDTO>>> ListUsersForChargeTypeHistoryReport()
         => Ok(await _mediator.Send(new ListUsersForChargeTypeHistoryReport.Query()));

        [HttpGet]
        [Route("listactionschargetypehistoryreport")]
        public async Task<ActionResult<IEnumerable<ActionDropDownDTO>>> ListActionsForChargeTypeHistoryReport()
         => Ok(await _mediator.Send(new ListActionsForChargeTypeHistoryReport.Query()));
    }
}