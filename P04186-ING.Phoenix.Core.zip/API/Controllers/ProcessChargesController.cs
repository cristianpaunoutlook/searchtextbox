﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.DboChargeType;
using Application.DboSession;
using Application.DTO;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProcessChargesController : PhoenixControllerBase
    {
        public ProcessChargesController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger) { }

        [HttpGet]
        [Route("ExportByRunDay")]
        public async Task<ProcessChargesResultDTO> ExportByRunDay()
        {
            var response = await _mediator.Send(new ProcessByRunDay.Query());
            return await GetResponseInfo(response, true);
        }

        [HttpGet]
        [Route("ExportForJobBased")]
        public async Task<ProcessChargesResultDTO> ExportForJobBased()
        {
            var response = await _mediator.Send(new ProcessJobBased.Query());
            return await GetResponseInfo(response, false);
        }

        [HttpGet]
        [Route("ExportByIds/{chargeTypeIds}")]
        public async Task<ProcessChargesResultDTO> ExportByIds(string chargeTypeIds)
        {
            var response = await _mediator.Send(new ProcessChargeTypesByIds.Query() { ChargeTypeIds = chargeTypeIds });
            return await GetResponseInfo(response, false);
        }

        private async Task<ProcessChargesResultDTO> GetResponseInfo(ProcessResponseDTO response, bool sendNotification)
        {
            if (response == null)
            {
                _logger.LogInformation($"No charges to process today: {DateTime.Now}");
                return new ProcessChargesResultDTO()
                {
                    SessionInfo = null,
                    ProcessResponse = new ProcessResponseDTO { SessionId = 0, Response = "No payments to process!" }
                };
            }


            var sessionInfo = await _mediator.Send(new SessionInfo.Query());

            if (sessionInfo.Count() == 0)
            {
                _logger.LogInformation($"No payments to process!");
                return new ProcessChargesResultDTO()
                {
                    SessionInfo = null,
                    ProcessResponse = new ProcessResponseDTO { SessionId = 0, Response = "No payments to process!" }
                };
            }

            if (sendNotification)
            {
                await _mediator.Send(new ManualProcessNotification.Command()
                {
                    SessionId = response.SessionId,
                    SessionInfo = sessionInfo,
                    UserKey = "SYSTEM"
                });
            }
            

            return new ProcessChargesResultDTO()
            {
                SessionInfo = sessionInfo,
                ProcessResponse = response
            };
        }
    }
}