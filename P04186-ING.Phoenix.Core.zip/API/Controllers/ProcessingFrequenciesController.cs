﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Application.DboProcessingFrequency;
using Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace API.Controllers
{
    public class ProcessingFrequenciesController : PhoenixControllerBase
    {
        public ProcessingFrequenciesController(IMediator mediator, ILogger<ProcessingFrequenciesController> logger) : base(mediator, logger) { }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProcessingFrequency>>> Get() => await _mediator.Send(new List.Query());
    }
}
