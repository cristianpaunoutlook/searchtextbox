﻿using System.Threading.Tasks;
using Application.DboCustomers;
using Application.DTO;
using Application.Helpers;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace API.Controllers
{
    public class CustomersController : PhoenixControllerBase
    {
        public CustomersController(IMediator mediator, ILogger<ControllerBase> logger) : base(mediator, logger) { }

        [HttpGet]
        public async Task<ActionResult<PagedList<CustomerListDTO>>> Get([FromQuery]CustomerParams customersParams)
            => await _mediator.Send(new List.Query() { CustomerParams = customersParams });

        [HttpPut]
        public async Task<ActionResult<Unit>> SaveComments(SaveComments.Command command)
        {
            command.LastModifiedBy = GetUserName();
            return await _mediator.Send(command);
        }
    }
}
