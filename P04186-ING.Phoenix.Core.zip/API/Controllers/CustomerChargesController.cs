﻿using Application.Authorization;
using Application.DboCharge;
using Application.DTO;
using Application.Helpers;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Controllers
{
    public class CustomerChargesController : PhoenixControllerBase
    {
        public CustomerChargesController(IMediator mediator, ILogger<CustomerChargesController> logger) : base(mediator, logger) { }

        [HttpGet("{customerId}")]
        public async Task<ActionResult<CustomerChargesDTO>> Get(string customerId)
        {
            _logger.LogInformation($"Get customer charges for {customerId}");
            return await _mediator.Send(new List.Query() { CustomerId = customerId });
        }

        [HttpDelete("{id}")]
        [GroupKeyAuthorize("CCH_2")]
        public async Task<ActionResult<Unit>> Delete(int Id) => await _mediator.Send(new Delete.Command() { ChargeId = Id, LastModifiedBy = GetUserName() });

        [HttpPost]
        [GroupKeyAuthorize("CCH_2")]
        public async Task<ActionResult<Unit>> Create([FromBody] Create.Command command)
        {
            command.LastModifiedBy = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [GroupKeyAuthorize("CCH_2")]
        public async Task<ActionResult<Unit>> Edit(Edit.Command command)
        {
            command.LastModifiedBy = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("approve")]
        [GroupKeyAuthorize("CCH_3")]
        public async Task<ActionResult<Unit>> Approve(Approve.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpPut]
        [Route("reject")]
        [GroupKeyAuthorize("CCH_3")]
        public async Task<ActionResult<Unit>> Reject(Reject.Command command)
        {
            command.UserKey = GetUserName();
            return await _mediator.Send(command);
        }

        [HttpGet]
        [Route("verification")]
        public async Task<PagedList<ChargeValidationDTO>> ChargeVerificationList([FromQuery]ValidationParams validationParams)
        {
            return await _mediator.Send(new Verification.Query() { ValidationParams = validationParams, UserKey = GetUserName() });
        }

        [HttpGet]
        [Route("chargedetails/{chargeID}")]
        public async Task<ActionResult<ChargeDTO>> ChargeDetails(int chargeId)
        {
            _logger.LogInformation($"Get charge details for charge with id: {chargeId}");
            return await _mediator.Send(new ChargeDetails.Query() { ChargeId = chargeId });
        }

        [HttpGet]
        [Route("listusersforchargeverification")]
        public async Task<ActionResult<IEnumerable<string>>> ListUsersForChargeVerification()
            => Ok(await _mediator.Send(new ListUsersForChargeVerification.Query() { UserKey = GetUserName() }));

        [HttpPut]
        [Route("bulkapprove")]
        [GroupKeyAuthorize("CCH_3")]
        public async Task<ActionResult<int>> BulkApprove([FromBody] ChargesVerification charge)
        {
            return await _mediator.Send(new BulkApprove.Query()
            {
                ChargeIds = charge.ChargeIds,
                Filter = charge.Filter,
                ListToExclude = charge.ListToExclude,
                UserKey = GetUserName()
            });
        }

        [HttpPut]
        [Route("bulkreject")]
        [GroupKeyAuthorize("CCH_3")]
        public async Task<ActionResult<int>> BulkReject([FromBody] ChargesVerification charge)
        {
            return await _mediator.Send(new BulkReject.Query()
            {
                ChargeIds = charge.ChargeIds,
                Filter = charge.Filter,
                ListToExclude = charge.ListToExclude,
                RejectReason = charge.RejectReason,
                UserKey = GetUserName()
            });
        }
    }
}
