using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Application.Errors;
using System.Text.Json;
using System.Collections.Generic;
using Application.SECUserLog;
using Application.Commons.Constants;
using MediatR;

namespace API.Middleware
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ErrorHandlingMiddleware> _logger;
        private readonly IMediator _mediator;

        public ErrorHandlingMiddleware(RequestDelegate next,
            ILogger<ErrorHandlingMiddleware> logger,
            IMediator mediator)
        {
            _next = next;
            _logger = logger;
            _mediator = mediator;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception ex)
        {
            object errors = null;
            switch (ex)
            {
                case RestException re:
                    _logger.LogError(ex, "REST ERROR");
                    context.Response.StatusCode = (int)re.StatusCode;
                    await LogLoginFailed(context, re);
                    errors = re.Errors;
                    break;
                case Exception exception:
                    _logger.LogError(ex, "SERVER ERROR");
                    errors = "Internal Server Error!";
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    break;
            }

            if (errors != null)
            {
                context.Response.ContentType = "application/json";
                var result = JsonSerializer.Serialize(new
                {
                    statusCode = context.Response.StatusCode,
                    errors
                });

                await context.Response.WriteAsync(result);
            }
        }

        private async Task LogLoginFailed(HttpContext context, RestException re)
        {
            if (re.StatusCode == HttpStatusCode.Unauthorized)
            {
                var user = context.User.Identity.Name;
                var corporateKey = user.Substring(user.Length - Constants.CORPORATE_KEY_LENGTH).ToUpper();
                var ip = context.Connection.RemoteIpAddress.ToString();
                context.Response.StatusCode = (int)HttpStatusCode.Forbidden;
                var secUserLog = new InvalidLogin.Command()
                {
                    IP = ip,
                    UserId = corporateKey,
                    Workstation = ip
                };
                await _mediator.Send(secUserLog);
            }
        }
    }
}