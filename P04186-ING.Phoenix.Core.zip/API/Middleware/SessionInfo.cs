﻿using System;
using System.Threading.Tasks;
using Application.Commons.Constants;
using Application.Interfaces;
using Application.SECSession;
using Application.Security;
using Application.SECUserLog;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace API.Middleware
{
    public class SessionInfo
    {
        private readonly RequestDelegate _next;
        private readonly IMediator _mediator;
        private readonly IJWTGenerator _jwtGenerator;
        private readonly IConfiguration _configuration;
        private readonly ILogger<SessionInfo> _logger;

        public SessionInfo(RequestDelegate next,
            IMediator mediator,
            IJWTGenerator jwtGenerator,
            IConfiguration configuration,
            ILogger<SessionInfo> logger)
        {
            _next = next;
            _mediator = mediator;
            _jwtGenerator = jwtGenerator;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            if (context.Request.Path.ToString().Contains("/api/") && !context.Request.Path.ToString().Contains("/api/sessionexpired"))
            {
                await WriteSessionInfo(context);
            }

            await _next(context);
        }

        private async Task WriteSessionInfo(HttpContext context)
        {
            var jwtSecKey = _configuration.GetSection("JWTSecurytyKey").Value;
            var jwtHeaderKey = _configuration.GetSection("jwtHeaderKey").Value;
            var sessionMinExpiration = int.Parse(_configuration.GetSection("WebSessionExpirationMinutes").Value);
            var user = context.User.Identity;
            if (context.Request.Headers.ContainsKey(jwtHeaderKey) && context.Request.Headers.ContainsKey("SessionId") &&
                DateTime.Compare(_jwtGenerator.GetExpirationDate(jwtSecKey, jwtHeaderKey), DateTime.Now) == 1)
            {
                var headerSession = context.Request.Headers["SessionId"];
                var sessionId = _jwtGenerator.GetSessionId(jwtSecKey, jwtHeaderKey);
                if (headerSession != sessionId)
                    throw new UnauthorizedAccessException("Invalid session!");
                var rights = await _mediator.Send(new UserGroups.Query() { User = user });
                context.Response.Headers.Add(jwtHeaderKey, _jwtGenerator.RefreshToken(jwtSecKey, sessionMinExpiration, jwtHeaderKey, rights));
                context.Response.Headers.Add("SessionId", context.Request.Headers["SessionId"]);
            }
            else
            {
                var corporateKey = user.Name.Substring(user.Name.Length - Constants.CORPORATE_KEY_LENGTH).ToUpper();
                var claims = await _mediator.Send(new UserGroups.Query() { User = user });
                var lastSession = await _mediator.Send(new LastSession.Query() { CorporateKey = corporateKey });
                claims.Add(new KeyValue() { Key = "lastLoginDate", Value = (lastSession != null) ? lastSession.SessionDate.ToString("MMM dd yyyy h:mmtt") : "" });
                claims.Add(new KeyValue() { Key = "lastLoginIP", Value = (lastSession != null) ? lastSession.IP.ToString() : "" });
                var sessionId = Guid.NewGuid().ToString().Replace("-", "");
                claims.Add(new KeyValue() { Key = "SessionId", Value = sessionId });
                var jwtToken = _jwtGenerator.CreateToken(claims, jwtSecKey, sessionMinExpiration);
                string ipAddress = context.Connection.RemoteIpAddress.ToString();
                await _mediator.Send(
                    new Create.Command()
                    {
                        UserId = corporateKey,
                        IP = ipAddress,
                        Workstation = ipAddress,
                        Session = sessionId
                    });
                await _mediator.Send(
                    new LogIn.Command()
                    {
                        UserId = corporateKey,
                        IP = ipAddress,
                        Workstation = ipAddress,
                        SessionId = sessionId
                    });
                context.Response.Headers.Add(jwtHeaderKey, jwtToken);
                context.Response.Headers.Add("SessionId", sessionId);
            }
        }
    }
}
