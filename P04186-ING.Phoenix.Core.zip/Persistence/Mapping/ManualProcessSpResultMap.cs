﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ManualProcessSpResultMap : IEntityTypeConfiguration<ManualProcessSpResult>
    {
        public void Configure(EntityTypeBuilder<ManualProcessSpResult> builder)
        {
            builder.HasKey(p => p.ChargeTypeId);
        }
    }
}
