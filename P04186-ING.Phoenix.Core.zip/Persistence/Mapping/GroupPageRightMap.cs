﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class GroupPageRightMap : IEntityTypeConfiguration<GroupPageRight>
    {
        public void Configure(EntityTypeBuilder<GroupPageRight> builder)
        {
            builder.ToTable("GroupsPagesRights");
            builder.HasKey(o => new { o.GroupId, o.PageId });
        }
    }
}
