﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class DlfilesTblNonWorkingDaysMap : IEntityTypeConfiguration<DlfilesTblNonWorkingDays>
    {
        public void Configure(EntityTypeBuilder<DlfilesTblNonWorkingDays> builder)
        {
            builder
                .ToTable("tblNonWorkingDays", "dlfiles")
                .HasKey(t => t.Date);
        }
    }
}
