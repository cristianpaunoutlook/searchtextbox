﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ProcedureResultMap : IEntityTypeConfiguration<ProcedureResult>
    {
        public void Configure(EntityTypeBuilder<ProcedureResult> builder)
        {
            builder.HasKey(p => p.CountModifiedCharges);
        }
    }
}
