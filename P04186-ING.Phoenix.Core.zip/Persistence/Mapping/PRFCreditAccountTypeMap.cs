﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class PRFCreditAccountTypeMap : IEntityTypeConfiguration<PRFCreditAccountType>
    {
        public void Configure(EntityTypeBuilder<PRFCreditAccountType> builder)
        {
            builder.ToTable("PRFCreditAccountType")
                .HasKey(ca => new { ca.CifTypeId, ca.Code });
        }
    }
}
