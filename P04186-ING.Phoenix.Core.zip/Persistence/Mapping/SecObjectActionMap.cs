﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    class SecObjectActionMap : IEntityTypeConfiguration<SecObjectAction>
    {
        public void Configure(EntityTypeBuilder<SecObjectAction> builder)
        {
            builder
                .ToTable("ObjectAction", "sec")
                .HasKey(oa => oa.ActionId);
            builder
                .Property(oa => oa.ActionId)
                .ValueGeneratedOnAdd()
                .IsRequired();
            builder
                .Property(oa => oa.ActionId)
                .HasColumnType("SMALLINT");
        }
    }
}
