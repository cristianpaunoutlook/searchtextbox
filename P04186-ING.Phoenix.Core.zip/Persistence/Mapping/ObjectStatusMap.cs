﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ObjectStatusMap : IEntityTypeConfiguration<ObjectStatus>
    {
        public void Configure(EntityTypeBuilder<ObjectStatus> builder)
        {
            builder.ToTable("ObjectStatus");
            builder.HasKey(p => p.ObjectStatusId);
        }
    }
}
