﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class DeletedChargeHistoryMap : IEntityTypeConfiguration<DeletedChargeHistory>
    {
        public void Configure(EntityTypeBuilder<DeletedChargeHistory> builder)
        {
            builder.ToTable("DeletedChargeHistory");
            builder.HasKey(dch => dch.DeletedChargeHistoryId);
            builder.Property(dch => dch.SpecialAmount).HasColumnType("decimal");
            builder.Property(dch => dch.ActionId).HasColumnType("SMALLINT");
        }
    }
}
