﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class SecUserGroupRightsMap : IEntityTypeConfiguration<SecUserGroupRights>
    {
        public void Configure(EntityTypeBuilder<SecUserGroupRights> builder)
        {
            builder
                .ToTable("UserGroupRights", "sec")
                .HasKey(ugr => ugr.RightId);
            builder
                .Property(ugr => ugr.RightId)
                .ValueGeneratedOnAdd()
                .IsRequired();
            builder
                .Property(ugr => ugr.RightId)
                .HasColumnType("SMALLINT");
            builder
                 .Property(ugr => ugr.GroupId)
                 .HasColumnType("SMALLINT");
            builder
                 .Property(ugr => ugr.PageId)
                 .HasColumnType("SMALLINT");
            builder
                 .Property(ugr => ugr.StatusId)
                 .HasColumnType("SMALLINT");
            builder
                .Property(ugr => ugr.PageActionId)
                .HasColumnType("SMALLINT");

            builder.HasOne(ugr => ugr.UserPage).WithMany().HasForeignKey(ugr=>ugr.PageId);
            builder.HasOne(ugr => ugr.UserGroup).WithMany().HasForeignKey(ugr=>ugr.GroupId);
            builder.HasOne(ugr => ugr.Status).WithMany().HasForeignKey(ugr=>ugr.StatusId);
        }
    }
}
