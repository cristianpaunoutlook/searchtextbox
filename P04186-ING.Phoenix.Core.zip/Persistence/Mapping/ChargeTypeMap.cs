﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeMap : IEntityTypeConfiguration<ChargeType>
    {
        public void Configure(EntityTypeBuilder<ChargeType> builder)
        {
            builder.ToTable("ChargeType");
            builder.HasKey(ct => ct.ChargeTypeId);
            builder.Property(ct => ct.AmountProduct).HasColumnType("decimal");
            builder.Property(ct => ct.DefaultAmount).HasColumnType("decimal");
            builder.Property(ct => ct.ForDepartment).HasColumnType("SMALLINT");

            builder.HasOne(ct => ct.Curr).WithMany().HasForeignKey(ct => ct.CurrId);
            builder.HasOne(ct => ct.Frequency).WithMany().HasForeignKey(ct => ct.FrequencyId);
            builder.HasOne(ct => ct.Status).WithMany().HasForeignKey(ct => ct.StatusId);
            builder.HasOne(ct => ct.Action).WithMany().HasForeignKey(ct => ct.ForDepartment);
            builder.HasOne(ct => ct.ChargeTypeGroup).WithMany().HasForeignKey(ct => ct.GroupId);
        }
    }
}
