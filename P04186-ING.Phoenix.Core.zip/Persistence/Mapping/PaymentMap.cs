﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class PaymentMap : IEntityTypeConfiguration<Payment>
    {
        public void Configure(EntityTypeBuilder<Payment> builder)
        {
            builder.ToTable("Payment");
            builder.HasKey(p => p.PaymentId);
            builder.HasOne(p => p.Session).WithMany().HasForeignKey(s => s.ExportSessionId);
            builder.HasOne(p => p.ChargeType).WithMany().HasForeignKey(ct => ct.ChargeTypeId);
            builder.HasOne(p => p.Currency).WithMany().HasForeignKey(c => c.CurrencyId);
            builder.HasOne(p => p.CustomerDetails).WithMany().HasForeignKey(cd => cd.CustomerAtlasId);
            builder.HasOne(p => p.ApplicationLog).WithMany().HasPrincipalKey(al => al.SessionId).HasForeignKey(al => al.ExportSessionId);
        }
    }
}
