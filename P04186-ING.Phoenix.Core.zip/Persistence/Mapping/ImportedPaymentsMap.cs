﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ImportedPaymentsMap : IEntityTypeConfiguration<ImportedPayments>
    {
        public void Configure(EntityTypeBuilder<ImportedPayments> builder)
        {
            builder.ToTable("ImportedPayments");
            builder.HasKey(p => new { p.SessionId, p.LineNumber });
        }
    }
}
