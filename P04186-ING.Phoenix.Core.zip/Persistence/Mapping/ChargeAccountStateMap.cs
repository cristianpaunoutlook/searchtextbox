﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ChargeAccountStateMap : IEntityTypeConfiguration<ChargeAccountState>
    {
        public void Configure(EntityTypeBuilder<ChargeAccountState> builder)
        {
            builder.HasKey(a => a.Status);
            builder.Property(a => a.Status).HasColumnType("smallint");
        }
    }
}