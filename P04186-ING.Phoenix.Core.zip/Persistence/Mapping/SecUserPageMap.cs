﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class SecUserPageMap : IEntityTypeConfiguration<SecUserPage>
    {
        public void Configure(EntityTypeBuilder<SecUserPage> builder)
        {
            builder
               .ToTable("UserPage", "sec")
               .HasKey(up => up.PageId);
            builder
                .Property(up => up.PageId)
                .ValueGeneratedOnAdd()
                .IsRequired();
            builder
                .Property(oa => oa.PageId)
                .HasColumnType("SMALLINT");
            builder
                .Property(oa => oa.FunctionId)
                .HasColumnType("SMALLINT");
            builder
                .Property(oa => oa.MenuIndex)
                .HasColumnType("SMALLINT");
        }
    }
}
