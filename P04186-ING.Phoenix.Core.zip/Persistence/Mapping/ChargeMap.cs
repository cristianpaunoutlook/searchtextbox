﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ChargeMap : IEntityTypeConfiguration<Charge>
    {
        public void Configure(EntityTypeBuilder<Charge> builder)
        {
            builder.ToTable("Charges");
            builder.HasKey(c =>c.ChargeId);
            builder.Property(c => c.SpecialAmount).HasColumnType("decimal");
            builder.Property(c => c.AccountState).HasColumnType("smallint");

            builder.HasOne(c => c.Currency).WithMany().HasForeignKey(c => c.CurrencyId);
            builder.HasOne(c => c.ChargeType).WithMany().HasForeignKey(c => c.ChargeTypeId);
            builder.HasOne(c => c.Status).WithMany().HasForeignKey(c => c.StatusId);
            builder.HasOne(c => c.CustomerChargeType).WithMany().HasForeignKey(c => c.CustomerChargeTypeId);
            builder.HasOne(c => c.ChargeAccountState).WithMany().HasForeignKey(c => c.AccountState);
        }
    }
}
