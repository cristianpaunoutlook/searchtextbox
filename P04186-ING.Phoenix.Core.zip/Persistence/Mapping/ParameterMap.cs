﻿
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ParameterMap : IEntityTypeConfiguration<PhxParameter>
    {
        public void Configure(EntityTypeBuilder<PhxParameter> builder)
        {
            builder.ToTable("Parameter");
            builder.HasKey(p => p.ParamName);
        }
    }
}
