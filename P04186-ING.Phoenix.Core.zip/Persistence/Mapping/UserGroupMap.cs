﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class UserGroupMap : IEntityTypeConfiguration<UserGroup>
    {
        public void Configure(EntityTypeBuilder<UserGroup> builder)
        {
            builder.ToTable("UserGroup", "sec");
            builder.HasKey(ug => ug.GroupId);
            builder.Property(ug => ug.GroupId).HasColumnType("SMALLINT");
            builder.Property(ug => ug.StatusId).HasColumnType("SMALLINT");
        }
    }
}
