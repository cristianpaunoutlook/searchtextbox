﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class SessionMap : IEntityTypeConfiguration<Session>
    {
        public void Configure(EntityTypeBuilder<Session> builder)
        {
            builder.ToTable("Session");
            builder.HasKey(p => p.SessionId);
            builder.Property(p => p.SessionId)
                .ValueGeneratedOnAdd()
                .IsRequired();
            builder.HasOne(s => s.ObjectType).WithMany();
        }
    }
}
