﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ProcessingFrequencyMap: IEntityTypeConfiguration<ProcessingFrequency>
    {
        public void Configure(EntityTypeBuilder<ProcessingFrequency> builder)
        {
            builder.ToTable("ProcessingFrequency");
            builder.HasKey(x => x.ProcessingFrequencyId);
        }
    }
}
