﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class CustomerDetailsMap : IEntityTypeConfiguration<CustomerDetails>
    {
        public void Configure(EntityTypeBuilder<CustomerDetails> builder)
        {
            builder.ToTable("CustomerDetails");
            builder.HasKey(p => p.CustomerId);
        }
    }
}
