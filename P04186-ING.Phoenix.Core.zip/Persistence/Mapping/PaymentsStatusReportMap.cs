﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class PaymentsStatusReportMap : IEntityTypeConfiguration<PaymentsStatusReport>
    {
        public void Configure(EntityTypeBuilder<PaymentsStatusReport> builder)
        {
            builder.HasKey(p => p.PaymentId);
        }
    }
}
