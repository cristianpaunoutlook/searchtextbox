﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class GBSDebitAccountTypeMap : IEntityTypeConfiguration<GBSDebitAccountType>
    {
        public void Configure(EntityTypeBuilder<GBSDebitAccountType> builder)
        {
            builder.ToTable("GBSDebitAccountType")
                .HasKey(x => x.Code);
        }
    }
}
