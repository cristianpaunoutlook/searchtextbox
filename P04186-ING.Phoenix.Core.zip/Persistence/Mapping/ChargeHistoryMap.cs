﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ChargeHistoryMap : IEntityTypeConfiguration<ChargeHistory>
    {
        public void Configure(EntityTypeBuilder<ChargeHistory> builder)
        {
            builder.ToTable("ChargeHistory");
            builder.HasKey(ch => ch.ChargeHistoryId);
            builder.Property(ch => ch.SpecialAmount).HasColumnType("decimal");
            builder.Property(ch => ch.ActionId).HasColumnType("SMALLINT");

            builder.HasOne(ch => ch.Charge).WithMany().HasForeignKey(ch => ch.ChargeId);
            builder.HasOne(ch => ch.Currency).WithMany().HasForeignKey(ch => ch.CurrencyId);
            builder.HasOne(ch => ch.ChargeType).WithMany().HasForeignKey(ch => ch.ChargeTypeId);
            builder.HasOne(ch => ch.Status).WithMany().HasForeignKey(ch => ch.StatusId);
            builder.HasOne(ch => ch.CustomerChargeType).WithMany().HasForeignKey(ch => ch.CustomerChargeTypeId);
            builder.HasOne(ch => ch.ObjectAction).WithMany().HasForeignKey(ch => ch.ActionId);
        }
    }
}
