﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class SecUserStatusMap : IEntityTypeConfiguration<SecUserStatus>
    {
        public void Configure(EntityTypeBuilder<SecUserStatus> builder)
        {
            builder.ToTable("UserStatus", "sec");
            builder.HasKey(us => us.StatusId);
            builder.Property(us => us.StatusId).HasColumnType("SMALLINT");
        }
    }
}
