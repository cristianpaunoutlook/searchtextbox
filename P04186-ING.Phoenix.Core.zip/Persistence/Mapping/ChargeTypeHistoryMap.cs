﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class ChargeTypeHistoryMap : IEntityTypeConfiguration<ChargeTypeHistory>
    {
        public void Configure(EntityTypeBuilder<ChargeTypeHistory> builder)
        {
            builder.ToTable("ChargeTypeHistory");
            builder.HasKey(cth => cth.ChargeTypeHistoryId);
            builder.Property(cth => cth.AmountProduct).HasColumnType("decimal");
            builder.Property(cth => cth.DefaultAmount).HasColumnType("decimal");
            builder.Property(cth => cth.ForDepartment).HasColumnType("SMALLINT");
            builder.Property(cth => cth.ActionId).HasColumnType("SMALLINT");

            builder.HasOne(cth => cth.ChargeType).WithMany().HasForeignKey(ct => ct.ChargeTypeId);
            builder.HasOne(cth => cth.Status).WithMany().HasForeignKey(ct => ct.StatusId);
            builder.HasOne(cth => cth.Frequency).WithMany().HasForeignKey(ct => ct.FrequencyId);
            builder.HasOne(ct => ct.ObjectAction).WithMany().HasForeignKey(ct => ct.ActionId);
        }
    }
}
