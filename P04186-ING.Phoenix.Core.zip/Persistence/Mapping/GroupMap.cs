﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class GroupMap : IEntityTypeConfiguration<Group>
    {
        public void Configure(EntityTypeBuilder<Group> builder)
        {
            builder.ToTable("Groups");
            builder.HasKey(g => g.Id);
            builder.HasOne(g => g.Status).WithMany().HasForeignKey(os => os.StatusId);
            builder.HasOne(g => g.NextStatus).WithMany().HasForeignKey(os => os.NextStatusId);
        }
    }
}
