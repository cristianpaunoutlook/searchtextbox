﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class PRFDebitAccountTypeMap : IEntityTypeConfiguration<PRFDebitAccountType>
    {
        public void Configure(EntityTypeBuilder<PRFDebitAccountType> builder)
        {
            builder.ToTable("PRFDebitAccountType")
                .HasKey(da => new { da.CifTypeId, da.Code });
        }
    }
}
