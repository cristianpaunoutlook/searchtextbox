﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace Persistence.Mapping
{
    [ExcludeFromCodeCoverage]
    public class GBSCreditAccountTypeMap : IEntityTypeConfiguration<GBSCreditAccountType>
    {
        public void Configure(EntityTypeBuilder<GBSCreditAccountType> builder)
        {
            builder.ToTable("GBSCreditAccountType")
                    .HasKey(x => x.Code);
        }
    }
}
