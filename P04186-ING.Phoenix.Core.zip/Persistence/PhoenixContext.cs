﻿using Domain;
using Domain.UserDefinedTable;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Persistence.SQLHelpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Persistence
{
    public class PhoenixContext : DbContext
    {
        public PhoenixContext(DbContextOptions options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region entity configuration
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
            #endregion
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseLazyLoadingProxies();
        }

        #region DbSets for data tables
        public DbSet<Session> Sessions { get; set; }
        public DbSet<ObjectType> ObjectTypes { get; set; }
        public DbSet<UserGroup> UserGroups { get; set; }
        public DbSet<Account> Accounts { get; set; }
        public DbSet<ObjectStatus> ObjectStatus { get; set; }
        public DbSet<Charge> Charges { get; set; }
        public DbSet<ChargeHistory> ChargesHistory { get; set; }
        public DbSet<CustomerChargeType> CustomerChargeTypes { get; set; }
        public DbSet<ImportedPayments> ImportedPayments { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Currency> Currencies { get; set; }
        public DbSet<ChargeType> ChargeTypes { get; set; }
        public DbSet<ChargeTypeGroup> ChargeTypeGroups { get; set; }
        public DbSet<SecSession> SecSessions { get; set; }
        public DbSet<SecUserPage> UserPages { get; set; }
        public DbSet<SecObjectAction> ObjectActions { get; set; }
        public DbSet<SecUserGroupRights> UserGroupRights { get; set; }
        public DbSet<SecUserStatus> UserStatus { get; set; }
        public DbSet<ProcessingFrequency> ProcessingFrequencies { get; set; }
        public DbSet<ChargeTypeHistory> ChargeTypeHistories { get; set; }
        public DbSet<PRFCreditAccountType> PRFCreditAccountTypes { get; set; }
        public DbSet<PRFDebitAccountType> PRFDebitAccountTypes { get; set; }
        public DbSet<GBSCreditAccountType> GBSCreditAccountTypes { get; set; }
        public DbSet<GBSDebitAccountType> GBSDebitAccountTypes { get; set; }
        public DbSet<ChargeAccountState> ChargeAccountStates { get; set; }
        public DbSet<PhxParameter> Parameters { get; set; }
        public DbSet<ProcedureResult> ProcedureResults { get; set; }
        public DbSet<ManualProcessSpResult> ManualProcessSpResults { get; set; }
        public DbSet<DlfilesTblNonWorkingDays> NonWorkingDays { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<Page> Pages { get; set; }
        public DbSet<GroupPageRight> GroupsPagesRights { get; set; }
        public DbSet<Right> Rights { get; set; }
        public DbSet<ApplicationLog> ApplicationLogs { get; set; }
        public DbSet<DeletedChargeHistory> DeletedChargesHistory { get; set; }
        public DbSet<PaymentsStatusReport> PaymentsStatusReportResult { get; set; }
        public DbSet<CustomerDetails> CustomersDetails { get; set; }
        public DbSet<SecUserObject> UserObjects { get; set; }
        public DbSet<SecUserAction> UserActions { get; set; }
        public DbSet<SecUserLog> UserLogs { get; set; }
        public DbSet<MailList> MailList { get; set; }

        [ExcludeFromCodeCoverage]
        private SqlParameter[] CreateSqlParamForApproveReject(int[] chargeIdsList, string userKey, string rejectReason = "")
        {
            var tableStructure = new IntList();

            var parameters = new SqlParameter[] {
                SQLHelper.CreateUserDefinedTableSQLParameter(tableStructure, chargeIdsList, "@ChargeIdList", "dbo.IntList"),
                SQLHelper.CreateStringSQLParameter("@UserId", userKey),
                SQLHelper.CreateOutputSQLParameter("@CountModifiedCharges", SqlDbType.Int)
            };

            if (!string.IsNullOrEmpty(rejectReason))
            {
                parameters = parameters.Concat(new SqlParameter[] { SQLHelper.CreateStringSQLParameter("@RejectReason", rejectReason) }).ToArray();
            }

            return parameters;
        }
        [ExcludeFromCodeCoverage]
        public async Task<int> BulkApproveCharges(int[] chargeIdsList, string userKey)
        {
            var parameters = CreateSqlParamForApproveReject(chargeIdsList, userKey);

            await ProcedureResults.FromSqlRaw("EXECUTE spBulkApproveCharges @ChargeIdList, @UserId, @CountModifiedCharges OUTPUT",
                    parameters).ToListAsync();

            return Convert.ToInt32(parameters.FirstOrDefault(p => p.ParameterName == "@CountModifiedCharges").Value);
        }

        [ExcludeFromCodeCoverage]
        public async Task<int> BulkRejectCharges(int[] chargeIdsList, string userKey, string rejectReason)
        {
            var parameters = CreateSqlParamForApproveReject(chargeIdsList, userKey, rejectReason);

            await ProcedureResults.FromSqlRaw("EXECUTE spBulkRejectCharges @ChargeIdList, @UserId, @RejectReason, @CountModifiedCharges OUTPUT",
                    parameters).ToListAsync();

            return Convert.ToInt32(parameters.FirstOrDefault(p => p.ParameterName == "@CountModifiedCharges").Value);
        }
        [ExcludeFromCodeCoverage]
        public async Task SetNextRunDay(int[] chargeTypeIds)
        {
            var tableStructure = new IntList();

            var parameters = new SqlParameter[] {
                SQLHelper.CreateUserDefinedTableSQLParameter(tableStructure, chargeTypeIds, "@ChargeTypeIdList", "dbo.IntList")
                };

            await Database.ExecuteSqlRawAsync($"exec spCalculateNextRunDay @ChargeTypeIdList", parameters);
        }
        [ExcludeFromCodeCoverage]
        public async Task<List<ManualProcessSpResult>> ListForManualProcess(int pageNumber, int pageSize, int chargeTypeId, DateTime? nextRunDay,
            string chargeDescription)
        {
            var parameters = new SqlParameter[] {
                SQLHelper.CreateIntSQLParameter("@PageNumber", pageNumber),
                SQLHelper.CreateIntSQLParameter("@PageSize", pageSize),
                SQLHelper.CreateIntSQLParameter("@ChargeTypeId", chargeTypeId),
                SQLHelper.CreateDateSQLParameter("@NextRunDay", nextRunDay),
                SQLHelper.CreateStringSQLParameter("@ChargeDescription", chargeDescription)
                };

            return await ManualProcessSpResults.FromSqlRaw("EXECUTE spGetManualProcessingList @PageNumber, @PageSize, @ChargeTypeId, @NextRunDay, " +
                "@ChargeDescription", parameters).ToListAsync();
        }
        [ExcludeFromCodeCoverage]
        public async Task<List<PaymentsStatusReport>> PaymentsStatusReport(int pageNumber, int pageSize, string sortColumn, string sortOrder, int sessionId, string customerId, string TRID,
                                                                            int chargeTypeId, int processed, string userId, DateTime? exportStartDate, DateTime? exportEndDate)
        {
            var parameters = new SqlParameter[] {
                SQLHelper.CreateIntSQLParameter("@PageNumber", pageNumber),
                SQLHelper.CreateIntSQLParameter("@PageSize", pageSize),
                SQLHelper.CreateStringSQLParameter("@SortColumn", sortColumn ?? ""),
                SQLHelper.CreateStringSQLParameter("@SortOrder", sortOrder ?? ""),
                SQLHelper.CreateIntSQLParameter("@SessionId", sessionId),
                SQLHelper.CreateStringSQLParameter("@CustomerId", customerId ?? ""),
                SQLHelper.CreateStringSQLParameter("@TRID", TRID ?? ""),
                SQLHelper.CreateIntSQLParameter("@ChargeTypeId", chargeTypeId),
                SQLHelper.CreateIntSQLParameter("@Processed", processed),
                SQLHelper.CreateStringSQLParameter("@UserID", userId ?? ""),
                SQLHelper.CreateDateSQLParameter("@ExportStartDate", exportStartDate),
                SQLHelper.CreateDateSQLParameter("@ExportEndDate", exportEndDate),
            };

            return await PaymentsStatusReportResult.FromSqlRaw("EXECUTE spGetPaymentsStatusReport @PageNumber, @PageSize, @SortColumn, @SortOrder, @SessionId, @CustomerId, @TRID, " +
                "@ChargeTypeId, @Processed, @UserID, @ExportStartDate, @ExportEndDate", parameters).ToListAsync();
        }

        [ExcludeFromCodeCoverage]
        public async Task StartImportAnafFile(string fileName)
        {
            var parameters = new SqlParameter[] {
                SQLHelper.CreateStringSQLParameter("@FileName", fileName)
                };

            await Database.ExecuteSqlRawAsync($"exec spImportAnafStart @FileName", parameters);
        }

        [ExcludeFromCodeCoverage]
        public async Task StopImportAnafFile(string fileName, bool isError)
        {
            var parameters = new SqlParameter[] {
                SQLHelper.CreateStringSQLParameter("@FileName", fileName),
                SQLHelper.CreateBitSQLParameter("@IsError", isError)
                };

            await Database.ExecuteSqlRawAsync($"exec spImportAnafStop @FileName, @IsError", parameters);
        }

        #endregion
    }
}
