﻿using System;
using System.Collections.Generic;

namespace ImportFileInDb
{
    public class ImportConfiguration
    {
        public ImportConfiguration(string pathToFile, string tableName, bool hasHeader, string delimitator, Dictionary<string, string> mapping,
            string dbConnectionString)
        {
            PathToFile = string.IsNullOrEmpty(pathToFile) ? throw new Exception("Please provide path to file!") : pathToFile;
            TableName = string.IsNullOrEmpty(tableName) ? throw new Exception("Please provide table name to import!") : tableName;
            HasHeader = hasHeader;
            Delimitator = string.IsNullOrEmpty(delimitator) ? ";" : delimitator;
            Mapping = mapping ?? null;
            DbConnectionString = dbConnectionString;
        }

        private ImportConfiguration()
        {

        }
        public string PathToFile { get; set; }
        public string TableName { get; set; }
        public bool HasHeader { get; set; }
        public string Delimitator { get; set; }
        public Dictionary<string, string> Mapping { get; set; }
        public string ExcelConnectionString { get; } = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";
        public string DbConnectionString { get; set; }
    }
}
