﻿using ImportFileInDb.Commons.Enums;
using ImportFileInDb.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Data;

namespace ImportFileInDb
{
    public class CsvToDatatable : FileImportBase, IDataToDatatable
    {
        private readonly ILogger logger;
        private readonly ImportConfiguration config;

        public CsvToDatatable(ILogger logger, ImportConfiguration config) : base(logger)
        {
            this.logger = logger;
            this.config = config;
        }
        public DataTable WriteToDataTable()
        {
            DataTable dt = new DataTable();
            FillDataTableFromCsv(dt);
            return dt;
        }

        private void FillDataTableFromCsv(DataTable csvData)
        {
            DataTable schemaTable = GetSchema(config.TableName, config.DbConnectionString);
            int autoIncrementColumn = GetAutoIncrementPosition(schemaTable);
            logger.LogInformation($"Start reading csv file");
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(config.PathToFile))
                {
                    csvReader.SetDelimiters(new string[] { config.Delimitator });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields;
                    colFields = csvReader.ReadFields();
                    bool tableCreated = false;
                    List<int> columnPositions = new List<int>();
                    while (tableCreated == false)
                    {
                        for (int i = 0; i < colFields.Length; i++)
                        {
                            var columnName = config.HasHeader ? colFields[i] : $"COL{i}";
                            if (config.Mapping == null || (config.Mapping != null && config.Mapping.ContainsKey(columnName)))
                            {
                                var dbColumnName = config.Mapping != null ? config.Mapping[columnName] : string.Empty;
                                DataColumn datecolumn;
                                //set column of datatable to double if type is bool in order to avoid errors
                                if (CheckColumnType(schemaTable, i, autoIncrementColumn, DataTypes.Boolean, dbColumnName))
                                    datecolumn = new DataColumn(columnName, typeof(Double));
                                // set column of datatable to guid if type is guid in order to avoid errors
                                else if (CheckColumnType(schemaTable, i, autoIncrementColumn, DataTypes.Guid, dbColumnName))
                                    datecolumn = new DataColumn(columnName, typeof(Guid));
                                else
                                    datecolumn = new DataColumn(columnName);
                                datecolumn.AllowDBNull = true;
                                csvData.Columns.Add(datecolumn);
                                columnPositions.Add(i);
                            }
                        }

                        tableCreated = true;
                    }
                    if (!config.HasHeader)
                    {
                        colFields = config.Mapping != null ? GetColFields(colFields, columnPositions) : colFields;
                        csvData.Rows.Add(SetNullValues(colFields));
                    }

                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        fieldData = config.Mapping != null ? GetColFields(fieldData, columnPositions) : fieldData;
                        //Making empty value as null
                        SetNullValues(fieldData);
                        csvData.Rows.Add(fieldData);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogInformation(ex.Message);
                throw new Exception(ex.Message);   
            }
        }

        private string[] SetNullValues(string[] fieldData)
        {
            for (int i = 0; i < fieldData.Length; i++)
            {
                if (fieldData[i].Trim() == string.Empty)
                    fieldData[i] = null;
            }

            return fieldData;
        }

        private string[] GetColFields(string[] colFields, List<int> columnPositions)
        {
            string[] result = new string[columnPositions.Count];
            for (int i = 0; i < columnPositions.Count; i++)
            {
                result[i] = colFields[columnPositions[i]];
            }
            return result;
        }
    }
}
