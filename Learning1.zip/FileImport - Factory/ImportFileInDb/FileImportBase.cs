﻿using ImportFileInDb.Commons;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace ImportFileInDb
{
    public class FileImportBase
    {
        private readonly ILogger logger;

        public FileImportBase(ILogger logger)
        {
            this.logger = logger;
        }
        protected DataTable GetSchema(string tableName, SqlConnection con)
        {
            DataTable schemaTable;

            using (var command = new SqlCommand($"SELECT * FROM {tableName}", con))
            {
                command.CommandType = CommandType.Text;
                // Includes the primary key information.
                var dataReader = command.ExecuteReader(CommandBehavior.KeyInfo);
                // Gets the column schema into a DataTable
                schemaTable = dataReader.GetSchemaTable();
            }

            return schemaTable;
        }

        protected DataTable GetSchema(string tableName, string dbConnectionString)
        {
            DataTable schemaTable;
            logger.LogInformation($"Get schema for table: {tableName}");
            // get SQL schema for destination table
            using (SqlConnection connection = new SqlConnection(dbConnectionString))
            {
                connection.Open();
                schemaTable = GetSchema(tableName, connection);
                connection.Close();
            }

            return schemaTable;
        }

        protected int GetAutoIncrementPosition(DataTable schemaTable)
        {
            DataRow result = schemaTable.Select($"IsIdentity = {true} AND IsAutoIncrement = {true}").SingleOrDefault();
            if (result != null)
                return (int)result.ItemArray[1];
            return -1;
        }

        protected bool CheckColumnType(DataTable schemaTable, int columnOrder, int autoIncrementPosition, string columnType, string dbColumnName)
        {
            logger.LogInformation($"Check if sql table hascolumn type: {columnType} for {dbColumnName}");
            if (!string.IsNullOrEmpty(dbColumnName))
            {
                var row = schemaTable.Select($"ColumnName = '{dbColumnName}'").SingleOrDefault();
                return row["DataType"].ToString() == columnType;
            }
            else
            {
                if (autoIncrementPosition != -1 && autoIncrementPosition < columnOrder)
                    columnOrder++;
                return schemaTable.Rows[columnOrder]["DataType"].ToString() == columnType;
            }
        }

        protected string GetErrorMessage(Exception ex)
        {
            if (ex is InvalidOperationException)
                return ex.Message;
            else if (ex is SqlException)
                return GetSQLExceptionMessage(ex.Message);
            else
                return "An error occurred. File was not imported!";
        }

        private string GetSQLExceptionMessage(string message)
        {
            logger.LogInformation($"Exception message is: {message}");
            var messages = new Dictionary<string, Func<string, string>>();
            messages.Add(Constants.PK_ERROR_MESSAGE, GetMessageForPK);
            messages.Add(Constants.INVALID_COLUMN_LEN_ERROR_MESSAGE, GetMessageForInvalidColumnLength);
            messages.Add(Constants.FK_ERROR_MESSAGE, GetMessageForFK);
            messages.Add(Constants.UK_CONSTRAINT_ERROR_MESSAGE, GetMessageForUniqueConstraint);

            var errorMessage = Constants.ERROR_MESSAGES_TYPE.Where(e => message.Contains(e)).FirstOrDefault();

            return messages[errorMessage].Invoke(message);
        }

        private string GetMessageForPK(string message)
        {
            string[] values = message.Split('(', ')');
            if (values.Length >= 2)
                return $"On the primary key column there is a duplicate value: {values[1]}";
            return string.Empty;
        }

        private string GetMessageForInvalidColumnLength(string message)
        {
            string searchedString = GetStringBetweenTwoStrings(message, "colid ", ".");
            if (!string.IsNullOrEmpty(searchedString))
                return $"Invalid column length on column {searchedString}";
            return string.Empty;
        }

        private string GetMessageForFK(string message)
        {
            string searchedString = GetStringBetweenTwoStrings(message, "column '", "'.");
            if (!string.IsNullOrEmpty(searchedString))
                return $"Column '{searchedString}' has invalid value.";
            return string.Empty;
        }

        private string GetMessageForUniqueConstraint(string message)
        {
            string[] values = message.Split('(', ')');
            if (values.Length >= 2)
                return $"The duplicate key value '{values[1]}'";
            return string.Empty;
        }

        private string GetStringBetweenTwoStrings(string searchingString, string firstString, string secondString)
        {
            int from = searchingString.IndexOf(firstString) + firstString.Length;
            int to = searchingString.LastIndexOf(secondString);
            if (from != -1 && to != -1)
                return searchingString.Substring(from, to - from);
            return string.Empty;
        }
    }
}
