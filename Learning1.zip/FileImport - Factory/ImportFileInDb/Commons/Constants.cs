﻿namespace ImportFileInDb.Commons
{
    public static class Constants
    {
        public const string PK_ERROR_MESSAGE = "PRIMARY KEY constraint";
        public const string INVALID_COLUMN_LEN_ERROR_MESSAGE = "invalid column length";
        public const string FK_ERROR_MESSAGE = "FOREIGN KEY constraint";
        public const string UK_CONSTRAINT_ERROR_MESSAGE = "UNIQUE KEY constraint";

        public static readonly string[] ERROR_MESSAGES_TYPE = new string[] { PK_ERROR_MESSAGE, INVALID_COLUMN_LEN_ERROR_MESSAGE,
            FK_ERROR_MESSAGE, UK_CONSTRAINT_ERROR_MESSAGE };

        public const string XLS = ".xls";
        public const string XLSX = ".xlsx";
        public const string CSV = ".csv";
        public const string TXT = ".txt";
    }
}
