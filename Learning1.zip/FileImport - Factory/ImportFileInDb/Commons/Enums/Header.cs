﻿namespace ImportFileInDb.Commons.Enums
{
    public enum Header
    {
        YES,
        NO
    }
}
