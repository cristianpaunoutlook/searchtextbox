﻿namespace ImportFileInDb.Commons.Enums
{
    public static class DataTypes
    {
        public static string Boolean { get { return "System.Boolean"; } }
        public static string Guid { get { return "System.Guid"; } }
    }
}
