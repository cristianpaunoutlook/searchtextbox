﻿using ImportFileInDb.Interfaces;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;

namespace ImportFileInDb
{
    public class FileImport : FileImportBase, IFileImport
    {
        private readonly ILogger Logger;

        private readonly string DbConnectionString;

        public FileImport(ILogger logger, string dbConnectionString) : base(logger)
        {
            this.Logger = logger ?? throw new Exception("Please provide logging object!");
            this.DbConnectionString = string.IsNullOrEmpty(dbConnectionString) ? throw new Exception("Please provide DB connection string!") : dbConnectionString;
        }
        public void ImportFile(string pathToFile, string tableName, bool hasHeader = false, Dictionary<string, string> mapping = null,
            string delimitatorForCsv = ";", Func<DataTable, DataTable> filterData = null, string currentCulture = "")
        {
            if (!File.Exists(pathToFile))
                throw new Exception("File provided does not exist or you do not have access!");

            //fill datatable 
            DataTable dt = WriteFileToDataTable(pathToFile, tableName, hasHeader, delimitatorForCsv, mapping);

            if (filterData != null)
                dt = filterData.Invoke(dt);

            //Insert data from file to Database Table.
            if(!string.IsNullOrEmpty(currentCulture))
            CultureInfo.CurrentCulture = new CultureInfo(currentCulture);
            WriteDatatableToDatabase(tableName, mapping, dt);
        }

        private void WriteDatatableToDatabase(string tableName, Dictionary<string, string> mapping, DataTable dt)
        {
            Logger.LogInformation($"Start writing datatable to database");
            using (SqlConnection connection = new SqlConnection(DbConnectionString))
            {
                //option for bulk copy
                var options = SqlBulkCopyOptions.CheckConstraints | SqlBulkCopyOptions.FireTriggers | SqlBulkCopyOptions.TableLock;
                connection.Open();
                try
                {
                    Logger.LogInformation($"Check if SQL table has identity autoincrement column");
                    CheckIfTableHasIdentityColumn(tableName, dt, connection);

                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(DbConnectionString, options))
                    {
                        //Set the database table name.
                        sqlBulkCopy.DestinationTableName = tableName;

                        //[OPTIONAL]: Map the Excel/csv columns with that of the database table
                        if (mapping != null)
                            foreach (var item in mapping)
                            {
                                sqlBulkCopy.ColumnMappings.Add(item.Key, item.Value);
                            }

                        sqlBulkCopy.WriteToServer(dt);
                    }
                }

                catch (Exception ex)
                {
                    Logger.LogInformation(ex.Message);
                    string message = GetErrorMessage(ex);
                    Logger.LogInformation(message);
                    throw new Exception(ex.Message);
                }
                finally
                {
                    connection.Close();
                }

            }
        }

        private DataTable WriteFileToDataTable(string pathToFile, string tableName, bool hasHeader, string delimitator,
            Dictionary<string, string> mapping)
        {
            ImportConfiguration config = new ImportConfiguration(pathToFile, tableName, hasHeader, delimitator, mapping, DbConnectionString);

            var factory = new DataToDatatableFactory(Logger, config);

            var data = factory.CreateDatatable();

            return data.WriteToDataTable() ?? throw new Exception("File is empty!");
        }

        private void CheckIfTableHasIdentityColumn(string tableName, DataTable dt, SqlConnection con)
        {
            DataTable schemaTable = GetSchema(tableName, con);

            int position = GetAutoIncrementPosition(schemaTable);
            if (position != -1)
            {
                dt.Columns.Add().SetOrdinal(position);
                Logger.LogInformation($"Autoincrement column position is: {position}");
            }
        }
    }
}
