﻿using System.Data;

namespace ImportFileInDb.Interfaces
{
    public interface IDataToDatatable
    {
        DataTable WriteToDataTable();
    }
}
