﻿using System;
using System.Collections.Generic;
using System.Data;

namespace ImportFileInDb.Interfaces
{
    public interface IFileImport
    {
        void ImportFile(string pathToFile, string tableName, bool hasHeader = false, Dictionary<string, string> mapping = null, 
            string delimitatorForCsv = ";", Func<DataTable, DataTable> filterData = null, string currentCulture = "");
    }
}
