﻿using ImportFileInDb.Commons.Enums;
using ImportFileInDb.Interfaces;
using Microsoft.Extensions.Logging;
using System;
using System.Data;
using System.Data.OleDb;
using System.Linq;

namespace ImportFileInDb
{
    public class ExcelToDatatable : FileImportBase, IDataToDatatable
    {
        private readonly ILogger logger;
        private readonly ImportConfiguration config;

        public ExcelToDatatable(ILogger logger, ImportConfiguration config) : base(logger)
        {
            this.logger = logger;
            this.config = config;
        }
        public DataTable WriteToDataTable()
        {
            DataTable dt = new DataTable();
            FillDataTableFromExcel(dt);
            CheckIfTableHasGuidColumn(dt);

            return dt;
        }

        private void FillDataTableFromExcel(DataTable dt)
        {
            string excelConnection = string.Format(config.ExcelConnectionString, config.PathToFile,
                            config.HasHeader ? Header.YES.ToString() : Header.NO.ToString());
            logger.LogInformation($"Excel conn string is: {excelConnection}");
            try
            {
                using (OleDbConnection connExcel = new OleDbConnection(excelConnection))
                {
                    using (OleDbCommand cmdExcel = new OleDbCommand())
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            logger.LogInformation($"Start reading excel file");
                            cmdExcel.Connection = connExcel;

                            //Get the name of First Sheet.
                            connExcel.Open();
                            DataTable dtExcelSchema;
                            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            string sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                            connExcel.Close();

                            //Read Data from First Sheet.
                            string columnList = config.Mapping != null ? string.Join(",", config.Mapping.Keys.ToList()) : "*";
                            connExcel.Open();
                            cmdExcel.CommandText = $"SELECT {columnList} From [{sheetName}]";
                            odaExcel.SelectCommand = cmdExcel;
                            odaExcel.Fill(dt);
                            connExcel.Close();
                        }
                    }
                }
                logger.LogInformation($"Added excel file to datatable");
            }
            catch (Exception ex)
            {
                logger.LogInformation(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        private void CheckIfTableHasGuidColumn(DataTable dt)
        {
            logger.LogInformation($"Check if sql table has GUID column");
            DataTable schemaTable = GetSchema(config.TableName, config.DbConnectionString);
            int autoIncrementColumn = GetAutoIncrementPosition(schemaTable);
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                string guidColumnName;
                var columnName = dt.Columns[i].ColumnName;
                var dbColumnName = config.Mapping != null ? config.Mapping[columnName] : string.Empty;
                dt.Columns[i].AllowDBNull = true;
                if (CheckColumnType(schemaTable, i, autoIncrementColumn, DataTypes.Guid, dbColumnName))
                {
                    logger.LogInformation($"Convert datatable column to guid");
                    dt.Columns.Add("CopyColumn", typeof(Guid));
                    guidColumnName = dt.Columns[i].ColumnName;
                    foreach (DataRow dr in dt.Rows)
                    {
                        dr["CopyColumn"] = dr[guidColumnName];
                    }
                    dt.Columns.RemoveAt(i);
                    dt.Columns["CopyColumn"].SetOrdinal(i);
                    dt.Columns["CopyColumn"].ColumnName = guidColumnName;
                }
            }
        }
    }
}
