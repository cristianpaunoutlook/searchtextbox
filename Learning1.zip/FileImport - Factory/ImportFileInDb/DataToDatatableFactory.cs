﻿using ImportFileInDb.Commons;
using ImportFileInDb.Interfaces;
using Microsoft.Extensions.Logging;
using System.IO;

namespace ImportFileInDb
{
    public class DataToDatatableFactory
    {
        private readonly ILogger logger;
        private readonly ImportConfiguration config;

        public DataToDatatableFactory(ILogger logger, ImportConfiguration config)
        {
            this.logger = logger;
            this.config = config;
        }
        public IDataToDatatable CreateDatatable()
        {
            string fileExtension = Path.GetExtension(config.PathToFile);
            switch (fileExtension)
            {
                case Constants.XLS:
                case Constants.XLSX:
                    return new ExcelToDatatable(logger, config);
                case Constants.TXT:
                case Constants.CSV:
                    return new CsvToDatatable(logger, config);
                default:
                    return null;
            }
        }
    }
}
