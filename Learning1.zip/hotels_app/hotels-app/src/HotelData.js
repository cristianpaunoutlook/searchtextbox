const hotelData = [
    {
        id: 1,
        country: "Thailand",
        location: "Bangkok",
        name: "Thai Hotel",
        price: 200,
        image: 'https://cdn.getyourguide.com/img/country/5774d92595279.jpeg/88.jpg'
    },
    {
        id: 2,
        country: "Italy",
        location: "Rome",
        name: "Rome Hotel",
        price: 79,
        image: 'https://cdn.contexttravel.com/image/upload/c_fill,q_60,w_2600/v1549318570/production/city/hero_image_2_1549318566.jpg'
    },
    {
        id: 3,
        country: "France",
        location: "Paris",
        name: "Paris Hotel",
        price: 123,
        image: 'https://ilovetravel.ro/wp-content/uploads/2015/12/Tour-Eiffel-Paris-Franta-by-day-image.jpg'
    },
    {
        id: 4,
        country: "Brasil",
        location: "Rio de Janeiro",
        name: "Copacabana Hotel",
        price: 110,
        image: 'https://edifica.ro/wp-content/uploads/2016/02/000-1024x707.jpg'
    },
    {
        id: 5,
        country: "Greece",
        location: "Crete",
        name: "Chania Hotel",
        price: 90,
        image: 'https://grecia.de-weekend.ro/wp-content/uploads/2016/07/creta-chania-plaja-balos.jpg'
    },
];

export default hotelData