import React from "react";
import StarRatings from "react-star-ratings";

function StarComponent(props) {
  return <StarRatings rating={props.rating} starDimension="40px" starSpacing="15px" />;
}

export default StarComponent;
