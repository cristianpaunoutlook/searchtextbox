import React from "react";
import StarComponent from "../StarComponent";
import "./HotelCard.css";

function HotelCard(props) {
  const style = { backgroundImage: `url(${props.hotel.image})` };
  return (
    <div className="wrapper">
      <h1>{props.hotel.country}</h1>
      <div style={style} className="image"></div>
      <div className="details">
        <h1>
          <em>{props.hotel.location}</em>
        </h1>
        <h2>{props.hotel.name}</h2>
      </div>
      <h1>{props.hotel.price}€</h1>
      <div><StarComponent rating={props.hotel.rating}/></div>
    </div>
  );
}

export default HotelCard;
