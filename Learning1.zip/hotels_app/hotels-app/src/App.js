import logo from "./logo.svg";
import "./App.css";
import Header from "./components/Header";
import HotelCard from "./components/HotelCard";
import React from "react";

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      hotels: [],
      country: "",
    };
  }

  componentDidMount() {
    fetch("https://run.mocky.io/v3/1eb85d04-176c-4447-b310-23a799bb3c24")
      .then((response) => response.json())
      .then((response) => {
        const { hotels } = response.data;
        this.setState({ hotels: hotels });
      });
  }

  handleChange = (event) => {
    const { name, value } = event.target;
    this.setState({
      country: value,
    });
  };

  render() {
    let hotelComponents = this.state.hotels
      .filter(
        (f) =>
          f.country.toLowerCase().includes(this.state.country) ||
          this.state.country === ""
      )
      .map((hotel) => <HotelCard key={hotel.id} hotel={hotel} />);
    console.log(hotelComponents);
    return (
      <div className="App">
        <Header />
        <div>
          <label>Country</label>
          <input
            type="text"
            name="country"
            value={this.state.country}
            placeholder="Country"
            onChange={this.handleChange}
          ></input>
        </div>
        <br />
        <div>{hotelComponents}</div>
      </div>
    );
  }
}

export default App;
